<?php
/**
 * Chess Heaven - Contact Page
 * Complete contact page with contact form, location, and support information
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']); // Fixed: added missing closing parenthesis

// Handle form submission
$formSubmitted = false;
$formError = '';
$formSuccess = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_contact'])) {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $category = $_POST['category'] ?? 'general';
    
    // Validate
    if (empty($name) || empty($email) || empty($subject) || empty($message)) {
        $formError = 'Please fill in all required fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $formError = 'Please enter a valid email address.';
    } elseif (strlen($message) < 10) {
        $formError = 'Your message must be at least 10 characters long.';
    } else {
        // Save to database or send email
        $formSuccess = 'Thank you for your message! We will get back to you within 24 hours.';
        $formSubmitted = true;
        
        // You can add email sending logic here
        // mail($email, $subject, $message);
    }
}

// Get contact data
$contactInfo = getContactInfo();
$supportHours = getSupportHours();
$socialLinks = getSocialLinks();
$faqItems = getFAQItems(4);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Contact Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }

        /* ===== HERO ===== */
        .contact-hero {
            text-align:center;
            padding:3rem 2rem;
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem;
            border:1px solid var(--border-color);
            margin:2rem;
        }
        .contact-hero h1 {
            font-size:2.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:1rem;
        }
        .contact-hero p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
        }

        /* ===== CONTACT FORM ===== */
        .contact-grid {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
        }
        .contact-form {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
        }
        .contact-form .form-group {
            margin-bottom:1.2rem;
        }
        .contact-form label {
            display:block;
            color:#f0d6b0;
            font-weight:500;
            margin-bottom:0.3rem;
            font-size:0.9rem;
        }
        .contact-form label .required {
            color:var(--danger);
        }
        .contact-form input,
        .contact-form select,
        .contact-form textarea {
            width:100%;
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-size:0.9rem;
            transition:all 0.3s;
        }
        .contact-form input:focus,
        .contact-form select:focus,
        .contact-form textarea:focus {
            outline:none;
            border-color:var(--secondary);
            background:rgba(255,255,255,0.08);
        }
        .contact-form select option {
            background:#1a0a0a;
            color:#f0e0d0;
        }
        .contact-form textarea {
            min-height:120px;
            resize:vertical;
        }
        .contact-form .btn-submit {
            padding:0.8rem 2.5rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.95rem;
            width:100%;
        }
        .contact-form .btn-submit:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.5);
        }
        .contact-form .btn-submit:disabled {
            opacity:0.6;
            cursor:not-allowed;
            transform:none;
        }
        .contact-form .form-error {
            color:var(--danger);
            font-size:0.85rem;
            margin-top:0.3rem;
            display:none;
        }
        .contact-form .form-success {
            color:var(--success);
            font-size:0.95rem;
            padding:1rem;
            background:rgba(46,204,113,0.1);
            border:1px solid var(--success);
            border-radius:0.8rem;
            margin-bottom:1rem;
            display:none;
        }
        .contact-form .form-success.show,
        .contact-form .form-error.show {
            display:block;
        }

        /* ===== CONTACT INFO ===== */
        .contact-info {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .info-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            transition:all 0.3s;
        }
        .info-card:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-3px);
        }
        .info-card .info-header {
            display:flex;
            align-items:center;
            gap:1rem;
            margin-bottom:0.5rem;
        }
        .info-card .info-header i {
            font-size:1.8rem;
            color:var(--secondary);
            width:40px;
            text-align:center;
        }
        .info-card .info-header h3 {
            color:#f0d6b0;
            font-size:1.1rem;
        }
        .info-card p {
            color:#a09080;
            line-height:1.6;
            padding-left:3.5rem;
        }
        .info-card .info-detail {
            color:#d4c0b0;
            padding-left:3.5rem;
            font-weight:500;
        }

        /* ===== SOCIAL LINKS ===== */
        .social-links-big {
            display:flex;
            gap:1.5rem;
            justify-content:center;
            flex-wrap:wrap;
            margin-top:1rem;
        }
        .social-links-big a {
            display:flex;
            flex-direction:column;
            align-items:center;
            gap:0.3rem;
            color:#7a6a5a;
            font-size:2rem;
            transition:all 0.3s;
            padding:0.5rem 1rem;
            border-radius:1rem;
            background:var(--card-bg);
            border:1px solid var(--border-color);
            min-width:80px;
        }
        .social-links-big a:hover {
            color:var(--secondary);
            transform:translateY(-5px);
            border-color:var(--secondary);
            background:rgba(198,151,107,0.1);
        }
        .social-links-big a span {
            font-size:0.7rem;
            color:#7a6a5a;
        }

        /* ===== MAP ===== */
        .map-container {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            overflow:hidden;
        }
        .map-container .map-placeholder {
            background:rgba(0,0,0,0.3);
            padding:3rem;
            text-align:center;
        }
        .map-container .map-placeholder i {
            font-size:4rem;
            color:var(--secondary);
            opacity:0.3;
        }
        .map-container .map-placeholder p {
            color:#7a6a5a;
            margin-top:0.5rem;
        }

        /* ===== FAQ ===== */
        .faq-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            margin-bottom:0.8rem;
            cursor:pointer;
            transition:all 0.3s;
        }
        .faq-item:hover { border-color:var(--secondary); }
        .faq-item .faq-question {
            display:flex;
            justify-content:space-between;
            align-items:center;
            color:#f0d6b0;
            font-weight:600;
        }
        .faq-item .faq-answer {
            color:#a09080;
            margin-top:0.8rem;
            display:none;
            line-height:1.6;
        }
        .faq-item.active .faq-answer { display:block; }
        .faq-item .faq-toggle { color:var(--secondary); transition:0.3s; }
        .faq-item.active .faq-toggle { transform:rotate(180deg); }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .contact-grid {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .contact-hero { margin:1rem; padding:2rem 1rem; }
            .contact-hero h1 { font-size:2rem; flex-direction:column; }
            .contact-form { padding:1.5rem; }
            .info-card .info-detail,
            .info-card p { padding-left:0; }
            .info-card .info-header { flex-direction:column; text-align:center; }
            .social-links-big a { min-width:60px; font-size:1.5rem; padding:0.5rem; }
        }
        @media (max-width:480px) {
            .section-header h2 { font-size:1.3rem; }
            .contact-hero h1 { font-size:1.5rem; }
            .social-links-big { gap:0.8rem; }
            .social-links-big a { min-width:50px; font-size:1.2rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php" class="active-link"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <div class="contact-hero">
        <h1>
            <i class="fas fa-envelope"></i>
            Contact Us
            <i class="fas fa-chess"></i>
        </h1>
        <p>Have questions, feedback, or want to get involved? We'd love to hear from you! Reach out to us and we'll get back to you as soon as possible.</p>
    </div>

    <!-- ===== CONTACT SECTION ===== -->
    <section class="section" style="padding-top:0;">
        <div class="contact-grid">
            <!-- Contact Form -->
            <div class="contact-form">
                <h2 style="color:#f0d6b0;font-size:1.5rem;margin-bottom:1.5rem;">
                    <i class="fas fa-paper-plane" style="color:var(--secondary);"></i> Send Us a Message
                </h2>
                
                <?php if ($formSuccess): ?>
                    <div class="form-success show">
                        <i class="fas fa-check-circle"></i> <?php echo e($formSuccess); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($formError): ?>
                    <div class="form-error show">
                        <i class="fas fa-exclamation-circle"></i> <?php echo e($formError); ?>
                    </div>
                <?php endif; ?>

                <form method="POST" action="" id="contactForm" onsubmit="return validateForm()">
                    <div class="form-group">
                        <label for="name">Your Name <span class="required">*</span></label>
                        <input type="text" id="name" name="name" placeholder="Enter your full name" value="<?php echo isset($_POST['name']) ? e($_POST['name']) : ''; ?>" required />
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address <span class="required">*</span></label>
                        <input type="email" id="email" name="email" placeholder="Enter your email address" value="<?php echo isset($_POST['email']) ? e($_POST['email']) : ''; ?>" required />
                    </div>
                    
                    <div class="form-group">
                        <label for="category">Subject Category <span class="required">*</span></label>
                        <select id="category" name="category" required>
                            <option value="">Select a category...</option>
                            <option value="general" <?php echo (isset($_POST['category']) && $_POST['category'] === 'general') ? 'selected' : ''; ?>>General Inquiry</option>
                            <option value="support" <?php echo (isset($_POST['category']) && $_POST['category'] === 'support') ? 'selected' : ''; ?>>Technical Support</option>
                            <option value="volunteer" <?php echo (isset($_POST['category']) && $_POST['category'] === 'volunteer') ? 'selected' : ''; ?>>Volunteer Opportunities</option>
                            <option value="donation" <?php echo (isset($_POST['category']) && $_POST['category'] === 'donation') ? 'selected' : ''; ?>>Donations & Sponsorship</option>
                            <option value="partnership" <?php echo (isset($_POST['category']) && $_POST['category'] === 'partnership') ? 'selected' : ''; ?>>Partnerships</option>
                            <option value="feedback" <?php echo (isset($_POST['category']) && $_POST['category'] === 'feedback') ? 'selected' : ''; ?>>Feedback & Suggestions</option>
                            <option value="press" <?php echo (isset($_POST['category']) && $_POST['category'] === 'press') ? 'selected' : ''; ?>>Press & Media</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="subject">Subject <span class="required">*</span></label>
                        <input type="text" id="subject" name="subject" placeholder="Brief subject line" value="<?php echo isset($_POST['subject']) ? e($_POST['subject']) : ''; ?>" required />
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Your Message <span class="required">*</span></label>
                        <textarea id="message" name="message" placeholder="Write your message here..." required><?php echo isset($_POST['message']) ? e($_POST['message']) : ''; ?></textarea>
                    </div>
                    
                    <button type="submit" name="submit_contact" class="btn-submit">
                        <i class="fas fa-paper-plane"></i> Send Message
                    </button>
                </form>
            </div>

            <!-- Contact Information -->
            <div class="contact-info">
                <div class="info-card">
                    <div class="info-header">
                        <i class="fas fa-map-marker-alt"></i>
                        <h3>Our Location</h3>
                    </div>
                    <p><?php echo e($contactInfo['address'] ?? '123 Chess Lane, New York, NY 10001, USA'); ?></p>
                </div>

                <div class="info-card">
                    <div class="info-header">
                        <i class="fas fa-envelope"></i>
                        <h3>Email Us</h3>
                    </div>
                    <div class="info-detail">
                        <a href="mailto:<?php echo e($contactInfo['email'] ?? 'contact@chessheaven.org'); ?>" style="color:var(--secondary);">
                            <?php echo e($contactInfo['email'] ?? 'contact@chessheaven.org'); ?>
                        </a>
                    </div>
                    <p style="margin-top:0.3rem;">We'll respond within 24 hours</p>
                </div>

                <div class="info-card">
                    <div class="info-header">
                        <i class="fas fa-phone"></i>
                        <h3>Call Us</h3>
                    </div>
                    <div class="info-detail"><?php echo e($contactInfo['phone'] ?? '+1 (555) 123-4567'); ?></div>
                    <p style="margin-top:0.3rem;">Available during support hours</p>
                </div>

                <div class="info-card">
                    <div class="info-header">
                        <i class="fas fa-clock"></i>
                        <h3>Support Hours</h3>
                    </div>
                    <?php if (!empty($supportHours)): ?>
                        <?php foreach ($supportHours as $hours): ?>
                            <p><strong><?php echo e($hours['day']); ?>:</strong> <?php echo e($hours['hours']); ?></p>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p><strong>Monday - Friday:</strong> 9:00 AM - 6:00 PM EST</p>
                        <p><strong>Saturday:</strong> 10:00 AM - 4:00 PM EST</p>
                        <p><strong>Sunday:</strong> Closed</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== SOCIAL LINKS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-share-alt"></i> Connect With Us</h2>
        </div>
        <div class="social-links-big">
            <?php if (!empty($socialLinks)): ?>
                <?php foreach ($socialLinks as $social): ?>
                    <a href="<?php echo e($social['url']); ?>" target="_blank">
                        <i class="fab fa-<?php echo e($social['icon']); ?>"></i>
                        <span><?php echo e($social['name']); ?></span>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="#" target="_blank">
                    <i class="fab fa-twitter"></i>
                    <span>Twitter</span>
                </a>
                <a href="#" target="_blank">
                    <i class="fab fa-youtube"></i>
                    <span>YouTube</span>
                </a>
                <a href="#" target="_blank">
                    <i class="fab fa-discord"></i>
                    <span>Discord</span>
                </a>
                <a href="#" target="_blank">
                    <i class="fab fa-instagram"></i>
                    <span>Instagram</span>
                </a>
                <a href="#" target="_blank">
                    <i class="fab fa-facebook"></i>
                    <span>Facebook</span>
                </a>
                <a href="#" target="_blank">
                    <i class="fab fa-tiktok"></i>
                    <span>TikTok</span>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== MAP ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-map"></i> Find Us</h2>
        </div>
        <div class="map-container">
            <div class="map-placeholder">
                <i class="fas fa-map-marked-alt"></i>
                <p><?php echo e($contactInfo['address'] ?? '123 Chess Lane, New York, NY 10001, USA'); ?></p>
                <p style="font-size:0.8rem;color:#7a6a5a;margin-top:0.3rem;">
                    <i class="fas fa-info-circle"></i> Interactive map coming soon
                </p>
            </div>
        </div>
    </section>

    <!-- ===== FAQ ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-question-circle"></i> Frequently Asked Questions</h2>
            <a href="faq.php" class="view-all">All FAQs <i class="fas fa-arrow-right"></i></a>
        </div>
        <?php if (!empty($faqItems)): ?>
            <?php foreach ($faqItems as $index => $faq): ?>
                <div class="faq-item <?php echo $index === 0 ? 'active' : ''; ?>" onclick="toggleFAQ(this)">
                    <div class="faq-question">
                        <span><?php echo e($faq['question']); ?></span>
                        <i class="fas fa-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer"><?php echo e($faq['answer']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="faq-item active" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>How quickly will I get a response?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">We typically respond to all inquiries within 24 hours during business days. For urgent matters, please call us directly.</div>
            </div>
            <div class="faq-item" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>Can I volunteer with Chess Heaven?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">Absolutely! We're always looking for passionate volunteers. Please select "Volunteer Opportunities" in the category dropdown and tell us about your skills and interests.</div>
            </div>
            <div class="faq-item" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>How can I donate to support Chess Heaven?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">You can make a donation through our secure online portal. Select "Donations & Sponsorship" in the category dropdown and we'll send you more information.</div>
            </div>
            <div class="faq-item" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>Do you offer chess programs in my area?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">We have programs in many locations worldwide. Please contact us with your location and we'll let you know about programs near you.</div>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:var(--card-bg);border-radius:1.5rem;padding:2rem;border:1px solid var(--border-color);text-align:center;">
            <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--secondary);"></i>
            <h3 style="color:#f0d6b0;margin:0.5rem 0;">Before You Contact Us</h3>
            <p style="color:#a09080;max-width:600px;margin:0 auto;">
                <i class="fas fa-chess-pawn"></i> Check our <a href="faq.php" style="color:var(--secondary);">FAQ page</a> for quick answers to common questions.
                <br>
                <span style="color:var(--secondary);font-size:0.85rem;">We're here to help you with any questions or concerns.</span>
            </p>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // FAQ toggle
        function toggleFAQ(element) {
            element.classList.toggle('active');
        }

        // Form validation
        function validateForm() {
            const name = document.getElementById('name').value.trim();
            const email = document.getElementById('email').value.trim();
            const subject = document.getElementById('subject').value.trim();
            const message = document.getElementById('message').value.trim();
            const category = document.getElementById('category').value;

            // Clear previous errors
            document.querySelectorAll('.form-error').forEach(el => el.style.display = 'none');

            if (!name) {
                showError('Please enter your name.');
                return false;
            }
            if (!email) {
                showError('Please enter your email address.');
                return false;
            }
            if (!email.includes('@') || !email.includes('.')) {
                showError('Please enter a valid email address.');
                return false;
            }
            if (!category) {
                showError('Please select a category.');
                return false;
            }
            if (!subject) {
                showError('Please enter a subject.');
                return false;
            }
            if (!message || message.length < 10) {
                showError('Please enter a message (at least 10 characters).');
                return false;
            }

            return true;
        }

        function showError(message) {
            const errorDiv = document.querySelector('.form-error');
            errorDiv.innerHTML = '<i class="fas fa-exclamation-circle"></i> ' + message;
            errorDiv.style.display = 'block';
            errorDiv.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        // Auto-hide success/error messages after 5 seconds
        setTimeout(function() {
            const success = document.querySelector('.form-success');
            const error = document.querySelector('.form-error');
            if (success && success.classList.contains('show')) {
                setTimeout(function() {
                    success.style.display = 'none';
                }, 5000);
            }
            if (error && error.classList.contains('show')) {
                setTimeout(function() {
                    error.style.display = 'none';
                }, 5000);
            }
        }, 100);
    </script>
</body>
</html>