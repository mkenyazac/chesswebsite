<?php
/**
 * Chess Heaven - Register Page
 * Complete registration page with form validation and account creation
 */

require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');

// Handle registration form submission
$registerError = '';
$registerSuccess = '';
$formData = [
    'username' => '',
    'email' => '',
    'first_name' => '',
    'last_name' => '',
    'agree_terms' => false
];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    // Get form data
    $formData['username'] = trim($_POST['username'] ?? '');
    $formData['email'] = trim($_POST['email'] ?? '');
    $formData['first_name'] = trim($_POST['first_name'] ?? '');
    $formData['last_name'] = trim($_POST['last_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $password_confirm = $_POST['password_confirm'] ?? '';
    $formData['agree_terms'] = isset($_POST['agree_terms']);
    
    // Validate
    $errors = [];
    
    if (empty($formData['username'])) {
        $errors[] = 'Please choose a username.';
    } elseif (strlen($formData['username']) < 3) {
        $errors[] = 'Username must be at least 3 characters long.';
    } elseif (strlen($formData['username']) > 30) {
        $errors[] = 'Username must be less than 30 characters.';
    } elseif (!preg_match('/^[a-zA-Z0-9_]+$/', $formData['username'])) {
        $errors[] = 'Username can only contain letters, numbers, and underscores.';
    }
    
    if (empty($formData['email'])) {
        $errors[] = 'Please enter your email address.';
    } elseif (!filter_var($formData['email'], FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }
    
    if (empty($password)) {
        $errors[] = 'Please enter a password.';
    } elseif (strlen($password) < 6) {
        $errors[] = 'Password must be at least 6 characters long.';
    } elseif ($password !== $password_confirm) {
        $errors[] = 'Passwords do not match.';
    }
    
    if (!$formData['agree_terms']) {
        $errors[] = 'You must agree to the Terms and Conditions.';
    }
    
    // Check if username exists
    if (empty($errors) && usernameExists($formData['username'])) {
        $errors[] = 'Username is already taken. Please choose another.';
    }
    
    // Check if email exists
    if (empty($errors) && emailExists($formData['email'])) {
        $errors[] = 'Email address is already registered. Please login or use a different email.';
    }
    
    // If no errors, create account
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $userId = createUser($formData['username'], $formData['email'], $hashedPassword, $formData['first_name'], $formData['last_name']);
        
        if ($userId) {
            $registerSuccess = 'Your account has been created successfully! You can now login.';
            $formData = [
                'username' => '',
                'email' => '',
                'first_name' => '',
                'last_name' => '',
                'agree_terms' => false
            ];
            
            // Auto-login after registration
            $_SESSION['user_id'] = $userId;
            $_SESSION['username'] = $formData['username'];
            $_SESSION['user_email'] = $formData['email'];
            
            // Redirect to welcome page or dashboard
            header('Location: welcome.php');
            exit;
        } else {
            $registerError = 'There was an error creating your account. Please try again.';
        }
    } else {
        $registerError = implode('<br>', $errors);
    }
}

// Get registration benefits
$registrationBenefits = getRegistrationBenefits();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Register</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== REGISTER CONTAINER ===== */
        .register-container {
            min-height:calc(100vh - var(--nav-height) - 200px);
            display:flex;
            align-items:center;
            justify-content:center;
            padding:2rem;
        }
        .register-box {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2.5rem;
            max-width:520px;
            width:100%;
            backdrop-filter:blur(8px);
        }
        .register-box .register-header {
            text-align:center;
            margin-bottom:2rem;
        }
        .register-box .register-header .register-icon {
            font-size:3rem;
            color:var(--secondary);
            margin-bottom:0.5rem;
        }
        .register-box .register-header h1 {
            color:#f0d6b0;
            font-size:1.8rem;
        }
        .register-box .register-header p {
            color:#a09080;
            font-size:0.9rem;
            margin-top:0.3rem;
        }

        /* ===== FORM ===== */
        .register-box .form-group {
            margin-bottom:1.2rem;
        }
        .register-box label {
            display:block;
            color:#f0d6b0;
            font-weight:500;
            margin-bottom:0.3rem;
            font-size:0.9rem;
        }
        .register-box label .required {
            color:var(--danger);
        }
        .register-box .input-group {
            position:relative;
        }
        .register-box .input-group i {
            position:absolute;
            left:1rem;
            top:50%;
            transform:translateY(-50%);
            color:#7a6a5a;
        }
        .register-box .input-group input {
            width:100%;
            padding:0.8rem 1rem 0.8rem 2.8rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-size:0.9rem;
            transition:all 0.3s;
        }
        .register-box .input-group input:focus {
            outline:none;
            border-color:var(--secondary);
            background:rgba(255,255,255,0.08);
        }
        .register-box .input-group input::placeholder {
            color:#5a4a3a;
        }
        .register-box .input-group .password-toggle {
            position:absolute;
            right:1rem;
            top:50%;
            transform:translateY(-50%);
            color:#7a6a5a;
            cursor:pointer;
            transition:0.3s;
            background:none;
            border:none;
            font-size:1rem;
        }
        .register-box .input-group .password-toggle:hover {
            color:var(--secondary);
        }

        .register-box .form-row {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:1rem;
        }

        .register-box .form-check {
            display:flex;
            align-items:flex-start;
            gap:0.8rem;
            margin:1rem 0;
        }
        .register-box .form-check input[type="checkbox"] {
            accent-color:var(--secondary);
            width:18px;
            height:18px;
            margin-top:2px;
            cursor:pointer;
            flex-shrink:0;
        }
        .register-box .form-check label {
            color:#a09080;
            font-weight:400;
            font-size:0.85rem;
            cursor:pointer;
            margin-bottom:0;
        }
        .register-box .form-check label a {
            color:var(--secondary);
            font-weight:500;
        }
        .register-box .form-check label a:hover {
            color:#f0d6b0;
        }

        .register-box .password-strength {
            margin-top:0.3rem;
            display:flex;
            gap:0.3rem;
        }
        .register-box .password-strength .strength-bar {
            flex:1;
            height:3px;
            background:var(--border-color);
            border-radius:2px;
            transition:all 0.3s;
        }
        .register-box .password-strength .strength-bar.active.weak { background:var(--danger); }
        .register-box .password-strength .strength-bar.active.medium { background:var(--warning); }
        .register-box .password-strength .strength-bar.active.strong { background:var(--success); }
        .register-box .password-strength-text {
            font-size:0.7rem;
            color:#7a6a5a;
            margin-top:0.2rem;
        }

        .register-box .btn-register {
            width:100%;
            padding:0.8rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            font-size:1rem;
            cursor:pointer;
            transition:all 0.3s;
        }
        .register-box .btn-register:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.5);
        }
        .register-box .btn-register:disabled {
            opacity:0.6;
            cursor:not-allowed;
            transform:none;
        }

        .register-box .divider {
            display:flex;
            align-items:center;
            gap:1rem;
            margin:1.5rem 0;
            color:#7a6a5a;
            font-size:0.85rem;
        }
        .register-box .divider::before,
        .register-box .divider::after {
            content:'';
            flex:1;
            height:1px;
            background:var(--border-color);
        }

        .register-box .social-register {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:0.8rem;
        }
        .register-box .social-register button {
            padding:0.6rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-weight:500;
            cursor:pointer;
            transition:all 0.3s;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:0.5rem;
            font-size:0.85rem;
        }
        .register-box .social-register button:hover {
            background:rgba(255,255,255,0.1);
            border-color:var(--secondary);
            transform:translateY(-2px);
        }
        .register-box .social-register button i {
            font-size:1.2rem;
        }
        .register-box .social-register .btn-google i { color:#ea4335; }
        .register-box .social-register .btn-facebook i { color:#1877f2; }
        .register-box .social-register .btn-twitter i { color:#1da1f2; }
        .register-box .social-register .btn-github i { color:#6e5494; }

        .register-box .login-link {
            text-align:center;
            margin-top:1.5rem;
            color:#a09080;
            font-size:0.9rem;
        }
        .register-box .login-link a {
            color:var(--secondary);
            font-weight:600;
            transition:0.3s;
        }
        .register-box .login-link a:hover {
            color:#f0d6b0;
        }

        /* ===== ERROR/SUCCESS MESSAGES ===== */
        .register-box .message {
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            margin-bottom:1rem;
            font-size:0.9rem;
        }
        .register-box .message.error {
            background:rgba(231,76,60,0.15);
            border:1px solid var(--danger);
            color:var(--danger);
        }
        .register-box .message.success {
            background:rgba(46,204,113,0.15);
            border:1px solid var(--success);
            color:var(--success);
        }
        .register-box .message i {
            margin-right:0.5rem;
        }

        /* ===== BENEFITS ===== */
        .benefits-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
            gap:1rem;
            max-width:900px;
            margin:2rem auto 0;
        }
        .benefits-grid .benefit-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1rem;
            text-align:center;
            transition:all 0.3s;
        }
        .benefits-grid .benefit-item:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-3px);
        }
        .benefits-grid .benefit-item i {
            font-size:1.5rem;
            color:var(--secondary);
            margin-bottom:0.3rem;
        }
        .benefits-grid .benefit-item h4 {
            color:#f0d6b0;
            font-size:0.85rem;
        }
        .benefits-grid .benefit-item p {
            color:#7a6a5a;
            font-size:0.75rem;
            margin-top:0.2rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .register-container { padding:1rem; }
            .register-box { padding:1.5rem; }
            .register-box .register-header h1 { font-size:1.5rem; }
            .register-box .form-row { grid-template-columns:1fr; }
            .register-box .social-register { grid-template-columns:1fr; }
            .benefits-grid { grid-template-columns:1fr 1fr; }
        }
        @media (max-width:480px) {
            .register-box { padding:1.2rem; }
            .register-box .register-header .register-icon { font-size:2.5rem; }
            .register-box .register-header h1 { font-size:1.3rem; }
            .benefits-grid { grid-template-columns:1fr; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup active-link"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== REGISTER ===== -->
    <div class="register-container">
        <div class="register-box">
            <div class="register-header">
                <div class="register-icon"><i class="fas fa-chess-king"></i></div>
                <h1>Create Account</h1>
                <p>Join Chess Heaven and start your chess journey</p>
            </div>

            <?php if ($registerError): ?>
                <div class="message error">
                    <i class="fas fa-exclamation-circle"></i> <?php echo $registerError; ?>
                </div>
            <?php endif; ?>

            <?php if ($registerSuccess): ?>
                <div class="message success">
                    <i class="fas fa-check-circle"></i> <?php echo e($registerSuccess); ?>
                </div>
            <?php endif; ?>

            <!-- Registration Form -->
            <form method="POST" action="" id="registerForm" onsubmit="return validateRegister()">
                <div class="form-group">
                    <label for="username">Username <span class="required">*</span></label>
                    <div class="input-group">
                        <i class="fas fa-user"></i>
                        <input type="text" id="username" name="username" placeholder="Choose a username" value="<?php echo e($formData['username']); ?>" required />
                    </div>
                    <div style="font-size:0.75rem;color:#7a6a5a;margin-top:0.2rem;">
                        Letters, numbers, and underscores only. 3-30 characters.
                    </div>
                </div>

                <div class="form-group">
                    <label for="email">Email Address <span class="required">*</span></label>
                    <div class="input-group">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" placeholder="Enter your email" value="<?php echo e($formData['email']); ?>" required />
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="first_name">First Name</label>
                        <div class="input-group">
                            <i class="fas fa-user"></i>
                            <input type="text" id="first_name" name="first_name" placeholder="First name" value="<?php echo e($formData['first_name']); ?>" />
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="last_name">Last Name</label>
                        <div class="input-group">
                            <i class="fas fa-user"></i>
                            <input type="text" id="last_name" name="last_name" placeholder="Last name" value="<?php echo e($formData['last_name']); ?>" />
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="password">Password <span class="required">*</span></label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password" name="password" placeholder="Create a password" required onkeyup="checkPasswordStrength(this.value)" />
                        <button type="button" class="password-toggle" onclick="togglePassword()">
                            <i class="fas fa-eye" id="passwordIcon"></i>
                        </button>
                    </div>
                    <div class="password-strength" id="passwordStrength">
                        <span class="strength-bar"></span>
                        <span class="strength-bar"></span>
                        <span class="strength-bar"></span>
                        <span class="strength-bar"></span>
                    </div>
                    <div class="password-strength-text" id="strengthText">Password must be at least 6 characters</div>
                </div>

                <div class="form-group">
                    <label for="password_confirm">Confirm Password <span class="required">*</span></label>
                    <div class="input-group">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="password_confirm" name="password_confirm" placeholder="Confirm your password" required />
                    </div>
                </div>

                <div class="form-check">
                    <input type="checkbox" id="agree_terms" name="agree_terms" <?php echo $formData['agree_terms'] ? 'checked' : ''; ?> required />
                    <label for="agree_terms">
                        I agree to the <a href="terms.php">Terms and Conditions</a> and <a href="privacy.php">Privacy Policy</a> <span class="required">*</span>
                    </label>
                </div>

                <button type="submit" name="register" class="btn-register">
                    <i class="fas fa-user-plus"></i> Create Account
                </button>
            </form>

            <!-- Divider -->
            <div class="divider">or sign up with</div>

            <!-- Social Register -->
            <div class="social-register">
                <button type="button" class="btn-google" onclick="socialRegister('google')">
                    <i class="fab fa-google"></i> Google
                </button>
                <button type="button" class="btn-facebook" onclick="socialRegister('facebook')">
                    <i class="fab fa-facebook"></i> Facebook
                </button>
                <button type="button" class="btn-twitter" onclick="socialRegister('twitter')">
                    <i class="fab fa-twitter"></i> Twitter
                </button>
                <button type="button" class="btn-github" onclick="socialRegister('github')">
                    <i class="fab fa-github"></i> GitHub
                </button>
            </div>

            <!-- Login Link -->
            <div class="login-link">
                Already have an account? <a href="login.php">Sign In</a>
            </div>
        </div>
    </div>

    <!-- ===== REGISTRATION BENEFITS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="benefits-grid">
            <?php if (!empty($registrationBenefits)): ?>
                <?php foreach ($registrationBenefits as $benefit): ?>
                    <div class="benefit-item">
                        <i class="fas fa-<?php echo e($benefit['icon'] ?? 'star'); ?>"></i>
                        <h4><?php echo e($benefit['title']); ?></h4>
                        <p><?php echo e($benefit['description']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="benefit-item">
                    <i class="fas fa-chess-board"></i>
                    <h4>Free Lessons</h4>
                    <p>Access all chess lessons and tutorials</p>
                </div>
                <div class="benefit-item">
                    <i class="fas fa-trophy"></i>
                    <h4>Tournaments</h4>
                    <p>Join live tournaments and compete</p>
                </div>
                <div class="benefit-item">
                    <i class="fas fa-puzzle-piece"></i>
                    <h4>Daily Puzzles</h4>
                    <p>Solve puzzles and improve tactics</p>
                </div>
                <div class="benefit-item">
                    <i class="fas fa-users"></i>
                    <h4>Community</h4>
                    <p>Connect with other chess players</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // Toggle password visibility
        function togglePassword() {
            const passwordInput = document.getElementById('password');
            const icon = document.getElementById('passwordIcon');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }

        // Password strength checker
        function checkPasswordStrength(password) {
            const bars = document.querySelectorAll('.strength-bar');
            const text = document.getElementById('strengthText');
            let strength = 0;
            
            // Reset bars
            bars.forEach(bar => {
                bar.className = 'strength-bar';
            });
            
            if (password.length === 0) {
                text.textContent = 'Password must be at least 6 characters';
                return;
            }
            
            // Check length
            if (password.length >= 6) strength++;
            if (password.length >= 10) strength++;
            
            // Check for numbers
            if (/\d/.test(password)) strength++;
            
            // Check for special characters
            if (/[!@#$%^&*(),.?":{}|<>]/.test(password)) strength++;
            
            // Check for uppercase and lowercase
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            
            // Determine strength
            let level = 'weak';
            let message = '';
            
            if (strength <= 2) {
                level = 'weak';
                message = 'Weak password - add more characters, numbers, and special characters';
            } else if (strength <= 4) {
                level = 'medium';
                message = 'Medium password - good, but could be stronger';
            } else {
                level = 'strong';
                message = 'Strong password - great job!';
            }
            
            // Update bars
            const activeBars = Math.min(strength, 4);
            bars.forEach((bar, index) => {
                if (index < activeBars) {
                    bar.className = 'strength-bar active ' + level;
                }
            });
            
            text.textContent = message;
            text.style.color = level === 'weak' ? 'var(--danger)' : (level === 'medium' ? 'var(--warning)' : 'var(--success)');
        }

        // Social register
        function socialRegister(provider) {
            alert('You are being redirected to ' + provider.charAt(0).toUpperCase() + provider.slice(1) + ' for registration.');
            // In production, redirect to OAuth endpoint
            // window.location.href = 'auth.php?provider=' + provider + '&action=register';
        }

        // Form validation
        function validateRegister() {
            const username = document.getElementById('username').value.trim();
            const email = document.getElementById('email').value.trim();
            const password = document.getElementById('password').value;
            const passwordConfirm = document.getElementById('password_confirm').value;
            const agreeTerms = document.getElementById('agree_terms').checked;

            // Username validation
            if (!username) {
                alert('Please choose a username.');
                return false;
            }
            if (username.length < 3) {
                alert('Username must be at least 3 characters long.');
                return false;
            }
            if (username.length > 30) {
                alert('Username must be less than 30 characters.');
                return false;
            }
            if (!/^[a-zA-Z0-9_]+$/.test(username)) {
                alert('Username can only contain letters, numbers, and underscores.');
                return false;
            }

            // Email validation
            if (!email) {
                alert('Please enter your email address.');
                return false;
            }
            if (!email.includes('@') || !email.includes('.')) {
                alert('Please enter a valid email address.');
                return false;
            }

            // Password validation
            if (!password) {
                alert('Please enter a password.');
                return false;
            }
            if (password.length < 6) {
                alert('Password must be at least 6 characters long.');
                return false;
            }
            if (password !== passwordConfirm) {
                alert('Passwords do not match.');
                return false;
            }

            // Terms agreement
            if (!agreeTerms) {
                alert('You must agree to the Terms and Conditions.');
                return false;
            }

            return true;
        }

        // Real-time password match check
        document.getElementById('password_confirm').addEventListener('input', function() {
            const password = document.getElementById('password').value;
            const confirm = this.value;
            const text = document.getElementById('strengthText');
            
            if (confirm.length > 0 && password !== confirm) {
                text.textContent = 'Passwords do not match';
                text.style.color = 'var(--danger)';
            } else if (confirm.length > 0 && password === confirm) {
                text.textContent = 'Passwords match ✓';
                text.style.color = 'var(--success)';
            }
        });
    </script>
</body>
</html>