<?php
/**
 * Chess Heaven - Learn Page
 * Complete educational hub with interactive chess board for visual learning
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get learning data - using functions from config.php
$lessons = getLessons(12);
$categories = getLessonCategories();
$featuredLesson = getFeaturedLesson();
$learningPaths = getLearningPaths();
$videoTutorials = getVideoTutorials(6);
$chessBooks = getRecommendedBooks(4);
$practiceExercises = getPracticeExercises(6);
$achievements = getUserAchievements();
$progress = getLearningProgress();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Learn Chess</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
            position:relative;
            overflow:hidden;
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }
        .card .badge {
            position:absolute;
            top:1rem;
            right:1rem;
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .badge-beginner { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .badge-intermediate { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .badge-advanced { background:rgba(231,76,60,0.2); color:#e74c3c; }
        .badge-free { background:rgba(52,152,219,0.2); color:#3498db; }
        .badge-premium { background:rgba(198,151,107,0.2); color:#C6976B; }

        /* ===== HERO ===== */
        .learn-hero {
            text-align:center;
            padding:3rem 2rem;
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem;
            border:1px solid var(--border-color);
            margin:2rem;
        }
        .learn-hero h1 {
            font-size:2.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:1rem;
        }
        .learn-hero p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
        }
        .learn-hero .search-box {
            max-width:500px;
            margin:1.5rem auto;
            display:flex;
            gap:0.5rem;
        }
        .learn-hero .search-box input {
            flex:1;
            padding:0.8rem 1.2rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-size:0.9rem;
        }
        .learn-hero .search-box input:focus {
            outline:none;
            border-color:var(--secondary);
        }
        .learn-hero .search-box button {
            padding:0.8rem 1.5rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
        }
        .learn-hero .search-box button:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }

        /* ===== CATEGORY FILTERS ===== */
        .category-filters {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            justify-content:center;
            margin:1rem 0 2rem;
        }
        .category-filters button {
            padding:0.5rem 1.5rem;
            border-radius:2rem;
            border:2px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.85rem;
        }
        .category-filters button:hover,
        .category-filters button.active {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }

        /* ===== FEATURED LESSON ===== */
        .featured-lesson {
            background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));
            border-radius:2rem;
            padding:2rem;
            border:2px solid var(--gold);
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
            align-items:center;
            margin-bottom:2rem;
        }
        .featured-lesson .featured-content h2 {
            color:#f0d6b0;
            font-size:1.8rem;
            margin-bottom:0.5rem;
        }
        .featured-lesson .featured-content p {
            color:#a09080;
            line-height:1.8;
        }
        .featured-lesson .featured-content .lesson-meta {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            margin:1rem 0;
        }
        .featured-lesson .featured-content .lesson-meta span {
            color:var(--secondary);
            font-size:0.85rem;
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .featured-lesson .featured-image {
            text-align:center;
            padding:2rem;
        }
        .featured-lesson .featured-image i {
            font-size:6rem;
            color:var(--secondary);
            opacity:0.3;
        }
        .btn-start-lesson {
            display:inline-block;
            padding:0.8rem 2rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            margin-top:1rem;
        }
        .btn-start-lesson:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.5);
        }

        /* ===== INTERACTIVE LEARNING BOARD ===== */
        .learning-board-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.12),rgba(10,5,5,0.5));
            border-radius:2rem;
            padding:2rem;
            border:1px solid var(--border-color);
            margin-bottom:2rem;
        }
        .learning-board-container {
            display:grid;
            grid-template-columns:1.2fr 1fr;
            gap:2rem;
            align-items:start;
        }
        .board-wrapper {
            background:rgba(0,0,0,0.4);
            border-radius:1.5rem;
            padding:1.5rem;
            border:2px solid var(--border-color);
        }
        .board-wrapper .board-title {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:0.8rem;
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .board-wrapper .board-title .lesson-name {
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .board-wrapper .board-title .lesson-name i {
            color:var(--secondary);
        }
        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:500px;
            aspect-ratio:1;
            margin:0 auto;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
            transition:transform 0.3s ease;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.8rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
            position:relative;
        }
        .chess-board .square.light { background:var(--light-square); }
        .chess-board .square.dark { background:var(--dark-square); }
        .chess-board .square.highlight {
            background:rgba(255,255,0,0.4) !important;
            box-shadow:inset 0 0 20px rgba(255,255,0,0.3);
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
            pointer-events:none;
            z-index:1;
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }
        .chess-board .square .coords {
            position:absolute;
            font-size:0.55rem;
            color:rgba(0,0,0,0.3);
            pointer-events:none;
            font-weight:600;
        }
        .chess-board .square .coords.file { bottom:2px; right:4px; }
        .chess-board .square .coords.rank { top:2px; left:4px; }
        .chess-board .square.dark .coords { color:rgba(255,255,255,0.3); }

        .board-controls {
            display:flex;
            gap:0.6rem;
            flex-wrap:wrap;
            justify-content:center;
            margin-top:0.8rem;
            width:100%;
        }
        .board-controls button {
            padding:0.5rem 1rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.75rem;
            display:inline-flex;
            align-items:center;
            gap:0.4rem;
        }
        .btn-nav {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-nav:hover { background:rgba(198,151,107,0.25); }
        .btn-nav:disabled {
            opacity:0.3;
            cursor:not-allowed;
        }
        .btn-reset-board {
            background:rgba(255,255,255,0.05);
            color:#a09080;
            border:1px solid rgba(255,255,255,0.1) !important;
        }
        .btn-reset-board:hover { background:rgba(255,255,255,0.1); }
        .btn-flip-board {
            background:rgba(46,204,113,0.15);
            color:#2ecc71;
            border:1px solid #2ecc71 !important;
        }
        .btn-flip-board:hover { background:rgba(46,204,113,0.25); }

        /* ===== LESSON SIDEBAR ===== */
        .lesson-sidebar {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .lesson-panel {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
        }
        .lesson-panel h3 {
            color:#f0d6b0;
            font-size:1rem;
            margin-bottom:0.8rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .lesson-panel h3 i { color:var(--secondary); }
        .lesson-panel .lesson-content {
            color:#a09080;
            font-size:0.9rem;
            line-height:1.8;
        }
        .lesson-panel .lesson-content .highlight-text {
            color:var(--gold);
            font-weight:600;
        }
        .lesson-panel .lesson-content .example {
            background:rgba(0,0,0,0.2);
            padding:0.8rem;
            border-radius:0.5rem;
            margin:0.5rem 0;
            font-family:monospace;
            color:#f0d6b0;
            font-size:0.85rem;
        }
        .lesson-panel .key-points {
            list-style:none;
            margin:0.5rem 0;
        }
        .lesson-panel .key-points li {
            padding:0.3rem 0;
            padding-left:1.5rem;
            position:relative;
            color:#a09080;
            font-size:0.85rem;
        }
        .lesson-panel .key-points li::before {
            content:'✓';
            position:absolute;
            left:0;
            color:var(--secondary);
            font-weight:700;
        }

        .lesson-progress {
            background:rgba(0,0,0,0.2);
            border-radius:2rem;
            height:6px;
            overflow:hidden;
            margin:0.5rem 0;
        }
        .lesson-progress .progress-bar {
            height:100%;
            background:linear-gradient(90deg,var(--secondary),var(--gold));
            border-radius:2rem;
            transition:width 0.6s;
        }

        /* ===== VIDEO PLAYER ===== */
        .video-player-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.12),rgba(10,5,5,0.5));
            border-radius:2rem;
            padding:2rem;
            border:1px solid var(--border-color);
            margin-bottom:2rem;
        }
        .video-player-container {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:2rem;
            align-items:start;
        }
        .video-player-wrapper {
            background:rgba(0,0,0,0.6);
            border-radius:1.5rem;
            padding:1rem;
            border:2px solid var(--border-color);
            position:relative;
        }
        .video-player-wrapper video {
            width:100%;
            border-radius:1rem;
            background:#000;
            display:block;
        }
        .video-player-wrapper .video-overlay {
            position:absolute;
            top:0;
            left:0;
            right:0;
            bottom:0;
            display:flex;
            align-items:center;
            justify-content:center;
            background:rgba(0,0,0,0.4);
            border-radius:1.5rem;
            cursor:pointer;
            transition:all 0.3s;
            opacity:0;
        }
        .video-player-wrapper .video-overlay:hover {
            opacity:1;
        }
        .video-player-wrapper .video-overlay .play-btn-large {
            width:80px;
            height:80px;
            background:rgba(139,26,26,0.8);
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            color:white;
            font-size:2.5rem;
            transition:all 0.3s;
        }
        .video-player-wrapper .video-overlay .play-btn-large:hover {
            background:var(--primary);
            transform:scale(1.1);
        }

        .video-controls {
            display:flex;
            align-items:center;
            gap:1rem;
            padding:0.8rem 1rem;
            background:rgba(0,0,0,0.4);
            border-radius:1rem;
            margin-top:0.8rem;
            flex-wrap:wrap;
        }
        .video-controls button {
            background:transparent;
            border:none;
            color:#f0d6b0;
            font-size:1.2rem;
            cursor:pointer;
            transition:all 0.3s;
            padding:0.3rem 0.5rem;
        }
        .video-controls button:hover {
            color:var(--secondary);
            transform:scale(1.1);
        }
        .video-controls .progress-bar-container {
            flex:1;
            min-width:100px;
            height:6px;
            background:rgba(255,255,255,0.1);
            border-radius:3px;
            cursor:pointer;
            position:relative;
        }
        .video-controls .progress-bar-container .progress-fill {
            height:100%;
            background:linear-gradient(90deg,var(--secondary),var(--gold));
            border-radius:3px;
            width:0%;
            transition:width 0.1s;
        }
        .video-controls .time-display {
            color:#a09080;
            font-size:0.8rem;
            font-family:monospace;
            min-width:100px;
        }
        .video-controls .volume-control {
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .video-controls .volume-control input[type="range"] {
            width:80px;
            height:4px;
            -webkit-appearance:none;
            background:rgba(255,255,255,0.1);
            border-radius:2px;
            outline:none;
        }
        .video-controls .volume-control input[type="range"]::-webkit-slider-thumb {
            -webkit-appearance:none;
            width:12px;
            height:12px;
            border-radius:50%;
            background:var(--secondary);
            cursor:pointer;
        }

        .video-playlist {
            display:flex;
            flex-direction:column;
            gap:0.8rem;
            max-height:500px;
            overflow-y:auto;
            padding-right:0.5rem;
        }
        .video-playlist::-webkit-scrollbar {
            width:4px;
        }
        .video-playlist::-webkit-scrollbar-track {
            background:transparent;
        }
        .video-playlist::-webkit-scrollbar-thumb {
            background:var(--secondary);
            border-radius:2px;
        }

        .playlist-item {
            display:flex;
            gap:1rem;
            padding:0.8rem;
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:0.8rem;
            cursor:pointer;
            transition:all 0.3s;
            align-items:center;
        }
        .playlist-item:hover {
            background:rgba(139,26,26,0.15);
            border-color:var(--secondary);
            transform:translateX(5px);
        }
        .playlist-item.active {
            background:rgba(139,26,26,0.2);
            border-color:var(--gold);
        }
        .playlist-item .thumbnail {
            width:80px;
            height:55px;
            background:rgba(0,0,0,0.3);
            border-radius:0.5rem;
            display:flex;
            align-items:center;
            justify-content:center;
            flex-shrink:0;
            border:1px solid var(--border-color);
            position:relative;
        }
        .playlist-item .thumbnail i {
            font-size:1.8rem;
            color:var(--secondary);
            opacity:0.5;
        }
        .playlist-item .thumbnail .play-indicator {
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            background:rgba(139,26,26,0.8);
            border-radius:50%;
            width:30px;
            height:30px;
            display:flex;
            align-items:center;
            justify-content:center;
            color:white;
            font-size:0.8rem;
            opacity:0;
            transition:all 0.3s;
        }
        .playlist-item:hover .thumbnail .play-indicator {
            opacity:1;
        }
        .playlist-item .info {
            flex:1;
        }
        .playlist-item .info h4 {
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .playlist-item .info p {
            color:#7a6a5a;
            font-size:0.75rem;
        }
        .playlist-item .info .duration {
            color:#5a4a3a;
            font-size:0.7rem;
            font-family:monospace;
        }
        .playlist-item .status {
            color:var(--secondary);
            font-size:0.8rem;
        }
        .playlist-item .status .fa-check-circle {
            color:var(--success);
        }

        /* ===== VIDEO TUTORIALS ===== */
        .video-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            overflow:hidden;
            transition:all 0.3s;
            cursor:pointer;
        }
        .video-card:hover {
            transform:translateY(-5px);
            border-color:var(--secondary);
        }
        .video-card .video-thumbnail {
            background:rgba(0,0,0,0.4);
            padding:2rem;
            text-align:center;
            position:relative;
            border-bottom:1px solid var(--border-color);
        }
        .video-card .video-thumbnail i {
            font-size:4rem;
            color:var(--secondary);
            opacity:0.3;
        }
        .video-card .video-thumbnail .play-btn {
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            width:60px;
            height:60px;
            background:rgba(139,26,26,0.8);
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            color:white;
            font-size:1.5rem;
            transition:0.3s;
        }
        .video-card .video-thumbnail .play-btn:hover {
            background:var(--primary);
            transform:translate(-50%,-50%) scale(1.1);
        }
        .video-card .video-info {
            padding:1.2rem;
        }
        .video-card .video-info h3 {
            color:#f0d6b0;
            font-size:1rem;
            margin-bottom:0.3rem;
        }
        .video-card .video-info p {
            color:#a09080;
            font-size:0.85rem;
        }
        .video-card .video-info .video-meta {
            display:flex;
            gap:1rem;
            margin-top:0.5rem;
            color:#7a6a5a;
            font-size:0.75rem;
        }

        /* ===== LEARNING PATHS ===== */
        .learning-path {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            transition:all 0.3s;
        }
        .learning-path:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-3px);
        }
        .learning-path .path-header {
            display:flex;
            align-items:center;
            gap:1rem;
            margin-bottom:1rem;
        }
        .learning-path .path-header i {
            font-size:2.5rem;
            color:var(--secondary);
        }
        .learning-path .path-header h3 {
            color:#f0d6b0;
            font-size:1.1rem;
        }
        .learning-path .path-progress {
            background:rgba(255,255,255,0.05);
            border-radius:2rem;
            height:8px;
            overflow:hidden;
            margin:0.5rem 0;
        }
        .learning-path .path-progress .progress-bar {
            height:100%;
            background:linear-gradient(90deg,var(--secondary),var(--gold));
            border-radius:2rem;
            transition:width 0.6s;
        }
        .learning-path .path-stats {
            display:flex;
            justify-content:space-between;
            color:#7a6a5a;
            font-size:0.8rem;
            margin-top:0.5rem;
        }
        .learning-path .path-lessons {
            display:flex;
            flex-direction:column;
            gap:0.3rem;
            margin-top:0.8rem;
        }
        .learning-path .path-lessons .lesson-item {
            display:flex;
            align-items:center;
            gap:0.5rem;
            padding:0.3rem 0.5rem;
            border-radius:0.5rem;
            color:#a09080;
            font-size:0.85rem;
            transition:0.3s;
        }
        .learning-path .path-lessons .lesson-item:hover {
            background:rgba(139,26,26,0.1);
        }
        .learning-path .path-lessons .lesson-item.completed {
            color:#2ecc71;
        }
        .learning-path .path-lessons .lesson-item i {
            font-size:0.8rem;
            margin:0;
            color:inherit;
        }

        /* ===== BOOKS ===== */
        .book-card {
            display:flex;
            gap:1rem;
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.2rem;
            transition:all 0.3s;
        }
        .book-card:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-3px);
        }
        .book-card .book-cover {
            width:80px;
            height:100px;
            background:rgba(0,0,0,0.3);
            border-radius:0.5rem;
            display:flex;
            align-items:center;
            justify-content:center;
            flex-shrink:0;
            border:1px solid var(--border-color);
        }
        .book-card .book-cover i {
            font-size:2.5rem;
            color:var(--secondary);
            margin:0;
        }
        .book-card .book-info h4 {
            color:#f0d6b0;
            font-size:1rem;
        }
        .book-card .book-info p {
            color:#a09080;
            font-size:0.85rem;
        }
        .book-card .book-info .book-meta {
            color:#7a6a5a;
            font-size:0.75rem;
            margin-top:0.3rem;
        }

        /* ===== PRACTICE EXERCISES ===== */
        .exercise-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            transition:all 0.3s;
            text-align:center;
        }
        .exercise-card:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-5px);
        }
        .exercise-card i {
            font-size:2.5rem;
            color:var(--secondary);
            margin-bottom:0.8rem;
        }
        .exercise-card h3 {
            color:#f0d6b0;
            font-size:1rem;
        }
        .exercise-card p {
            color:#a09080;
            font-size:0.85rem;
            margin:0.5rem 0;
        }
        .exercise-card .exercise-difficulty {
            display:inline-block;
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
        }

        /* ===== ACHIEVEMENTS ===== */
        .achievement-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(150px,1fr));
            gap:1rem;
        }
        .achievement-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            text-align:center;
            transition:all 0.3s;
        }
        .achievement-item.locked {
            opacity:0.4;
        }
        .achievement-item.locked i {
            color:#5a4a3a !important;
        }
        .achievement-item:hover {
            transform:translateY(-3px);
        }
        .achievement-item i {
            font-size:2.5rem;
            color:var(--gold);
        }
        .achievement-item h4 {
            color:#f0d6b0;
            font-size:0.85rem;
            margin-top:0.3rem;
        }
        .achievement-item p {
            color:#7a6a5a;
            font-size:0.7rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .featured-lesson {
                grid-template-columns:1fr;
            }
            .learning-board-container {
                grid-template-columns:1fr;
            }
            .video-player-container {
                grid-template-columns:1fr;
            }
            .chess-board { max-width:400px; }
            .video-playlist {
                max-height:300px;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .learn-hero { margin:1rem; padding:2rem 1rem; }
            .learn-hero h1 { font-size:2rem; flex-direction:column; }
            .learn-hero .search-box { flex-direction:column; }
            .featured-lesson { padding:1.5rem; }
            .card-grid { grid-template-columns:1fr; }
            .achievement-grid { grid-template-columns:repeat(3,1fr); }
            .learning-board-section { padding:1rem; }
            .board-wrapper { padding:0.8rem; }
            .chess-board .square .piece { font-size:2rem; }
            .chess-board { max-width:100%; }
            .video-player-section { padding:1rem; }
            .video-controls { flex-wrap:wrap; gap:0.5rem; }
            .video-controls .volume-control input[type="range"] { width:50px; }
            .playlist-item .thumbnail { width:60px; height:40px; }
        }
        @media (max-width:480px) {
            .section-header h2 { font-size:1.3rem; }
            .learn-hero h1 { font-size:1.5rem; }
            .category-filters button { padding:0.3rem 1rem; font-size:0.75rem; }
            .achievement-grid { grid-template-columns:repeat(2,1fr); }
            .chess-board .square .piece { font-size:1.5rem; }
            .lesson-panel { padding:1rem; }
            .video-player-wrapper { padding:0.5rem; }
            .video-controls .time-display { font-size:0.7rem; min-width:70px; }
            .video-controls .volume-control input[type="range"] { width:40px; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php" class="active-link"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="openings.php"><i class="fas fa-book-open"></i> Openings</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <div class="learn-hero">
        <h1>
            <i class="fas fa-graduation-cap"></i>
            Learn Chess
            <i class="fas fa-chess"></i>
        </h1>
        <p>Master the royal game with our interactive lessons, video tutorials, visual board demonstrations, and comprehensive resources.</p>
        <div class="search-box">
            <input type="text" placeholder="Search lessons, openings, strategies..." id="lessonSearch" onkeyup="filterLessons()">
            <button onclick="filterLessons()"><i class="fas fa-search"></i> Search</button>
        </div>
    </div>

    <!-- ===== VIDEO PLAYER SECTION ===== -->
    <section class="section" style="padding-top:0;">
        <div class="video-player-section">
            <h2 style="color:#f0d6b0;font-size:1.5rem;margin-bottom:1.5rem;display:flex;align-items:center;gap:0.8rem;">
                <i class="fas fa-video" style="color:var(--secondary);"></i>
                Chess Video Tutorials
                <span style="font-size:0.85rem;color:#7a6a5a;font-weight:400;">— Learn from expert instructors</span>
            </h2>
            <div class="video-player-container">
                <!-- Video Player -->
                <div class="video-player-wrapper">
                    <video id="mainVideo" controls preload="metadata" style="width:100%;border-radius:1rem;background:#000;display:block;">
                        <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4">
                        Your browser does not support the video tag.
                    </video>
                    <div class="video-overlay" id="videoOverlay" onclick="toggleVideoPlay()">
                        <div class="play-btn-large">
                            <i class="fas fa-play"></i>
                        </div>
                    </div>
                    
                    <!-- Video Controls -->
                    <div class="video-controls">
                        <button onclick="toggleVideoPlay()" id="playPauseBtn" title="Play/Pause">
                            <i class="fas fa-play"></i>
                        </button>
                        <button onclick="skipVideo(-10)" title="Rewind 10s">
                            <i class="fas fa-backward"></i> 10
                        </button>
                        <button onclick="skipVideo(10)" title="Forward 10s">
                            10 <i class="fas fa-forward"></i>
                        </button>
                        <div class="progress-bar-container" id="progressContainer" onclick="setVideoProgress(event)">
                            <div class="progress-fill" id="progressFill"></div>
                        </div>
                        <span class="time-display" id="timeDisplay">00:00 / 00:00</span>
                        <div class="volume-control">
                            <button onclick="toggleMute()" id="muteBtn" title="Mute/Unmute">
                                <i class="fas fa-volume-up"></i>
                            </button>
                            <input type="range" id="volumeSlider" min="0" max="1" step="0.1" value="1" onchange="setVolume(this.value)">
                        </div>
                        <button onclick="toggleFullscreen()" title="Fullscreen">
                            <i class="fas fa-expand"></i>
                        </button>
                    </div>
                </div>

                <!-- Playlist -->
                <div>
                    <h3 style="color:#f0d6b0;font-size:1rem;margin-bottom:0.8rem;display:flex;align-items:center;gap:0.5rem;">
                        <i class="fas fa-list" style="color:var(--secondary);"></i>
                        Playlist
                        <span style="font-size:0.75rem;color:#7a6a5a;font-weight:400;margin-left:auto;" id="playlistCount">6 videos</span>
                    </h3>
                    <div class="video-playlist" id="videoPlaylist">
                        <!-- Playlist items will be populated by JavaScript -->
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== INTERACTIVE LEARNING BOARD ===== -->
    <section class="section" style="padding-top:0;">
        <div class="learning-board-section">
            <h2 style="color:#f0d6b0;font-size:1.5rem;margin-bottom:1.5rem;display:flex;align-items:center;gap:0.8rem;">
                <i class="fas fa-chess-board" style="color:var(--secondary);"></i>
                Interactive Learning Board
                <span style="font-size:0.85rem;color:#7a6a5a;font-weight:400;">— Visualize chess concepts in real-time</span>
            </h2>
            <div class="learning-board-container">
                <!-- Board -->
                <div class="board-wrapper">
                    <div class="board-title">
                        <span class="lesson-name">
                            <i class="fas fa-chess-king"></i>
                            <span id="boardLessonTitle">Piece Movement Basics</span>
                        </span>
                        <span style="color:#7a6a5a;font-size:0.75rem;" id="boardStepIndicator">Step 1/8</span>
                    </div>
                    <div class="chess-board" id="learningBoard"></div>
                    <div class="board-controls">
                        <button class="btn-nav" id="prevStepBtn" onclick="prevLearningStep()">
                            <i class="fas fa-chevron-left"></i> Prev
                        </button>
                        <button class="btn-nav" id="nextStepBtn" onclick="nextLearningStep()">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                        <button class="btn-reset-board" onclick="resetLearningBoard()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                        <button class="btn-flip-board" onclick="flipLearningBoard()">
                            <i class="fas fa-sync-alt"></i> Flip
                        </button>
                        <button class="btn-nav" onclick="toggleAutoPlay()" id="autoPlayBtn">
                            <i class="fas fa-play"></i> Auto
                        </button>
                    </div>
                </div>

                <!-- Lesson Panel -->
                <div class="lesson-sidebar">
                    <div class="lesson-panel">
                        <h3><i class="fas fa-book"></i> <span id="lessonPanelTitle">How Pieces Move</span></h3>
                        <div class="lesson-content" id="lessonContent">
                            <p>Each chess piece moves in a unique way. Understanding these movements is the first step to mastering chess.</p>
                            <ul class="key-points">
                                <li><strong style="color:#f0d6b0;">Pawn:</strong> Moves forward one square (two on first move), captures diagonally</li>
                                <li><strong style="color:#f0d6b0;">Knight:</strong> Moves in an "L" shape — the only piece that can jump over others</li>
                                <li><strong style="color:#f0d6b0;">Bishop:</strong> Moves diagonally any number of squares</li>
                                <li><strong style="color:#f0d6b0;">Rook:</strong> Moves horizontally or vertically any number of squares</li>
                                <li><strong style="color:#f0d6b0;">Queen:</strong> Combines the power of rook and bishop</li>
                                <li><strong style="color:#f0d6b0;">King:</strong> Moves one square in any direction</li>
                            </ul>
                            <div class="example">
                                💡 <span class="highlight-text">Tip:</span> Use the navigation buttons to see each piece in action!
                            </div>
                        </div>
                        <div class="lesson-progress">
                            <div class="progress-bar" id="lessonProgressBar" style="width:12.5%;"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CATEGORY FILTERS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="category-filters" id="categoryFilters">
            <button class="active" onclick="filterCategory('all')">All</button>
            <?php if (!empty($categories)): ?>
                <?php foreach ($categories as $category): ?>
                    <button onclick="filterCategory('<?php echo e($category['slug']); ?>')"><?php echo e($category['name']); ?></button>
                <?php endforeach; ?>
            <?php else: ?>
                <button onclick="filterCategory('beginner')">Beginner</button>
                <button onclick="filterCategory('intermediate')">Intermediate</button>
                <button onclick="filterCategory('advanced')">Advanced</button>
                <button onclick="filterCategory('openings')">Openings</button>
                <button onclick="filterCategory('middlegame')">Middlegame</button>
                <button onclick="filterCategory('endgame')">Endgame</button>
                <button onclick="filterCategory('strategy')">Strategy</button>
                <button onclick="filterCategory('tactics')">Tactics</button>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LESSONS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="section-header">
            <h2><i class="fas fa-book"></i> All Lessons</h2>
            <a href="lessons.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid" id="lessonGrid">
            <?php if (!empty($lessons)): ?>
                <?php foreach ($lessons as $lesson): ?>
                    <a href="lesson.php?id=<?php echo e($lesson['id']); ?>" class="card" data-category="<?php echo e($lesson['category'] ?? 'all'); ?>" onclick="loadLesson(<?php echo e($lesson['id']); ?>); return false;">
                        <span class="badge badge-<?php echo e($lesson['level'] ?? 'beginner'); ?>"><?php echo e(ucfirst($lesson['level'] ?? 'Beginner')); ?></span>
                        <i class="fas fa-<?php echo e($lesson['icon'] ?? 'book'); ?>"></i>
                        <h3><?php echo e($lesson['title']); ?></h3>
                        <p><?php echo e($lesson['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-clock"></i> <?php echo e($lesson['duration'] ?? '30 min'); ?></span>
                            <span><i class="fas fa-play-circle"></i> <?php echo e($lesson['lessons_count'] ?? '5'); ?> lessons</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- Default lessons -->
                <a href="#" class="card" data-category="beginner" onclick="loadLessonPreset('pawn'); return false;">
                    <span class="badge badge-beginner">Beginner</span>
                    <i class="fas fa-chess-pawn"></i>
                    <h3>Pawn Movement & Structure</h3>
                    <p>Learn how pawns move, capture, and the importance of pawn structure.</p>
                    <div class="meta"><span><i class="fas fa-clock"></i> 25 min</span><span><i class="fas fa-play-circle"></i> 6 lessons</span></div>
                </a>
                <a href="#" class="card" data-category="beginner" onclick="loadLessonPreset('knight'); return false;">
                    <span class="badge badge-beginner">Beginner</span>
                    <i class="fas fa-chess-knight"></i>
                    <h3>Knight Movement & Fork Tactics</h3>
                    <p>Master the unique L-shaped movement and powerful fork tactics.</p>
                    <div class="meta"><span><i class="fas fa-clock"></i> 30 min</span><span><i class="fas fa-play-circle"></i> 5 lessons</span></div>
                </a>
                <a href="#" class="card" data-category="beginner" onclick="loadLessonPreset('bishop'); return false;">
                    <span class="badge badge-beginner">Beginner</span>
                    <i class="fas fa-chess-bishop"></i>
                    <h3>Bishop Pair & Diagonal Control</h3>
                    <p>Understand bishop movement and the power of the bishop pair.</p>
                    <div class="meta"><span><i class="fas fa-clock"></i> 25 min</span><span><i class="fas fa-play-circle"></i> 4 lessons</span></div>
                </a>
                <a href="#" class="card" data-category="beginner" onclick="loadLessonPreset('rook'); return false;">
                    <span class="badge badge-intermediate">Intermediate</span>
                    <i class="fas fa-chess-rook"></i>
                    <h3>Rook & Open Files</h3>
                    <p>Learn rook movement and the importance of controlling open files.</p>
                    <div class="meta"><span><i class="fas fa-clock"></i> 30 min</span><span><i class="fas fa-play-circle"></i> 5 lessons</span></div>
                </a>
                <a href="#" class="card" data-category="intermediate" onclick="loadLessonPreset('queen'); return false;">
                    <span class="badge badge-intermediate">Intermediate</span>
                    <i class="fas fa-chess-queen"></i>
                    <h3>Queen & Attacking Combinations</h3>
                    <p>Master the most powerful piece and its attacking patterns.</p>
                    <div class="meta"><span><i class="fas fa-clock"></i> 35 min</span><span><i class="fas fa-play-circle"></i> 6 lessons</span></div>
                </a>
                <a href="#" class="card" data-category="advanced" onclick="loadLessonPreset('king'); return false;">
                    <span class="badge badge-advanced">Advanced</span>
                    <i class="fas fa-chess-king"></i>
                    <h3>King Safety & Endgame</h3>
                    <p>Learn king safety in the middlegame and king activity in endgames.</p>
                    <div class="meta"><span><i class="fas fa-clock"></i> 40 min</span><span><i class="fas fa-play-circle"></i> 7 lessons</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LEARNING PATHS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-route"></i> Learning Paths</h2>
            <a href="learning-paths.php" class="view-all">All Paths <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($learningPaths)): ?>
                <?php foreach ($learningPaths as $path): ?>
                    <div class="learning-path">
                        <div class="path-header">
                            <i class="fas fa-<?php echo e($path['icon'] ?? 'road'); ?>"></i>
                            <h3><?php echo e($path['name']); ?></h3>
                        </div>
                        <p style="color:#a09080;font-size:0.85rem;"><?php echo e($path['description']); ?></p>
                        <div class="path-progress">
                            <div class="progress-bar" style="width:<?php echo e($path['progress'] ?? 0); ?>%"></div>
                        </div>
                        <div class="path-stats">
                            <span><?php echo e($path['completed'] ?? 0); ?>/<?php echo e($path['total'] ?? 10); ?> lessons</span>
                            <span><?php echo e($path['progress'] ?? 0); ?>% complete</span>
                        </div>
                        <div class="path-lessons">
                            <?php if (!empty($path['lessons'])): ?>
                                <?php foreach ($path['lessons'] as $lesson): ?>
                                    <div class="lesson-item <?php echo $lesson['completed'] ? 'completed' : ''; ?>">
                                        <i class="fas fa-<?php echo $lesson['completed'] ? 'check-circle' : 'circle'; ?>"></i>
                                        <span><?php echo e($lesson['name']); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 1: Getting Started</span></div>
                                <div class="lesson-item completed"><i class="fas fa-check-circle"></i><span>Lesson 2: Basic Moves</span></div>
                                <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 3: Tactics</span></div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="learning-path">
                    <div class="path-header"><i class="fas fa-road"></i><h3>Beginner to Intermediate</h3></div>
                    <p style="color:#a09080;font-size:0.85rem;">Master the fundamentals and build a solid foundation.</p>
                    <div class="path-progress"><div class="progress-bar" style="width:40%"></div></div>
                    <div class="path-stats"><span>4/10 lessons</span><span>40% complete</span></div>
                    <div class="path-lessons">
                        <div class="lesson-item completed"><i class="fas fa-check-circle"></i><span>Lesson 1: Chess Basics</span></div>
                        <div class="lesson-item completed"><i class="fas fa-check-circle"></i><span>Lesson 2: Piece Movement</span></div>
                        <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 3: Opening Principles</span></div>
                        <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 4: Basic Tactics</span></div>
                    </div>
                </div>
                <div class="learning-path">
                    <div class="path-header"><i class="fas fa-trophy"></i><h3>Intermediate to Advanced</h3></div>
                    <p style="color:#a09080;font-size:0.85rem;">Deepen your understanding and master complex strategies.</p>
                    <div class="path-progress"><div class="progress-bar" style="width:25%"></div></div>
                    <div class="path-stats"><span>2/8 lessons</span><span>25% complete</span></div>
                    <div class="path-lessons">
                        <div class="lesson-item completed"><i class="fas fa-check-circle"></i><span>Lesson 1: Advanced Tactics</span></div>
                        <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 2: Positional Play</span></div>
                        <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 3: Endgame Mastery</span></div>
                    </div>
                </div>
                <div class="learning-path">
                    <div class="path-header"><i class="fas fa-chess"></i><h3>Opening Repertoire</h3></div>
                    <p style="color:#a09080;font-size:0.85rem;">Build a complete opening repertoire for White and Black.</p>
                    <div class="path-progress"><div class="progress-bar" style="width:15%"></div></div>
                    <div class="path-stats"><span>1/8 lessons</span><span>15% complete</span></div>
                    <div class="path-lessons">
                        <div class="lesson-item completed"><i class="fas fa-check-circle"></i><span>Lesson 1: Italian Game</span></div>
                        <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 2: Ruy Lopez</span></div>
                        <div class="lesson-item"><i class="fas fa-circle"></i><span>Lesson 3: Sicilian Defense</span></div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== VIDEO TUTORIALS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-play-circle"></i> More Video Tutorials</h2>
            <a href="videos.php" class="view-all">All Videos <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid" id="videoTutorialGrid">
            <?php if (!empty($videoTutorials)): ?>
                <?php foreach ($videoTutorials as $index => $video): ?>
                    <div class="video-card" onclick="playVideoFromCard(<?php echo e($index); ?>)">
                        <div class="video-thumbnail">
                            <i class="fas fa-<?php echo e($video['icon'] ?? 'video'); ?>"></i>
                            <div class="play-btn"><i class="fas fa-play"></i></div>
                        </div>
                        <div class="video-info">
                            <h3><?php echo e($video['title']); ?></h3>
                            <p><?php echo e($video['description']); ?></p>
                            <div class="video-meta">
                                <span><i class="fas fa-clock"></i> <?php echo e($video['duration'] ?? '15 min'); ?></span>
                                <span><i class="fas fa-user"></i> <?php echo e($video['instructor'] ?? 'GM Instructor'); ?></span>
                                <span><i class="fas fa-eye"></i> <?php echo e($video['views'] ?? '1.2k'); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="video-card" onclick="playVideoFromCard(0)">
                    <div class="video-thumbnail"><i class="fas fa-chess-king"></i><div class="play-btn"><i class="fas fa-play"></i></div></div>
                    <div class="video-info"><h3>Understanding Pawn Structure</h3><p>Learn the importance of pawn structures in chess.</p><div class="video-meta"><span><i class="fas fa-clock"></i> 15 min</span><span><i class="fas fa-user"></i> GM Magnus</span><span><i class="fas fa-eye"></i> 2.4k</span></div></div>
                </div>
                <div class="video-card" onclick="playVideoFromCard(1)">
                    <div class="video-thumbnail"><i class="fas fa-chess-queen"></i><div class="play-btn"><i class="fas fa-play"></i></div></div>
                    <div class="video-info"><h3>Queen Sacrifice Patterns</h3><p>Recognize when to sacrifice your queen for victory.</p><div class="video-meta"><span><i class="fas fa-clock"></i> 20 min</span><span><i class="fas fa-user"></i> GM Kasparov</span><span><i class="fas fa-eye"></i> 1.8k</span></div></div>
                </div>
                <div class="video-card" onclick="playVideoFromCard(2)">
                    <div class="video-thumbnail"><i class="fas fa-chess-knight"></i><div class="play-btn"><i class="fas fa-play"></i></div></div>
                    <div class="video-info"><h3>Knight Fork Mastery</h3><p>Master the powerful knight fork tactic.</p><div class="video-meta"><span><i class="fas fa-clock"></i> 12 min</span><span><i class="fas fa-user"></i> IM Sarah</span><span><i class="fas fa-eye"></i> 1.5k</span></div></div>
                </div>
                <div class="video-card" onclick="playVideoFromCard(3)">
                    <div class="video-thumbnail"><i class="fas fa-chess-rook"></i><div class="play-btn"><i class="fas fa-play"></i></div></div>
                    <div class="video-info"><h3>Rook Endgame Fundamentals</h3><p>Essential rook endgame techniques every player must know.</p><div class="video-meta"><span><i class="fas fa-clock"></i> 25 min</span><span><i class="fas fa-user"></i> GM Carlsen</span><span><i class="fas fa-eye"></i> 3.1k</span></div></div>
                </div>
                <div class="video-card" onclick="playVideoFromCard(4)">
                    <div class="video-thumbnail"><i class="fas fa-chess-bishop"></i><div class="play-btn"><i class="fas fa-play"></i></div></div>
                    <div class="video-info"><h3>Bishop Pair Advantage</h3><p>Learn to utilize the bishop pair for maximum effect.</p><div class="video-meta"><span><i class="fas fa-clock"></i> 18 min</span><span><i class="fas fa-user"></i> GM Polgar</span><span><i class="fas fa-eye"></i> 1.9k</span></div></div>
                </div>
                <div class="video-card" onclick="playVideoFromCard(5)">
                    <div class="video-thumbnail"><i class="fas fa-chess-pawn"></i><div class="play-btn"><i class="fas fa-play"></i></div></div>
                    <div class="video-info"><h3>Pawn Promotion Techniques</h3><p>Master the art of promoting pawns to victory.</p><div class="video-meta"><span><i class="fas fa-clock"></i> 14 min</span><span><i class="fas fa-user"></i> IM Lee</span><span><i class="fas fa-eye"></i> 1.3k</span></div></div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== RECOMMENDED BOOKS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-book-open"></i> Recommended Books</h2>
            <a href="books.php" class="view-all">All Books <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($chessBooks)): ?>
                <?php foreach ($chessBooks as $book): ?>
                    <div class="book-card">
                        <div class="book-cover"><i class="fas fa-<?php echo e($book['icon'] ?? 'book'); ?>"></i></div>
                        <div class="book-info">
                            <h4><?php echo e($book['title']); ?></h4>
                            <p><?php echo e($book['description']); ?></p>
                            <div class="book-meta">
                                <span>by <?php echo e($book['author']); ?></span>
                                <span>• <?php echo e($book['pages'] ?? '200'); ?> pages</span>
                                <span>• ⭐ <?php echo e($book['rating'] ?? '4.5'); ?></span>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="book-card">
                    <div class="book-cover"><i class="fas fa-book"></i></div>
                    <div class="book-info"><h4>Bobby Fischer Teaches Chess</h4><p>Classic book by the legendary chess champion.</p><div class="book-meta"><span>by Bobby Fischer</span><span>• 352 pages</span><span>• ⭐ 4.8</span></div></div>
                </div>
                <div class="book-card">
                    <div class="book-cover"><i class="fas fa-book"></i></div>
                    <div class="book-info"><h4>My Great Predecessors</h4><p>Kasparov's masterful analysis of chess legends.</p><div class="book-meta"><span>by Garry Kasparov</span><span>• 480 pages</span><span>• ⭐ 4.9</span></div></div>
                </div>
                <div class="book-card">
                    <div class="book-cover"><i class="fas fa-book"></i></div>
                    <div class="book-info"><h4>The Art of Attack in Chess</h4><p>Master the art of attacking play.</p><div class="book-meta"><span>by Vladimir Vukovic</span><span>• 288 pages</span><span>• ⭐ 4.7</span></div></div>
                </div>
                <div class="book-card">
                    <div class="book-cover"><i class="fas fa-book"></i></div>
                    <div class="book-info"><h4>Endgame Strategy</h4><p>Essential endgame knowledge for every player.</p><div class="book-meta"><span>by Mikhail Shereshevsky</span><span>• 256 pages</span><span>• ⭐ 4.6</span></div></div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== PRACTICE EXERCISES ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-puzzle-piece"></i> Practice Exercises</h2>
            <a href="practice.php" class="view-all">All Exercises <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($practiceExercises)): ?>
                <?php foreach ($practiceExercises as $exercise): ?>
                    <div class="exercise-card">
                        <i class="fas fa-<?php echo e($exercise['icon'] ?? 'chess'); ?>"></i>
                        <h3><?php echo e($exercise['title']); ?></h3>
                        <p><?php echo e($exercise['description']); ?></p>
                        <span class="exercise-difficulty badge-<?php echo e($exercise['level'] ?? 'beginner'); ?>">
                            <?php echo e(ucfirst($exercise['level'] ?? 'Beginner')); ?>
                        </span>
                        <div style="margin-top:0.5rem;">
                            <a href="practice.php?id=<?php echo e($exercise['id'] ?? 1); ?>" class="btn-start-lesson" style="padding:0.5rem 1.2rem;font-size:0.8rem;">
                                <i class="fas fa-play"></i> Practice
                            </a>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="exercise-card"><i class="fas fa-chess-knight"></i><h3>Fork Practice</h3><p>Practice identifying and executing forks.</p><span class="exercise-difficulty badge-beginner">Beginner</span><div style="margin-top:0.5rem;"><a href="#" class="btn-start-lesson" style="padding:0.5rem 1.2rem;font-size:0.8rem;"><i class="fas fa-play"></i> Practice</a></div></div>
                <div class="exercise-card"><i class="fas fa-chess-queen"></i><h3>Pin Exercises</h3><p>Master the art of pins and use them effectively.</p><span class="exercise-difficulty badge-intermediate">Intermediate</span><div style="margin-top:0.5rem;"><a href="#" class="btn-start-lesson" style="padding:0.5rem 1.2rem;font-size:0.8rem;"><i class="fas fa-play"></i> Practice</a></div></div>
                <div class="exercise-card"><i class="fas fa-chess-rook"></i><h3>Skewer Training</h3><p>Learn to skewer enemy pieces for material gain.</p><span class="exercise-difficulty badge-intermediate">Intermediate</span><div style="margin-top:0.5rem;"><a href="#" class="btn-start-lesson" style="padding:0.5rem 1.2rem;font-size:0.8rem;"><i class="fas fa-play"></i> Practice</a></div></div>
                <div class="exercise-card"><i class="fas fa-chess-king"></i><h3>Checkmate Patterns</h3><p>Recognize and execute checkmate patterns.</p><span class="exercise-difficulty badge-advanced">Advanced</span><div style="margin-top:0.5rem;"><a href="#" class="btn-start-lesson" style="padding:0.5rem 1.2rem;font-size:0.8rem;"><i class="fas fa-play"></i> Practice</a></div></div>
                <div class="exercise-card"><i class="fas fa-chess-pawn"></i><h3>Pawn Endgames</h3><p>Practice essential pawn endgame positions.</p><span class="exercise-difficulty badge-intermediate">Intermediate</span><div style="margin-top:0.5rem;"><a href="#" class="btn-start-lesson" style="padding:0.5rem 1.2rem;font-size:0.8rem;"><i class="fas fa-play"></i> Practice</a></div></div>
                <div class="exercise-card"><i class="fas fa-chess-queen"></i><h3>Queen vs Rook Endgame</h3><p>Master the queen vs rook endgame.</p><span class="exercise-difficulty badge-advanced">Advanced</span><div style="margin-top:0.5rem;"><a href="#" class="btn-start-lesson" style="padding:0.5rem 1.2rem;font-size:0.8rem;"><i class="fas fa-play"></i> Practice</a></div></div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== ACHIEVEMENTS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-trophy"></i> Your Achievements</h2>
            <a href="achievements.php" class="view-all">All Achievements <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="achievement-grid">
            <?php if (!empty($achievements)): ?>
                <?php foreach ($achievements as $achievement): ?>
                    <div class="achievement-item <?php echo $achievement['unlocked'] ? '' : 'locked'; ?>">
                        <i class="fas fa-<?php echo e($achievement['icon'] ?? 'medal'); ?>"></i>
                        <h4><?php echo e($achievement['name']); ?></h4>
                        <p><?php echo e($achievement['description']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="achievement-item"><i class="fas fa-medal"></i><h4>First Lesson</h4><p>Complete your first lesson</p></div>
                <div class="achievement-item"><i class="fas fa-medal"></i><h4>Tactics Master</h4><p>Solve 50 tactical puzzles</p></div>
                <div class="achievement-item locked"><i class="fas fa-medal"></i><h4>Opening Expert</h4><p>Master 5 openings</p></div>
                <div class="achievement-item locked"><i class="fas fa-medal"></i><h4>Endgame Specialist</h4><p>Complete all endgame lessons</p></div>
                <div class="achievement-item"><i class="fas fa-medal"></i><h4>Learning Streak</h4><p>Learn 7 days in a row</p></div>
                <div class="achievement-item locked"><i class="fas fa-medal"></i><h4>Grandmaster in Training</h4><p>Complete all lessons</p></div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:var(--card-bg);border-radius:1.5rem;padding:2rem;border:1px solid var(--border-color);text-align:center;">
            <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--secondary);"></i>
            <h3 style="color:#f0d6b0;margin:0.5rem 0;">Learning Tip</h3>
            <p style="color:#a09080;max-width:600px;margin:0 auto;">
                <i class="fas fa-chess-pawn"></i> Practice regularly, watch video tutorials, analyze your games, and never stop learning.
                <br>
                <span style="color:var(--secondary);font-size:0.85rem;">"The strongest chess player is the one who never stops learning."</span>
            </p>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== VIDEO PLAYER =====
        const video = document.getElementById('mainVideo');
        const playPauseBtn = document.getElementById('playPauseBtn');
        const progressFill = document.getElementById('progressFill');
        const progressContainer = document.getElementById('progressContainer');
        const timeDisplay = document.getElementById('timeDisplay');
        const volumeSlider = document.getElementById('volumeSlider');
        const muteBtn = document.getElementById('muteBtn');
        const videoOverlay = document.getElementById('videoOverlay');

        // Video playlist data
        const videoPlaylist = [
            {
                title: 'How to Play Chess: Beginner\'s Guide',
                description: 'Learn the complete rules and basic strategies of chess.',
                duration: '15:30',
                instructor: 'GM Magnus Carlsen',
                views: '15.2k',
                icon: 'chess-king',
                videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
            },
            {
                title: 'Opening Principles Explained',
                description: 'Master the fundamental principles of chess openings.',
                duration: '22:15',
                instructor: 'GM Garry Kasparov',
                views: '12.8k',
                icon: 'chess-queen',
                videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
            },
            {
                title: 'Tactical Patterns: Forks & Pins',
                description: 'Learn to recognize and execute tactical patterns.',
                duration: '18:45',
                instructor: 'IM Sarah Lee',
                views: '9.4k',
                icon: 'chess-knight',
                videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
            },
            {
                title: 'Endgame Mastery: Rook Endings',
                description: 'Essential rook endgame techniques every player must know.',
                duration: '25:30',
                instructor: 'GM Viswanathan Anand',
                views: '8.1k',
                icon: 'chess-rook',
                videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
            },
            {
                title: 'Bishop Pair Advantage',
                description: 'Learn to utilize the bishop pair for maximum effect.',
                duration: '18:20',
                instructor: 'GM Judit Polgár',
                views: '6.9k',
                icon: 'chess-bishop',
                videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
            },
            {
                title: 'Pawn Promotion Techniques',
                description: 'Master the art of promoting pawns to victory.',
                duration: '14:50',
                instructor: 'IM Lee Wei',
                views: '5.3k',
                icon: 'chess-pawn',
                videoUrl: 'https://www.w3schools.com/html/mov_bbb.mp4'
            }
        ];

        let currentVideoIndex = 0;
        let isPlaying = false;
        let isMuted = false;

        // Initialize playlist
        function renderPlaylist() {
            const playlistEl = document.getElementById('videoPlaylist');
            if (!playlistEl) return;
            
            playlistEl.innerHTML = '';
            
            videoPlaylist.forEach((videoItem, index) => {
                const item = document.createElement('div');
                item.className = `playlist-item ${index === currentVideoIndex ? 'active' : ''}`;
                item.innerHTML = `
                    <div class="thumbnail">
                        <i class="fas fa-${videoItem.icon}"></i>
                        <div class="play-indicator"><i class="fas fa-play"></i></div>
                    </div>
                    <div class="info">
                        <h4>${videoItem.title}</h4>
                        <p>${videoItem.instructor}</p>
                        <span class="duration">${videoItem.duration}</span>
                    </div>
                    <div class="status">
                        ${index === currentVideoIndex ? '<i class="fas fa-play"></i>' : ''}
                    </div>
                `;
                item.onclick = () => playVideo(index);
                playlistEl.appendChild(item);
            });
            
            document.getElementById('playlistCount').textContent = `${videoPlaylist.length} videos`;
        }

        // Play video by index
        function playVideo(index) {
            if (index < 0 || index >= videoPlaylist.length) return;
            
            currentVideoIndex = index;
            const videoItem = videoPlaylist[index];
            
            // Update video source
            video.src = videoItem.videoUrl;
            video.load();
            video.play().catch(e => console.log('Auto-play prevented'));
            
            // Update UI
            isPlaying = true;
            updatePlayButton();
            renderPlaylist();
            
            // Hide overlay
            videoOverlay.style.opacity = '0';
            
            // Update video title
            document.querySelector('.video-player-wrapper .video-overlay .play-btn-large i').className = 'fas fa-pause';
        }

        // Play video from card
        function playVideoFromCard(index) {
            playVideo(index);
            document.querySelector('.video-player-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        // Toggle play/pause
        function toggleVideoPlay() {
            if (video.paused) {
                video.play();
                isPlaying = true;
                videoOverlay.style.opacity = '0';
            } else {
                video.pause();
                isPlaying = false;
                videoOverlay.style.opacity = '1';
            }
            updatePlayButton();
        }

        // Update play button icon
        function updatePlayButton() {
            const icon = playPauseBtn.querySelector('i');
            if (isPlaying || !video.paused) {
                icon.className = 'fas fa-pause';
                videoOverlay.style.opacity = '0';
            } else {
                icon.className = 'fas fa-play';
                videoOverlay.style.opacity = '1';
            }
        }

        // Skip video
        function skipVideo(seconds) {
            video.currentTime = Math.max(0, Math.min(video.currentTime + seconds, video.duration));
        }

        // Set video progress
        function setVideoProgress(e) {
            const rect = progressContainer.getBoundingClientRect();
            const pos = (e.clientX - rect.left) / rect.width;
            video.currentTime = pos * video.duration;
        }

        // Update progress bar
        function updateProgress() {
            if (video.duration) {
                const progress = (video.currentTime / video.duration) * 100;
                progressFill.style.width = progress + '%';
                
                // Update time display
                const currentTime = formatTime(video.currentTime);
                const duration = formatTime(video.duration);
                timeDisplay.textContent = `${currentTime} / ${duration}`;
            }
        }

        // Format time
        function formatTime(seconds) {
            if (isNaN(seconds)) return '00:00';
            const mins = Math.floor(seconds / 60);
            const secs = Math.floor(seconds % 60);
            return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        }

        // Set volume
        function setVolume(value) {
            video.volume = parseFloat(value);
            isMuted = video.volume === 0;
            updateMuteButton();
        }

        // Toggle mute
        function toggleMute() {
            isMuted = !isMuted;
            video.muted = isMuted;
            if (!isMuted && video.volume === 0) {
                video.volume = 1;
                volumeSlider.value = 1;
            }
            updateMuteButton();
        }

        // Update mute button
        function updateMuteButton() {
            const icon = muteBtn.querySelector('i');
            if (isMuted || video.volume === 0) {
                icon.className = 'fas fa-volume-mute';
            } else if (video.volume < 0.5) {
                icon.className = 'fas fa-volume-down';
            } else {
                icon.className = 'fas fa-volume-up';
            }
        }

        // Toggle fullscreen
        function toggleFullscreen() {
            if (!document.fullscreenElement) {
                document.documentElement.requestFullscreen().catch(e => {});
            } else {
                document.exitFullscreen().catch(e => {});
            }
        }

        // Video event listeners
        video.addEventListener('play', () => {
            isPlaying = true;
            updatePlayButton();
        });
        
        video.addEventListener('pause', () => {
            isPlaying = false;
            updatePlayButton();
        });
        
        video.addEventListener('timeupdate', updateProgress);
        video.addEventListener('volumechange', updateMuteButton);
        video.addEventListener('ended', () => {
            // Play next video in playlist
            if (currentVideoIndex < videoPlaylist.length - 1) {
                playVideo(currentVideoIndex + 1);
            } else {
                isPlaying = false;
                updatePlayButton();
                videoOverlay.style.opacity = '1';
            }
        });

        // Volume slider sync with video
        volumeSlider.addEventListener('input', function() {
            video.volume = parseFloat(this.value);
            isMuted = video.volume === 0;
            updateMuteButton();
        });

        // Keyboard shortcuts for video
        document.addEventListener('keydown', function(e) {
            if (e.key === ' ' && document.activeElement?.tagName !== 'INPUT') {
                e.preventDefault();
                toggleVideoPlay();
            } else if (e.key === 'ArrowRight') {
                skipVideo(5);
            } else if (e.key === 'ArrowLeft') {
                skipVideo(-5);
            } else if (e.key === 'm') {
                toggleMute();
            } else if (e.key === 'f') {
                toggleFullscreen();
            }
        });

        // ===== PIECE SYMBOLS =====
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // ===== LEARNING BOARD STATE =====
        let learningBoard = [];
        let learningStep = 0;
        let learningSteps = [];
        let isLearningFlipped = false;
        let autoPlayInterval = null;
        let isAutoPlaying = false;

        // ===== LESSON DATA =====
        const LESSONS = {
            'pawn': {
                title: 'Pawn Movement & Structure',
                steps: [
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'Pawn Starting Position',
                        content: '<p>Pawns start on the second rank (White) and seventh rank (Black). They move <span class="highlight-text">forward one square</span> (or two squares from their starting position).</p><ul class="key-points"><li>White pawns move upward (decreasing row numbers)</li><li>Black pawns move downward (increasing row numbers)</li><li>Pawns capture diagonally</li></ul>'
                    },
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'Pawn Moves Forward',
                        content: '<p>Pawns can move <span class="highlight-text">one square forward</span> if the square is empty. From their starting position, they can move two squares forward.</p><div class="example">💡 The pawn on a2 can move to a3 or a4. The pawn on e2 can move to e3 or e4.</div>'
                    },
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','p','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'Pawn Captures Diagonally',
                        content: '<p>Pawns capture <span class="highlight-text">diagonally forward</span> one square. They cannot capture straight ahead.</p><div class="example">🔴 The white pawn on c2 can capture the black pawn on d3 (diagonal), but cannot capture a piece on d2 or c3.</div>'
                    }
                ]
            },
            'knight': {
                title: 'Knight Movement & Fork Tactics',
                steps: [
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'Knight Starting Position',
                        content: '<p>Knights are the <span class="highlight-text">only pieces that can jump over others</span>. They move in an "L" shape: two squares in one direction and one square perpendicular.</p><ul class="key-points"><li>White knights start on b1 and g1</li><li>Black knights start on b8 and g8</li><li>Knights can jump over any piece</li></ul>'
                    },
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','N','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','','B','Q','K','B','N','R']
                        ],
                        title: 'Knight Movement Pattern',
                        content: '<p>The knight moves in an <span class="highlight-text">"L" shape</span> — two squares vertically and one horizontally, or vice versa.</p><div class="example">♘ From c4, the knight can move to: a3, a5, b2, b6, d2, d6, e3, e5</div>'
                    }
                ]
            },
            'bishop': {
                title: 'Bishop & Diagonal Control',
                steps: [
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'Bishop Starting Position',
                        content: '<p>Bishops move <span class="highlight-text">diagonally</span> any number of squares. Each bishop stays on its original color for the entire game.</p><ul class="key-points"><li>White\'s light-squared bishop starts on c1 (light squares)</li><li>White\'s dark-squared bishop starts on f1 (dark squares)</li><li>Black\'s bishops start on c8 and f8</li></ul>'
                    },
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','B','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','','Q','K','B','N','R']
                        ],
                        title: 'Bishop Movement Pattern',
                        content: '<p>Bishops control <span class="highlight-text">diagonal lines</span> across the board. They are powerful on open diagonals.</p><div class="example">♗ From d5, the bishop controls: c4, b3, a2, c6, b7, a8, e4, f3, g2, h1, e6, f7, g8</div>'
                    }
                ]
            },
            'rook': {
                title: 'Rook & Open Files',
                steps: [
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'Rook Starting Position',
                        content: '<p>Rooks move <span class="highlight-text">horizontally or vertically</span> any number of squares. They are most powerful on open files.</p><ul class="key-points"><li>White rooks start on a1 and h1</li><li>Black rooks start on a8 and h8</li><li>Rooks control ranks (rows) and files (columns)</li></ul>'
                    }
                ]
            },
            'queen': {
                title: 'Queen & Attacking Combinations',
                steps: [
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'Queen Starting Position',
                        content: '<p>The queen is the <span class="highlight-text">most powerful piece</span>, combining the movement of rook and bishop.</p><ul class="key-points"><li>White queen starts on d1</li><li>Black queen starts on d8</li><li>The queen moves like a rook AND a bishop combined</li></ul>'
                    }
                ]
            },
            'king': {
                title: 'King Safety & Endgame',
                steps: [
                    {
                        board: [
                            ['r','n','b','q','k','b','n','r'],
                            ['p','p','p','p','p','p','p','p'],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['','','','','','','',''],
                            ['P','P','P','P','P','P','P','P'],
                            ['R','N','B','Q','K','B','N','R']
                        ],
                        title: 'King Starting Position',
                        content: '<p>The king moves <span class="highlight-text">one square in any direction</span>. Protecting the king is the most important priority in chess.</p><ul class="key-points"><li>White king starts on e1</li><li>Black king starts on e8</li><li>The king can never move into check</li></ul>'
                    }
                ]
            }
        };

        // ===== BOARD RENDER FUNCTIONS =====
        function renderLearningBoard() {
            const boardEl = document.getElementById('learningBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            const board = learningSteps[learningStep]?.board || [];
            if (board.length === 0) return;
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isLearningFlipped ? 7 - row : row;
                    const actualCol = isLearningFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    
                    const piece = board[actualRow]?.[actualCol] || '';
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    // Coordinates
                    if (col === 0) {
                        const rank = document.createElement('span');
                        rank.className = 'coords rank';
                        rank.textContent = 8 - actualRow;
                        square.appendChild(rank);
                    }
                    if (row === 7) {
                        const file = document.createElement('span');
                        file.className = 'coords file';
                        file.textContent = 'abcdefgh'[actualCol];
                        square.appendChild(file);
                    }
                    
                    boardEl.appendChild(square);
                }
            }
            
            // Update UI
            updateLearningUI();
        }

        function updateLearningUI() {
            const step = learningSteps[learningStep];
            if (!step) return;
            
            document.getElementById('boardLessonTitle').textContent = step.title;
            document.getElementById('lessonPanelTitle').textContent = step.title;
            document.getElementById('lessonContent').innerHTML = step.content;
            document.getElementById('boardStepIndicator').textContent = `Step ${learningStep + 1}/${learningSteps.length}`;
            
            const progress = ((learningStep + 1) / learningSteps.length) * 100;
            document.getElementById('lessonProgressBar').style.width = progress + '%';
            
            document.getElementById('prevStepBtn').disabled = learningStep === 0;
            document.getElementById('nextStepBtn').disabled = learningStep >= learningSteps.length - 1;
        }

        // ===== NAVIGATION FUNCTIONS =====
        function nextLearningStep() {
            if (learningStep < learningSteps.length - 1) {
                learningStep++;
                renderLearningBoard();
                if (isAutoPlaying) {
                    clearTimeout(autoPlayInterval);
                    autoPlayInterval = setTimeout(() => nextLearningStep(), 2000);
                }
            }
        }

        function prevLearningStep() {
            if (learningStep > 0) {
                learningStep--;
                renderLearningBoard();
                if (isAutoPlaying) {
                    clearTimeout(autoPlayInterval);
                    autoPlayInterval = setTimeout(() => nextLearningStep(), 2000);
                }
            }
        }

        function resetLearningBoard() {
            learningStep = 0;
            renderLearningBoard();
            if (isAutoPlaying) {
                clearTimeout(autoPlayInterval);
                autoPlayInterval = setTimeout(() => nextLearningStep(), 2000);
            }
        }

        function flipLearningBoard() {
            isLearningFlipped = !isLearningFlipped;
            renderLearningBoard();
        }

        function toggleAutoPlay() {
            isAutoPlaying = !isAutoPlaying;
            const btn = document.getElementById('autoPlayBtn');
            if (isAutoPlaying) {
                btn.innerHTML = '<i class="fas fa-pause"></i> Pause';
                if (learningStep < learningSteps.length - 1) {
                    autoPlayInterval = setTimeout(() => nextLearningStep(), 2000);
                }
            } else {
                btn.innerHTML = '<i class="fas fa-play"></i> Auto';
                clearTimeout(autoPlayInterval);
            }
        }

        // ===== LOAD LESSON FUNCTIONS =====
        function loadLessonPreset(lessonKey) {
            const lesson = LESSONS[lessonKey];
            if (!lesson) return;
            
            learningSteps = lesson.steps;
            learningStep = 0;
            isLearningFlipped = false;
            
            if (isAutoPlaying) {
                clearTimeout(autoPlayInterval);
                isAutoPlaying = false;
                document.getElementById('autoPlayBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
            }
            
            renderLearningBoard();
            
            // Scroll to board
            document.querySelector('.learning-board-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
            
            return false;
        }

        function loadLesson(id) {
            const keys = Object.keys(LESSONS);
            const randomKey = keys[Math.floor(Math.random() * keys.length)];
            loadLessonPreset(randomKey);
            return false;
        }

        // ===== KEYBOARD SHORTCUTS =====
        document.addEventListener('keydown', function(e) {
            // Learning board shortcuts (only when not focused on input)
            if (document.activeElement?.tagName !== 'INPUT') {
                if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                    e.preventDefault();
                    nextLearningStep();
                } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                    e.preventDefault();
                    prevLearningStep();
                } else if (e.key === 'r' || e.key === 'R') {
                    resetLearningBoard();
                } else if (e.key === 'f' && !e.ctrlKey && !e.metaKey) {
                    // Don't intercept Ctrl+F or Cmd+F
                    if (!e.ctrlKey && !e.metaKey) {
                        e.preventDefault();
                        flipLearningBoard();
                    }
                } else if (e.key === ' ') {
                    e.preventDefault();
                    // Toggle video play if video is visible
                    const rect = video.getBoundingClientRect();
                    if (rect.top < window.innerHeight && rect.bottom > 0) {
                        toggleVideoPlay();
                    } else {
                        toggleAutoPlay();
                    }
                }
            }
        });

        // ===== CATEGORY FILTER =====
        function filterCategory(category) {
            document.querySelectorAll('.category-filters button').forEach(btn => {
                btn.classList.toggle('active', btn.textContent.toLowerCase() === category || 
                    (category === 'all' && btn.textContent === 'All'));
            });

            const cards = document.querySelectorAll('#lessonGrid .card');
            cards.forEach(card => {
                if (category === 'all' || card.dataset.category === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        function filterLessons() {
            const searchTerm = document.getElementById('lessonSearch').value.toLowerCase();
            const cards = document.querySelectorAll('#lessonGrid .card');
            
            cards.forEach(card => {
                const title = card.querySelector('h3')?.textContent?.toLowerCase() || '';
                const desc = card.querySelector('p')?.textContent?.toLowerCase() || '';
                
                if (title.includes(searchTerm) || desc.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // ===== NAVBAR SCROLL =====
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== INIT =====
        document.addEventListener('DOMContentLoaded', function() {
            // Load default lesson
            loadLessonPreset('pawn');
            
            // Initialize video player
            renderPlaylist();
            
            // Load first video
            playVideo(0);
            
            // Make video functions globally accessible
            window.toggleVideoPlay = toggleVideoPlay;
            window.skipVideo = skipVideo;
            window.setVideoProgress = setVideoProgress;
            window.setVolume = setVolume;
            window.toggleMute = toggleMute;
            window.toggleFullscreen = toggleFullscreen;
            window.playVideoFromCard = playVideoFromCard;
            window.playVideo = playVideo;
            window.renderPlaylist = renderPlaylist;
        });
    </script>
</body>
</html>