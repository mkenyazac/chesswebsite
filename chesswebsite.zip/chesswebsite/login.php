<?php
/**
 * Chess Heaven - Login & Registration Page
 * Supports Admin, Coach, and Member roles with database authentication
 */
require_once 'config.php';

// Get redirect URL from query string
$redirect = isset($_GET['redirect']) ? $_GET['redirect'] : 'index.php';

// Get settings
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');

// Check if user is already logged in
if (isset($_SESSION['user_id']) && isset($_SESSION['role'])) {
    switch ($_SESSION['role']) {
        case 'admin':
            header('Location: admindashboard.php');
            break;
        case 'coach':
            header('Location: coachdashboard.php');
            break;
        case 'member':
        default:
            header('Location: userdashboard.php');
            break;
    }
    exit;
}

// Helper functions (in case they're not in config.php)
if (!function_exists('getUserByUsername')) {
    function getUserByUsername($username) {
        $conn = getDBConnection();
        if (!$conn) return null;
        $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}

if (!function_exists('getUserByEmail')) {
    function getUserByEmail($email) {
        $conn = getDBConnection();
        if (!$conn) return null;
        $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}

if (!function_exists('getAdminData')) {
    function getAdminData($userId) {
        $conn = getDBConnection();
        if (!$conn) return null;
        $stmt = $conn->prepare("SELECT * FROM admins WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}

if (!function_exists('getCoachData')) {
    function getCoachData($userId) {
        $conn = getDBConnection();
        if (!$conn) return null;
        $stmt = $conn->prepare("SELECT * FROM coaches WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}

if (!function_exists('getMemberData')) {
    function getMemberData($userId) {
        $conn = getDBConnection();
        if (!$conn) return null;
        $stmt = $conn->prepare("SELECT * FROM members WHERE user_id = ?");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc();
    }
}

if (!function_exists('updateLastLogin')) {
    function updateLastLogin($userId) {
        $conn = getDBConnection();
        if (!$conn) return false;
        $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $stmt->bind_param("i", $userId);
        return $stmt->execute();
    }
}

// Handle login form submission
$error = '';
$success = '';
$activeTab = 'login';

// LOGIN HANDLING
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $password = isset($_POST['password']) ? $_POST['password'] : '';
    $remember = isset($_POST['remember']) ? true : false;
    
    if (empty($username) || empty($password)) {
        $error = 'Please enter both username and password.';
    } else {
        $conn = getDBConnection();
        if ($conn) {
            // Check username first, then email
            $user = getUserByUsername($username);
            if (!$user) {
                $user = getUserByEmail($username);
            }
            
            if ($user && password_verify($password, $user['password'])) {
                // Check if user is active
                if ($user['is_active'] != 1) {
                    $error = 'Your account has been deactivated. Please contact support.';
                } else {
                    // Set session
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $user['username'];
                    $_SESSION['email'] = $user['email'];
                    $_SESSION['role'] = $user['role'];
                    $_SESSION['display_name'] = $user['display_name'] ?: $user['username'];
                    $_SESSION['logged_in'] = true;
                    
                    // Set role-specific session data from respective tables
                    switch ($user['role']) {
                        case 'admin':
                            $adminData = getAdminData($user['id']);
                            if ($adminData) {
                                $_SESSION['admin_level'] = $adminData['admin_level'] ?? 'moderator';
                                $_SESSION['department'] = $adminData['department'] ?? 'General';
                                $_SESSION['can_manage_users'] = $adminData['can_manage_users'] ?? 1;
                                $_SESSION['can_manage_coaches'] = $adminData['can_manage_coaches'] ?? 1;
                                $_SESSION['can_manage_tournaments'] = $adminData['can_manage_tournaments'] ?? 1;
                                $_SESSION['can_view_reports'] = $adminData['can_view_reports'] ?? 1;
                                $_SESSION['admin_phone'] = $adminData['phone'] ?? '';
                                $_SESSION['permissions'] = json_decode($adminData['permissions'] ?? '{}', true);
                            }
                            break;
                            
                        case 'coach':
                            $coachData = getCoachData($user['id']);
                            if ($coachData) {
                                $_SESSION['coach_level'] = $coachData['coach_level'] ?? 'junior';
                                $_SESSION['specialization'] = $coachData['specialization'] ?? 'General';
                                $_SESSION['experience_years'] = $coachData['experience_years'] ?? 0;
                                $_SESSION['certification'] = $coachData['certification'] ?? '';
                                $_SESSION['coach_phone'] = $coachData['phone'] ?? '';
                                $_SESSION['rating'] = $coachData['rating'] ?? 1200;
                                $_SESSION['is_available'] = $coachData['is_available'] ?? 1;
                                $_SESSION['max_students'] = $coachData['max_students'] ?? 20;
                                $_SESSION['hourly_rate'] = $coachData['hourly_rate'] ?? 0;
                                $_SESSION['biography'] = $coachData['biography'] ?? '';
                            }
                            break;
                            
                        case 'member':
                        default:
                            $memberData = getMemberData($user['id']);
                            if ($memberData) {
                                $_SESSION['rating'] = $memberData['rating'] ?? 1200;
                                $_SESSION['country'] = $memberData['country'] ?? 'Unknown';
                                $_SESSION['city'] = $memberData['city'] ?? '';
                                $_SESSION['games_played'] = $memberData['games_played'] ?? 0;
                                $_SESSION['games_won'] = $memberData['games_won'] ?? 0;
                                $_SESSION['games_drawn'] = $memberData['games_drawn'] ?? 0;
                                $_SESSION['games_lost'] = $memberData['games_lost'] ?? 0;
                                $_SESSION['current_streak'] = $memberData['current_streak'] ?? 0;
                                $_SESSION['best_streak'] = $memberData['best_streak'] ?? 0;
                                $_SESSION['membership_type'] = $memberData['membership_type'] ?? 'free';
                                $_SESSION['favorite_opening'] = $memberData['favorite_opening'] ?? '';
                                $_SESSION['favorite_piece'] = $memberData['favorite_piece'] ?? '';
                            }
                            break;
                    }
                    
                    // Update last login
                    updateLastLogin($user['id']);
                    
                    // Set remember me cookie if checked
                    if ($remember) {
                        setcookie('chessheaven_username', $username, time() + (86400 * 30), '/');
                    }
                    
                    // Redirect based on role
                    switch ($user['role']) {
                        case 'admin':
                            header('Location: admindashboard.php');
                            break;
                        case 'coach':
                            header('Location: coachdashboard.php');
                            break;
                        case 'member':
                        default:
                            header('Location: userdashboard.php');
                            break;
                    }
                    exit;
                }
            } else {
                $error = 'Invalid username or password. Please try again.';
            }
        } else {
            $error = 'Database connection error. Please try again later.';
        }
    }
}

// REGISTRATION HANDLING
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register'])) {
    $reg_username = isset($_POST['reg_username']) ? trim($_POST['reg_username']) : '';
    $reg_email = isset($_POST['reg_email']) ? trim($_POST['reg_email']) : '';
    $reg_password = isset($_POST['reg_password']) ? $_POST['reg_password'] : '';
    $reg_confirm_password = isset($_POST['reg_confirm_password']) ? $_POST['reg_confirm_password'] : '';
    $reg_role = isset($_POST['reg_role']) ? $_POST['reg_role'] : 'member';
    $reg_display_name = isset($_POST['reg_display_name']) ? trim($_POST['reg_display_name']) : '';
    
    // Validation
    if (empty($reg_username) || empty($reg_email) || empty($reg_password) || empty($reg_confirm_password)) {
        $error = 'Please fill in all required fields.';
    } elseif (!filter_var($reg_email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (strlen($reg_username) < 3) {
        $error = 'Username must be at least 3 characters long.';
    } elseif (strlen($reg_password) < 6) {
        $error = 'Password must be at least 6 characters long.';
    } elseif ($reg_password !== $reg_confirm_password) {
        $error = 'Passwords do not match.';
    } else {
        $conn = getDBConnection();
        if ($conn) {
            // Check if username or email already exists
            $check = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $check->bind_param("ss", $reg_username, $reg_email);
            $check->execute();
            $check_result = $check->get_result();
            
            if ($check_result->num_rows > 0) {
                $error = 'Username or email already exists. Please choose different ones.';
            } else {
                // Begin transaction
                $conn->begin_transaction();
                
                try {
                    // Hash password and insert user
                    $hashed_password = password_hash($reg_password, PASSWORD_DEFAULT);
                    $display_name = !empty($reg_display_name) ? $reg_display_name : $reg_username;
                    
                    $stmt = $conn->prepare("INSERT INTO users (username, email, password, role, display_name, is_active) VALUES (?, ?, ?, ?, ?, 1)");
                    $stmt->bind_param("sssss", $reg_username, $reg_email, $hashed_password, $reg_role, $display_name);
                    
                    if ($stmt->execute()) {
                        $userId = $conn->insert_id;
                        
                        // Insert role-specific data
                        switch ($reg_role) {
                            case 'admin':
                                $stmt2 = $conn->prepare("INSERT INTO admins (user_id, admin_level, department, can_manage_users, can_manage_coaches, can_manage_tournaments, can_view_reports) VALUES (?, 'moderator', 'General', 1, 1, 1, 1)");
                                $stmt2->bind_param("i", $userId);
                                $stmt2->execute();
                                break;
                            case 'coach':
                                $stmt2 = $conn->prepare("INSERT INTO coaches (user_id, coach_level, rating, is_available, max_students) VALUES (?, 'junior', 1200, 1, 20)");
                                $stmt2->bind_param("i", $userId);
                                $stmt2->execute();
                                break;
                            case 'member':
                            default:
                                $stmt2 = $conn->prepare("INSERT INTO members (user_id, rating, country, membership_type, games_played, games_won, games_drawn, games_lost) VALUES (?, 1200, 'Unknown', 'free', 0, 0, 0, 0)");
                                $stmt2->bind_param("i", $userId);
                                $stmt2->execute();
                                break;
                        }
                        
                        // Create user stats
                        $stmt3 = $conn->prepare("INSERT INTO user_stats (user_id, rating, games_played, games_won, games_drawn, games_lost) VALUES (?, 1200, 0, 0, 0, 0)");
                        $stmt3->bind_param("i", $userId);
                        $stmt3->execute();
                        
                        $conn->commit();
                        $success = 'Registration successful! You can now login with your credentials.';
                        $activeTab = 'login';
                    } else {
                        throw new Exception('Registration failed');
                    }
                } catch (Exception $e) {
                    $conn->rollback();
                    $error = 'Registration failed: ' . $e->getMessage();
                }
            }
        } else {
            $error = 'Database connection error. Please try again later.';
        }
    }
}

// Check for remember me cookie
$remembered_username = '';
if (isset($_COOKIE['chessheaven_username']) && !isset($_SESSION['user_id'])) {
    $remembered_username = $_COOKIE['chessheaven_username'];
}

// Determine active tab based on GET parameter
if (isset($_GET['tab']) && $_GET['tab'] === 'register') {
    $activeTab = 'register';
}

// Get login features for display
$loginFeatures = getLoginFeatures();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · <?php echo $activeTab === 'login' ? 'Login' : 'Register'; ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }

        body {
            min-height: 100vh;
            background: radial-gradient(circle at 30% 20%, #3a1a1a, #0a0505);
            color: #f0e0d0;
            overflow-x: hidden;
            padding-top: var(--nav-height);
            display: flex;
            flex-direction: column;
        }

        a { text-decoration: none; color: inherit; }

        /* ===== FIXED NAVIGATION ===== */
        .navbar-fixed {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            z-index: 9999;
            background: rgba(10, 5, 5, 0.92);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-bottom: 1px solid rgba(201, 168, 124, 0.12);
            box-shadow: 0 4px 30px rgba(0, 0, 0, 0.8);
            padding: 0.5rem 2rem;
            transition: all 0.3s ease;
        }

        .navbar-fixed.scrolled {
            background: rgba(10, 5, 5, 0.98);
            box-shadow: 0 4px 40px rgba(0, 0, 0, 0.9);
        }

        .navbar-container {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 1rem;
        }

        .navbar-logo {
            display: flex;
            align-items: center;
            gap: 0.8rem;
            text-decoration: none;
            flex-shrink: 0;
        }

        .navbar-logo .logo-icon {
            font-size: 1.8rem;
            color: var(--secondary);
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            padding: 0.4rem;
            border-radius: 50%;
            width: 44px;
            height: 44px;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 15px rgba(139, 26, 26, 0.4);
        }

        .navbar-logo .logo-text {
            font-size: 1.3rem;
            font-weight: 700;
            background: linear-gradient(135deg, #f0d6b0, #d4a080);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            letter-spacing: -0.5px;
        }

        .nav-links {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 0.2rem 1rem;
            margin: 0;
            padding: 0;
        }

        .nav-links a {
            color: #d4c0b0;
            text-decoration: none;
            font-weight: 500;
            font-size: 0.85rem;
            letter-spacing: 0.3px;
            padding: 0.5rem 0.3rem;
            border-bottom: 2px solid transparent;
            transition: 0.25s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.4rem;
            white-space: nowrap;
        }

        .nav-links a i {
            color: var(--secondary);
            font-size: 0.8rem;
        }

        .nav-links a:hover {
            color: #f0d6b0;
            border-bottom-color: var(--secondary);
            transform: translateY(-1px);
        }

        .nav-links .active-link {
            color: #f0d6b0;
            border-bottom-color: var(--gold);
        }

        .menu-toggle {
            display: none;
            flex-direction: column;
            gap: 4px;
            background: transparent;
            border: none;
            cursor: pointer;
            padding: 0.5rem;
            z-index: 10001;
        }

        .menu-toggle span {
            display: block;
            width: 28px;
            height: 2.5px;
            background: #f0d6b0;
            border-radius: 2px;
            transition: all 0.3s ease;
        }

        .menu-toggle.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
        }
        .menu-toggle.active span:nth-child(2) {
            opacity: 0;
        }
        .menu-toggle.active span:nth-child(3) {
            transform: rotate(-45deg) translate(5px, -5px);
        }

        /* ===== AUTH SECTION ===== */
        .auth-section {
            flex: 1;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
            min-height: calc(100vh - var(--nav-height) - 200px);
        }

        .auth-container {
            width: 100%;
            max-width: 480px;
            background: rgba(10, 5, 5, 0.7);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-radius: 2rem;
            padding: 2.5rem;
            border: 1px solid rgba(201, 168, 124, 0.12);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6);
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .auth-header {
            text-align: center;
            margin-bottom: 2rem;
        }

        .auth-header .auth-icon {
            font-size: 3rem;
            color: var(--secondary);
            background: rgba(201, 168, 124, 0.1);
            width: 80px;
            height: 80px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1rem auto;
            border: 2px solid rgba(201, 168, 124, 0.15);
        }

        .auth-header h1 {
            font-size: 2rem;
            font-weight: 700;
            color: #f0d6b0;
            margin-bottom: 0.3rem;
        }

        .auth-header p {
            color: #a09080;
            font-size: 0.95rem;
        }

        /* ===== TABS ===== */
        .auth-tabs {
            display: flex;
            gap: 0;
            margin-bottom: 1.5rem;
            border-radius: 1rem;
            overflow: hidden;
            border: 1px solid rgba(201, 168, 124, 0.1);
            background: rgba(10, 5, 5, 0.3);
        }

        .auth-tab {
            flex: 1;
            padding: 0.8rem;
            text-align: center;
            border: none;
            background: transparent;
            color: #a09080;
            font-weight: 600;
            font-size: 0.95rem;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .auth-tab:hover {
            color: #d4c0b0;
        }

        .auth-tab.active {
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            color: white;
            box-shadow: 0 4px 15px rgba(139, 26, 26, 0.3);
        }

        .auth-tab i {
            margin-right: 0.5rem;
        }

        /* ===== ALERTS ===== */
        .alert {
            padding: 0.8rem 1rem;
            border-radius: 0.8rem;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.8rem;
            font-size: 0.9rem;
        }

        .alert i {
            font-size: 1.2rem;
        }

        .alert-error {
            background: rgba(255, 50, 50, 0.1);
            border: 1px solid rgba(255, 50, 50, 0.2);
            color: #ff6b6b;
        }

        .alert-success {
            background: rgba(50, 200, 50, 0.1);
            border: 1px solid rgba(50, 200, 50, 0.2);
            color: #50d050;
        }

        /* ===== FORM ===== */
        .form-group {
            margin-bottom: 1.2rem;
        }

        .form-group label {
            display: block;
            color: #d4c0b0;
            font-size: 0.9rem;
            font-weight: 600;
            margin-bottom: 0.3rem;
        }

        .form-group label .required {
            color: #e74c3c;
        }

        .form-group .input-wrapper {
            position: relative;
        }

        .form-group .input-wrapper i {
            position: absolute;
            left: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #5a4a3a;
            font-size: 1rem;
        }

        .form-group .input-wrapper input,
        .form-group .input-wrapper select {
            width: 100%;
            padding: 0.8rem 1rem 0.8rem 2.8rem;
            border-radius: 0.8rem;
            border: 1px solid rgba(201, 168, 124, 0.15);
            background: rgba(10, 5, 5, 0.4);
            color: #f0d6b0;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            outline: none;
        }

        .form-group .input-wrapper select {
            appearance: none;
            padding-right: 2.5rem;
            cursor: pointer;
        }

        .form-group .input-wrapper select option {
            background: #1a0a0a;
            color: #f0d6b0;
        }

        .form-group .input-wrapper input::placeholder {
            color: #5a4a3a;
        }

        .form-group .input-wrapper input:focus,
        .form-group .input-wrapper select:focus {
            border-color: var(--secondary);
            box-shadow: 0 0 20px rgba(201, 168, 124, 0.1);
            background: rgba(10, 5, 5, 0.6);
        }

        .form-group .input-wrapper .toggle-password {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #5a4a3a;
            cursor: pointer;
            font-size: 1rem;
            transition: 0.3s;
        }

        .form-group .input-wrapper .toggle-password:hover {
            color: var(--secondary);
        }

        .form-group .input-wrapper .select-arrow {
            position: absolute;
            right: 1rem;
            top: 50%;
            transform: translateY(-50%);
            color: #5a4a3a;
            pointer-events: none;
        }

        /* ===== REMEMBER ME & FORGOT PASSWORD ===== */
        .form-options {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin: 1rem 0 1.5rem 0;
            flex-wrap: wrap;
            gap: 0.5rem;
        }

        .form-options .remember-me {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            color: #a09080;
            font-size: 0.9rem;
            cursor: pointer;
        }

        .form-options .remember-me input[type="checkbox"] {
            width: 18px;
            height: 18px;
            accent-color: var(--secondary);
            cursor: pointer;
        }

        .form-options .forgot-password {
            color: var(--secondary);
            text-decoration: none;
            font-size: 0.9rem;
            transition: 0.3s;
        }

        .form-options .forgot-password:hover {
            color: #f0d6b0;
            text-decoration: underline;
        }

        /* ===== ROLE HINT ===== */
        .role-hint {
            font-size: 0.75rem;
            color: #5a4a3a;
            margin-top: 0.3rem;
            display: flex;
            align-items: center;
            gap: 0.3rem;
        }

        .role-hint i {
            color: var(--secondary);
        }

        /* ===== SUBMIT BUTTON ===== */
        .btn-submit {
            width: 100%;
            padding: 1rem;
            border: none;
            border-radius: 1rem;
            font-weight: 700;
            font-size: 1.1rem;
            color: white;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            box-shadow: 0 4px 15px rgba(139, 26, 26, 0.4);
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.8rem;
        }

        .btn-submit:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(139, 26, 26, 0.6);
        }

        .btn-submit:active {
            transform: translateY(0);
        }

        /* ===== SWITCH LINK ===== */
        .switch-link {
            text-align: center;
            margin-top: 1.5rem;
            color: #a09080;
            font-size: 0.95rem;
        }

        .switch-link a {
            color: var(--secondary);
            text-decoration: none;
            font-weight: 600;
            transition: 0.3s;
        }

        .switch-link a:hover {
            color: #f0d6b0;
            text-decoration: underline;
        }

        /* ===== SOCIAL LOGIN ===== */
        .social-login {
            margin-top: 1.5rem;
        }

        .social-login .divider {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1rem;
            color: #5a4a3a;
            font-size: 0.85rem;
        }

        .social-login .divider::before,
        .social-login .divider::after {
            content: '';
            flex: 1;
            height: 1px;
            background: rgba(201, 168, 124, 0.1);
        }

        .social-buttons {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.8rem;
        }

        .social-btn {
            padding: 0.7rem;
            border: 1px solid rgba(201, 168, 124, 0.15);
            border-radius: 0.8rem;
            background: rgba(10, 5, 5, 0.3);
            color: #d4c0b0;
            font-weight: 600;
            font-size: 0.85rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .social-btn:hover {
            background: rgba(201, 168, 124, 0.1);
            border-color: var(--secondary);
            transform: translateY(-2px);
        }

        .social-btn.google {
            color: #ea4335;
        }
        .social-btn.facebook {
            color: #1877f2;
        }
        .social-btn.apple {
            color: #f0d6b0;
        }
        .social-btn.github {
            color: #6e5494;
        }

        /* ===== FEATURES SECTION ===== */
        .auth-features {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 1rem;
            max-width: 900px;
            margin: 2rem auto 0;
            padding: 0 2rem;
        }

        .auth-features .feature-item {
            background: var(--card-bg);
            border: 1px solid var(--border-color);
            border-radius: 1rem;
            padding: 1rem;
            text-align: center;
            transition: all 0.3s;
        }

        .auth-features .feature-item:hover {
            background: rgba(139, 26, 26, 0.12);
            border-color: var(--secondary);
            transform: translateY(-3px);
        }

        .auth-features .feature-item i {
            font-size: 1.5rem;
            color: var(--secondary);
            margin-bottom: 0.3rem;
        }

        .auth-features .feature-item h4 {
            color: #f0d6b0;
            font-size: 0.85rem;
        }

        .auth-features .feature-item p {
            color: #7a6a5a;
            font-size: 0.75rem;
            margin-top: 0.2rem;
        }

        /* ===== FOOTER ===== */
        .footer {
            margin-top: 0;
            padding: 3rem 2rem 2rem;
            border-top: 1px solid var(--border-color);
            display: grid;
            grid-template-columns: 2fr 1fr 1fr 1fr;
            gap: 2rem;
            max-width: 1400px;
            margin-left: auto;
            margin-right: auto;
        }

        .footer a {
            display: block;
            color: #7a6a5a;
            transition: 0.3s;
            padding: 0.2rem 0;
            font-size: 0.9rem;
        }

        .footer a:hover {
            color: #f0d6b0;
        }

        .footer h4 {
            color: #f0d6b0;
            margin-bottom: 0.8rem;
        }

        .footer .footer-bottom {
            grid-column: 1/-1;
            text-align: center;
            padding-top: 2rem;
            border-top: 1px solid var(--border-color);
            color: #5a4a3a;
            font-size: 0.85rem;
        }

        .footer .footer-bottom a {
            display: inline;
            color: #7a6a5a;
        }

        .footer .footer-bottom a:hover {
            color: #f0d6b0;
        }

        .newsletter input {
            padding: 0.6rem 1rem;
            border-radius: 2rem;
            border: 1px solid var(--border-color);
            background: rgba(255, 255, 255, 0.05);
            color: #f0e0d0;
            width: 100%;
            margin-bottom: 0.5rem;
        }

        .newsletter button {
            padding: 0.6rem 1.5rem;
            border-radius: 2rem;
            border: none;
            background: linear-gradient(145deg, var(--primary), var(--primary-dark));
            color: white;
            font-weight: 600;
            cursor: pointer;
            width: 100%;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 768px) {
            :root {
                --nav-height: 60px;
            }

            .navbar-fixed {
                padding: 0.5rem 1rem;
            }

            .nav-links {
                display: none;
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                flex-direction: column;
                align-items: stretch;
                background: rgba(10, 5, 5, 0.98);
                backdrop-filter: blur(16px);
                padding: 1rem;
                border-top: 1px solid rgba(201, 168, 124, 0.1);
                border-bottom: 1px solid rgba(201, 168, 124, 0.1);
                gap: 0.2rem;
                max-height: 80vh;
                overflow-y: auto;
            }

            .nav-links.open {
                display: flex;
            }

            .nav-links a {
                padding: 0.6rem 0.8rem;
                font-size: 0.9rem;
                border-bottom: 1px solid rgba(139, 26, 26, 0.15);
                white-space: normal;
            }

            .menu-toggle {
                display: flex;
            }

            .auth-container {
                padding: 1.5rem;
            }

            .auth-header h1 {
                font-size: 1.6rem;
            }

            .auth-features {
                grid-template-columns: 1fr 1fr;
                padding: 0 1rem;
            }

            .footer {
                grid-template-columns: 1fr 1fr;
                padding: 2rem 1rem;
            }
        }

        @media (max-width: 480px) {
            .navbar-logo .logo-text {
                font-size: 1rem;
            }

            .navbar-logo .logo-icon {
                width: 36px;
                height: 36px;
                font-size: 1.4rem;
            }

            .auth-container {
                padding: 1.2rem;
                border-radius: 1.2rem;
            }

            .auth-header .auth-icon {
                width: 60px;
                height: 60px;
                font-size: 2rem;
            }

            .social-buttons {
                grid-template-columns: 1fr;
            }

            .form-options {
                flex-direction: column;
                align-items: flex-start;
            }

            .auth-tab {
                font-size: 0.8rem;
                padding: 0.6rem;
            }

            .auth-features {
                grid-template-columns: 1fr;
                padding: 0 0.5rem;
            }

            .footer {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- ===== FIXED NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar" role="navigation" aria-label="Main navigation">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>

            <button class="menu-toggle" id="menuToggle" aria-label="Toggle menu">
                <span></span>
                <span></span>
                <span></span>
            </button>

            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
        </div>
    </nav>

    <!-- ===== AUTH SECTION ===== -->
    <section class="auth-section">
        <div class="auth-container">
            <div class="auth-header">
                <div class="auth-icon">
                    <i class="fas fa-chess-king"></i>
                </div>
                <h1><?php echo $activeTab === 'login' ? 'Welcome Back' : 'Join Chess Heaven'; ?></h1>
                <p><?php echo $activeTab === 'login' ? 'Sign in to your account' : 'Create your account and start playing'; ?></p>
            </div>

            <!-- Tabs -->
            <div class="auth-tabs">
                <button class="auth-tab <?php echo $activeTab === 'login' ? 'active' : ''; ?>" onclick="switchTab('login')">
                    <i class="fas fa-sign-in-alt"></i> Login
                </button>
                <button class="auth-tab <?php echo $activeTab === 'register' ? 'active' : ''; ?>" onclick="switchTab('register')">
                    <i class="fas fa-user-plus"></i> Register
                </button>
            </div>

            <!-- Error/Success Messages -->
            <?php if ($error): ?>
                <div class="alert alert-error">
                    <i class="fas fa-exclamation-circle"></i>
                    <?php echo e($error); ?>
                </div>
            <?php endif; ?>

            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i>
                    <?php echo e($success); ?>
                </div>
            <?php endif; ?>

            <!-- ===== LOGIN FORM ===== -->
            <div id="loginForm" style="display: <?php echo $activeTab === 'login' ? 'block' : 'none'; ?>">
                <form method="POST" action="">
                    <input type="hidden" name="login" value="1">
                    <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
                    
                    <div class="form-group">
                        <label>Username or Email</label>
                        <div class="input-wrapper">
                            <i class="fas fa-user"></i>
                            <input type="text" name="username" placeholder="Enter your username or email" 
                                   value="<?php echo isset($remembered_username) ? e($remembered_username) : ''; ?>" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Password</label>
                        <div class="input-wrapper">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="password" id="loginPassword" placeholder="Enter your password" required>
                            <button type="button" class="toggle-password" onclick="togglePassword('loginPassword', 'loginIcon')">
                                <i class="fas fa-eye" id="loginIcon"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-options">
                        <label class="remember-me">
                            <input type="checkbox" name="remember" <?php echo isset($remembered_username) ? 'checked' : ''; ?>>
                            Remember me
                        </label>
                        <a href="forgot-password.php" class="forgot-password">Forgot password?</a>
                    </div>

                    <button type="submit" class="btn-submit">
                        <i class="fas fa-sign-in-alt"></i> Sign In
                    </button>
                </form>

                <div class="switch-link">
                    Don't have an account? <a href="#" onclick="switchTab('register')">Create one now</a>
                </div>

                <!-- Social Login -->
                <div class="social-login">
                    <div class="divider">or continue with</div>
                    <div class="social-buttons">
                        <a href="#" class="social-btn google" onclick="socialLogin('google')">
                            <i class="fab fa-google"></i> Google
                        </a>
                        <a href="#" class="social-btn facebook" onclick="socialLogin('facebook')">
                            <i class="fab fa-facebook"></i> Facebook
                        </a>
                        <a href="#" class="social-btn apple" onclick="socialLogin('apple')">
                            <i class="fab fa-apple"></i> Apple
                        </a>
                        <a href="#" class="social-btn github" onclick="socialLogin('github')">
                            <i class="fab fa-github"></i> GitHub
                        </a>
                    </div>
                </div>
            </div>

            <!-- ===== REGISTER FORM ===== -->
            <div id="registerForm" style="display: <?php echo $activeTab === 'register' ? 'block' : 'none'; ?>">
                <form method="POST" action="">
                    <input type="hidden" name="register" value="1">
                    <input type="hidden" name="redirect" value="<?php echo e($redirect); ?>">
                    
                    <div class="form-group">
                        <label>Username <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i class="fas fa-user"></i>
                            <input type="text" name="reg_username" placeholder="Choose a username (min 3 chars)" required 
                                   value="<?php echo isset($_POST['reg_username']) ? e($_POST['reg_username']) : ''; ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Display Name</label>
                        <div class="input-wrapper">
                            <i class="fas fa-id-card"></i>
                            <input type="text" name="reg_display_name" placeholder="How you want to be displayed" 
                                   value="<?php echo isset($_POST['reg_display_name']) ? e($_POST['reg_display_name']) : ''; ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Email Address <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i class="fas fa-envelope"></i>
                            <input type="email" name="reg_email" placeholder="Enter your email" required 
                                   value="<?php echo isset($_POST['reg_email']) ? e($_POST['reg_email']) : ''; ?>">
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Password <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i class="fas fa-lock"></i>
                            <input type="password" name="reg_password" id="regPassword" placeholder="Min 6 characters" required>
                            <button type="button" class="toggle-password" onclick="togglePassword('regPassword', 'regIcon')">
                                <i class="fas fa-eye" id="regIcon"></i>
                            </button>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Confirm Password <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i class="fas fa-check-circle"></i>
                            <input type="password" name="reg_confirm_password" id="regConfirmPassword" placeholder="Confirm your password" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Role <span class="required">*</span></label>
                        <div class="input-wrapper">
                            <i class="fas fa-user-tag"></i>
                            <select name="reg_role" required>
                                <option value="member" <?php echo (isset($_POST['reg_role']) && $_POST['reg_role'] == 'member') ? 'selected' : ''; ?>>♟️ Member (Player)</option>
                                <option value="coach" <?php echo (isset($_POST['reg_role']) && $_POST['reg_role'] == 'coach') ? 'selected' : ''; ?>>🎓 Coach</option>
                                <option value="admin" <?php echo (isset($_POST['reg_role']) && $_POST['reg_role'] == 'admin') ? 'selected' : ''; ?>>👑 Admin</option>
                            </select>
                            <span class="select-arrow"><i class="fas fa-chevron-down"></i></span>
                        </div>
                        <div class="role-hint">
                            <i class="fas fa-info-circle"></i>
                            Select your role. Admins have full access, Coaches manage lessons, Members play and learn.
                        </div>
                    </div>

                    <button type="submit" class="btn-submit">
                        <i class="fas fa-user-plus"></i> Create Account
                    </button>
                </form>

                <div class="switch-link">
                    Already have an account? <a href="#" onclick="switchTab('login')">Sign in here</a>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== FEATURES ===== -->
    <section class="auth-features">
        <?php if (!empty($loginFeatures)): ?>
            <?php foreach ($loginFeatures as $feature): ?>
                <div class="feature-item">
                    <i class="fas fa-<?php echo e($feature['icon'] ?? 'star'); ?>"></i>
                    <h4><?php echo e($feature['title']); ?></h4>
                    <p><?php echo e($feature['description']); ?></p>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="feature-item">
                <i class="fas fa-chess-board"></i>
                <h4>Free Chess Lessons</h4>
                <p>Access all lessons and tutorials</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-trophy"></i>
                <h4>Tournaments</h4>
                <p>Join live tournaments and compete</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-puzzle-piece"></i>
                <h4>Daily Puzzles</h4>
                <p>Solve puzzles and improve tactics</p>
            </div>
            <div class="feature-item">
                <i class="fas fa-users"></i>
                <h4>Community</h4>
                <p>Connect with other chess players</p>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" />
            <button onclick="alert('Thank you for subscribing!')">Subscribe</button>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php">Privacy Policy</a> · <a href="terms.php">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== TOGGLE PASSWORD VISIBILITY =====
        function togglePassword(inputId, iconId) {
            const passwordInput = document.getElementById(inputId);
            const toggleIcon = document.getElementById(iconId);
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                toggleIcon.className = 'fas fa-eye-slash';
            } else {
                passwordInput.type = 'password';
                toggleIcon.className = 'fas fa-eye';
            }
        }

        // ===== SWITCH TABS =====
        function switchTab(tab) {
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerForm');
            const tabs = document.querySelectorAll('.auth-tab');
            
            if (tab === 'login') {
                loginForm.style.display = 'block';
                registerForm.style.display = 'none';
                tabs[0].classList.add('active');
                tabs[1].classList.remove('active');
                const url = new URL(window.location);
                url.searchParams.delete('tab');
                window.history.pushState({}, '', url);
            } else {
                loginForm.style.display = 'none';
                registerForm.style.display = 'block';
                tabs[0].classList.remove('active');
                tabs[1].classList.add('active');
                const url = new URL(window.location);
                url.searchParams.set('tab', 'register');
                window.history.pushState({}, '', url);
            }
        }

        // ===== SOCIAL LOGIN =====
        function socialLogin(provider) {
            alert('You are being redirected to ' + provider.charAt(0).toUpperCase() + provider.slice(1) + ' for authentication.');
        }

        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');

        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });

        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        document.addEventListener('click', function(event) {
            const navbar = document.querySelector('.navbar-fixed');
            if (window.innerWidth <= 768) {
                if (!navbar.contains(event.target)) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            }
        });

        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });
    </script>
</body>
</html>