<?php
/**
 * Chess Heaven - Theme Detail Page
 * Displays puzzles for a specific theme with interactive board
 */

require_once 'config.php';

// Get theme ID from URL
$themeId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get theme details
$themeDetails = getThemeDetails($themeId);
$themePuzzles = getThemePuzzles($themeId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · <?php echo e($themeDetails ? $themeDetails['name'] : 'Puzzle Theme'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== THEME HERO ===== */
        .theme-hero {
            text-align:center;
            padding:3rem 2rem;
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem;
            border:1px solid var(--border-color);
            margin:2rem;
            position:relative;
            overflow:hidden;
        }
        .theme-hero::before {
            content:'';
            position:absolute;
            top:-50%;
            left:-50%;
            width:200%;
            height:200%;
            background:radial-gradient(circle at center, rgba(198,151,107,0.05), transparent 70%);
            animation: rotateGlow 20s linear infinite;
        }
        @keyframes rotateGlow {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        .theme-hero .hero-content {
            position:relative;
            z-index:1;
        }
        .theme-hero .hero-icon {
            font-size:4rem;
            color:var(--secondary);
            margin-bottom:0.5rem;
        }
        .theme-hero h1 {
            font-size:2.8rem;
            color:#f0d6b0;
        }
        .theme-hero p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
        }
        .theme-hero .theme-stats {
            display:flex;
            justify-content:center;
            gap:3rem;
            margin-top:1.5rem;
            flex-wrap:wrap;
        }
        .theme-hero .theme-stats .stat-item {
            text-align:center;
        }
        .theme-hero .theme-stats .stat-item .stat-number {
            font-size:1.5rem;
            font-weight:700;
            color:var(--gold);
        }
        .theme-hero .theme-stats .stat-item .stat-label {
            color:#7a6a5a;
            font-size:0.85rem;
        }

        /* ===== PUZZLE BOARD ===== */
        .puzzle-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.12),rgba(10,5,5,0.5));
            border-radius:2rem;
            padding:2rem;
            border:1px solid var(--border-color);
            margin-bottom:2rem;
        }
        .puzzle-container {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
            align-items:start;
        }
        .board-wrapper {
            background:rgba(0,0,0,0.4);
            border-radius:1.5rem;
            padding:1.5rem;
            border:2px solid var(--border-color);
        }
        .board-wrapper .board-title {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:0.8rem;
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .board-wrapper .board-title .turn-indicator {
            display:flex;
            align-items:center;
            gap:0.5rem;
            color:var(--secondary);
            font-size:0.85rem;
        }
        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:500px;
            aspect-ratio:1;
            margin:0 auto;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
            transition:transform 0.3s ease;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.8rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
            position:relative;
        }
        .chess-board .square.light { background:var(--light-square); }
        .chess-board .square.dark { background:var(--dark-square); }
        .chess-board .square.highlight {
            background:rgba(255,255,0,0.4) !important;
            box-shadow:inset 0 0 20px rgba(255,255,0,0.3);
        }
        .chess-board .square.last-move {
            background:rgba(255,255,100,0.3) !important;
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
            pointer-events:none;
            z-index:1;
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }
        .chess-board .square .coords {
            position:absolute;
            font-size:0.55rem;
            color:rgba(0,0,0,0.3);
            pointer-events:none;
            font-weight:600;
        }
        .chess-board .square .coords.file { bottom:2px; right:4px; }
        .chess-board .square .coords.rank { top:2px; left:4px; }
        .chess-board .square.dark .coords { color:rgba(255,255,255,0.3); }
        .chess-board .square.check {
            background:rgba(255,0,0,0.3) !important;
        }

        .board-controls {
            display:flex;
            gap:0.6rem;
            flex-wrap:wrap;
            justify-content:center;
            margin-top:0.8rem;
            width:100%;
        }
        .board-controls button {
            padding:0.4rem 0.9rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.75rem;
            display:inline-flex;
            align-items:center;
            gap:0.4rem;
        }
        .btn-nav {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-nav:hover { background:rgba(198,151,107,0.25); }
        .btn-nav:disabled {
            opacity:0.3;
            cursor:not-allowed;
        }
        .btn-reset-board {
            background:rgba(255,255,255,0.05);
            color:#a09080;
            border:1px solid rgba(255,255,255,0.1) !important;
        }
        .btn-reset-board:hover { background:rgba(255,255,255,0.1); }
        .btn-flip-board {
            background:rgba(46,204,113,0.15);
            color:#2ecc71;
            border:1px solid #2ecc71 !important;
        }
        .btn-flip-board:hover { background:rgba(46,204,113,0.25); }

        /* ===== PUZZLE INFO ===== */
        .puzzle-info {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .puzzle-info .info-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
        }
        .puzzle-info .info-card h3 {
            color:#f0d6b0;
            font-size:1rem;
            margin-bottom:0.5rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .puzzle-info .info-card h3 i { color:var(--secondary); }
        .puzzle-info .info-card p {
            color:#a09080;
            line-height:1.8;
            font-size:0.9rem;
        }
        .puzzle-info .info-card .puzzle-meta {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            margin:0.5rem 0;
        }
        .puzzle-info .info-card .puzzle-meta span {
            color:#a09080;
            font-size:0.85rem;
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .badge {
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
            display:inline-block;
        }
        .badge-easy { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .badge-medium { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .badge-hard { background:rgba(231,76,60,0.2); color:#e74c3c; }
        .badge-expert { background:rgba(155,89,182,0.2); color:#9b59b6; }

        .puzzle-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
        }
        .puzzle-actions button {
            padding:0.7rem 1.5rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
            flex:1;
            justify-content:center;
        }
        .btn-hint {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-hint:hover { background:rgba(198,151,107,0.25); transform:translateY(-2px); }
        .btn-solution {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .btn-solution:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .btn-next {
            background:rgba(52,152,219,0.15);
            color:#3498db;
            border:1px solid #3498db !important;
        }
        .btn-next:hover { background:rgba(52,152,219,0.25); transform:translateY(-2px); }

        .feedback-display {
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            font-size:0.9rem;
            display:none;
        }
        .feedback-display.success {
            display:block;
            background:rgba(46,204,113,0.15);
            border:1px solid rgba(46,204,113,0.3);
            color:#2ecc71;
        }
        .feedback-display.error {
            display:block;
            background:rgba(231,76,60,0.15);
            border:1px solid rgba(231,76,60,0.3);
            color:#e74c3c;
        }
        .feedback-display.info {
            display:block;
            background:rgba(52,152,219,0.15);
            border:1px solid rgba(52,152,219,0.3);
            color:#3498db;
        }

        .hint-display, .solution-display {
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            font-size:0.9rem;
            display:none;
            margin-top:0.5rem;
        }
        .hint-display {
            background:rgba(198,151,107,0.1);
            border:1px solid rgba(198,151,107,0.2);
            color:var(--secondary);
        }
        .solution-display {
            background:rgba(212,163,115,0.1);
            border:1px solid rgba(212,163,115,0.2);
            color:var(--gold);
        }

        /* ===== PUZZLE LIST ===== */
        .puzzle-list {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(250px,1fr));
            gap:1rem;
            margin-top:1rem;
        }
        .puzzle-list-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:0.8rem;
            padding:1rem;
            transition:all 0.3s;
            cursor:pointer;
            display:flex;
            align-items:center;
            gap:1rem;
        }
        .puzzle-list-item:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateX(5px);
        }
        .puzzle-list-item.active {
            border-color:var(--gold);
            background:rgba(212,163,115,0.1);
        }
        .puzzle-list-item .puzzle-number {
            width:30px;
            height:30px;
            border-radius:50%;
            background:rgba(255,255,255,0.05);
            display:flex;
            align-items:center;
            justify-content:center;
            font-weight:700;
            font-size:0.8rem;
            color:#5a4a3a;
            flex-shrink:0;
        }
        .puzzle-list-item .puzzle-info-text {
            flex:1;
        }
        .puzzle-list-item .puzzle-info-text h4 {
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .puzzle-list-item .puzzle-info-text p {
            color:#7a6a5a;
            font-size:0.75rem;
        }
        .puzzle-list-item .puzzle-status {
            font-size:0.8rem;
        }
        .puzzle-list-item .puzzle-status .solved { color:var(--success); }
        .puzzle-list-item .puzzle-status .unsolved { color:#5a4a3a; }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .puzzle-container {
                grid-template-columns:1fr;
            }
            .chess-board { max-width:400px; }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .theme-hero { margin:1rem; padding:2rem 1rem; }
            .theme-hero h1 { font-size:2rem; }
            .theme-hero .theme-stats { gap:1.5rem; }
            .puzzle-section { padding:1rem; }
            .board-wrapper { padding:0.8rem; }
            .chess-board .square .piece { font-size:2rem; }
            .chess-board { max-width:100%; }
            .puzzle-container { grid-template-columns:1fr; }
            .puzzle-list { grid-template-columns:1fr; }
        }
        @media (max-width:480px) {
            .theme-hero h1 { font-size:1.5rem; }
            .theme-hero .hero-icon { font-size:3rem; }
            .chess-board .square .piece { font-size:1.5rem; }
            .puzzle-actions { flex-direction:column; }
            .puzzle-actions button { width:100%; }
        }

        @keyframes fadeInUp {
            from { opacity:0; transform:translateY(20px); }
            to { opacity:1; transform:translateY(0); }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="openings.php"><i class="fas fa-book-open"></i> Openings</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== THEME HERO ===== -->
    <div class="theme-hero">
        <div class="hero-content">
            <div class="hero-icon">
                <i class="fas fa-<?php echo e($themeDetails ? $themeDetails['icon'] : 'tag'); ?>"></i>
            </div>
            <h1><?php echo e($themeDetails ? $themeDetails['name'] : 'Puzzle Theme'); ?></h1>
            <p><?php echo e($themeDetails ? $themeDetails['description'] : 'Practice and master this puzzle theme.'); ?></p>
            <div class="theme-stats">
                <div class="stat-item">
                    <div class="stat-number"><?php echo e($themeDetails ? $themeDetails['total_puzzles'] : 0); ?></div>
                    <div class="stat-label">Total Puzzles</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo e($themeDetails ? $themeDetails['solved'] : 0); ?></div>
                    <div class="stat-label">Solved</div>
                </div>
                <div class="stat-item">
                    <div class="stat-number"><?php echo e($themeDetails ? $themeDetails['progress'] : 0); ?>%</div>
                    <div class="stat-label">Progress</div>
                </div>
            </div>
        </div>
    </div>

    <!-- ===== PUZZLE SECTION ===== -->
    <section class="section" style="padding-top:0;">
        <div class="puzzle-section">
            <div class="puzzle-container">
                <!-- Board -->
                <div class="board-wrapper">
                    <div class="board-title">
                        <span class="turn-indicator">
                            <span id="puzzleTurnIndicator">⚪ White to move</span>
                        </span>
                        <span style="color:#7a6a5a;font-size:0.75rem;" id="puzzleMoveCounter">Move 0</span>
                    </div>
                    <div class="chess-board" id="puzzleBoard"></div>
                    <div class="board-controls">
                        <button class="btn-nav" id="puzzlePrevBtn" onclick="prevPuzzleMove()">
                            <i class="fas fa-chevron-left"></i> Prev
                        </button>
                        <button class="btn-nav" id="puzzleNextBtn" onclick="nextPuzzleMove()">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                        <button class="btn-reset-board" onclick="resetPuzzleBoard()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                        <button class="btn-flip-board" onclick="flipPuzzleBoard()">
                            <i class="fas fa-sync-alt"></i> Flip
                        </button>
                        <button class="btn-nav" onclick="togglePuzzleAutoPlay()" id="puzzleAutoBtn">
                            <i class="fas fa-play"></i> Auto
                        </button>
                    </div>
                </div>

                <!-- Puzzle Info -->
                <div class="puzzle-info">
                    <div class="info-card">
                        <h3><i class="fas fa-puzzle-piece"></i> <span id="puzzleTitle">Loading Puzzle...</span></h3>
                        <div class="puzzle-meta">
                            <span><i class="fas fa-signal"></i> Difficulty: <span class="badge badge-medium" id="puzzleDifficultyBadge">Medium</span></span>
                            <span><i class="fas fa-users"></i> <span id="puzzleAttempts">0</span> attempts</span>
                            <span><i class="fas fa-check-circle"></i> <span id="puzzleSuccessRate">0</span>% solved</span>
                            <span><i class="fas fa-hashtag"></i> <span id="puzzleNumber">1</span>/<span id="puzzleTotal">0</span></span>
                        </div>
                        <p id="puzzleDescription">Click on a puzzle from the list below to start solving.</p>
                    </div>

                    <div class="info-card">
                        <h3><i class="fas fa-chess"></i> Controls</h3>
                        <div class="puzzle-actions">
                            <button class="btn-hint" onclick="showHint()"><i class="fas fa-lightbulb"></i> Hint</button>
                            <button class="btn-solution" onclick="showSolution()"><i class="fas fa-eye"></i> Solution</button>
                            <button class="btn-next" onclick="nextPuzzle()"><i class="fas fa-forward"></i> Next</button>
                        </div>
                        <div class="hint-display" id="hintDisplay"></div>
                        <div class="solution-display" id="solutionDisplay"></div>
                        <div class="feedback-display" id="feedbackDisplay"></div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== PUZZLE LIST ===== -->
    <section class="section" style="padding-top:0;">
        <div class="section-header">
            <h2><i class="fas fa-list"></i> Puzzles in this Theme</h2>
            <a href="puzzles.php" class="view-all">Back to Puzzles <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="puzzle-list" id="puzzleList">
            <?php if (!empty($themePuzzles)): ?>
                <?php foreach ($themePuzzles as $index => $puzzle): ?>
                    <div class="puzzle-list-item <?php echo $index === 0 ? 'active' : ''; ?>" onclick="loadPuzzle(<?php echo e($index); ?>)">
                        <div class="puzzle-number"><?php echo e($index + 1); ?></div>
                        <div class="puzzle-info-text">
                            <h4><?php echo e($puzzle['title']); ?></h4>
                            <p><?php echo e($puzzle['description']); ?></p>
                        </div>
                        <div class="puzzle-status">
                            <span class="<?php echo ($puzzle['solved'] ?? false) ? 'solved' : 'unsolved'; ?>">
                                <i class="fas fa-<?php echo ($puzzle['solved'] ?? false) ? 'check-circle' : 'circle'; ?>"></i>
                            </span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <!-- Default puzzles for theme -->
                <div class="puzzle-list-item active" onclick="loadPuzzle(0)">
                    <div class="puzzle-number">1</div>
                    <div class="puzzle-info-text">
                        <h4>Mate in 1</h4>
                        <p>Find the immediate checkmate</p>
                    </div>
                    <div class="puzzle-status"><span class="unsolved"><i class="fas fa-circle"></i></span></div>
                </div>
                <div class="puzzle-list-item" onclick="loadPuzzle(1)">
                    <div class="puzzle-number">2</div>
                    <div class="puzzle-info-text">
                        <h4>Mate in 2</h4>
                        <p>Find the forced mate in 2</p>
                    </div>
                    <div class="puzzle-status"><span class="solved"><i class="fas fa-check-circle"></i></span></div>
                </div>
                <div class="puzzle-list-item" onclick="loadPuzzle(2)">
                    <div class="puzzle-number">3</div>
                    <div class="puzzle-info-text">
                        <h4>Mate in 3</h4>
                        <p>Beautiful mate in 3 moves</p>
                    </div>
                    <div class="puzzle-status"><span class="unsolved"><i class="fas fa-circle"></i></span></div>
                </div>
                <div class="puzzle-list-item" onclick="loadPuzzle(3)">
                    <div class="puzzle-number">4</div>
                    <div class="puzzle-info-text">
                        <h4>Fork Tactic</h4>
                        <p>Use a knight fork to win</p>
                    </div>
                    <div class="puzzle-status"><span class="unsolved"><i class="fas fa-circle"></i></span></div>
                </div>
                <div class="puzzle-list-item" onclick="loadPuzzle(4)">
                    <div class="puzzle-number">5</div>
                    <div class="puzzle-info-text">
                        <h4>Pin to Win</h4>
                        <p>Exploit a pin for material</p>
                    </div>
                    <div class="puzzle-status"><span class="unsolved"><i class="fas fa-circle"></i></span></div>
                </div>
                <div class="puzzle-list-item" onclick="loadPuzzle(5)">
                    <div class="puzzle-number">6</div>
                    <div class="puzzle-info-text">
                        <h4>Skewer Tactic</h4>
                        <p>Use a skewer to win</p>
                    </div>
                    <div class="puzzle-status"><span class="unsolved"><i class="fas fa-circle"></i></span></div>
                </div>
                <div class="puzzle-list-item" onclick="loadPuzzle(6)">
                    <div class="puzzle-number">7</div>
                    <div class="puzzle-info-text">
                        <h4>Queen Sacrifice</h4>
                        <p>Sacrifice the queen for mate</p>
                    </div>
                    <div class="puzzle-status"><span class="unsolved"><i class="fas fa-circle"></i></span></div>
                </div>
                <div class="puzzle-list-item" onclick="loadPuzzle(7)">
                    <div class="puzzle-number">8</div>
                    <div class="puzzle-info-text">
                        <h4>Endgame Position</h4>
                        <p>Convert the winning endgame</p>
                    </div>
                    <div class="puzzle-status"><span class="unsolved"><i class="fas fa-circle"></i></span></div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:var(--card-bg);border-radius:1.5rem;padding:2rem;border:1px solid var(--border-color);text-align:center;">
            <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--secondary);"></i>
            <h3 style="color:#f0d6b0;margin:0.5rem 0;">Solving Tips</h3>
            <p style="color:#a09080;max-width:600px;margin:0 auto;">
                <i class="fas fa-chess-pawn"></i> Look for forcing moves: checks, captures, and threats.
                <br>
                <span style="color:var(--secondary);font-size:0.85rem;">"Tactics flow from a superior position." — Bobby Fischer</span>
            </p>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== PIECE SYMBOLS =====
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // ===== PUZZLE DATA =====
        const THEME_PUZZLES = <?php echo json_encode($themePuzzles ?: [
            [
                'id' => 1,
                'title' => 'Mate in 1',
                'description' => 'Find the immediate checkmate. White to play.',
                'difficulty' => 'easy',
                'attempts' => 456,
                'success_rate' => 78,
                'solved' => false,
                'board' => [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','p','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                'solution' => '1. Qh5+! Kd8 2. Qe8#',
                'hint' => 'Look for a move that attacks the king and can\'t be blocked.'
            ],
            [
                'id' => 2,
                'title' => 'Mate in 2',
                'description' => 'Find the forced mate in 2 moves.',
                'difficulty' => 'medium',
                'attempts' => 340,
                'success_rate' => 62,
                'solved' => true,
                'board' => [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                'solution' => '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                'hint' => 'Look for a forcing move that leads to mate.'
            ],
            [
                'id' => 3,
                'title' => 'Mate in 3',
                'description' => 'Find the beautiful mate in 3 moves.',
                'difficulty' => 'hard',
                'attempts' => 190,
                'success_rate' => 25,
                'solved' => false,
                'board' => [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                'solution' => '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                'hint' => 'Work backwards from the checkmate position.'
            ],
            [
                'id' => 4,
                'title' => 'Fork Tactic',
                'description' => 'Use a knight fork to win the queen.',
                'difficulty' => 'medium',
                'attempts' => 320,
                'success_rate' => 55,
                'solved' => false,
                'board' => [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','N','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','','B','Q','K','B','N','R']
                ],
                'solution' => '1. Nf7+! Rxf7 2. Qxf7+ Kxf7 3. Rxf7#',
                'hint' => 'The knight can jump to f7 to attack both the king and queen.'
            ],
            [
                'id' => 5,
                'title' => 'Pin to Win',
                'description' => 'Exploit a pin to win material.',
                'difficulty' => 'medium',
                'attempts' => 280,
                'success_rate' => 48,
                'solved' => false,
                'board' => [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','B','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                'solution' => '1. Bxf7+! Kxf7 2. Qe6+ Kf8 3. Qe8#',
                'hint' => 'The bishop can capture on f7, exposing the queen\'s attack.'
            ],
            [
                'id' => 6,
                'title' => 'Skewer Tactic',
                'description' => 'Use a skewer to win the queen.',
                'difficulty' => 'medium',
                'attempts' => 300,
                'success_rate' => 52,
                'solved' => false,
                'board' => [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                'solution' => '1. Rxh7+! Kxh7 2. Qh5+ Kg8 3. Qh8#',
                'hint' => 'The rook can sacrifice itself on h7 to open the h-file.'
            ],
            [
                'id' => 7,
                'title' => 'Queen Sacrifice',
                'description' => 'Sacrifice your queen for a winning attack.',
                'difficulty' => 'hard',
                'attempts' => 200,
                'success_rate' => 32,
                'solved' => false,
                'board' => [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                'solution' => '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                'hint' => 'The queen can capture on f7, forcing the rook to take.'
            ],
            [
                'id' => 8,
                'title' => 'Endgame Position',
                'description' => 'Convert the winning endgame.',
                'difficulty' => 'hard',
                'attempts' => 180,
                'success_rate' => 28,
                'solved' => false,
                'board' => [
                    ['','','','k','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','K','','','','']
                ],
                'solution' => '1. Kc2 Kd4 2. Kd2 Ke4 3. Ke2',
                'hint' => 'Use opposition to force the king back.'
            ]
        ]); ?>;

        // ===== STATE =====
        let currentPuzzleIndex = 0;
        let puzzleBoard = [];
        let puzzleSteps = [];
        let puzzleStep = 0;
        let isPuzzleFlipped = false;
        let puzzleAutoInterval = null;
        let isPuzzleAutoPlaying = false;
        let selectedPuzzleSquare = null;
        let currentPuzzleData = null;

        // ===== BOARD RENDER =====
        function renderPuzzleBoard() {
            const boardEl = document.getElementById('puzzleBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            const board = puzzleSteps[puzzleStep] || puzzleBoard;
            if (!board || board.length === 0) return;
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isPuzzleFlipped ? 7 - row : row;
                    const actualCol = isPuzzleFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    square.dataset.row = actualRow;
                    square.dataset.col = actualCol;
                    
                    const piece = board[actualRow]?.[actualCol] || '';
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    if (col === 0) {
                        const rank = document.createElement('span');
                        rank.className = 'coords rank';
                        rank.textContent = 8 - actualRow;
                        square.appendChild(rank);
                    }
                    if (row === 7) {
                        const file = document.createElement('span');
                        file.className = 'coords file';
                        file.textContent = 'abcdefgh'[actualCol];
                        square.appendChild(file);
                    }
                    
                    if (selectedPuzzleSquare && selectedPuzzleSquare.row === actualRow && selectedPuzzleSquare.col === actualCol) {
                        square.classList.add('highlight');
                    }
                    
                    square.addEventListener('click', () => onSquareClick(actualRow, actualCol));
                    boardEl.appendChild(square);
                }
            }
            
            updateUI();
        }

        function updateUI() {
            const totalSteps = puzzleSteps.length;
            document.getElementById('puzzleMoveCounter').textContent = `Move ${puzzleStep}/${Math.max(0, totalSteps - 1)}`;
            
            const isWhiteTurn = puzzleStep % 2 === 0;
            document.getElementById('puzzleTurnIndicator').innerHTML = isWhiteTurn ? '⚪ White to move' : '⚫ Black to move';
            
            document.getElementById('puzzlePrevBtn').disabled = puzzleStep === 0;
            document.getElementById('puzzleNextBtn').disabled = puzzleStep >= totalSteps - 1;
        }

        // ===== SQUARE CLICK =====
        function onSquareClick(row, col) {
            const board = puzzleSteps[puzzleStep] || puzzleBoard;
            const piece = board[row]?.[col];
            
            if (selectedPuzzleSquare) {
                const fromRow = selectedPuzzleSquare.row;
                const fromCol = selectedPuzzleSquare.col;
                const fromPiece = board[fromRow]?.[fromCol];
                
                if (fromPiece && (row !== fromRow || col !== fromCol)) {
                    const result = tryMove(fromRow, fromCol, row, col);
                    if (result) {
                        selectedPuzzleSquare = null;
                        renderPuzzleBoard();
                        return;
                    }
                }
                selectedPuzzleSquare = null;
                renderPuzzleBoard();
                return;
            }
            
            if (piece) {
                selectedPuzzleSquare = { row, col };
                renderPuzzleBoard();
            }
        }

        function tryMove(fromRow, fromCol, toRow, toCol) {
            const board = puzzleSteps[puzzleStep] || puzzleBoard;
            const piece = board[fromRow]?.[fromCol];
            if (!piece) return false;
            
            const target = board[toRow]?.[toCol];
            const isWhite = piece === piece.toUpperCase();
            
            if (target) {
                const isTargetWhite = target === target.toUpperCase();
                if (isWhite === isTargetWhite) return false;
            }
            
            const newBoard = board.map(row => [...row]);
            newBoard[toRow][toCol] = piece;
            newBoard[fromRow][fromCol] = '';
            
            if (piece.toLowerCase() === 'p' && (toRow === 0 || toRow === 7)) {
                newBoard[toRow][toCol] = piece === 'P' ? 'Q' : 'q';
            }
            
            if (puzzleStep < puzzleSteps.length - 1) {
                puzzleSteps = puzzleSteps.slice(0, puzzleStep + 1);
            }
            puzzleSteps.push(newBoard);
            puzzleStep++;
            
            showFeedback('Move made!', 'success');
            return true;
        }

        // ===== NAVIGATION =====
        function nextPuzzleMove() {
            if (puzzleStep < puzzleSteps.length - 1) {
                puzzleStep++;
                renderPuzzleBoard();
                if (isPuzzleAutoPlaying) {
                    clearTimeout(puzzleAutoInterval);
                    puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
                }
            }
        }

        function prevPuzzleMove() {
            if (puzzleStep > 0) {
                puzzleStep--;
                renderPuzzleBoard();
                if (isPuzzleAutoPlaying) {
                    clearTimeout(puzzleAutoInterval);
                    puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
                }
            }
        }

        function resetPuzzleBoard() {
            puzzleStep = 0;
            selectedPuzzleSquare = null;
            renderPuzzleBoard();
            if (isPuzzleAutoPlaying) {
                clearTimeout(puzzleAutoInterval);
                puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
            }
            document.getElementById('feedbackDisplay').className = 'feedback-display';
            document.getElementById('feedbackDisplay').style.display = 'none';
        }

        function flipPuzzleBoard() {
            isPuzzleFlipped = !isPuzzleFlipped;
            renderPuzzleBoard();
        }

        function togglePuzzleAutoPlay() {
            isPuzzleAutoPlaying = !isPuzzleAutoPlaying;
            const btn = document.getElementById('puzzleAutoBtn');
            if (isPuzzleAutoPlaying) {
                btn.innerHTML = '<i class="fas fa-pause"></i> Pause';
                if (puzzleStep < puzzleSteps.length - 1) {
                    puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
                }
            } else {
                btn.innerHTML = '<i class="fas fa-play"></i> Auto';
                clearTimeout(puzzleAutoInterval);
            }
        }

        // ===== LOAD PUZZLE =====
        function loadPuzzle(index) {
            const puzzles = THEME_PUZZLES;
            if (index < 0 || index >= puzzles.length) return;
            
            currentPuzzleIndex = index;
            currentPuzzleData = puzzles[index];
            
            // Update UI
            document.getElementById('puzzleTitle').textContent = currentPuzzleData.title;
            document.getElementById('puzzleDescription').textContent = currentPuzzleData.description;
            document.getElementById('puzzleAttempts').textContent = currentPuzzleData.attempts || 0;
            document.getElementById('puzzleSuccessRate').textContent = currentPuzzleData.success_rate || 0;
            document.getElementById('puzzleNumber').textContent = index + 1;
            document.getElementById('puzzleTotal').textContent = puzzles.length;
            
            // Update difficulty badge
            const badge = document.getElementById('puzzleDifficultyBadge');
            const diffMap = {
                'easy': 'badge-easy',
                'medium': 'badge-medium',
                'hard': 'badge-hard',
                'expert': 'badge-expert'
            };
            badge.className = `badge ${diffMap[currentPuzzleData.difficulty] || 'badge-medium'}`;
            badge.textContent = currentPuzzleData.difficulty.charAt(0).toUpperCase() + currentPuzzleData.difficulty.slice(1);
            
            // Set board
            puzzleBoard = currentPuzzleData.board.map(row => [...row]);
            puzzleSteps = [puzzleBoard.map(row => [...row])];
            puzzleStep = 0;
            selectedPuzzleSquare = null;
            
            // Reset displays
            document.getElementById('hintDisplay').style.display = 'none';
            document.getElementById('solutionDisplay').style.display = 'none';
            document.getElementById('feedbackDisplay').className = 'feedback-display';
            document.getElementById('feedbackDisplay').style.display = 'none';
            
            // Update list
            document.querySelectorAll('.puzzle-list-item').forEach((item, i) => {
                item.classList.toggle('active', i === index);
            });
            
            if (isPuzzleAutoPlaying) {
                clearTimeout(puzzleAutoInterval);
                isPuzzleAutoPlaying = false;
                document.getElementById('puzzleAutoBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
            }
            
            renderPuzzleBoard();
        }

        function nextPuzzle() {
            const puzzles = THEME_PUZZLES;
            const nextIndex = (currentPuzzleIndex + 1) % puzzles.length;
            loadPuzzle(nextIndex);
        }

        // ===== HINT & SOLUTION =====
        function showHint() {
            if (!currentPuzzleData) return;
            const hintDisplay = document.getElementById('hintDisplay');
            hintDisplay.style.display = 'block';
            hintDisplay.innerHTML = '💡 <strong>Hint:</strong> ' + (currentPuzzleData.hint || 'Look for a forcing move.');
            hintDisplay.style.animation = 'none';
            setTimeout(() => {
                hintDisplay.style.animation = 'fadeInUp 0.5s ease-out';
            }, 10);
        }

        function showSolution() {
            if (!currentPuzzleData) return;
            const solutionDisplay = document.getElementById('solutionDisplay');
            solutionDisplay.style.display = 'block';
            solutionDisplay.innerHTML = '✅ <strong>Solution:</strong> ' + (currentPuzzleData.solution || 'Check all forcing moves.');
            solutionDisplay.style.animation = 'none';
            setTimeout(() => {
                solutionDisplay.style.animation = 'fadeInUp 0.5s ease-out';
            }, 10);
        }

        function showFeedback(message, type = 'info') {
            const feedback = document.getElementById('feedbackDisplay');
            feedback.className = `feedback-display ${type}`;
            feedback.textContent = message;
            feedback.style.display = 'block';
        }

        // ===== KEYBOARD SHORTCUTS =====
        document.addEventListener('keydown', function(e) {
            if (document.activeElement?.tagName === 'INPUT') return;
            
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                nextPuzzleMove();
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                prevPuzzleMove();
            } else if (e.key === 'r' || e.key === 'R') {
                resetPuzzleBoard();
            } else if (e.key === 'f' || e.key === 'F') {
                if (!e.ctrlKey && !e.metaKey) {
                    e.preventDefault();
                    flipPuzzleBoard();
                }
            } else if (e.key === ' ') {
                e.preventDefault();
                togglePuzzleAutoPlay();
            } else if (e.key === 'h' || e.key === 'H') {
                showHint();
            } else if (e.key === 's' || e.key === 'S') {
                showSolution();
            } else if (e.key === 'n' || e.key === 'N') {
                nextPuzzle();
            }
        });

        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // ===== NAVBAR SCROLL =====
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== INIT =====
        document.addEventListener('DOMContentLoaded', function() {
            if (THEME_PUZZLES.length > 0) {
                loadPuzzle(0);
            }
        });

        // Make functions globally accessible
        window.loadPuzzle = loadPuzzle;
        window.nextPuzzleMove = nextPuzzleMove;
        window.prevPuzzleMove = prevPuzzleMove;
        window.resetPuzzleBoard = resetPuzzleBoard;
        window.flipPuzzleBoard = flipPuzzleBoard;
        window.togglePuzzleAutoPlay = togglePuzzleAutoPlay;
        window.showHint = showHint;
        window.showSolution = showSolution;
        window.nextPuzzle = nextPuzzle;
        window.onSquareClick = onSquareClick;
    </script>
</body>
</html>
<?php
/**
 * Helper functions for theme page
 */
function getThemeDetails($themeId) {
    // Simulated theme data
    $themes = [
        1 => [
            'id' => 1,
            'name' => 'Checkmate Patterns',
            'description' => 'Practice and master various checkmate patterns. Learn to spot and execute mating combinations.',
            'icon' => 'chess-king',
            'total_puzzles' => 24,
            'solved' => 8,
            'progress' => 33
        ],
        2 => [
            'id' => 2,
            'name' => 'Forks',
            'description' => 'Master the fork tactic - using one piece to attack two or more enemy pieces simultaneously.',
            'icon' => 'chess-knight',
            'total_puzzles' => 18,
            'solved' => 5,
            'progress' => 28
        ],
        3 => [
            'id' => 3,
            'name' => 'Pins',
            'description' => 'Practice pinning pieces to the king or other valuable targets. Learn to exploit pinned pieces.',
            'icon' => 'chess-queen',
            'total_puzzles' => 15,
            'solved' => 3,
            'progress' => 20
        ],
        4 => [
            'id' => 4,
            'name' => 'Skewers',
            'description' => 'Master the skewer tactic - attacking a valuable piece that forces a less valuable piece to move.',
            'icon' => 'chess-rook',
            'total_puzzles' => 12,
            'solved' => 2,
            'progress' => 17
        ],
        5 => [
            'id' => 5,
            'name' => 'Sacrifices',
            'description' => 'Learn when and how to sacrifice pieces for a winning attack or positional advantage.',
            'icon' => 'fire',
            'total_puzzles' => 20,
            'solved' => 4,
            'progress' => 20
        ],
        6 => [
            'id' => 6,
            'name' => 'Endgame',
            'description' => 'Practice essential endgame positions and techniques for converting advantages.',
            'icon' => 'chess-pawn',
            'total_puzzles' => 16,
            'solved' => 2,
            'progress' => 13
        ]
    ];
    
    return $themes[$themeId] ?? $themes[1];
}

function getThemePuzzles($themeId) {
    // Sample puzzles for each theme
    $allPuzzles = [
        1 => [
            ['id' => 1, 'title' => 'Mate in 1', 'description' => 'Find the immediate checkmate.', 'difficulty' => 'easy', 'attempts' => 456, 'success_rate' => 78, 'solved' => true],
            ['id' => 2, 'title' => 'Mate in 2', 'description' => 'Find the forced mate in 2.', 'difficulty' => 'medium', 'attempts' => 340, 'success_rate' => 62, 'solved' => false],
            ['id' => 3, 'title' => 'Mate in 3', 'description' => 'Beautiful mate in 3 moves.', 'difficulty' => 'hard', 'attempts' => 190, 'success_rate' => 25, 'solved' => false],
            ['id' => 4, 'title' => 'Back Rank Mate', 'description' => 'Exploit the back rank weakness.', 'difficulty' => 'medium', 'attempts' => 280, 'success_rate' => 54, 'solved' => false],
            ['id' => 5, 'title' => 'Smothered Mate', 'description' => 'The classic smothered mate pattern.', 'difficulty' => 'hard', 'attempts' => 220, 'success_rate' => 38, 'solved' => false],
            ['id' => 6, 'title' => 'Epaulette Mate', 'description' => 'The epaulette mate pattern.', 'difficulty' => 'medium', 'attempts' => 300, 'success_rate' => 48, 'solved' => false]
        ],
        2 => [
            ['id' => 7, 'title' => 'Royal Fork', 'description' => 'Fork the king and queen.', 'difficulty' => 'medium', 'attempts' => 320, 'success_rate' => 55, 'solved' => false],
            ['id' => 8, 'title' => 'Knight Fork', 'description' => 'Use a knight to fork two pieces.', 'difficulty' => 'medium', 'attempts' => 290, 'success_rate' => 52, 'solved' => false],
            ['id' => 9, 'title' => 'Queen Fork', 'description' => 'Fork with the queen.', 'difficulty' => 'hard', 'attempts' => 200, 'success_rate' => 35, 'solved' => false],
            ['id' => 10, 'title' => 'Pawn Fork', 'description' => 'Use a pawn to fork pieces.', 'difficulty' => 'easy', 'attempts' => 380, 'success_rate' => 72, 'solved' => true]
        ],
        3 => [
            ['id' => 11, 'title' => 'Absolute Pin', 'description' => 'Pin a piece to the king.', 'difficulty' => 'medium', 'attempts' => 280, 'success_rate' => 48, 'solved' => false],
            ['id' => 12, 'title' => 'Relative Pin', 'description' => 'Pin a piece to the queen.', 'difficulty' => 'medium', 'attempts' => 260, 'success_rate' => 45, 'solved' => false],
            ['id' => 13, 'title' => 'Pin and Win', 'description' => 'Use a pin to win material.', 'difficulty' => 'hard', 'attempts' => 180, 'success_rate' => 30, 'solved' => false]
        ],
        4 => [
            ['id' => 14, 'title' => 'Queen Skewer', 'description' => 'Skewer the queen.', 'difficulty' => 'medium', 'attempts' => 300, 'success_rate' => 52, 'solved' => false],
            ['id' => 15, 'title' => 'Rook Skewer', 'description' => 'Use a rook to skewer.', 'difficulty' => 'medium', 'attempts' => 270, 'success_rate' => 48, 'solved' => false],
            ['id' => 16, 'title' => 'Bishop Skewer', 'description' => 'Use a bishop to skewer.', 'difficulty' => 'hard', 'attempts' => 190, 'success_rate' => 32, 'solved' => false]
        ],
        5 => [
            ['id' => 17, 'title' => 'Queen Sacrifice', 'description' => 'Sacrifice the queen for mate.', 'difficulty' => 'hard', 'attempts' => 200, 'success_rate' => 32, 'solved' => false],
            ['id' => 18, 'title' => 'Rook Sacrifice', 'description' => 'Sacrifice the rook for an attack.', 'difficulty' => 'hard', 'attempts' => 170, 'success_rate' => 28, 'solved' => false],
            ['id' => 19, 'title' => 'Bishop Sacrifice', 'description' => 'Sacrifice the bishop.', 'difficulty' => 'medium', 'attempts' => 240, 'success_rate' => 42, 'solved' => false],
            ['id' => 20, 'title' => 'Exchange Sacrifice', 'description' => 'Sacrifice exchange for positional advantage.', 'difficulty' => 'expert', 'attempts' => 150, 'success_rate' => 22, 'solved' => false]
        ],
        6 => [
            ['id' => 21, 'title' => 'King and Pawn', 'description' => 'Win the king and pawn endgame.', 'difficulty' => 'medium', 'attempts' => 260, 'success_rate' => 44, 'solved' => false],
            ['id' => 22, 'title' => 'Rook Endgame', 'description' => 'Convert the rook endgame.', 'difficulty' => 'hard', 'attempts' => 180, 'success_rate' => 28, 'solved' => false],
            ['id' => 23, 'title' => 'Queen vs Pawn', 'description' => 'Queen vs pawn endgame.', 'difficulty' => 'hard', 'attempts' => 190, 'success_rate' => 30, 'solved' => false],
            ['id' => 24, 'title' => 'Bishop Endgame', 'description' => 'Bishop endgame technique.', 'difficulty' => 'expert', 'attempts' => 140, 'success_rate' => 18, 'solved' => false]
        ]
    ];
    
    return $allPuzzles[$themeId] ?? $allPuzzles[1];
}
?>