<?php
/**
 * Chess Heaven - Tournament Results Page
 * Displays complete results, standings, and statistics for finished tournaments
 */

require_once 'config.php';

// Get tournament ID from URL
$tournamentId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get tournament results
$tournamentDetails = getTournamentResultDetails($tournamentId);
$finalStandings = getFinalStandings($tournamentId, 10);
$allMatches = getAllMatches($tournamentId, 20);
$tournamentStats = getTournamentResultStats($tournamentId);
$podiumPlayers = getPodiumPlayers($tournamentId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · <?php echo e($tournamentDetails ? $tournamentDetails['name'] : 'Tournament Results'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== TOURNAMENT HEADER ===== */
        .tournament-header {
            background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));
            border-radius:2rem;
            padding:2rem;
            border:2px solid var(--gold);
            margin-bottom:2rem;
        }
        .tournament-header .header-top {
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:1rem;
        }
        .tournament-header h1 {
            color:#f0d6b0;
            font-size:2.2rem;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .tournament-header .status-badge {
            padding:0.3rem 1.2rem;
            border-radius:2rem;
            background:rgba(155,155,155,0.2);
            color:#999;
            font-weight:700;
            font-size:0.85rem;
        }
        .tournament-header .header-meta {
            display:flex;
            gap:1.5rem;
            flex-wrap:wrap;
            margin-top:1rem;
            color:#a09080;
            font-size:0.9rem;
        }
        .tournament-header .header-meta span {
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .tournament-header .header-meta span i { color:var(--secondary); }
        .tournament-header .header-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            margin-top:1rem;
        }

        /* ===== PODIUM ===== */
        .podium-section {
            display:grid;
            grid-template-columns:repeat(3, 1fr);
            gap:1rem;
            margin:2rem 0;
            max-width:700px;
            margin-left:auto;
            margin-right:auto;
        }
        .podium-item {
            text-align:center;
            padding:1.5rem 1rem;
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            transition:all 0.3s;
            position:relative;
        }
        .podium-item:hover {
            transform:translateY(-5px);
            border-color:var(--secondary);
        }
        .podium-item .podium-rank {
            font-size:2.5rem;
            font-weight:900;
            margin-bottom:0.5rem;
        }
        .podium-item .podium-rank.gold { color:var(--gold); }
        .podium-item .podium-rank.silver { color:#c0c0c0; }
        .podium-item .podium-rank.bronze { color:#cd7f32; }
        .podium-item .podium-avatar {
            width:70px;
            height:70px;
            border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex;
            align-items:center;
            justify-content:center;
            margin:0 auto 0.5rem;
            font-size:2rem;
            color:var(--secondary);
            border:3px solid var(--secondary);
        }
        .podium-item .podium-name {
            color:#f0d6b0;
            font-weight:600;
            font-size:1.1rem;
        }
        .podium-item .podium-title {
            color:var(--secondary);
            font-size:0.8rem;
        }
        .podium-item .podium-points {
            color:#7a6a5a;
            font-size:0.85rem;
            margin-top:0.3rem;
        }
        .podium-item .podium-medal {
            position:absolute;
            top:-10px;
            right:-10px;
            font-size:1.5rem;
        }
        .podium-item .podium-medal.gold { color:var(--gold); }
        .podium-item .podium-medal.silver { color:#c0c0c0; }
        .podium-item .podium-medal.bronze { color:#cd7f32; }

        /* ===== STATS GRID ===== */
        .stats-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
            gap:1rem;
            margin:1.5rem 0;
        }
        .stat-box {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            text-align:center;
        }
        .stat-box .stat-number {
            font-size:1.8rem;
            font-weight:700;
            color:var(--gold);
        }
        .stat-box .stat-label {
            color:#7a6a5a;
            font-size:0.8rem;
            margin-top:0.2rem;
        }

        /* ===== STANDINGS TABLE ===== */
        .standings-table-wrapper {
            background:var(--card-bg);
            border-radius:1.5rem;
            padding:1.5rem;
            border:1px solid var(--border-color);
            overflow-x:auto;
        }
        .standings-table {
            width:100%;
            border-collapse:collapse;
        }
        .standings-table th {
            color:#7a6a5a;
            border-bottom:1px solid var(--border-color);
            padding:0.8rem;
            text-align:left;
            font-size:0.85rem;
        }
        .standings-table td {
            padding:0.8rem;
            border-bottom:1px solid rgba(255,255,255,0.03);
            font-size:0.85rem;
        }
        .standings-table tr:last-child td { border-bottom:none; }
        .standings-table .rank {
            font-weight:700;
            color:#5a4a3a;
        }
        .standings-table .rank-1 { color:var(--gold); }
        .standings-table .rank-2 { color:#c0c0c0; }
        .standings-table .rank-3 { color:#cd7f32; }
        .standings-table .player-name {
            color:#f0d6b0;
            font-weight:500;
        }
        .standings-table .points {
            color:var(--gold);
            font-weight:600;
        }
        .standings-table .wins { color:var(--success); }
        .standings-table .draws { color:var(--warning); }
        .standings-table .losses { color:var(--danger); }

        /* ===== MATCH RESULTS ===== */
        .match-result-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1rem 1.2rem;
            margin-bottom:0.6rem;
            transition:all 0.3s;
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:0.8rem;
        }
        .match-result-item:hover {
            background:rgba(139,26,26,0.08);
            border-color:var(--secondary);
        }
        .match-result-item .match-players {
            display:flex;
            align-items:center;
            gap:1rem;
            flex-wrap:wrap;
        }
        .match-result-item .match-players .player {
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .match-result-item .match-players .player .avatar {
            width:28px;
            height:28px;
            border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:0.7rem;
            color:var(--secondary);
        }
        .match-result-item .match-players .vs {
            color:#5a4a3a;
            font-weight:700;
            font-size:0.8rem;
        }
        .match-result-item .match-result {
            font-weight:600;
            font-size:0.9rem;
            min-width:80px;
            text-align:center;
        }
        .match-result-item .match-result .win { color:var(--success); }
        .match-result-item .match-result .loss { color:var(--danger); }
        .match-result-item .match-result .draw { color:var(--warning); }
        .match-result-item .match-info {
            color:#7a6a5a;
            font-size:0.75rem;
            display:flex;
            gap:1rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .tournament-header { padding:1.5rem; }
            .tournament-header h1 { font-size:1.5rem; }
            .podium-section { grid-template-columns:1fr; max-width:300px; }
            .stats-grid { grid-template-columns:repeat(2,1fr); }
            .match-result-item { flex-direction:column; align-items:stretch; text-align:center; }
            .match-result-item .match-players { justify-content:center; }
            .match-result-item .match-info { justify-content:center; }
            .standings-table-wrapper { padding:1rem; }
            .standings-table th, .standings-table td { padding:0.5rem; font-size:0.75rem; }
        }
        @media (max-width:480px) {
            .tournament-header h1 { font-size:1.2rem; }
            .stats-grid { grid-template-columns:1fr 1fr; }
            .podium-section { max-width:250px; }
            .podium-item .podium-avatar { width:50px; height:50px; font-size:1.5rem; }
            .podium-item .podium-rank { font-size:2rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php" class="active-link"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <?php if ($tournamentDetails): ?>
        <!-- ===== TOURNAMENT HEADER ===== -->
        <section class="section" style="padding-top:2rem;">
            <div class="tournament-header">
                <div class="header-top">
                    <h1>
                        <i class="fas fa-trophy" style="color:var(--gold);"></i>
                        <?php echo e($tournamentDetails['name']); ?>
                    </h1>
                    <span class="status-badge">✓ Finished</span>
                </div>
                <div class="header-meta">
                    <span><i class="fas fa-calendar"></i> <?php echo e($tournamentDetails['date']); ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?php echo e($tournamentDetails['location']); ?></span>
                    <span><i class="fas fa-users"></i> <?php echo e($tournamentDetails['players']); ?> players</span>
                    <span><i class="fas fa-trophy"></i> $<?php echo e($tournamentDetails['prize']); ?> prize pool</span>
                    <span><i class="fas fa-clock"></i> <?php echo e($tournamentDetails['time_control'] ?? 'Standard'); ?></span>
                    <span><i class="fas fa-check-circle" style="color:var(--success);"></i> Completed</span>
                </div>
                <div class="header-actions">
                    <a href="tournaments.php" class="btn-back" style="display:inline-block;padding:0.6rem 1.5rem;border-radius:2rem;border:1px solid var(--border-color);background:transparent;color:#a09080;font-weight:600;cursor:pointer;transition:all 0.3s;text-decoration:none;">
                        <i class="fas fa-arrow-left"></i> Back to Tournaments
                    </a>
                    <a href="tournament-watch.php?id=<?php echo e($tournamentId); ?>" class="btn-watch" style="display:inline-block;padding:0.6rem 1.5rem;border-radius:2rem;border:2px solid var(--secondary);background:transparent;color:var(--secondary);font-weight:600;cursor:pointer;transition:all 0.3s;text-decoration:none;">
                        <i class="fas fa-archive"></i> View Archive
                    </a>
                </div>
            </div>
        </section>

        <!-- ===== PODIUM ===== -->
        <?php if (!empty($podiumPlayers)): ?>
            <section class="section" style="padding-top:0;">
                <div class="section-header">
                    <h2><i class="fas fa-medal"></i> Podium</h2>
                </div>
                <div class="podium-section">
                    <!-- 2nd Place (Silver) -->
                    <div class="podium-item">
                        <div class="podium-rank silver">🥈</div>
                        <div class="podium-avatar"><i class="fas fa-user"></i></div>
                        <div class="podium-name"><?php echo e($podiumPlayers[1]['name'] ?? 'Runner Up'); ?></div>
                        <div class="podium-title">2nd Place</div>
                        <div class="podium-points"><?php echo e($podiumPlayers[1]['points'] ?? '0'); ?> points</div>
                        <div class="podium-medal silver"><i class="fas fa-medal"></i></div>
                    </div>

                    <!-- 1st Place (Gold) -->
                    <div class="podium-item" style="transform:scale(1.05);border-color:var(--gold);">
                        <div class="podium-rank gold">🥇</div>
                        <div class="podium-avatar" style="border-color:var(--gold);"><i class="fas fa-user"></i></div>
                        <div class="podium-name"><?php echo e($podiumPlayers[0]['name'] ?? 'Champion'); ?></div>
                        <div class="podium-title">🏆 Champion</div>
                        <div class="podium-points"><?php echo e($podiumPlayers[0]['points'] ?? '0'); ?> points</div>
                        <div class="podium-medal gold"><i class="fas fa-medal"></i></div>
                    </div>

                    <!-- 3rd Place (Bronze) -->
                    <div class="podium-item">
                        <div class="podium-rank bronze">🥉</div>
                        <div class="podium-avatar"><i class="fas fa-user"></i></div>
                        <div class="podium-name"><?php echo e($podiumPlayers[2]['name'] ?? 'Third Place'); ?></div>
                        <div class="podium-title">3rd Place</div>
                        <div class="podium-points"><?php echo e($podiumPlayers[2]['points'] ?? '0'); ?> points</div>
                        <div class="podium-medal bronze"><i class="fas fa-medal"></i></div>
                    </div>
                </div>
            </section>
        <?php endif; ?>

        <!-- ===== TOURNAMENT STATS ===== -->
        <section class="section" style="padding-top:0;">
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentStats['total_rounds'] ?? 11); ?></div>
                    <div class="stat-label">Total Rounds</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentStats['total_games'] ?? 198); ?></div>
                    <div class="stat-label">Games Played</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentStats['decisive_games'] ?? 142); ?></div>
                    <div class="stat-label">Decisive Games</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentStats['draws'] ?? 56); ?></div>
                    <div class="stat-label">Draws</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentStats['white_wins'] ?? 78); ?></div>
                    <div class="stat-label">White Wins</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentStats['black_wins'] ?? 64); ?></div>
                    <div class="stat-label">Black Wins</div>
                </div>
            </div>
        </section>

        <!-- ===== FINAL STANDINGS ===== -->
        <section class="section" style="padding-top:0;">
            <div class="section-header">
                <h2><i class="fas fa-list-ol"></i> Final Standings</h2>
                <a href="standings.php?id=<?php echo e($tournamentId); ?>" class="view-all">Full Standings <i class="fas fa-arrow-right"></i></a>
            </div>
            <div class="standings-table-wrapper">
                <table class="standings-table">
                    <thead>
                        <tr>
                            <th style="text-align:left;">#</th>
                            <th style="text-align:left;">Player</th>
                            <th style="text-align:center;">Rating</th>
                            <th style="text-align:center;">Points</th>
                            <th style="text-align:center;">Wins</th>
                            <th style="text-align:center;">Draws</th>
                            <th style="text-align:center;">Losses</th>
                            <th style="text-align:center;">Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($finalStandings)): ?>
                            <?php foreach ($finalStandings as $index => $player): ?>
                                <tr>
                                    <td class="rank rank-<?php echo $index + 1 <= 3 ? $index + 1 : ''; ?>"><?php echo e($index + 1); ?></td>
                                    <td class="player-name">
                                        <?php echo e($player['name']); ?>
                                        <?php if ($index === 0): ?>
                                            <span style="color:var(--gold);font-size:0.7rem;"> 👑</span>
                                        <?php endif; ?>
                                    </td>
                                    <td style="text-align:center;color:#a09080;"><?php echo e($player['rating']); ?></td>
                                    <td class="points" style="text-align:center;"><?php echo e($player['points']); ?></td>
                                    <td class="wins" style="text-align:center;"><?php echo e($player['wins']); ?></td>
                                    <td class="draws" style="text-align:center;"><?php echo e($player['draws']); ?></td>
                                    <td class="losses" style="text-align:center;"><?php echo e($player['losses']); ?></td>
                                    <td style="text-align:center;color:#3498db;font-weight:600;"><?php echo e($player['score'] ?? $player['points']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td class="rank rank-1">1</td><td class="player-name">Magnus Carlsen 👑</td><td style="text-align:center;color:#a09080;">2847</td><td class="points" style="text-align:center;">8.5</td><td class="wins" style="text-align:center;">7</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">1</td><td style="text-align:center;color:#3498db;font-weight:600;">8.5</td></tr>
                            <tr><td class="rank rank-2">2</td><td class="player-name">Ian Nepomniachtchi</td><td style="text-align:center;color:#a09080;">2795</td><td class="points" style="text-align:center;">7.5</td><td class="wins" style="text-align:center;">6</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">2</td><td style="text-align:center;color:#3498db;font-weight:600;">7.5</td></tr>
                            <tr><td class="rank rank-3">3</td><td class="player-name">Hikaru Nakamura</td><td style="text-align:center;color:#a09080;">2788</td><td class="points" style="text-align:center;">6.5</td><td class="wins" style="text-align:center;">5</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">3</td><td style="text-align:center;color:#3498db;font-weight:600;">6.5</td></tr>
                            <tr><td>4</td><td class="player-name">Fabiano Caruana</td><td style="text-align:center;color:#a09080;">2782</td><td class="points" style="text-align:center;">6.0</td><td class="wins" style="text-align:center;">4</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">3</td><td style="text-align:center;color:#3498db;font-weight:600;">6.0</td></tr>
                            <tr><td>5</td><td class="player-name">Levon Aronian</td><td style="text-align:center;color:#a09080;">2775</td><td class="points" style="text-align:center;">5.5</td><td class="wins" style="text-align:center;">3</td><td class="draws" style="text-align:center;">5</td><td class="losses" style="text-align:center;">3</td><td style="text-align:center;color:#3498db;font-weight:600;">5.5</td></tr>
                            <tr><td>6</td><td class="player-name">Wesley So</td><td style="text-align:center;color:#a09080;">2760</td><td class="points" style="text-align:center;">5.0</td><td class="wins" style="text-align:center;">3</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">4</td><td style="text-align:center;color:#3498db;font-weight:600;">5.0</td></tr>
                            <tr><td>7</td><td class="player-name">Anish Giri</td><td style="text-align:center;color:#a09080;">2745</td><td class="points" style="text-align:center;">4.5</td><td class="wins" style="text-align:center;">2</td><td class="draws" style="text-align:center;">5</td><td class="losses" style="text-align:center;">4</td><td style="text-align:center;color:#3498db;font-weight:600;">4.5</td></tr>
                            <tr><td>8</td><td class="player-name">Alireza Firouzja</td><td style="text-align:center;color:#a09080;">2730</td><td class="points" style="text-align:center;">4.0</td><td class="wins" style="text-align:center;">2</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">5</td><td style="text-align:center;color:#3498db;font-weight:600;">4.0</td></tr>
                            <tr><td>9</td><td class="player-name">Maxime Vachier-Lagrave</td><td style="text-align:center;color:#a09080;">2720</td><td class="points" style="text-align:center;">3.5</td><td class="wins" style="text-align:center;">1</td><td class="draws" style="text-align:center;">5</td><td class="losses" style="text-align:center;">5</td><td style="text-align:center;color:#3498db;font-weight:600;">3.5</td></tr>
                            <tr><td>10</td><td class="player-name">Shakhriyar Mamedyarov</td><td style="text-align:center;color:#a09080;">2715</td><td class="points" style="text-align:center;">3.0</td><td class="wins" style="text-align:center;">1</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">6</td><td style="text-align:center;color:#3498db;font-weight:600;">3.0</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- ===== MATCH RESULTS ===== -->
        <section class="section" style="padding-top:0;">
            <div class="section-header">
                <h2><i class="fas fa-chess"></i> Match Results</h2>
                <a href="matches.php?id=<?php echo e($tournamentId); ?>" class="view-all">All Matches <i class="fas fa-arrow-right"></i></a>
            </div>
            <div>
                <?php if (!empty($allMatches)): ?>
                    <?php foreach ($allMatches as $match): ?>
                        <div class="match-result-item">
                            <div class="match-players">
                                <div class="player">
                                    <div class="avatar"><i class="fas fa-user"></i></div>
                                    <span style="color:#f0d6b0;"><?php echo e($match['white']); ?></span>
                                    <span style="color:#7a6a5a;font-size:0.7rem;">(<?php echo e($match['white_rating'] ?? '---'); ?>)</span>
                                </div>
                                <span class="vs">VS</span>
                                <div class="player">
                                    <div class="avatar"><i class="fas fa-user"></i></div>
                                    <span style="color:#f0d6b0;"><?php echo e($match['black']); ?></span>
                                    <span style="color:#7a6a5a;font-size:0.7rem;">(<?php echo e($match['black_rating'] ?? '---'); ?>)</span>
                                </div>
                            </div>
                            <div style="text-align:center;">
                                <div class="match-result">
                                    <?php if ($match['result'] === 'win'): ?>
                                        <span class="win">🏆 <?php echo e($match['winner'] ?? 'White'); ?> wins</span>
                                    <?php elseif ($match['result'] === 'loss'): ?>
                                        <span class="loss">🏆 <?php echo e($match['winner'] ?? 'Black'); ?> wins</span>
                                    <?php elseif ($match['result'] === 'draw'): ?>
                                        <span class="draw">🤝 Draw</span>
                                    <?php else: ?>
                                        <span style="color:#3498db;">In Progress</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="match-info">
                                <?php if (isset($match['moves'])): ?>
                                    <span><i class="fas fa-exchange-alt"></i> <?php echo e($match['moves']); ?> moves</span>
                                <?php endif; ?>
                                <?php if (isset($match['round'])): ?>
                                    <span><i class="fas fa-sync"></i> Round <?php echo e($match['round']); ?></span>
                                <?php endif; ?>
                                <?php if (isset($match['board'])): ?>
                                    <span><i class="fas fa-chess-board"></i> Board <?php echo e($match['board']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="match-result-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Magnus Carlsen</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2847)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Ian Nepomniachtchi</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2795)</span>
                            </div>
                        </div>
                        <div class="match-result"><span class="win">🏆 White wins</span></div>
                        <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 45 moves</span><span><i class="fas fa-sync"></i> Round 7</span></div>
                    </div>
                    <div class="match-result-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Hikaru Nakamura</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2788)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Fabiano Caruana</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2782)</span>
                            </div>
                        </div>
                        <div class="match-result"><span class="draw">🤝 Draw</span></div>
                        <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 62 moves</span><span><i class="fas fa-sync"></i> Round 8</span></div>
                    </div>
                    <div class="match-result-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Levon Aronian</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2775)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Wesley So</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2760)</span>
                            </div>
                        </div>
                        <div class="match-result"><span class="win">🏆 White wins</span></div>
                        <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 38 moves</span><span><i class="fas fa-sync"></i> Round 6</span></div>
                    </div>
                    <div class="match-result-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Anish Giri</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2745)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Alireza Firouzja</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2730)</span>
                            </div>
                        </div>
                        <div class="match-result"><span class="loss">🏆 Black wins</span></div>
                        <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 51 moves</span><span><i class="fas fa-sync"></i> Round 5</span></div>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- ===== ABOUT TOURNAMENT ===== -->
        <section class="section" style="padding-top:0;">
            <div style="background:var(--card-bg);border:1px solid var(--border-color);border-radius:1.2rem;padding:1.5rem;">
                <h3 style="color:#f0d6b0;margin-bottom:0.8rem;display:flex;align-items:center;gap:0.5rem;">
                    <i class="fas fa-info-circle" style="color:var(--secondary);"></i> Tournament Summary
                </h3>
                <p style="color:#a09080;line-height:1.8;"><?php echo e($tournamentDetails['summary'] ?? 'A prestigious chess tournament featuring the world\'s best players. This tournament was won by ' . ($podiumPlayers[0]['name'] ?? 'the champion') . ' after a hard-fought competition.'); ?></p>
                
                <?php if (!empty($tournamentDetails['highlights'])): ?>
                    <div style="margin-top:1rem;">
                        <h4 style="color:#f0d6b0;font-size:1rem;margin-bottom:0.3rem;">Tournament Highlights:</h4>
                        <ul style="color:#a09080;line-height:1.8;list-style:none;padding-left:1rem;">
                            <?php foreach ($tournamentDetails['highlights'] as $highlight): ?>
                                <li style="padding:0.2rem 0;"><i class="fas fa-star" style="color:var(--gold);margin-right:0.5rem;"></i> <?php echo e($highlight); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </section>

    <?php else: ?>
        <section class="section" style="padding-top:3rem;">
            <div style="text-align:center;padding:4rem 2rem;">
                <i class="fas fa-exclamation-triangle" style="font-size:4rem;color:var(--secondary);"></i>
                <h2 style="color:#f0d6b0;margin:1rem 0;">Tournament Not Found</h2>
                <p style="color:#a09080;">The tournament results you're looking for don't exist or have been removed.</p>
                <a href="tournaments.php" class="btn-register" style="display:inline-block;margin-top:1.5rem;padding:0.8rem 2rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-decoration:none;">
                    <i class="fas fa-arrow-left"></i> Back to Tournaments
                </a>
            </div>
        </section>
    <?php endif; ?>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:2rem;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });
    </script>
</body>
</html>
<?php
/**
 * Helper functions for tournament results page
 */
function getTournamentResultDetails($id) {
    // Simulated tournament result data
    $tournaments = [
        1 => [
            'id' => 1,
            'name' => 'World Chess Championship 2024',
            'date' => 'Nov 25 - Dec 15, 2024',
            'location' => 'Dubai, UAE',
            'players' => 64,
            'prize' => '2,000,000',
            'time_control' => '90+30',
            'summary' => 'The 2024 World Chess Championship was won by Magnus Carlsen, who defeated Ian Nepomniachtchi 7.5-6.5 in a dramatic 14-game match. Carlsen\'s victory marked his 5th consecutive world championship title.'
        ],
        2 => [
            'id' => 2,
            'name' => 'Grand Chess Tour 2025',
            'date' => 'Nov 25-30, 2025',
            'location' => 'Paris, France',
            'players' => 32,
            'prize' => '500,000',
            'time_control' => '120+30',
            'summary' => 'Fabiano Caruana dominated the Grand Chess Tour with a stellar performance, scoring 8/11 to claim the title. The tournament featured some of the most exciting chess of the year.'
        ],
        3 => [
            'id' => 3,
            'name' => 'Chess Heaven Open 2025',
            'date' => 'Dec 1-8, 2025',
            'location' => 'Online',
            'players' => 200,
            'prize' => '50,000',
            'time_control' => '60+15',
            'summary' => 'GM Hikaru Nakamura won the Chess Heaven Open with an impressive 9.5/11 score. The tournament raised over $50,000 for chess education programs.'
        ],
        4 => [
            'id' => 4,
            'name' => 'World Rapid Championship 2025',
            'date' => 'Oct 18-20, 2025',
            'location' => 'Moscow, Russia',
            'players' => 48,
            'prize' => '150,000',
            'time_control' => '15+10',
            'summary' => 'GM Ian Nepomniachtchi won the World Rapid Championship, demonstrating exceptional tactical skills in the fast-paced format.'
        ]
    ];
    
    return $tournaments[$id] ?? $tournaments[1];
}

function getFinalStandings($tournamentId, $limit = 10) {
    if ($tournamentId == 2) {
        return [
            ['name' => 'Fabiano Caruana', 'rating' => 2782, 'points' => 8.0, 'wins' => 6, 'draws' => 4, 'losses' => 1, 'score' => 8.0],
            ['name' => 'Magnus Carlsen', 'rating' => 2847, 'points' => 7.5, 'wins' => 5, 'draws' => 5, 'losses' => 1, 'score' => 7.5],
            ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 7.0, 'wins' => 5, 'draws' => 4, 'losses' => 2, 'score' => 7.0],
            ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'points' => 6.5, 'wins' => 4, 'draws' => 5, 'losses' => 2, 'score' => 6.5],
            ['name' => 'Levon Aronian', 'rating' => 2775, 'points' => 6.0, 'wins' => 4, 'draws' => 4, 'losses' => 3, 'score' => 6.0],
            ['name' => 'Wesley So', 'rating' => 2760, 'points' => 5.5, 'wins' => 3, 'draws' => 5, 'losses' => 3, 'score' => 5.5],
            ['name' => 'Anish Giri', 'rating' => 2745, 'points' => 5.0, 'wins' => 2, 'draws' => 6, 'losses' => 3, 'score' => 5.0],
            ['name' => 'Alireza Firouzja', 'rating' => 2730, 'points' => 4.5, 'wins' => 2, 'draws' => 5, 'losses' => 4, 'score' => 4.5],
            ['name' => 'Maxime Vachier-Lagrave', 'rating' => 2720, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 5, 'score' => 4.0],
            ['name' => 'Shakhriyar Mamedyarov', 'rating' => 2715, 'points' => 3.5, 'wins' => 1, 'draws' => 5, 'losses' => 5, 'score' => 3.5]
        ];
    } elseif ($tournamentId == 3) {
        return [
            ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 9.5, 'wins' => 9, 'draws' => 1, 'losses' => 1, 'score' => 9.5],
            ['name' => 'GM Alex Rodriguez', 'rating' => 2650, 'points' => 8.5, 'wins' => 7, 'draws' => 3, 'losses' => 1, 'score' => 8.5],
            ['name' => 'IM Sarah Lee', 'rating' => 2450, 'points' => 8.0, 'wins' => 7, 'draws' => 2, 'losses' => 2, 'score' => 8.0],
            ['name' => 'FM David Chen', 'rating' => 2380, 'points' => 7.5, 'wins' => 6, 'draws' => 3, 'losses' => 2, 'score' => 7.5],
            ['name' => 'CM Emma Watson', 'rating' => 2350, 'points' => 7.0, 'wins' => 6, 'draws' => 2, 'losses' => 3, 'score' => 7.0],
            ['name' => 'James Thompson', 'rating' => 2280, 'points' => 6.5, 'wins' => 5, 'draws' => 3, 'losses' => 3, 'score' => 6.5]
        ];
    } elseif ($tournamentId == 4) {
        return [
            ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'points' => 7.5, 'wins' => 6, 'draws' => 3, 'losses' => 0, 'score' => 7.5],
            ['name' => 'Magnus Carlsen', 'rating' => 2847, 'points' => 7.0, 'wins' => 5, 'draws' => 4, 'losses' => 0, 'score' => 7.0],
            ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 6.5, 'wins' => 5, 'draws' => 3, 'losses' => 1, 'score' => 6.5],
            ['name' => 'Fabiano Caruana', 'rating' => 2782, 'points' => 6.0, 'wins' => 4, 'draws' => 4, 'losses' => 1, 'score' => 6.0],
            ['name' => 'Levon Aronian', 'rating' => 2775, 'points' => 5.5, 'wins' => 4, 'draws' => 3, 'losses' => 2, 'score' => 5.5],
            ['name' => 'Wesley So', 'rating' => 2760, 'points' => 5.0, 'wins' => 3, 'draws' => 4, 'losses' => 2, 'score' => 5.0]
        ];
    } else {
        return [
            ['name' => 'Magnus Carlsen', 'rating' => 2847, 'points' => 8.5, 'wins' => 7, 'draws' => 3, 'losses' => 1, 'score' => 8.5],
            ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'points' => 7.5, 'wins' => 6, 'draws' => 3, 'losses' => 2, 'score' => 7.5],
            ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 6.5, 'wins' => 5, 'draws' => 3, 'losses' => 3, 'score' => 6.5],
            ['name' => 'Fabiano Caruana', 'rating' => 2782, 'points' => 6.0, 'wins' => 4, 'draws' => 4, 'losses' => 3, 'score' => 6.0],
            ['name' => 'Levon Aronian', 'rating' => 2775, 'points' => 5.5, 'wins' => 3, 'draws' => 5, 'losses' => 3, 'score' => 5.5],
            ['name' => 'Wesley So', 'rating' => 2760, 'points' => 5.0, 'wins' => 3, 'draws' => 4, 'losses' => 4, 'score' => 5.0],
            ['name' => 'Anish Giri', 'rating' => 2745, 'points' => 4.5, 'wins' => 2, 'draws' => 5, 'losses' => 4, 'score' => 4.5],
            ['name' => 'Alireza Firouzja', 'rating' => 2730, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 5, 'score' => 4.0],
            ['name' => 'Maxime Vachier-Lagrave', 'rating' => 2720, 'points' => 3.5, 'wins' => 1, 'draws' => 5, 'losses' => 5, 'score' => 3.5],
            ['name' => 'Shakhriyar Mamedyarov', 'rating' => 2715, 'points' => 3.0, 'wins' => 1, 'draws' => 4, 'losses' => 6, 'score' => 3.0]
        ];
    }
}

function getAllMatches($tournamentId, $limit = 20) {
    if ($tournamentId == 2) {
        return [
            ['id' => 1, 'round' => 7, 'board' => 1, 'white' => 'Fabiano Caruana', 'white_rating' => '2782', 'black' => 'Magnus Carlsen', 'black_rating' => '2847', 'result' => 'win', 'winner' => 'White', 'moves' => 45],
            ['id' => 2, 'round' => 7, 'board' => 2, 'white' => 'Hikaru Nakamura', 'white_rating' => '2788', 'black' => 'Ian Nepomniachtchi', 'black_rating' => '2795', 'result' => 'draw', 'moves' => 62],
            ['id' => 3, 'round' => 6, 'board' => 1, 'white' => 'Levon Aronian', 'white_rating' => '2775', 'black' => 'Wesley So', 'black_rating' => '2760', 'result' => 'win', 'winner' => 'White', 'moves' => 38],
            ['id' => 4, 'round' => 6, 'board' => 2, 'white' => 'Anish Giri', 'white_rating' => '2745', 'black' => 'Alireza Firouzja', 'black_rating' => '2730', 'result' => 'loss', 'winner' => 'Black', 'moves' => 51],
            ['id' => 5, 'round' => 5, 'board' => 1, 'white' => 'Magnus Carlsen', 'white_rating' => '2847', 'black' => 'Fabiano Caruana', 'black_rating' => '2782', 'result' => 'draw', 'moves' => 56],
            ['id' => 6, 'round' => 5, 'board' => 2, 'white' => 'Ian Nepomniachtchi', 'white_rating' => '2795', 'black' => 'Hikaru Nakamura', 'black_rating' => '2788', 'result' => 'win', 'winner' => 'White', 'moves' => 41],
            ['id' => 7, 'round' => 4, 'board' => 1, 'white' => 'Wesley So', 'white_rating' => '2760', 'black' => 'Levon Aronian', 'black_rating' => '2775', 'result' => 'draw', 'moves' => 49],
            ['id' => 8, 'round' => 4, 'board' => 2, 'white' => 'Alireza Firouzja', 'white_rating' => '2730', 'black' => 'Anish Giri', 'black_rating' => '2745', 'result' => 'win', 'winner' => 'White', 'moves' => 33]
        ];
    } elseif ($tournamentId == 3) {
        return [
            ['id' => 1, 'round' => 11, 'board' => 1, 'white' => 'Hikaru Nakamura', 'white_rating' => '2788', 'black' => 'GM Alex Rodriguez', 'black_rating' => '2650', 'result' => 'win', 'winner' => 'White', 'moves' => 36],
            ['id' => 2, 'round' => 11, 'board' => 2, 'white' => 'IM Sarah Lee', 'white_rating' => '2450', 'black' => 'FM David Chen', 'black_rating' => '2380', 'result' => 'draw', 'moves' => 48],
            ['id' => 3, 'round' => 10, 'board' => 1, 'white' => 'GM Alex Rodriguez', 'white_rating' => '2650', 'black' => 'Hikaru Nakamura', 'black_rating' => '2788', 'result' => 'loss', 'winner' => 'Black', 'moves' => 42],
            ['id' => 4, 'round' => 10, 'board' => 2, 'white' => 'CM Emma Watson', 'white_rating' => '2350', 'black' => 'James Thompson', 'black_rating' => '2280', 'result' => 'win', 'winner' => 'White', 'moves' => 29]
        ];
    } else {
        return [
            ['id' => 1, 'round' => 7, 'board' => 1, 'white' => 'Magnus Carlsen', 'white_rating' => '2847', 'black' => 'Ian Nepomniachtchi', 'black_rating' => '2795', 'result' => 'win', 'winner' => 'White', 'moves' => 45],
            ['id' => 2, 'round' => 7, 'board' => 2, 'white' => 'Hikaru Nakamura', 'white_rating' => '2788', 'black' => 'Fabiano Caruana', 'black_rating' => '2782', 'result' => 'draw', 'moves' => 62],
            ['id' => 3, 'round' => 6, 'board' => 1, 'white' => 'Levon Aronian', 'white_rating' => '2775', 'black' => 'Wesley So', 'black_rating' => '2760', 'result' => 'win', 'winner' => 'White', 'moves' => 38],
            ['id' => 4, 'round' => 6, 'board' => 2, 'white' => 'Anish Giri', 'white_rating' => '2745', 'black' => 'Alireza Firouzja', 'black_rating' => '2730', 'result' => 'loss', 'winner' => 'Black', 'moves' => 51],
            ['id' => 5, 'round' => 5, 'board' => 1, 'white' => 'Ian Nepomniachtchi', 'white_rating' => '2795', 'black' => 'Magnus Carlsen', 'black_rating' => '2847', 'result' => 'draw', 'moves' => 56],
            ['id' => 6, 'round' => 5, 'board' => 2, 'white' => 'Fabiano Caruana', 'white_rating' => '2782', 'black' => 'Hikaru Nakamura', 'black_rating' => '2788', 'result' => 'win', 'winner' => 'White', 'moves' => 41],
            ['id' => 7, 'round' => 4, 'board' => 1, 'white' => 'Wesley So', 'white_rating' => '2760', 'black' => 'Levon Aronian', 'black_rating' => '2775', 'result' => 'draw', 'moves' => 49],
            ['id' => 8, 'round' => 4, 'board' => 2, 'white' => 'Alireza Firouzja', 'white_rating' => '2730', 'black' => 'Anish Giri', 'black_rating' => '2745', 'result' => 'win', 'winner' => 'White', 'moves' => 33]
        ];
    }
}

function getTournamentResultStats($tournamentId) {
    if ($tournamentId == 2) {
        return [
            'total_rounds' => 8,
            'total_games' => 56,
            'decisive_games' => 38,
            'draws' => 18,
            'white_wins' => 22,
            'black_wins' => 16
        ];
    } elseif ($tournamentId == 3) {
        return [
            'total_rounds' => 11,
            'total_games' => 220,
            'decisive_games' => 165,
            'draws' => 55,
            'white_wins' => 95,
            'black_wins' => 70
        ];
    } elseif ($tournamentId == 4) {
        return [
            'total_rounds' => 9,
            'total_games' => 72,
            'decisive_games' => 52,
            'draws' => 20,
            'white_wins' => 30,
            'black_wins' => 22
        ];
    } else {
        return [
            'total_rounds' => 14,
            'total_games' => 198,
            'decisive_games' => 142,
            'draws' => 56,
            'white_wins' => 78,
            'black_wins' => 64
        ];
    }
}

function getPodiumPlayers($tournamentId) {
    $standings = getFinalStandings($tournamentId, 3);
    return $standings;
}
?>