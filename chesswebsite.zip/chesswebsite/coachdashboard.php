<?php
/**
 * Chess Heaven - Coach Dashboard
 * Complete coach dashboard with all features
 * Enhanced: Coach can play chess, request games, and oversee matches
 */

require_once 'config.php';

// Check if user is logged in and is a coach
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header('Location: login.php');
    exit;
}

// Redirect non-coaches
if ($_SESSION['role'] === 'admin') {
    header('Location: admindashboard.php');
    exit;
} elseif ($_SESSION['role'] === 'member') {
    header('Location: userdashboard.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Coach';
$displayName = $_SESSION['display_name'] ?? $username;
$role = $_SESSION['role'] ?? 'coach';
$rating = $_SESSION['rating'] ?? 1200;
$email = $_SESSION['email'] ?? '';
$coachLevel = $_SESSION['coach_level'] ?? 'junior';
$specialization = $_SESSION['specialization'] ?? 'General';
$experienceYears = $_SESSION['experience_years'] ?? 0;
$certification = $_SESSION['certification'] ?? '';
$isAvailable = $_SESSION['is_available'] ?? 1;
$maxStudents = $_SESSION['max_students'] ?? 20;
$hourlyRate = $_SESSION['hourly_rate'] ?? 0;
$biography = $_SESSION['biography'] ?? '';

// Get coach data from database
$coachData = getCoachData($userId);
if ($coachData) {
    $coachLevel = $coachData['coach_level'] ?? 'junior';
    $specialization = $coachData['specialization'] ?? 'General';
    $experienceYears = $coachData['experience_years'] ?? 0;
    $certification = $coachData['certification'] ?? '';
    $isAvailable = $coachData['is_available'] ?? 1;
    $maxStudents = $coachData['max_students'] ?? 20;
    $hourlyRate = $coachData['hourly_rate'] ?? 0;
    $biography = $coachData['biography'] ?? '';
}

// Get site settings
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');

// Sample data for demonstration
$activeStudents = 12;
$upcomingSessions = 5;
$totalLessons = 24;
$assignmentsPending = 7;
$notificationCount = 4;

// Sample online users for chess challenges
$onlineUsers = [
    ['id' => 1, 'username' => 'GrandMaster99', 'role' => 'member', 'status' => 'online', 'rating' => 2150],
    ['id' => 2, 'username' => 'ChessPro2024', 'role' => 'member', 'status' => 'online', 'rating' => 1850],
    ['id' => 3, 'username' => 'QueenSlayer', 'role' => 'member', 'status' => 'online', 'rating' => 1920],
    ['id' => 4, 'username' => 'TacticalKing', 'role' => 'member', 'status' => 'online', 'rating' => 2080],
    ['id' => 5, 'username' => 'EndgameMaster', 'role' => 'member', 'status' => 'online', 'rating' => 1750],
];

// Sample active games (for oversight)
$activeGames = [
    ['id' => 101, 'white' => 'GrandMaster99', 'black' => 'ChessPro2024', 'status' => 'in_progress', 'move' => 14, 'time' => '12:34'],
    ['id' => 102, 'white' => 'QueenSlayer', 'black' => 'TacticalKing', 'status' => 'in_progress', 'move' => 9, 'time' => '06:22'],
    ['id' => 103, 'white' => 'EndgameMaster', 'black' => 'UnknownPlayer', 'status' => 'in_progress', 'move' => 22, 'time' => '18:45'],
];

// Get students (example data)
$students = [
    ['id' => 1, 'name' => 'Alice Johnson', 'rating' => 1450, 'progress' => 65, 'joined' => '2026-01-15', 'status' => 'active'],
    ['id' => 2, 'name' => 'Bob Smith', 'rating' => 1320, 'progress' => 42, 'joined' => '2026-02-01', 'status' => 'active'],
    ['id' => 3, 'name' => 'Carol White', 'rating' => 1580, 'progress' => 78, 'joined' => '2025-11-10', 'status' => 'active'],
    ['id' => 4, 'name' => 'David Brown', 'rating' => 1200, 'progress' => 25, 'joined' => '2026-03-15', 'status' => 'active'],
    ['id' => 5, 'name' => 'Eva Green', 'rating' => 1650, 'progress' => 85, 'joined' => '2025-09-20', 'status' => 'active'],
];

// Get lessons (example data)
$lessons = [
    ['id' => 1, 'title' => 'Opening Principles', 'topic' => 'Openings', 'status' => 'published', 'date' => '2026-06-28'],
    ['id' => 2, 'title' => 'Pawn Endgames', 'topic' => 'Endgames', 'status' => 'draft', 'date' => '2026-07-01'],
    ['id' => 3, 'title' => 'Tactical Patterns', 'topic' => 'Tactics', 'status' => 'published', 'date' => '2026-06-25'],
    ['id' => 4, 'title' => 'Positional Play', 'topic' => 'Strategy', 'status' => 'scheduled', 'date' => '2026-07-05'],
];

// Get upcoming sessions (example data)
$upcomingSessionsList = [
    ['id' => 1, 'student' => 'Alice Johnson', 'date' => '2026-07-04', 'time' => '10:00 AM', 'type' => 'Online'],
    ['id' => 2, 'student' => 'Bob Smith', 'date' => '2026-07-04', 'time' => '2:00 PM', 'type' => 'Online'],
    ['id' => 3, 'student' => 'Carol White', 'date' => '2026-07-05', 'time' => '11:00 AM', 'type' => 'In-Person'],
];

// Get tournaments (example data)
$tournaments = [
    ['id' => 1, 'name' => 'Weekly Blitz Tournament', 'date' => '2026-07-10', 'participants' => 12, 'status' => 'upcoming'],
    ['id' => 2, 'name' => 'Monthly Classical Championship', 'date' => '2026-07-20', 'participants' => 24, 'status' => 'upcoming'],
];

// Get recent notifications (example data)
$notifications = [
    ['id' => 1, 'type' => 'student_join', 'message' => 'New student registered: David Brown', 'time' => '2 hours ago', 'read' => false],
    ['id' => 2, 'type' => 'assignment', 'message' => 'Assignment submitted by Alice Johnson', 'time' => '4 hours ago', 'read' => false],
    ['id' => 3, 'type' => 'session', 'message' => 'Session reminder: Bob Smith tomorrow at 2:00 PM', 'time' => '1 day ago', 'read' => true],
];

// Get statistics (example data)
$statistics = [
    'total_students' => 12,
    'lessons_created' => 24,
    'assignments_completed' => 45,
    'sessions_conducted' => 68,
    'avg_performance' => 72,
    'improvement_trend' => '+8%',
];

// Determine active tab
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'dashboard';

// Handle POST requests
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle profile update
    if (isset($_POST['update_profile'])) {
        $displayName = trim($_POST['display_name'] ?? '');
        $biography = trim($_POST['biography'] ?? '');
        $specialization = trim($_POST['specialization'] ?? '');
        $experienceYears = intval($_POST['experience_years'] ?? 0);
        $certification = trim($_POST['certification'] ?? '');
        $hourlyRate = floatval($_POST['hourly_rate'] ?? 0);
        $isAvailable = isset($_POST['is_available']) ? 1 : 0;
        
        $conn = getDBConnection();
        if ($conn) {
            $stmt = $conn->prepare("UPDATE users SET display_name = ? WHERE id = ?");
            $stmt->bind_param("si", $displayName, $userId);
            $stmt->execute();
            
            $stmt = $conn->prepare("UPDATE coaches SET specialization = ?, experience_years = ?, certification = ?, hourly_rate = ?, is_available = ?, biography = ? WHERE user_id = ?");
            $stmt->bind_param("sisdisi", $specialization, $experienceYears, $certification, $hourlyRate, $isAvailable, $biography, $userId);
            $stmt->execute();
            
            $_SESSION['display_name'] = $displayName;
            $_SESSION['specialization'] = $specialization;
            $_SESSION['experience_years'] = $experienceYears;
            $_SESSION['certification'] = $certification;
            $_SESSION['hourly_rate'] = $hourlyRate;
            $_SESSION['is_available'] = $isAvailable;
            $_SESSION['biography'] = $biography;
            
            $message = 'Profile updated successfully!';
            $messageType = 'success';
        }
    }
    
    // Handle availability toggle
    if (isset($_POST['toggle_availability'])) {
        $newStatus = isset($_POST['is_available']) ? 1 : 0;
        $conn = getDBConnection();
        if ($conn) {
            $stmt = $conn->prepare("UPDATE coaches SET is_available = ? WHERE user_id = ?");
            $stmt->bind_param("ii", $newStatus, $userId);
            $stmt->execute();
            $_SESSION['is_available'] = $newStatus;
            $isAvailable = $newStatus;
            $message = 'Availability status updated!';
            $messageType = 'success';
        }
    }
    
    // Handle password change
    if (isset($_POST['change_password'])) {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (strlen($newPassword) < 6) {
            $message = 'Password must be at least 6 characters long.';
            $messageType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'Passwords do not match.';
            $messageType = 'error';
        } else {
            $conn = getDBConnection();
            if ($conn) {
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                
                if (password_verify($currentPassword, $user['password'])) {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->bind_param("si", $hashedPassword, $userId);
                    $stmt->execute();
                    
                    $message = 'Password changed successfully!';
                    $messageType = 'success';
                } else {
                    $message = 'Current password is incorrect.';
                    $messageType = 'error';
                }
            }
        }
    }
    
    // Handle notification preferences
    if (isset($_POST['update_notifications'])) {
        $emailNotifications = isset($_POST['email_notifications']) ? 1 : 0;
        $studentJoins = isset($_POST['student_joins']) ? 1 : 0;
        $assignmentSubmissions = isset($_POST['assignment_submissions']) ? 1 : 0;
        $sessionReminders = isset($_POST['session_reminders']) ? 1 : 0;
        
        $message = 'Notification preferences updated!';
        $messageType = 'success';
    }
    
    // Handle chess game request
    if (isset($_POST['request_game'])) {
        $opponentId = intval($_POST['opponent_id'] ?? 0);
        $color = $_POST['color'] ?? 'random';
        $timeControl = $_POST['time_control'] ?? '10';
        
        if ($opponentId > 0) {
            $opponentName = '';
            foreach ($onlineUsers as $u) {
                if ($u['id'] == $opponentId) {
                    $opponentName = $u['username'];
                    break;
                }
            }
            $message = "Game request sent to {$opponentName}!";
            $messageType = 'success';
        } else {
            $message = "Please select an opponent.";
            $messageType = 'error';
        }
    }
    
    // Handle game oversight (view game)
    if (isset($_POST['oversee_game'])) {
        $gameId = intval($_POST['game_id'] ?? 0);
        if ($gameId > 0) {
            $message = "Now overseeing game #{$gameId}. You can view moves in real-time.";
            $messageType = 'info';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Coach Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --sidebar-width: 250px;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
            --light-square: #f0d9b5;
            --dark-square: #b58863;
        }
        body {
            min-height:100vh;
            background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505);
            color:#f0e0d0;
            padding-top:var(--nav-height);
            display:flex;
            flex-direction:column;
        }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
            display:flex; align-items:center; justify-content:space-between;
        }
        .navbar-fixed.scrolled {
            background:rgba(10,5,5,0.98);
            box-shadow:0 4px 30px rgba(0,0,0,0.5);
        }
        .navbar-left { display:flex; align-items:center; gap:1rem; }
        .navbar-logo {
            display:flex; align-items:center; gap:0.8rem;
            text-decoration:none;
        }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .navbar-right { display:flex; align-items:center; gap:1rem; }
        .navbar-right .notification-btn {
            position:relative;
            background:rgba(255,255,255,0.05);
            border:1px solid var(--border-color);
            border-radius:50%;
            width:40px; height:40px;
            display:flex; align-items:center; justify-content:center;
            color:#d4c0b0; transition:0.3s;
            cursor:pointer;
        }
        .navbar-right .notification-btn:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        .navbar-right .notification-btn .badge {
            position:absolute; top:-5px; right:-5px;
            background:var(--danger); color:white;
            border-radius:50%; width:20px; height:20px;
            font-size:0.7rem; font-weight:700;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-right .user-menu {
            display:flex; align-items:center; gap:0.5rem;
            cursor:pointer; padding:0.3rem 0.8rem;
            border-radius:2rem; transition:0.3s;
            border:1px solid transparent;
        }
        .navbar-right .user-menu:hover {
            border-color:var(--border-color);
            background:rgba(255,255,255,0.05);
        }
        .navbar-right .user-avatar {
            width:36px; height:36px; border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex; align-items:center; justify-content:center;
            font-weight:700; color:white; font-size:1rem;
        }
        .navbar-right .user-name {
            color:#f0d6b0; font-weight:600; font-size:0.9rem;
        }
        .navbar-right .user-name span {
            color:#7a6a5a; font-weight:400; font-size:0.75rem;
        }
        .availability-badge {
            display:inline-block;
            padding:0.2rem 0.8rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .availability-badge.available {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .availability-badge.unavailable {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
        }

        /* ===== DASHBOARD LAYOUT ===== */
        .dashboard-container {
            display:flex;
            flex:1;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width:var(--sidebar-width);
            background:rgba(10,5,5,0.8);
            backdrop-filter:blur(16px);
            border-right:1px solid var(--border-color);
            padding:1.5rem 0;
            position:fixed;
            top:var(--nav-height);
            bottom:0;
            left:0;
            overflow-y:auto;
            transition:transform 0.3s ease;
            z-index:1000;
        }
        .sidebar::-webkit-scrollbar { width:4px; }
        .sidebar::-webkit-scrollbar-track { background:transparent; }
        .sidebar::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }

        .sidebar .sidebar-section {
            padding:0 1rem 1rem;
            border-bottom:1px solid rgba(255,255,255,0.05);
            margin-bottom:1rem;
        }
        .sidebar .sidebar-section:last-child { border-bottom:none; }

        .sidebar .section-title {
            font-size:0.7rem;
            text-transform:uppercase;
            letter-spacing:1px;
            color:#5a4a3a;
            font-weight:600;
            padding:0 0.5rem;
            margin-bottom:0.5rem;
        }

        .sidebar .sidebar-item {
            display:flex;
            align-items:center;
            gap:0.8rem;
            padding:0.6rem 1rem;
            border-radius:0.5rem;
            color:#a09080;
            transition:all 0.3s;
            cursor:pointer;
            text-decoration:none;
            margin-bottom:0.2rem;
            position:relative;
        }
        .sidebar .sidebar-item:hover {
            color:#f0d6b0;
            background:rgba(139,26,26,0.2);
        }
        .sidebar .sidebar-item.active {
            color:#f0d6b0;
            background:rgba(139,26,26,0.3);
            border-left:3px solid var(--secondary);
        }
        .sidebar .sidebar-item i {
            width:20px;
            text-align:center;
            font-size:1rem;
            color:var(--secondary);
        }
        .sidebar .sidebar-item .item-badge {
            margin-left:auto;
            background:var(--danger);
            color:white;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left:var(--sidebar-width);
            flex:1;
            padding:2rem;
            min-height:calc(100vh - var(--nav-height));
        }

        /* ===== PAGE HEADER ===== */
        .page-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:2rem;
            flex-wrap:wrap;
            gap:1rem;
        }
        .page-header h1 {
            font-size:1.8rem;
            font-weight:700;
            color:#f0d6b0;
        }
        .page-header h1 i {
            color:var(--secondary);
            margin-right:0.5rem;
        }
        .page-header .header-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
        }
        .page-header .header-actions .btn {
            padding:0.6rem 1.2rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            font-size:0.85rem;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .page-header .header-actions .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .page-header .header-actions .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 6px 25px rgba(139,26,26,0.5);
        }
        .page-header .header-actions .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .page-header .header-actions .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
        }
        .page-header .header-actions .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .page-header .header-actions .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }
        .page-header .header-actions .btn-success {
            background:rgba(46,204,113,0.2);
            color:var(--success);
            border:1px solid rgba(46,204,113,0.3);
        }
        .page-header .header-actions .btn-success:hover {
            background:rgba(46,204,113,0.3);
        }
        .page-header .header-actions .btn-danger {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
            border:1px solid rgba(231,76,60,0.3);
        }
        .page-header .header-actions .btn-danger:hover {
            background:rgba(231,76,60,0.3);
        }

        /* ===== STATS GRID ===== */
        .stats-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
            gap:1rem;
            margin-bottom:2rem;
        }
        .stat-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            transition:all 0.3s;
        }
        .stat-card:hover {
            border-color:rgba(201,168,124,0.3);
            transform:translateY(-3px);
        }
        .stat-card .stat-icon {
            font-size:1.8rem;
            color:var(--secondary);
            margin-bottom:0.3rem;
        }
        .stat-card .stat-value {
            font-size:1.8rem;
            font-weight:700;
            color:#f0d6b0;
        }
        .stat-card .stat-label {
            font-size:0.8rem;
            color:#7a6a5a;
        }

        /* ===== WELCOME CARD ===== */
        .welcome-card {
            background:linear-gradient(145deg, rgba(139,26,26,0.3), rgba(10,5,5,0.5));
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
            margin-bottom:2rem;
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:1rem;
        }
        .welcome-card .welcome-text h2 {
            font-size:1.5rem;
            color:#f0d6b0;
        }
        .welcome-card .welcome-text p {
            color:#a09080;
            margin-top:0.3rem;
        }
        .welcome-card .welcome-text .coach-badge {
            display:inline-block;
            background:rgba(201,168,124,0.15);
            padding:0.2rem 1rem;
            border-radius:1rem;
            border:1px solid rgba(201,168,124,0.2);
            font-weight:600;
            color:var(--secondary);
            margin-top:0.5rem;
        }
        .welcome-card .welcome-text .coach-badge i {
            margin-right:0.3rem;
        }
        .welcome-card .welcome-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
        }
        .welcome-card .welcome-actions .btn {
            padding:0.7rem 1.5rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .welcome-card .welcome-actions .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .welcome-card .welcome-actions .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 6px 25px rgba(139,26,26,0.5);
        }
        .welcome-card .welcome-actions .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .welcome-card .welcome-actions .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
            transform:translateY(-2px);
        }
        .welcome-card .welcome-actions .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .welcome-card .welcome-actions .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }

        /* ===== CONTENT GRID ===== */
        .content-grid {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:1.5rem;
            margin-bottom:2rem;
        }
        @media (max-width:992px) {
            .content-grid { grid-template-columns:1fr; }
        }

        /* ===== CARDS ===== */
        .card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.5rem;
            transition:all 0.3s;
        }
        .card:hover {
            border-color:rgba(201,168,124,0.2);
        }
        .card .card-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:1rem;
        }
        .card .card-header h3 {
            color:#f0d6b0;
            font-size:1.1rem;
        }
        .card .card-header .card-action {
            color:var(--secondary);
            font-size:0.85rem;
            transition:0.3s;
            cursor:pointer;
        }
        .card .card-header .card-action:hover {
            color:#f0d6b0;
        }
        .card .card-body { color:#d4c0b0; }

        /* ===== STUDENT ITEM ===== */
        .student-item {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:0.5rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .student-item:last-child { border-bottom:none; }
        .student-item .student-info {
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .student-item .student-avatar {
            width:32px; height:32px; border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex; align-items:center; justify-content:center;
            font-weight:700; color:white; font-size:0.8rem;
        }
        .student-item .student-progress {
            width:60px;
            height:4px;
            background:rgba(255,255,255,0.1);
            border-radius:2px;
            overflow:hidden;
        }
        .student-item .student-progress .progress-bar {
            height:100%;
            background:linear-gradient(90deg,var(--secondary),var(--gold));
            border-radius:2px;
        }
        .student-item .student-status {
            font-size:0.7rem;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
        }
        .student-item .student-status.active {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .student-item .student-status.inactive {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
        }

        /* ===== SESSION ITEM ===== */
        .session-item {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:0.5rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .session-item:last-child { border-bottom:none; }
        .session-item .session-info {
            display:flex;
            flex-direction:column;
            gap:0.2rem;
        }
        .session-item .session-info .session-student {
            color:#f0d6b0;
            font-weight:500;
        }
        .session-item .session-info .session-detail {
            font-size:0.8rem;
            color:#7a6a5a;
        }
        .session-item .session-type {
            font-size:0.7rem;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            background:rgba(52,152,219,0.2);
            color:var(--info);
        }

        /* ===== NOTIFICATION ITEM ===== */
        .notification-item {
            display:flex;
            gap:0.8rem;
            padding:0.6rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .notification-item:last-child { border-bottom:none; }
        .notification-item .notif-icon {
            width:32px; height:32px; border-radius:50%;
            background:rgba(139,26,26,0.3);
            display:flex; align-items:center; justify-content:center;
            color:var(--secondary);
            flex-shrink:0;
        }
        .notification-item .notif-content {
            flex:1;
        }
        .notification-item .notif-content .notif-text {
            font-size:0.9rem;
            color:#d4c0b0;
        }
        .notification-item .notif-content .notif-text strong {
            color:#f0d6b0;
        }
        .notification-item .notif-content .notif-time {
            font-size:0.75rem;
            color:#5a4a3a;
        }
        .notification-item.unread {
            background:rgba(139,26,26,0.1);
            border-radius:0.5rem;
            padding:0.6rem 0.8rem;
        }

        /* ===== TAB CONTENT ===== */
        .tab-content {
            display:none;
            animation:fadeIn 0.3s ease;
        }
        .tab-content.active {
            display:block;
        }
        @keyframes fadeIn {
            from { opacity:0; transform:translateY(10px); }
            to { opacity:1; transform:translateY(0); }
        }

        /* ===== FORMS ===== */
        .form-group {
            margin-bottom:1.2rem;
        }
        .form-group label {
            display:block;
            color:#d4c0b0;
            font-weight:500;
            margin-bottom:0.3rem;
            font-size:0.9rem;
        }
        .form-group .form-control {
            width:100%;
            padding:0.7rem 1rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0d6b0;
            font-size:0.95rem;
            transition:all 0.3s;
        }
        .form-group .form-control:focus {
            outline:none;
            border-color:var(--secondary);
            background:rgba(255,255,255,0.08);
        }
        .form-group .form-control::placeholder {
            color:#5a4a3a;
        }
        .form-group textarea.form-control {
            min-height:100px;
            resize:vertical;
        }
        .form-group .form-hint {
            font-size:0.75rem;
            color:#5a4a3a;
            margin-top:0.3rem;
        }

        /* ===== BUTTONS ===== */
        .btn {
            padding:0.6rem 1.2rem;
            border-radius:0.8rem;
            border:none;
            font-weight:600;
            font-size:0.85rem;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
        }
        .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.4);
        }
        .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
        }
        .btn-success {
            background:rgba(46,204,113,0.2);
            color:var(--success);
            border:1px solid rgba(46,204,113,0.3);
        }
        .btn-success:hover {
            background:rgba(46,204,113,0.3);
        }
        .btn-danger {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
            border:1px solid rgba(231,76,60,0.3);
        }
        .btn-danger:hover {
            background:rgba(231,76,60,0.3);
        }
        .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }

        /* ===== MESSAGES ===== */
        .message {
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            margin-bottom:1.5rem;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .message-success {
            background:rgba(46,204,113,0.15);
            border:1px solid rgba(46,204,113,0.2);
            color:var(--success);
        }
        .message-error {
            background:rgba(231,76,60,0.15);
            border:1px solid rgba(231,76,60,0.2);
            color:var(--danger);
        }
        .message-info {
            background:rgba(52,152,219,0.15);
            border:1px solid rgba(52,152,219,0.2);
            color:var(--info);
        }

        /* ===== TABLE ===== */
        .table {
            width:100%;
            border-collapse:collapse;
        }
        .table th {
            text-align:left;
            padding:0.6rem 0.8rem;
            color:#5a4a3a;
            font-weight:600;
            font-size:0.8rem;
            text-transform:uppercase;
            letter-spacing:0.5px;
            border-bottom:1px solid var(--border-color);
        }
        .table td {
            padding:0.6rem 0.8rem;
            border-bottom:1px solid rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .table tr:hover td {
            background:rgba(255,255,255,0.02);
        }
        .table .status-badge {
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .table .status-badge.published {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .table .status-badge.draft {
            background:rgba(241,196,15,0.2);
            color:var(--warning);
        }
        .table .status-badge.scheduled {
            background:rgba(52,152,219,0.2);
            color:var(--info);
        }
        .table .status-badge.in_progress {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }

        /* ===== CHESS BOARD ===== */
        .chess-board-container {
            display:flex;
            justify-content:center;
            padding:0.5rem;
        }
        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:500px;
            aspect-ratio:1;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.5rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
        }
        .chess-board .square.light {
            background:var(--light-square);
        }
        .chess-board .square.dark {
            background:var(--dark-square);
        }
        .chess-board .square.selected {
            background:rgba(255,255,0,0.4) !important;
        }
        .chess-board .square.legal-move {
            position:relative;
        }
        .chess-board .square.legal-move::after {
            content:'';
            position:absolute;
            width:30%;
            height:30%;
            background:rgba(0,0,0,0.15);
            border-radius:50%;
        }
        .chess-board .square.legal-capture {
            position:relative;
        }
        .chess-board .square.legal-capture::after {
            content:'';
            position:absolute;
            width:100%;
            height:100%;
            border:6px solid rgba(0,0,0,0.15);
            border-radius:50%;
            box-sizing:border-box;
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }

        /* ===== GAME OVERSIGHT ===== */
        .game-oversight {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:1rem;
        }
        @media (max-width:768px) {
            .game-oversight {
                grid-template-columns:1fr;
            }
        }

        .game-status-bar {
            display:flex;
            justify-content:space-between;
            padding:0.5rem 0;
            border-bottom:1px solid var(--border-color);
            margin-bottom:0.5rem;
        }
        .game-status-bar .player {
            font-weight:600;
            color:#f0d6b0;
        }
        .game-status-bar .player i {
            margin-right:0.3rem;
        }
        .game-status-bar .move-info {
            color:#7a6a5a;
            font-size:0.85rem;
        }

        /* ===== LESSON GRID ===== */
        .lesson-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(250px,1fr));
            gap:1rem;
        }
        .lesson-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            transition:all 0.3s;
        }
        .lesson-card:hover {
            border-color:rgba(201,168,124,0.3);
            transform:translateY(-3px);
        }
        .lesson-card .lesson-title {
            color:#f0d6b0;
            font-weight:600;
            font-size:1rem;
        }
        .lesson-card .lesson-topic {
            color:#7a6a5a;
            font-size:0.8rem;
        }
        .lesson-card .lesson-meta {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-top:0.5rem;
            padding-top:0.5rem;
            border-top:1px solid rgba(255,255,255,0.05);
        }
        .lesson-card .lesson-actions {
            display:flex;
            gap:0.3rem;
        }
        .lesson-card .lesson-actions .btn {
            padding:0.2rem 0.6rem;
            font-size:0.75rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:768px) {
            :root { --nav-height:60px; --sidebar-width:0px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .navbar-left .logo-text { font-size:1rem; }
            .navbar-right .user-name { display:none; }
            
            .sidebar {
                transform:translateX(-100%);
                width:280px;
            }
            .sidebar.open {
                transform:translateX(0);
            }
            .sidebar-overlay {
                display:none;
                position:fixed;
                top:var(--nav-height);
                left:0; right:0; bottom:0;
                background:rgba(0,0,0,0.5);
                z-index:999;
            }
            .sidebar-overlay.active {
                display:block;
            }
            
            .main-content {
                margin-left:0;
                padding:1rem;
            }
            .welcome-card {
                flex-direction:column;
                text-align:center;
            }
            .welcome-card .welcome-actions {
                justify-content:center;
            }
            .stats-grid {
                grid-template-columns:repeat(2,1fr);
            }
            .content-grid {
                grid-template-columns:1fr;
            }
            .page-header {
                flex-direction:column;
                align-items:flex-start;
            }
            .page-header .header-actions {
                width:100%;
            }
            .page-header .header-actions .btn {
                flex:1;
                justify-content:center;
            }
            .chess-board .square .piece {
                font-size:2rem;
            }
            .game-oversight {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:480px) {
            .stats-grid {
                grid-template-columns:1fr;
            }
            .student-item {
                flex-direction:column;
                align-items:flex-start;
                gap:0.3rem;
            }
            .session-item {
                flex-direction:column;
                align-items:flex-start;
                gap:0.3rem;
            }
            .chess-board .square .piece {
                font-size:1.5rem;
            }
        }

        /* ===== MOBILE SIDEBAR TOGGLE ===== */
        .sidebar-toggle {
            display:none;
            background:rgba(255,255,255,0.05);
            border:1px solid var(--border-color);
            border-radius:0.5rem;
            color:#d4c0b0;
            padding:0.5rem 0.8rem;
            cursor:pointer;
            transition:0.3s;
            font-size:1.2rem;
        }
        .sidebar-toggle:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        @media (max-width:768px) {
            .sidebar-toggle {
                display:block;
            }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-left">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
        </div>
        <div class="navbar-right">
            <span class="availability-badge <?php echo $isAvailable ? 'available' : 'unavailable'; ?>">
                <i class="fas fa-<?php echo $isAvailable ? 'check-circle' : 'times-circle'; ?>"></i>
                <?php echo $isAvailable ? 'Available' : 'Unavailable'; ?>
            </span>
            <div class="notification-btn" onclick="switchTab('notifications')">
                <i class="fas fa-bell"></i>
                <?php if ($notificationCount > 0): ?>
                    <span class="badge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </div>
            <div class="user-menu" onclick="switchTab('profile')">
                <div class="user-avatar"><?php echo strtoupper(substr($displayName, 0, 1)); ?></div>
                <span class="user-name"><?php echo e($displayName); ?> <span>· Coach</span></span>
            </div>
            <a href="logout.php" class="btn" style="border:1px solid var(--border-color);background:transparent;color:#7a6a5a;padding:0.4rem 0.8rem;border-radius:0.5rem;font-size:0.8rem;">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>

    <!-- ===== SIDEBAR OVERLAY (mobile) ===== -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ===== SIDEBAR ===== -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-section">
            <div class="section-title">Main</div>
            <a class="sidebar-item <?php echo $activeTab === 'dashboard' ? 'active' : ''; ?>" href="?tab=dashboard">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'profile' ? 'active' : ''; ?>" href="?tab=profile">
                <i class="fas fa-user"></i> My Profile
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'students' ? 'active' : ''; ?>" href="?tab=students">
                <i class="fas fa-user-graduate"></i> Student Management
                <span class="item-badge"><?php echo $activeStudents; ?></span>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'lessons' ? 'active' : ''; ?>" href="?tab=lessons">
                <i class="fas fa-book"></i> Lesson Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'assignments' ? 'active' : ''; ?>" href="?tab=assignments">
                <i class="fas fa-tasks"></i> Chess Assignments
                <span class="item-badge"><?php echo $assignmentsPending; ?></span>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'analysis' ? 'active' : ''; ?>" href="?tab=analysis">
                <i class="fas fa-chart-line"></i> Game Analysis
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Resources</div>
            <a class="sidebar-item <?php echo $activeTab === 'materials' ? 'active' : ''; ?>" href="?tab=materials">
                <i class="fas fa-folder-open"></i> Training Materials
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'puzzles' ? 'active' : ''; ?>" href="?tab=puzzles">
                <i class="fas fa-puzzle-piece"></i> Puzzle Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'coaching' ? 'active' : ''; ?>" href="?tab=coaching">
                <i class="fas fa-video"></i> Live Coaching
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Chess Play</div>
            <a class="sidebar-item <?php echo $activeTab === 'play' ? 'active' : ''; ?>" href="?tab=play">
                <i class="fas fa-chess-king"></i> Play Chess
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'oversee' ? 'active' : ''; ?>" href="?tab=oversee">
                <i class="fas fa-eye"></i> Oversee Games
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'challenge' ? 'active' : ''; ?>" href="?tab=challenge">
                <i class="fas fa-handshake"></i> Challenge Players
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Events</div>
            <a class="sidebar-item <?php echo $activeTab === 'tournaments' ? 'active' : ''; ?>" href="?tab=tournaments">
                <i class="fas fa-trophy"></i> Tournament Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'calendar' ? 'active' : ''; ?>" href="?tab=calendar">
                <i class="fas fa-calendar"></i> Calendar
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Communication</div>
            <a class="sidebar-item <?php echo $activeTab === 'messages' ? 'active' : ''; ?>" href="?tab=messages">
                <i class="fas fa-envelope"></i> Messages
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'feedback' ? 'active' : ''; ?>" href="?tab=feedback">
                <i class="fas fa-comment"></i> Comments & Feedback
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'notifications' ? 'active' : ''; ?>" href="?tab=notifications">
                <i class="fas fa-bell"></i> Notifications
                <?php if ($notificationCount > 0): ?>
                    <span class="item-badge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Reports</div>
            <a class="sidebar-item <?php echo $activeTab === 'progress' ? 'active' : ''; ?>" href="?tab=progress">
                <i class="fas fa-chart-bar"></i> Progress Reports
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'statistics' ? 'active' : ''; ?>" href="?tab=statistics">
                <i class="fas fa-chart-pie"></i> Statistics
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'certificates' ? 'active' : ''; ?>" href="?tab=certificates">
                <i class="fas fa-certificate"></i> Certificates
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'reports' ? 'active' : ''; ?>" href="?tab=reports">
                <i class="fas fa-file-alt"></i> Reports
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Account</div>
            <a class="sidebar-item <?php echo $activeTab === 'settings' ? 'active' : ''; ?>" href="?tab=settings">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'help' ? 'active' : ''; ?>" href="?tab=help">
                <i class="fas fa-question-circle"></i> Help & Support
            </a>
        </div>
        
        <div class="sidebar-section" style="border-bottom:none;padding-top:0.5rem;">
            <a class="sidebar-item" href="logout.php" style="color:var(--danger);">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <!-- ===== MAIN CONTENT ===== -->
    <main class="main-content">
        <!-- ====== DASHBOARD TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'dashboard' ? 'active' : ''; ?>" id="tab-dashboard">
            <div class="page-header">
                <h1><i class="fas fa-th-large"></i> Coach Dashboard</h1>
                <div class="header-actions">
                    <form method="POST" style="display:inline;">
                        <input type="hidden" name="toggle_availability" value="1">
                        <input type="hidden" name="is_available" value="<?php echo $isAvailable ? 0 : 1; ?>">
                        <button type="submit" class="btn <?php echo $isAvailable ? 'btn-success' : 'btn-danger'; ?>">
                            <i class="fas fa-<?php echo $isAvailable ? 'check-circle' : 'times-circle'; ?>"></i>
                            <?php echo $isAvailable ? 'Mark Unavailable' : 'Mark Available'; ?>
                        </button>
                    </form>
                    <a href="?tab=students" class="btn btn-primary"><i class="fas fa-user-plus"></i> Add Student</a>
                    <a href="?tab=play" class="btn btn-chess"><i class="fas fa-chess-king"></i> Play Chess</a>
                </div>
            </div>

            <!-- Welcome Card -->
            <div class="welcome-card">
                <div class="welcome-text">
                    <h2>Welcome back, Coach <?php echo e($displayName); ?>! 👋</h2>
                    <p>Here's your coaching summary for today.</p>
                    <div class="coach-badge">
                        <i class="fas fa-star"></i> <?php echo ucfirst($coachLevel); ?> Coach · <?php echo $experienceYears; ?> years experience
                        <span style="margin-left:0.5rem;">· <?php echo e($specialization); ?></span>
                    </div>
                </div>
                <div class="welcome-actions">
                    <a href="?tab=coaching" class="btn btn-primary"><i class="fas fa-video"></i> Start Session</a>
                    <a href="?tab=students" class="btn btn-secondary"><i class="fas fa-user-graduate"></i> View Students</a>
                    <a href="?tab=play" class="btn btn-chess"><i class="fas fa-chess-king"></i> Play Chess</a>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
                    <div class="stat-value"><?php echo $activeStudents; ?></div>
                    <div class="stat-label">Active Students</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-calendar-check"></i></div>
                    <div class="stat-value"><?php echo $upcomingSessions; ?></div>
                    <div class="stat-label">Upcoming Sessions</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-book"></i></div>
                    <div class="stat-value"><?php echo $totalLessons; ?></div>
                    <div class="stat-label">Lessons Created</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-tasks"></i></div>
                    <div class="stat-value"><?php echo $assignmentsPending; ?></div>
                    <div class="stat-label">Pending Assignments</div>
                </div>
            </div>

            <!-- Content Grid -->
            <div class="content-grid">
                <!-- Recent Students -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-graduate"></i> Recent Students</h3>
                        <a href="?tab=students" class="card-action">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="card-body">
                        <?php foreach (array_slice($students, 0, 4) as $student): ?>
                            <div class="student-item">
                                <div class="student-info">
                                    <div class="student-avatar"><?php echo strtoupper(substr($student['name'], 0, 1)); ?></div>
                                    <div>
                                        <strong><?php echo e($student['name']); ?></strong>
                                        <span style="font-size:0.75rem;color:#5a4a3a;display:block;">
                                            Rating: <?php echo $student['rating']; ?>
                                        </span>
                                    </div>
                                </div>
                                <div style="display:flex;align-items:center;gap:0.5rem;">
                                    <div class="student-progress">
                                        <div class="progress-bar" style="width:<?php echo $student['progress']; ?>%;"></div>
                                    </div>
                                    <span style="font-size:0.75rem;color:#5a4a3a;"><?php echo $student['progress']; ?>%</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Upcoming Sessions -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-calendar-check"></i> Upcoming Sessions</h3>
                        <a href="?tab=calendar" class="card-action">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="card-body">
                        <?php foreach ($upcomingSessionsList as $session): ?>
                            <div class="session-item">
                                <div class="session-info">
                                    <span class="session-student"><?php echo e($session['student']); ?></span>
                                    <span class="session-detail">
                                        <i class="fas fa-calendar"></i> <?php echo e($session['date']); ?> 
                                        <i class="fas fa-clock" style="margin-left:0.5rem;"></i> <?php echo e($session['time']); ?>
                                    </span>
                                </div>
                                <span class="session-type"><?php echo e($session['type']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Notifications -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-bell"></i> Recent Notifications</h3>
                    <a href="?tab=notifications" class="card-action">View All <i class="fas fa-arrow-right"></i></a>
                </div>
                <div class="card-body">
                    <?php foreach ($notifications as $notif): ?>
                        <div class="notification-item <?php echo !$notif['read'] ? 'unread' : ''; ?>">
                            <div class="notif-icon">
                                <i class="fas <?php echo $notif['type'] === 'student_join' ? 'fa-user-plus' : ($notif['type'] === 'assignment' ? 'fa-tasks' : 'fa-calendar'); ?>"></i>
                            </div>
                            <div class="notif-content">
                                <div class="notif-text"><?php echo e($notif['message']); ?></div>
                                <div class="notif-time"><i class="fas fa-clock"></i> <?php echo e($notif['time']); ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ====== PROFILE TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'profile' ? 'active' : ''; ?>" id="tab-profile">
            <div class="page-header">
                <h1><i class="fas fa-user"></i> My Profile</h1>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="document.getElementById('profileForm').submit();">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'profile'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid" style="grid-template-columns:1fr 2fr;">
                <div class="card" style="text-align:center;">
                    <div class="user-avatar" style="width:120px;height:120px;border-radius:50%;margin:0 auto 1rem;font-size:3rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));display:flex;align-items:center;justify-content:center;color:white;">
                        <?php echo strtoupper(substr($displayName, 0, 1)); ?>
                    </div>
                    <h3 style="color:#f0d6b0;"><?php echo e($displayName); ?></h3>
                    <p style="color:#7a6a5a;">@<?php echo e($username); ?></p>
                    <p style="color:var(--secondary);">
                        <i class="fas fa-star"></i> <?php echo ucfirst($coachLevel); ?> Coach
                    </p>
                    <p style="color:#5a4a3a;font-size:0.85rem;">
                        <i class="fas fa-clock"></i> <?php echo $experienceYears; ?> years experience
                    </p>
                    <p style="color:#5a4a3a;font-size:0.85rem;">
                        <i class="fas fa-certificate"></i> <?php echo e($certification ?: 'No certification'); ?>
                    </p>
                    <div style="margin-top:0.8rem;">
                        <span class="availability-badge <?php echo $isAvailable ? 'available' : 'unavailable'; ?>">
                            <i class="fas fa-<?php echo $isAvailable ? 'check-circle' : 'times-circle'; ?>"></i>
                            <?php echo $isAvailable ? 'Available' : 'Unavailable'; ?>
                        </span>
                    </div>
                    <button class="btn btn-secondary" style="margin-top:0.8rem;width:100%;">
                        <i class="fas fa-camera"></i> Change Photo
                    </button>
                </div>

                <div class="card">
                    <form id="profileForm" method="POST">
                        <input type="hidden" name="update_profile" value="1">
                        <div class="form-group">
                            <label>Display Name</label>
                            <input type="text" name="display_name" class="form-control" value="<?php echo e($displayName); ?>">
                        </div>
                        <div class="form-group">
                            <label>Biography</label>
                            <textarea name="biography" class="form-control" placeholder="Tell your students about yourself"><?php echo e($biography); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Specialization</label>
                            <input type="text" name="specialization" class="form-control" value="<?php echo e($specialization); ?>" placeholder="e.g., Openings, Endgames, Tactics">
                        </div>
                        <div class="form-group">
                            <label>Experience Years</label>
                            <input type="number" name="experience_years" class="form-control" value="<?php echo $experienceYears; ?>" min="0" max="50">
                        </div>
                        <div class="form-group">
                            <label>Certification</label>
                            <input type="text" name="certification" class="form-control" value="<?php echo e($certification); ?>" placeholder="e.g., FIDE Certified Coach">
                        </div>
                        <div class="form-group">
                            <label>Hourly Rate ($)</label>
                            <input type="number" name="hourly_rate" class="form-control" value="<?php echo $hourlyRate; ?>" step="5" min="0">
                        </div>
                        <div class="form-group">
                            <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                <input type="checkbox" name="is_available" <?php echo $isAvailable ? 'checked' : ''; ?>>
                                Available for Coaching
                            </label>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-lock"></i> Change Password</h3>
                </div>
                <div class="card-body">
                    <form method="POST" style="max-width:400px;">
                        <input type="hidden" name="change_password" value="1">
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Min 6 characters" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ====== STUDENT MANAGEMENT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'students' ? 'active' : ''; ?>" id="tab-students">
            <div class="page-header">
                <h1><i class="fas fa-user-graduate"></i> Student Management</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-user-plus"></i> Add Student</button>
                    <button class="btn btn-secondary"><i class="fas fa-search"></i> Search</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-users"></i> All Students (<?php echo $activeStudents; ?>)</h3>
                    <div style="display:flex;gap:0.5rem;">
                        <select class="form-control" style="padding:0.3rem 0.8rem;width:auto;background:rgba(255,255,255,0.05);border:1px solid var(--border-color);border-radius:0.5rem;color:#d4c0b0;">
                            <option>All Students</option>
                            <option>Active</option>
                            <option>Inactive</option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Rating</th>
                                <th>Progress</th>
                                <th>Joined</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><strong style="color:#f0d6b0;"><?php echo e($student['name']); ?></strong></td>
                                    <td><?php echo $student['rating']; ?></td>
                                    <td>
                                        <div style="display:flex;align-items:center;gap:0.5rem;">
                                            <div class="student-progress">
                                                <div class="progress-bar" style="width:<?php echo $student['progress']; ?>%;"></div>
                                            </div>
                                            <span style="font-size:0.75rem;color:#5a4a3a;"><?php echo $student['progress']; ?>%</span>
                                        </div>
                                    </td>
                                    <td><?php echo e($student['joined']); ?></td>
                                    <td><span class="student-status <?php echo $student['status']; ?>"><?php echo ucfirst($student['status']); ?></span></td>
                                    <td>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;" title="Challenge to game">
                                            <i class="fas fa-chess-king"></i>
                                        </button>
                                        <button class="btn btn-danger" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== LESSON MANAGEMENT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'lessons' ? 'active' : ''; ?>" id="tab-lessons">
            <div class="page-header">
                <h1><i class="fas fa-book"></i> Lesson Management</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Create Lesson</button>
                </div>
            </div>

            <div class="lesson-grid">
                <?php foreach ($lessons as $lesson): ?>
                    <div class="lesson-card">
                        <div class="lesson-title"><?php echo e($lesson['title']); ?></div>
                        <div class="lesson-topic"><i class="fas fa-tag"></i> <?php echo e($lesson['topic']); ?></div>
                        <div style="font-size:0.8rem;color:#5a4a3a;margin-top:0.2rem;">
                            <i class="fas fa-calendar"></i> <?php echo e($lesson['date']); ?>
                        </div>
                        <div class="lesson-meta">
                            <span class="status-badge <?php echo $lesson['status']; ?>"><?php echo ucfirst($lesson['status']); ?></span>
                            <div class="lesson-actions">
                                <button class="btn btn-secondary"><i class="fas fa-edit"></i></button>
                                <button class="btn btn-secondary"><i class="fas fa-eye"></i></button>
                                <button class="btn btn-danger"><i class="fas fa-trash"></i></button>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>

        <!-- ====== ASSIGNMENTS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'assignments' ? 'active' : ''; ?>" id="tab-assignments">
            <div class="page-header">
                <h1><i class="fas fa-tasks"></i> Chess Assignments</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Create Assignment</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-clock"></i> Pending Assignments</h3>
                    <span style="color:#5a4a3a;font-size:0.85rem;"><?php echo $assignmentsPending; ?> pending</span>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Assignment</th>
                                <th>Student</th>
                                <th>Due Date</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Opening Principles Exercise</td>
                                <td>Alice Johnson</td>
                                <td>2026-07-05</td>
                                <td><span class="status-badge draft">Pending</span></td>
                                <td>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i> Review
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>Endgame Practice</td>
                                <td>Bob Smith</td>
                                <td>2026-07-06</td>
                                <td><span class="status-badge draft">Pending</span></td>
                                <td>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i> Review
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>Puzzle Solving</td>
                                <td>Carol White</td>
                                <td>2026-07-03</td>
                                <td><span class="status-badge published">Submitted</span></td>
                                <td>
                                    <button class="btn btn-success" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-check"></i> Grade
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== PLAY CHESS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'play' ? 'active' : ''; ?>" id="tab-play">
            <div class="page-header">
                <h1><i class="fas fa-chess-king"></i> Play Chess</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary" onclick="resetBoard()"><i class="fas fa-undo"></i> Reset Board</button>
                    <button class="btn btn-chess" onclick="flipBoard()"><i class="fas fa-arrows-alt-h"></i> Flip Board</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'play'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chess-board"></i> Chess Board</h3>
                        <span id="turn-indicator" style="color:var(--gold);font-weight:600;">
                            <i class="fas fa-circle" style="color:#f0d9b5;"></i> White's Turn
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="chess-board-container">
                            <div class="chess-board" id="chessBoard"></div>
                        </div>
                        <div style="display:flex;justify-content:space-between;margin-top:0.8rem;padding:0.5rem;background:rgba(255,255,255,0.03);border-radius:0.5rem;">
                            <span id="move-count" style="color:#7a6a5a;">Moves: 0</span>
                            <span id="game-status" style="color:var(--gold);">Game in progress</span>
                            <button class="btn btn-chess" style="padding:0.3rem 0.8rem;font-size:0.75rem;" onclick="undoMove()">
                                <i class="fas fa-undo-alt"></i> Undo
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-exchange-alt"></i> Game Controls</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Play Against</label>
                            <select class="form-control" id="playMode" onchange="changePlayMode()">
                                <option value="ai">Computer (AI)</option>
                                <option value="local">Local (2 Players)</option>
                                <option value="online">Online Player</option>
                            </select>
                        </div>
                        <div id="online-opponent-section" style="display:none;">
                            <div class="form-group">
                                <label>Select Opponent</label>
                                <select class="form-control" id="opponentSelect">
                                    <?php foreach ($onlineUsers as $opponent): ?>
                                        <option value="<?php echo $opponent['id']; ?>">
                                            <?php echo e($opponent['username']); ?> (<?php echo $opponent['role']; ?>) - <?php echo $opponent['rating']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Time Control (minutes)</label>
                                <select class="form-control" id="timeControl">
                                    <option value="5">5 min (Blitz)</option>
                                    <option value="10" selected>10 min (Rapid)</option>
                                    <option value="30">30 min (Classical)</option>
                                    <option value="60">60 min (Long)</option>
                                </select>
                            </div>
                            <button class="btn btn-chess" onclick="requestOnlineGame()" style="width:100%;">
                                <i class="fas fa-handshake"></i> Request Game
                            </button>
                        </div>
                        <div id="ai-section">
                            <div class="form-group">
                                <label>AI Difficulty</label>
                                <select class="form-control" id="aiDifficulty">
                                    <option value="easy">Easy</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="hard">Hard</option>
                                </select>
                            </div>
                            <button class="btn btn-chess" onclick="playAIMove()" style="width:100%;">
                                <i class="fas fa-robot"></i> AI Makes Move
                            </button>
                        </div>
                        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color);">
                            <div class="form-group">
                                <label>Piece Color</label>
                                <select class="form-control" id="playerColor">
                                    <option value="white">White</option>
                                    <option value="black">Black</option>
                                    <option value="random">Random</option>
                                </select>
                            </div>
                            <button class="btn btn-primary" onclick="startNewGame()" style="width:100%;">
                                <i class="fas fa-play"></i> Start New Game
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== OVERSEE GAMES TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'oversee' ? 'active' : ''; ?>" id="tab-oversee">
            <div class="page-header">
                <h1><i class="fas fa-eye"></i> Oversee Games</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-refresh"></i> Refresh</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'oversee'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid game-oversight">
                <!-- Active Games List -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-gamepad"></i> Active Games</h3>
                        <span class="card-action"><?php echo count($activeGames); ?> games</span>
                    </div>
                    <div class="card-body">
                        <?php foreach ($activeGames as $game): ?>
                            <div class="activity-item" style="border-bottom:1px solid rgba(255,255,255,0.05);padding:0.8rem 0;">
                                <div class="activity-icon">
                                    <i class="fas fa-chess"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-text">
                                        <strong><?php echo e($game['white']); ?></strong> 
                                        <span style="color:#7a6a5a;">vs</span> 
                                        <strong><?php echo e($game['black']); ?></strong>
                                    </div>
                                    <div style="display:flex;gap:1rem;font-size:0.8rem;color:#5a4a3a;margin-top:0.2rem;">
                                        <span><i class="fas fa-chess-knight"></i> Move <?php echo $game['move']; ?></span>
                                        <span><i class="fas fa-clock"></i> <?php echo $game['time']; ?></span>
                                        <span><span class="status-badge in_progress"><?php echo str_replace('_', ' ', $game['status']); ?></span></span>
                                    </div>
                                </div>
                                <form method="POST" style="margin-left:auto;">
                                    <input type="hidden" name="game_id" value="<?php echo $game['id']; ?>">
                                    <button type="submit" name="oversee_game" class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i> Oversee
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Game Oversight View -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-desktop"></i> Game Oversight</h3>
                        <span class="card-action" id="oversee-game-id">No game selected</span>
                    </div>
                    <div class="card-body" id="overseeBoardContainer">
                        <div style="text-align:center;padding:2rem;color:#5a4a3a;">
                            <i class="fas fa-eye" style="font-size:3rem;display:block;margin-bottom:1rem;"></i>
                            <p>Select a game above to oversee it in real-time.</p>
                            <p style="font-size:0.85rem;">You can view all moves and monitor the game progress.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== CHALLENGE PLAYERS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'challenge' ? 'active' : ''; ?>" id="tab-challenge">
            <div class="page-header">
                <h1><i class="fas fa-handshake"></i> Challenge Players</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-filter"></i> Filter</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'challenge'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-users"></i> Online Players</h3>
                    <span class="card-action"><?php echo count($onlineUsers); ?> online</span>
                </div>
                <div class="card-body">
                    <?php foreach ($onlineUsers as $player): ?>
                        <div class="user-item" style="display:flex;justify-content:space-between;align-items:center;padding:0.5rem 0;border-bottom:1px solid rgba(255,255,255,0.05);">
                            <div style="display:flex;align-items:center;gap:0.8rem;">
                                <div class="user-avatar-sm" style="width:32px;height:32px;border-radius:50%;background:linear-gradient(145deg,var(--primary),var(--primary-dark));display:flex;align-items:center;justify-content:center;font-weight:700;color:white;font-size:0.8rem;">
                                    <?php echo strtoupper(substr($player['username'], 0, 1)); ?>
                                </div>
                                <div>
                                    <strong style="color:#f0d6b0;"><?php echo e($player['username']); ?></strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;"> · <?php echo ucfirst($player['role']); ?></span>
                                    <div style="font-size:0.75rem;color:#7a6a5a;">
                                        <i class="fas fa-star" style="color:var(--gold);"></i> <?php echo $player['rating']; ?>
                                    </div>
                                </div>
                            </div>
                            <div style="display:flex;gap:0.5rem;align-items:center;">
                                <span class="user-status online" style="font-size:0.7rem;padding:0.1rem 0.5rem;border-radius:1rem;background:rgba(46,204,113,0.2);color:var(--success);">
                                    <i class="fas fa-circle"></i> Online
                                </span>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="opponent_id" value="<?php echo $player['id']; ?>">
                                    <input type="hidden" name="time_control" value="10">
                                    <input type="hidden" name="color" value="random">
                                    <button type="submit" name="request_game" class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-handshake"></i> Challenge
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> Recent Challenges</h3>
                </div>
                <div class="card-body">
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-handshake"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>You</strong> challenged <strong>GrandMaster99</strong> to a game</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 5 minutes ago · <span style="color:var(--warning);">Awaiting response</span></div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-check-circle" style="color:var(--success);"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>ChessPro2024</strong> accepted your challenge</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 1 hour ago · <span style="color:var(--success);">Game in progress</span></div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-times-circle" style="color:var(--danger);"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>QueenSlayer</strong> declined your challenge</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 3 hours ago · <span style="color:var(--danger);">Declined</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== GAME ANALYSIS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'analysis' ? 'active' : ''; ?>" id="tab-analysis">
            <div class="page-header">
                <h1><i class="fas fa-chart-line"></i> Game Analysis</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-upload"></i> Import Game</button>
                </div>
            </div>

            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-microchip"></i> Analyze Game</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Enter PGN</label>
                            <textarea class="form-control" placeholder="Paste game PGN here..." rows="6"></textarea>
                        </div>
                        <div class="form-group">
                            <label>Student (optional)</label>
                            <select class="form-control">
                                <option>Select student...</option>
                                <?php foreach ($students as $student): ?>
                                    <option><?php echo e($student['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button class="btn btn-primary" style="width:100%;">
                            <i class="fas fa-play"></i> Analyze Game
                        </button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Recent Analyses</h3>
                    </div>
                    <div class="card-body">
                        <div class="student-item">
                            <div class="student-info">
                                <div>
                                    <strong style="color:#f0d6b0;">Alice Johnson</strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Game vs Bob Smith</span>
                                </div>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-eye"></i> View
                            </button>
                        </div>
                        <div class="student-item">
                            <div class="student-info">
                                <div>
                                    <strong style="color:#f0d6b0;">Carol White</strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Game vs David Brown</span>
                                </div>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-eye"></i> View
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== TRAINING MATERIALS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'materials' ? 'active' : ''; ?>" id="tab-materials">
            <div class="page-header">
                <h1><i class="fas fa-folder-open"></i> Training Materials</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-upload"></i> Upload Material</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-file-pdf"></i> PDFs</h3>
                    </div>
                    <div class="card-body">
                        <div class="student-item">
                            <span>Opening Principles.pdf</span>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                        <div class="student-item">
                            <span>Endgame Basics.pdf</span>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-video"></i> Videos</h3>
                    </div>
                    <div class="card-body">
                        <div class="student-item">
                            <span>Tactical Patterns.mp4</span>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                        <div class="student-item">
                            <span>Positional Play.mp4</span>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-play"></i>
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-dumbbell"></i> Exercises</h3>
                    </div>
                    <div class="card-body">
                        <div class="student-item">
                            <span>Fork Practice.pdf</span>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                        <div class="student-item">
                            <span>Pin Exercises.pdf</span>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== PUZZLE MANAGEMENT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'puzzles' ? 'active' : ''; ?>" id="tab-puzzles">
            <div class="page-header">
                <h1><i class="fas fa-puzzle-piece"></i> Puzzle Management</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Create Puzzle</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> All Puzzles</h3>
                    <div style="display:flex;gap:0.5rem;">
                        <select class="form-control" style="padding:0.3rem 0.8rem;width:auto;background:rgba(255,255,255,0.05);border:1px solid var(--border-color);border-radius:0.5rem;color:#d4c0b0;">
                            <option>All Difficulties</option>
                            <option>Easy</option>
                            <option>Medium</option>
                            <option>Hard</option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Puzzle</th>
                                <th>Difficulty</th>
                                <th>Theme</th>
                                <th>Assigned To</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>Mate in 2</td>
                                <td><span class="status-badge published">Medium</span></td>
                                <td>Checkmate</td>
                                <td>Alice Johnson</td>
                                <td><span class="student-status active">Completed</span></td>
                                <td>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>Fork Practice</td>
                                <td><span class="status-badge draft">Easy</span></td>
                                <td>Fork</td>
                                <td>Bob Smith</td>
                                <td><span class="status-badge draft">Pending</span></td>
                                <td>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== LIVE COACHING TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'coaching' ? 'active' : ''; ?>" id="tab-coaching">
            <div class="page-header">
                <h1><i class="fas fa-video"></i> Live Coaching</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Schedule Session</button>
                </div>
            </div>

            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-play-circle"></i> Start Session</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Select Student</label>
                            <select class="form-control">
                                <option>Select student...</option>
                                <?php foreach ($students as $student): ?>
                                    <option><?php echo e($student['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Session Type</label>
                            <select class="form-control">
                                <option>Online Coaching</option>
                                <option>Game Analysis</option>
                                <option>Lesson Review</option>
                            </select>
                        </div>
                        <button class="btn btn-primary" style="width:100%;">
                            <i class="fas fa-video"></i> Start Session
                        </button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-clock"></i> Upcoming Sessions</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach ($upcomingSessionsList as $session): ?>
                            <div class="session-item">
                                <div class="session-info">
                                    <span class="session-student"><?php echo e($session['student']); ?></span>
                                    <span class="session-detail">
                                        <i class="fas fa-calendar"></i> <?php echo e($session['date']); ?> 
                                        <i class="fas fa-clock" style="margin-left:0.5rem;"></i> <?php echo e($session['time']); ?>
                                    </span>
                                </div>
                                <button class="btn btn-primary" style="padding:0.2rem 0.8rem;font-size:0.75rem;">
                                    <i class="fas fa-play"></i> Start
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== TOURNAMENT MANAGEMENT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'tournaments' ? 'active' : ''; ?>" id="tab-tournaments">
            <div class="page-header">
                <h1><i class="fas fa-trophy"></i> Tournament Management</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Create Tournament</button>
                </div>
            </div>

            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-calendar-plus"></i> Upcoming Tournaments</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach ($tournaments as $tournament): ?>
                            <div class="session-item">
                                <div class="session-info">
                                    <span class="session-student"><?php echo e($tournament['name']); ?></span>
                                    <span class="session-detail">
                                        <i class="fas fa-calendar"></i> <?php echo e($tournament['date']); ?> 
                                        <i class="fas fa-users" style="margin-left:0.5rem;"></i> <?php echo $tournament['participants']; ?> players
                                    </span>
                                </div>
                                <span class="session-type"><?php echo ucfirst($tournament['status']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-flag-checkered"></i> Active Tournaments</h3>
                    </div>
                    <div class="card-body">
                        <p style="color:#5a4a3a;text-align:center;padding:1rem 0;">
                            <i class="fas fa-info-circle"></i> No active tournaments at the moment.
                        </p>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== PROGRESS REPORTS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'progress' ? 'active' : ''; ?>" id="tab-progress">
            <div class="page-header">
                <h1><i class="fas fa-chart-bar"></i> Progress Reports</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-file-pdf"></i> Generate Report</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-graduate"></i> Student Performance</h3>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Progress</th>
                                <th>Lessons Completed</th>
                                <th>Assignments</th>
                                <th>Rating Change</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><strong style="color:#f0d6b0;"><?php echo e($student['name']); ?></strong></td>
                                    <td>
                                        <div style="display:flex;align-items:center;gap:0.5rem;">
                                            <div class="student-progress">
                                                <div class="progress-bar" style="width:<?php echo $student['progress']; ?>%;"></div>
                                            </div>
                                            <span style="font-size:0.75rem;color:#5a4a3a;"><?php echo $student['progress']; ?>%</span>
                                        </div>
                                    </td>
                                    <td><?php echo rand(3, 12); ?></td>
                                    <td><?php echo rand(2, 8); ?></td>
                                    <td style="color:var(--success);">+<?php echo rand(5, 30); ?></td>
                                    <td>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-file-alt"></i> View
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== NOTIFICATIONS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'notifications' ? 'active' : ''; ?>" id="tab-notifications">
            <div class="page-header">
                <h1><i class="fas fa-bell"></i> Notifications</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-check-double"></i> Mark All Read</button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <?php foreach ($notifications as $notif): ?>
                        <div class="notification-item <?php echo !$notif['read'] ? 'unread' : ''; ?>">
                            <div class="notif-icon">
                                <i class="fas <?php echo $notif['type'] === 'student_join' ? 'fa-user-plus' : ($notif['type'] === 'assignment' ? 'fa-tasks' : 'fa-calendar'); ?>"></i>
                            </div>
                            <div class="notif-content">
                                <div class="notif-text"><?php echo e($notif['message']); ?></div>
                                <div class="notif-time"><i class="fas fa-clock"></i> <?php echo e($notif['time']); ?></div>
                            </div>
                            <?php if (!$notif['read']): ?>
                                <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                    <i class="fas fa-check"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ====== STATISTICS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'statistics' ? 'active' : ''; ?>" id="tab-statistics">
            <div class="page-header">
                <h1><i class="fas fa-chart-pie"></i> Statistics</h1>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-graduate"></i></div>
                    <div class="stat-value"><?php echo $statistics['total_students']; ?></div>
                    <div class="stat-label">Total Students</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-book"></i></div>
                    <div class="stat-value"><?php echo $statistics['lessons_created']; ?></div>
                    <div class="stat-label">Lessons Created</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-tasks"></i></div>
                    <div class="stat-value"><?php echo $statistics['assignments_completed']; ?></div>
                    <div class="stat-label">Assignments Completed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-chalkboard-teacher"></i></div>
                    <div class="stat-value"><?php echo $statistics['sessions_conducted']; ?></div>
                    <div class="stat-label">Sessions Conducted</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-percent"></i></div>
                    <div class="stat-value"><?php echo $statistics['avg_performance']; ?>%</div>
                    <div class="stat-label">Avg Student Performance</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-arrow-up"></i></div>
                    <div class="stat-value"><?php echo $statistics['improvement_trend']; ?></div>
                    <div class="stat-label">Improvement Trend</div>
                </div>
            </div>
        </div>

        <!-- ====== SETTINGS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'settings' ? 'active' : ''; ?>" id="tab-settings">
            <div class="page-header">
                <h1><i class="fas fa-cog"></i> Settings</h1>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-bell"></i> Notification Preferences</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="update_notifications" value="1">
                            <div class="form-group">
                                <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                    <input type="checkbox" name="email_notifications" checked>
                                    Email Notifications
                                </label>
                            </div>
                            <div class="form-group">
                                <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                    <input type="checkbox" name="student_joins" checked>
                                    New Student Registrations
                                </label>
                            </div>
                            <div class="form-group">
                                <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                    <input type="checkbox" name="assignment_submissions" checked>
                                    Assignment Submissions
                                </label>
                            </div>
                            <div class="form-group">
                                <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                    <input type="checkbox" name="session_reminders" checked>
                                    Session Reminders
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Preferences</button>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-palette"></i> Appearance</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Theme</label>
                            <select class="form-control">
                                <option>Dark Mode</option>
                                <option>Light Mode</option>
                                <option>System Default</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Language</label>
                            <select class="form-control">
                                <option>English</option>
                                <option>Spanish</option>
                                <option>French</option>
                                <option>German</option>
                            </select>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-save"></i> Save Preferences</button>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== HELP & SUPPORT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'help' ? 'active' : ''; ?>" id="tab-help">
            <div class="page-header">
                <h1><i class="fas fa-question-circle"></i> Help & Support</h1>
            </div>

            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-question"></i> FAQs</h3>
                    </div>
                    <div class="card-body">
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I add a new student?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to Student Management and click "Add Student". Fill in the student's details and they will be added to your roster.</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I create a lesson?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to Lesson Management and click "Create Lesson". Add the lesson title, content, and choose the topic. You can also upload materials.</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I start a live coaching session?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to Live Coaching, select a student, choose the session type, and click "Start Session".</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I challenge another player?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to Challenge Players, find an online player, and click "Challenge".</p>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-headset"></i> Contact Support</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Subject</label>
                            <input type="text" class="form-control" placeholder="Brief description of your issue">
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea class="form-control" placeholder="Describe your issue in detail..." rows="4"></textarea>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Message</button>
                        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color);">
                            <p style="color:#5a4a3a;font-size:0.85rem;">
                                <i class="fas fa-envelope"></i> coach-support@chessheaven.org
                            </p>
                            <p style="color:#5a4a3a;font-size:0.85rem;">
                                <i class="fas fa-clock"></i> Response time: 24-48 hours
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== CERTIFICATES TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'certificates' ? 'active' : ''; ?>" id="tab-certificates">
            <div class="page-header">
                <h1><i class="fas fa-certificate"></i> Certificates</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Create Certificate</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Issued Certificates</h3>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Certificate</th>
                                <th>Student</th>
                                <th>Course</th>
                                <th>Issued Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>#C-2026-001</td>
                                <td>Alice Johnson</td>
                                <td>Opening Mastery</td>
                                <td>2026-06-15</td>
                                <td>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-download"></i> Download
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td>#C-2026-002</td>
                                <td>Bob Smith</td>
                                <td>Endgame Basics</td>
                                <td>2026-06-20</td>
                                <td>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-download"></i> Download
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== REPORTS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'reports' ? 'active' : ''; ?>" id="tab-reports">
            <div class="page-header">
                <h1><i class="fas fa-file-alt"></i> Reports</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-file-pdf"></i> Generate Report</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Student Performance Report</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Select Student</label>
                            <select class="form-control">
                                <option>All Students</option>
                                <?php foreach ($students as $student): ?>
                                    <option><?php echo e($student['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Date Range</label>
                            <div style="display:flex;gap:0.5rem;">
                                <input type="date" class="form-control">
                                <input type="date" class="form-control">
                            </div>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-file-pdf"></i> Generate Report</button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Recent Reports</h3>
                    </div>
                    <div class="card-body">
                        <div class="student-item">
                            <div>
                                <strong style="color:#f0d6b0;">Monthly Progress Report</strong>
                                <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Generated: 2026-06-30</span>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                        <div class="student-item">
                            <div>
                                <strong style="color:#f0d6b0;">Student Performance Summary</strong>
                                <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Generated: 2026-06-28</span>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-download"></i>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== CALENDAR TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'calendar' ? 'active' : ''; ?>" id="tab-calendar">
            <div class="page-header">
                <h1><i class="fas fa-calendar"></i> Calendar</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Add Event</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-calendar-week"></i> July 2026</h3>
                    <div style="display:flex;gap:0.5rem;">
                        <button class="btn btn-secondary" style="padding:0.2rem 0.8rem;"><i class="fas fa-chevron-left"></i></button>
                        <button class="btn btn-secondary" style="padding:0.2rem 0.8rem;"><i class="fas fa-chevron-right"></i></button>
                    </div>
                </div>
                <div class="card-body">
                    <div style="display:grid;grid-template-columns:repeat(7,1fr);gap:0.5rem;text-align:center;">
                        <div style="color:#5a4a3a;font-weight:600;font-size:0.8rem;">Mon</div>
                        <div style="color:#5a4a3a;font-weight:600;font-size:0.8rem;">Tue</div>
                        <div style="color:#5a4a3a;font-weight:600;font-size:0.8rem;">Wed</div>
                        <div style="color:#5a4a3a;font-weight:600;font-size:0.8rem;">Thu</div>
                        <div style="color:#5a4a3a;font-weight:600;font-size:0.8rem;">Fri</div>
                        <div style="color:#5a4a3a;font-weight:600;font-size:0.8rem;">Sat</div>
                        <div style="color:#5a4a3a;font-weight:600;font-size:0.8rem;">Sun</div>
                        <?php
                        $days = range(1, 31);
                        $firstDay = date('N', strtotime('2026-07-01'));
                        for ($i = 1; $i < $firstDay; $i++) {
                            echo '<div style="color:#2a1a1a;">&nbsp;</div>';
                        }
                        foreach ($days as $day) {
                            $date = '2026-07-' . str_pad($day, 2, '0', STR_PAD_LEFT);
                            $hasEvent = in_array($day, [4, 5, 10, 20]);
                            echo '<div style="padding:0.5rem;border-radius:0.5rem;' . ($hasEvent ? 'background:rgba(139,26,26,0.2);border:1px solid var(--border-color);' : '') . '">
                                <div style="font-weight:600;color:' . ($day == date('d') ? 'var(--secondary)' : '#d4c0b0') . ';">' . $day . '</div>';
                            if ($hasEvent) {
                                echo '<div style="width:6px;height:6px;border-radius:50%;background:var(--secondary);margin:2px auto;"></div>';
                            }
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> Upcoming Events</h3>
                </div>
                <div class="card-body">
                    <?php foreach ($upcomingSessionsList as $session): ?>
                        <div class="session-item">
                            <div class="session-info">
                                <span class="session-student">
                                    <i class="fas fa-chalkboard-teacher"></i> Session with <?php echo e($session['student']); ?>
                                </span>
                                <span class="session-detail">
                                    <i class="fas fa-calendar"></i> <?php echo e($session['date']); ?> 
                                    <i class="fas fa-clock" style="margin-left:0.5rem;"></i> <?php echo e($session['time']); ?>
                                </span>
                            </div>
                            <span class="session-type"><?php echo e($session['type']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ====== MESSAGES TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'messages' ? 'active' : ''; ?>" id="tab-messages">
            <div class="page-header">
                <h1><i class="fas fa-envelope"></i> Messages</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> New Message</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 2fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Conversations</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach (array_slice($students, 0, 4) as $student): ?>
                            <div class="student-item" style="cursor:pointer;padding:0.5rem;border-radius:0.5rem;transition:0.3s;">
                                <div class="student-info">
                                    <div class="student-avatar"><?php echo strtoupper(substr($student['name'], 0, 1)); ?></div>
                                    <div>
                                        <strong><?php echo e($student['name']); ?></strong>
                                        <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Last message</span>
                                    </div>
                                </div>
                                <span style="color:#5a4a3a;font-size:0.7rem;">2h ago</span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-comment"></i> Chat</h3>
                    </div>
                    <div class="card-body">
                        <div style="min-height:200px;display:flex;flex-direction:column;gap:0.5rem;margin-bottom:1rem;">
                            <div style="background:rgba(255,255,255,0.05);padding:0.8rem;border-radius:0.8rem;align-self:flex-start;max-width:80%;">
                                <span style="color:#f0d6b0;font-weight:600;">Alice Johnson</span>
                                <p style="color:#d4c0b0;font-size:0.9rem;">Can you review my latest game?</p>
                                <span style="color:#5a4a3a;font-size:0.7rem;">1 hour ago</span>
                            </div>
                            <div style="background:rgba(139,26,26,0.2);padding:0.8rem;border-radius:0.8rem;align-self:flex-end;max-width:80%;">
                                <p style="color:#f0d6b0;font-size:0.9rem;">Sure! Send me the PGN and I'll analyze it.</p>
                                <span style="color:#5a4a3a;font-size:0.7rem;">45 minutes ago</span>
                            </div>
                        </div>
                        <div style="display:flex;gap:0.5rem;">
                            <input type="text" class="form-control" placeholder="Type a message..." style="flex:1;">
                            <button class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== COMMENTS & FEEDBACK TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'feedback' ? 'active' : ''; ?>" id="tab-feedback">
            <div class="page-header">
                <h1><i class="fas fa-comment"></i> Comments & Feedback</h1>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-star"></i> Recent Feedback</h3>
                </div>
                <div class="card-body">
                    <?php
                    $feedbacks = [
                        ['student' => 'Alice Johnson', 'rating' => 5, 'comment' => 'Excellent lesson! Really helped me understand opening principles.', 'date' => '2 days ago'],
                        ['student' => 'Bob Smith', 'rating' => 4, 'comment' => 'Great analysis. Would love more examples.', 'date' => '3 days ago'],
                        ['student' => 'Carol White', 'rating' => 5, 'comment' => 'The puzzle exercises were very challenging and helpful!', 'date' => '5 days ago'],
                    ];
                    ?>
                    <?php foreach ($feedbacks as $feedback): ?>
                        <div style="padding:0.8rem 0;border-bottom:1px solid rgba(255,255,255,0.05);">
                            <div style="display:flex;justify-content:space-between;align-items:center;">
                                <strong style="color:#f0d6b0;"><?php echo e($feedback['student']); ?></strong>
                                <div>
                                    <span style="color:var(--gold);">
                                        <?php echo str_repeat('★', $feedback['rating']) . str_repeat('☆', 5 - $feedback['rating']); ?>
                                    </span>
                                    <span style="color:#5a4a3a;font-size:0.8rem;margin-left:0.5rem;"><?php echo e($feedback['date']); ?></span>
                                </div>
                            </div>
                            <p style="color:#d4c0b0;font-size:0.9rem;margin:0.3rem 0;"><?php echo e($feedback['comment']); ?></p>
                            <div style="display:flex;gap:0.5rem;margin-top:0.3rem;">
                                <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                    <i class="fas fa-reply"></i> Reply
                                </button>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== SIDEBAR TOGGLE (Mobile) =====
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('open');
                sidebarOverlay.classList.toggle('active');
            });
        }

        if (sidebarOverlay) {
            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('open');
                sidebarOverlay.classList.remove('active');
            });
        }

        // Close sidebar on window resize
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('open');
                sidebarOverlay.classList.remove('active');
            }
        });

        // ===== ACTIVE NAVIGATION =====
        document.querySelectorAll('.sidebar-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.sidebar-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                
                if (window.innerWidth <= 768) {
                    sidebar.classList.remove('open');
                    sidebarOverlay.classList.remove('active');
                }
            });
        });

        // ===== NAVBAR SCROLL EFFECT =====
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // ===== SWITCH TAB FUNCTION =====
        function switchTab(tab) {
            window.location.href = '?tab=' + tab;
        }

        // ===== CHESS ENGINE =====
        // Chess piece symbols
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // Initial board setup
        const INITIAL_BOARD = [
            ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
            ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
            ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R']
        ];

        // State
        let board = JSON.parse(JSON.stringify(INITIAL_BOARD));
        let currentTurn = 'white';
        let selectedSquare = null;
        let moveHistory = [];
        let moveCount = 0;
        let isFlipped = false;
        let gameOver = false;
        let playMode = 'ai';
        let playerColor = 'white';
        let moveList = [];
        let isAIMoving = false;
        let gameOverseeId = null;

        // File ranks for notation
        const FILES = 'abcdefgh';

        // ===== BOARD RENDERING =====
        function renderBoard() {
            const boardEl = document.getElementById('chessBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isFlipped ? 7 - row : row;
                    const actualCol = isFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    square.dataset.row = actualRow;
                    square.dataset.col = actualCol;
                    
                    const piece = board[actualRow][actualCol];
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    if (selectedSquare && selectedSquare.row === actualRow && selectedSquare.col === actualCol) {
                        square.classList.add('selected');
                    }
                    
                    if (selectedSquare) {
                        const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                        for (const move of legalMoves) {
                            if (move.row === actualRow && move.col === actualCol) {
                                if (board[actualRow][actualCol]) {
                                    square.classList.add('legal-capture');
                                } else {
                                    square.classList.add('legal-move');
                                }
                            }
                        }
                    }
                    
                    square.addEventListener('click', () => onSquareClick(actualRow, actualCol));
                    boardEl.appendChild(square);
                }
            }
            
            updateTurnIndicator();
        }

        // ===== TURN INDICATOR =====
        function updateTurnIndicator() {
            const indicator = document.getElementById('turn-indicator');
            if (!indicator) return;
            if (gameOver) {
                indicator.innerHTML = '<i class="fas fa-flag-checkered"></i> Game Over';
                return;
            }
            const colorName = currentTurn === 'white' ? 'White' : 'Black';
            const colorIcon = currentTurn === 'white' ? '#f0d9b5' : '#1a1a1a';
            indicator.innerHTML = `<i class="fas fa-circle" style="color:${colorIcon};"></i> ${colorName}'s Turn`;
        }

        // ===== MOVE GENERATION =====
        function getLegalMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const direction = isWhite ? -1 : 1;
                    if (row + direction >= 0 && row + direction < 8 && !board[row + direction][col]) {
                        moves.push({row: row + direction, col: col});
                        const startRow = isWhite ? 6 : 1;
                        if (row === startRow && !board[row + 2 * direction][col]) {
                            moves.push({row: row + 2 * direction, col: col});
                        }
                    }
                    for (const dcol of [-1, 1]) {
                        const newCol = col + dcol;
                        if (newCol >= 0 && newCol < 8 && row + direction >= 0 && row + direction < 8) {
                            const target = board[row + direction][newCol];
                            if (target && (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: row + direction, col: newCol});
                            }
                        }
                    }
                    break;
                case 'n':
                    const knightMoves = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
                    for (const [dr, dc] of knightMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
                case 'b':
                case 'r':
                case 'q':
                    const directions = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                                      piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                                      [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of directions) {
                        for (let i = 1; i < 8; i++) {
                            const newRow = row + dr * i, newCol = col + dc * i;
                            if (newRow < 0 || newRow >= 8 || newCol < 0 || newCol >= 8) break;
                            const target = board[newRow][newCol];
                            if (target) {
                                if (isWhite ? target === target.toLowerCase() : target === target.toUpperCase()) {
                                    moves.push({row: newRow, col: newCol});
                                }
                                break;
                            }
                            moves.push({row: newRow, col: newCol});
                        }
                    }
                    break;
                case 'k':
                    const kingMoves = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of kingMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
            }
            
            return moves.filter(move => !wouldBeInCheck(row, col, move.row, move.col));
        }

        function wouldBeInCheck(fromRow, fromCol, toRow, toCol) {
            const piece = board[fromRow][fromCol];
            const isWhite = piece === piece.toUpperCase();
            
            const captured = board[toRow][toCol];
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            let kingRow, kingCol;
            const kingPiece = isWhite ? 'K' : 'k';
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    if (board[r][c] === kingPiece) {
                        kingRow = r; kingCol = c;
                        break;
                    }
                }
                if (kingRow !== undefined) break;
            }
            
            let inCheck = false;
            if (kingRow !== undefined) {
                const opponent = isWhite ? 'black' : 'white';
                for (let r = 0; r < 8; r++) {
                    for (let c = 0; c < 8; c++) {
                        const p = board[r][c];
                        if (p && (opponent === 'white' ? p === p.toUpperCase() : p === p.toLowerCase())) {
                            const attacks = getRawMoves(r, c);
                            for (const attack of attacks) {
                                if (attack.row === kingRow && attack.col === kingCol) {
                                    inCheck = true;
                                    break;
                                }
                            }
                        }
                        if (inCheck) break;
                    }
                    if (inCheck) break;
                }
            }
            
            board[fromRow][fromCol] = piece;
            board[toRow][toCol] = captured;
            
            return inCheck;
        }

        function getRawMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const dir = isWhite ? -1 : 1;
                    if (row + dir >= 0 && row + dir < 8 && !board[row + dir][col]) {
                        moves.push({row: row + dir, col: col});
                    }
                    for (const dc of [-1, 1]) {
                        const nc = col + dc;
                        if (nc >= 0 && nc < 8 && row + dir >= 0 && row + dir < 8) {
                            if (board[row + dir][nc]) moves.push({row: row + dir, col: nc});
                        }
                    }
                    break;
                case 'n':
                    const nm = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
                    for (const [dr, dc] of nm) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
                case 'b':
                case 'r':
                case 'q':
                    const dirs = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                               piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                               [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of dirs) {
                        for (let i = 1; i < 8; i++) {
                            const nr = row + dr * i, nc = col + dc * i;
                            if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
                            moves.push({row: nr, col: nc});
                            if (board[nr][nc]) break;
                        }
                    }
                    break;
                case 'k':
                    const km = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of km) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
            }
            return moves;
        }

        // ===== GAME LOGIC =====
        function onSquareClick(row, col) {
            if (gameOver || isAIMoving) return;
            
            const piece = board[row][col];
            const isWhiteTurn = currentTurn === 'white';
            const isWhitePiece = piece && piece === piece.toUpperCase();
            
            if (selectedSquare) {
                const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                const isLegal = legalMoves.some(m => m.row === row && m.col === col);
                
                if (isLegal) {
                    makeMove(selectedSquare.row, selectedSquare.col, row, col);
                    selectedSquare = null;
                    renderBoard();
                    return;
                }
                
                if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                    selectedSquare = {row, col};
                    renderBoard();
                    return;
                }
                
                selectedSquare = null;
                renderBoard();
                return;
            }
            
            if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                selectedSquare = {row, col};
                renderBoard();
            }
        }

        function makeMove(fromRow, fromCol, toRow, toCol) {
            const piece = board[fromRow][fromCol];
            const captured = board[toRow][toCol];
            
            moveHistory.push({
                fromRow, fromCol, toRow, toCol,
                piece, captured,
                previousBoard: JSON.parse(JSON.stringify(board))
            });
            
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            if (piece.toLowerCase() === 'p' && (toRow === 0 || toRow === 7)) {
                board[toRow][toCol] = piece === 'P' ? 'Q' : 'q';
            }
            
            moveCount++;
            moveList.push(`${FILES[fromCol]}${8 - fromRow}${FILES[toCol]}${8 - toRow}`);
            
            const moveCountEl = document.getElementById('move-count');
            if (moveCountEl) moveCountEl.textContent = `Moves: ${moveCount}`;
            
            currentTurn = currentTurn === 'white' ? 'black' : 'white';
            
            checkGameOver();
            
            if (playMode === 'ai' && !gameOver && currentTurn !== playerColor) {
                setTimeout(() => playAIMove(), 300);
            }
        }

        function checkGameOver() {
            const hasLegalMoves = hasAnyLegalMoves(currentTurn);
            const statusEl = document.getElementById('game-status');
            
            if (!hasLegalMoves) {
                gameOver = true;
                const isWhite = currentTurn === 'white';
                const winner = isWhite ? 'Black' : 'White';
                if (statusEl) {
                    statusEl.textContent = `🏆 ${winner} wins! (Checkmate)`;
                    statusEl.style.color = 'var(--success)';
                }
                updateTurnIndicator();
                return;
            }
            
            if (!hasLegalMoves) {
                gameOver = true;
                if (statusEl) {
                    statusEl.textContent = '🤝 Stalemate!';
                    statusEl.style.color = 'var(--warning)';
                }
                updateTurnIndicator();
            }
        }

        function hasAnyLegalMoves(color) {
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((color === 'white' && isWhite) || (color === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            if (moves.length > 0) return true;
                        }
                    }
                }
            }
            return false;
        }

        // ===== AI =====
        function playAIMove() {
            if (isAIMoving || gameOver || playMode !== 'ai') return;
            isAIMoving = true;
            
            const aiColor = playerColor === 'white' ? 'black' : 'white';
            if (currentTurn !== aiColor) {
                isAIMoving = false;
                return;
            }
            
            const allMoves = [];
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((aiColor === 'white' && isWhite) || (aiColor === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            for (const move of moves) {
                                allMoves.push({fromRow: r, fromCol: c, toRow: move.row, toCol: move.col});
                            }
                        }
                    }
                }
            }
            
            if (allMoves.length === 0) {
                isAIMoving = false;
                checkGameOver();
                return;
            }
            
            const difficulty = document.getElementById('aiDifficulty')?.value || 'medium';
            
            const scoredMoves = allMoves.map(move => {
                let score = 0;
                const target = board[move.toRow][move.toCol];
                if (target) {
                    const pieceValues = {'p': 1, 'n': 3, 'b': 3, 'r': 5, 'q': 9, 'k': 100};
                    const val = pieceValues[target.toLowerCase()] || 0;
                    score += val * 10;
                }
                const centerDist = Math.abs(move.toRow - 3.5) + Math.abs(move.toCol - 3.5);
                score += (7 - centerDist) * 2;
                if (difficulty === 'easy') score += Math.random() * 10;
                if (difficulty === 'medium') score += Math.random() * 5;
                if (difficulty === 'hard') score += Math.random() * 2;
                return {move, score};
            });
            
            scoredMoves.sort((a, b) => b.score - a.score);
            
            let selectedMove;
            if (difficulty === 'easy') {
                const topN = Math.min(5, Math.floor(scoredMoves.length * 0.3) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else if (difficulty === 'medium') {
                const topN = Math.min(3, Math.floor(scoredMoves.length * 0.15) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else {
                selectedMove = scoredMoves[0].move;
            }
            
            makeMove(selectedMove.fromRow, selectedMove.fromCol, selectedMove.toRow, selectedMove.toCol);
            renderBoard();
            isAIMoving = false;
        }

        // ===== GAME CONTROLS =====
        function startNewGame() {
            board = JSON.parse(JSON.stringify(INITIAL_BOARD));
            currentTurn = 'white';
            moveHistory = [];
            moveCount = 0;
            gameOver = false;
            selectedSquare = null;
            moveList = [];
            isAIMoving = false;
            
            const colorSelect = document.getElementById('playerColor');
            if (colorSelect) {
                const val = colorSelect.value;
                if (val === 'random') {
                    playerColor = Math.random() < 0.5 ? 'white' : 'black';
                } else {
                    playerColor = val;
                }
            }
            
            if (playMode === 'ai' && playerColor === 'black') {
                setTimeout(() => playAIMove(), 500);
            }
            
            const statusEl = document.getElementById('game-status');
            if (statusEl) {
                statusEl.textContent = 'Game in progress';
                statusEl.style.color = 'var(--gold)';
            }
            const moveCountEl = document.getElementById('move-count');
            if (moveCountEl) moveCountEl.textContent = 'Moves: 0';
            
            renderBoard();
        }

        function resetBoard() {
            startNewGame();
        }

        function flipBoard() {
            isFlipped = !isFlipped;
            renderBoard();
        }

        function undoMove() {
            if (moveHistory.length === 0 || isAIMoving) return;
            const lastMove = moveHistory.pop();
            board = lastMove.previousBoard;
            currentTurn = currentTurn === 'white' ? 'black' : 'white';
            moveCount--;
            selectedSquare = null;
            gameOver = false;
            const statusEl = document.getElementById('game-status');
            if (statusEl) {
                statusEl.textContent = 'Game in progress';
                statusEl.style.color = 'var(--gold)';
            }
            renderBoard();
        }

        function changePlayMode() {
            const mode = document.getElementById('playMode')?.value || 'ai';
            playMode = mode;
            document.getElementById('ai-section').style.display = mode === 'ai' ? 'block' : 'none';
            document.getElementById('online-opponent-section').style.display = mode === 'online' ? 'block' : 'none';
            startNewGame();
        }

        function requestOnlineGame() {
            const opponentId = document.getElementById('opponentSelect')?.value;
            const timeControl = document.getElementById('timeControl')?.value;
            if (!opponentId) {
                alert('Please select an opponent.');
                return;
            }
            const form = document.createElement('form');
            form.method = 'POST';
            const fields = {
                'request_game': '1',
                'opponent_id': opponentId,
                'time_control': timeControl,
                'color': 'random'
            };
            for (const [key, value] of Object.entries(fields)) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = value;
                form.appendChild(input);
            }
            document.body.appendChild(form);
            form.submit();
        }

        // ===== OVERSIGHT =====
        function loadOversightGame(gameId) {
            gameOverseeId = gameId;
            const container = document.getElementById('overseeBoardContainer');
            const idDisplay = document.getElementById('oversee-game-id');
            if (idDisplay) idDisplay.textContent = `Game #${gameId}`;
            
            container.innerHTML = `
                <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                    <div style="flex:1;min-width:200px;">
                        <div class="game-status-bar">
                            <span class="player"><i class="fas fa-circle" style="color:#f0d9b5;"></i> White</span>
                            <span class="move-info">Move 12</span>
                        </div>
                        <div style="display:grid;grid-template-columns:repeat(8,1fr);max-width:300px;aspect-ratio:1;border:2px solid var(--secondary);border-radius:4px;margin:0 auto;">
                            ${Array.from({length:64}, (_, i) => {
                                const row = Math.floor(i/8), col = i%8;
                                const isLight = (row+col)%2===0;
                                const piece = (row+col)%3===0 ? (Math.random()>0.5 ? '♙' : '♟') : '';
                                return `<div class="square ${isLight?'light':'dark'}" style="display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:${isLight?'#1a1a1a':'#f0d9b5'};">${piece}</div>`;
                            }).join('')}
                        </div>
                    </div>
                    <div style="flex:1;min-width:150px;">
                        <div style="background:rgba(255,255,255,0.03);padding:0.8rem;border-radius:0.5rem;margin-bottom:0.5rem;">
                            <div style="display:flex;justify-content:space-between;font-size:0.85rem;">
                                <span>⏱️ White</span>
                                <span style="color:var(--gold);">12:34</span>
                            </div>
                            <div style="display:flex;justify-content:space-between;font-size:0.85rem;margin-top:0.2rem;">
                                <span>⏱️ Black</span>
                                <span style="color:var(--gold);">15:21</span>
                            </div>
                        </div>
                        <div style="max-height:200px;overflow-y:auto;font-size:0.8rem;color:#7a6a5a;">
                            ${Array.from({length:12}, (_, i) => 
                                `<div style="padding:0.2rem 0;border-bottom:1px solid rgba(255,255,255,0.03);">
                                    ${i+1}. ${String.fromCharCode(97 + (i%8))}${8 - (i%8)} ${String.fromCharCode(97 + ((i+3)%8))}${8 - ((i+5)%8)}
                                </div>`
                            ).join('')}
                        </div>
                    </div>
                </div>
                <div style="margin-top:0.8rem;padding-top:0.8rem;border-top:1px solid var(--border-color);display:flex;gap:0.5rem;flex-wrap:wrap;">
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-play"></i> Play
                    </button>
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-pause"></i> Pause
                    </button>
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-step-forward"></i> Forward
                    </button>
                    <span style="color:#5a4a3a;font-size:0.75rem;display:flex;align-items:center;margin-left:auto;">
                        <i class="fas fa-eye" style="color:var(--gold);margin-right:0.3rem;"></i> Overseeing in real-time
                    </span>
                </div>
            `;
        }

        // ===== INITIALIZATION =====
        document.addEventListener('DOMContentLoaded', function() {
            renderBoard();
            
            const overseeMessage = document.querySelector('#tab-oversee .message');
            if (overseeMessage && overseeMessage.textContent.includes('overseeing game')) {
                const gameId = parseInt(overseeMessage.textContent.match(/#(\d+)/)?.[1] || 101);
                loadOversightGame(gameId);
            }
            
            if (document.getElementById('tab-play')?.classList.contains('active')) {
                const hasPieces = board.some(row => row.some(cell => cell !== ''));
                if (hasPieces) {
                    if (playMode === 'ai' && playerColor === 'black' && currentTurn === 'black') {
                        setTimeout(() => playAIMove(), 500);
                    }
                }
            }
        });

        // Override for oversight form submission
        document.querySelectorAll('form input[name="oversee_game"]').forEach(input => {
            const form = input.closest('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const gameId = parseInt(this.querySelector('input[name="game_id"]')?.value || 101);
                    loadOversightGame(gameId);
                    if (window.history && window.history.pushState) {
                        window.history.pushState({}, '', '?tab=oversee&game=' + gameId);
                    }
                });
            }
        });
    </script>
</body>
</html>