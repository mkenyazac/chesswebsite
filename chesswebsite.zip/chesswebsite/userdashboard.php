<?php
/**
 * Chess Heaven - User Dashboard
 * Complete user dashboard with all features
 * Enhanced: User can play chess, request games, and oversee matches
 */

require_once 'config.php';

// Check if user is logged in
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header('Location: login.php');
    exit;
}

// Redirect non-members to their respective dashboards
if ($_SESSION['role'] === 'admin') {
    header('Location: admindashboard.php');
    exit;
} elseif ($_SESSION['role'] === 'coach') {
    header('Location: coachdashboard.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'User';
$displayName = $_SESSION['display_name'] ?? $username;
$role = $_SESSION['role'] ?? 'member';
$rating = $_SESSION['rating'] ?? 1200;
$membershipType = $_SESSION['membership_type'] ?? 'free';
$email = $_SESSION['email'] ?? '';

// Get user stats
$userStats = getUserStats($userId);
$gamesPlayed = $userStats['games_played'] ?? 0;
$gamesWon = $userStats['games_won'] ?? 0;
$gamesDrawn = $userStats['games_drawn'] ?? 0;
$gamesLost = $userStats['games_lost'] ?? 0;

// Calculate win percentage
$winPercentage = $gamesPlayed > 0 ? round(($gamesWon / $gamesPlayed) * 100) : 0;

// Get recent games
$recentGames = getRecentGames(5);

// Get daily puzzle
$dailyPuzzle = getDailyPuzzle();

// Get notifications count
$notificationCount = 3; // Example - would be from database

// Get site settings
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');

// Sample online users for chess challenges
$onlineUsers = [
    ['id' => 1, 'username' => 'GrandMaster99', 'role' => 'member', 'status' => 'online', 'rating' => 2150],
    ['id' => 2, 'username' => 'ChessPro2024', 'role' => 'member', 'status' => 'online', 'rating' => 1850],
    ['id' => 3, 'username' => 'QueenSlayer', 'role' => 'member', 'status' => 'online', 'rating' => 1920],
    ['id' => 4, 'username' => 'TacticalKing', 'role' => 'member', 'status' => 'online', 'rating' => 2080],
    ['id' => 5, 'username' => 'EndgameMaster', 'role' => 'member', 'status' => 'online', 'rating' => 1750],
];

// Sample active games (for oversight)
$activeGames = [
    ['id' => 101, 'white' => 'GrandMaster99', 'black' => 'ChessPro2024', 'status' => 'in_progress', 'move' => 14, 'time' => '12:34'],
    ['id' => 102, 'white' => 'QueenSlayer', 'black' => 'TacticalKing', 'status' => 'in_progress', 'move' => 9, 'time' => '06:22'],
    ['id' => 103, 'white' => 'EndgameMaster', 'black' => 'UnknownPlayer', 'status' => 'in_progress', 'move' => 22, 'time' => '18:45'],
];

// Handle POST requests
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle profile update
    if (isset($_POST['update_profile'])) {
        $displayName = trim($_POST['display_name'] ?? '');
        $bio = trim($_POST['bio'] ?? '');
        $country = trim($_POST['country'] ?? '');
        $city = trim($_POST['city'] ?? '');
        $favoriteOpening = trim($_POST['favorite_opening'] ?? '');
        $favoritePiece = trim($_POST['favorite_piece'] ?? '');
        
        $conn = getDBConnection();
        if ($conn) {
            $stmt = $conn->prepare("UPDATE users SET display_name = ? WHERE id = ?");
            $stmt->bind_param("si", $displayName, $userId);
            $stmt->execute();
            
            $stmt = $conn->prepare("UPDATE members SET country = ?, city = ?, favorite_opening = ?, favorite_piece = ? WHERE user_id = ?");
            $stmt->bind_param("ssssi", $country, $city, $favoriteOpening, $favoritePiece, $userId);
            $stmt->execute();
            
            $_SESSION['display_name'] = $displayName;
            $_SESSION['country'] = $country;
            $_SESSION['city'] = $city;
            $_SESSION['favorite_opening'] = $favoriteOpening;
            $_SESSION['favorite_piece'] = $favoritePiece;
            
            $message = 'Profile updated successfully!';
            $messageType = 'success';
        }
    }
    
    // Handle password change
    if (isset($_POST['change_password'])) {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (strlen($newPassword) < 6) {
            $message = 'Password must be at least 6 characters long.';
            $messageType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'Passwords do not match.';
            $messageType = 'error';
        } else {
            $conn = getDBConnection();
            if ($conn) {
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                
                if (password_verify($currentPassword, $user['password'])) {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->bind_param("si", $hashedPassword, $userId);
                    $stmt->execute();
                    
                    $message = 'Password changed successfully!';
                    $messageType = 'success';
                } else {
                    $message = 'Current password is incorrect.';
                    $messageType = 'error';
                }
            }
        }
    }
    
    // Handle notification preferences
    if (isset($_POST['update_notifications'])) {
        $emailNotifications = isset($_POST['email_notifications']) ? 1 : 0;
        $gameInvites = isset($_POST['game_invites']) ? 1 : 0;
        $tournamentReminders = isset($_POST['tournament_reminders']) ? 1 : 0;
        
        // Save to database (example - would need a settings table)
        $message = 'Notification preferences updated!';
        $messageType = 'success';
    }
    
    // Handle chess game request
    if (isset($_POST['request_game'])) {
        $opponentId = intval($_POST['opponent_id'] ?? 0);
        $color = $_POST['color'] ?? 'random';
        $timeControl = $_POST['time_control'] ?? '10';
        
        if ($opponentId > 0) {
            // Find opponent name
            $opponentName = '';
            foreach ($onlineUsers as $u) {
                if ($u['id'] == $opponentId) {
                    $opponentName = $u['username'];
                    break;
                }
            }
            $message = "Game request sent to {$opponentName}!";
            $messageType = 'success';
        } else {
            $message = "Please select an opponent.";
            $messageType = 'error';
        }
    }
    
    // Handle game oversight (view game)
    if (isset($_POST['oversee_game'])) {
        $gameId = intval($_POST['game_id'] ?? 0);
        if ($gameId > 0) {
            $message = "Now overseeing game #{$gameId}. You can view moves in real-time.";
            $messageType = 'info';
        }
    }
}

// Determine active tab
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'dashboard';

// Get member data for profile
$memberData = getMemberData($userId);
$country = $memberData['country'] ?? '';
$city = $memberData['city'] ?? '';
$favoriteOpening = $memberData['favorite_opening'] ?? '';
$favoritePiece = $memberData['favorite_piece'] ?? '';
$bio = $memberData['bio'] ?? '';

// Get friends (example data)
$friends = [
    ['id' => 1, 'name' => 'GrandMaster99', 'rating' => 2150, 'online' => true],
    ['id' => 2, 'name' => 'ChessPro2024', 'rating' => 1850, 'online' => false],
    ['id' => 3, 'name' => 'QueenSlayer', 'rating' => 1920, 'online' => true],
];

// Get achievements (example data)
$achievements = [
    ['name' => 'First Game', 'description' => 'Play your first game', 'icon' => 'fa-chess-pawn', 'unlocked' => true],
    ['name' => '10 Wins', 'description' => 'Win 10 games', 'icon' => 'fa-trophy', 'unlocked' => true],
    ['name' => 'Puzzle Master', 'description' => 'Solve 50 puzzles', 'icon' => 'fa-puzzle-piece', 'unlocked' => false],
    ['name' => 'Tournament Player', 'description' => 'Join your first tournament', 'icon' => 'fa-trophy', 'unlocked' => false],
];

// Get notifications (example data)
$notifications = [
    ['id' => 1, 'type' => 'friend_request', 'from' => 'ChessPro2024', 'message' => 'Sent you a friend request', 'time' => '2 hours ago', 'read' => false],
    ['id' => 2, 'type' => 'game_invite', 'from' => 'GrandMaster99', 'message' => 'Invited you to a game', 'time' => '5 hours ago', 'read' => false],
    ['id' => 3, 'type' => 'tournament', 'from' => 'Chess Heaven', 'message' => 'Tournament starts tomorrow', 'time' => '1 day ago', 'read' => true],
];

// Get tournaments (example data)
$upcomingTournaments = [
    ['id' => 1, 'name' => 'Weekly Blitz Tournament', 'date' => '2026-07-10', 'time' => '15:00', 'players' => 32, 'status' => 'open'],
    ['id' => 2, 'name' => 'Monthly Classical Championship', 'date' => '2026-07-20', 'time' => '14:00', 'players' => 64, 'status' => 'upcoming'],
];

// Get bookmarks (example data)
$bookmarks = [
    ['id' => 1, 'type' => 'lesson', 'title' => 'Queen\'s Gambit Explained', 'url' => 'learn.php?lesson=5'],
    ['id' => 2, 'type' => 'puzzle', 'title' => 'Checkmate in 3', 'url' => 'puzzles.php?id=42'],
];

// Get learning progress (example data)
$learningProgress = [
    'total_lessons' => 12,
    'completed_lessons' => 5,
    'total_exercises' => 50,
    'completed_exercises' => 23,
    'streak_days' => 4,
    'total_hours' => 18.5
];

// Get leaderboard (example data)
$leaderboard = [
    ['rank' => 1, 'name' => 'MagnusCarlsen', 'rating' => 2847, 'wins' => 127],
    ['rank' => 2, 'name' => 'NepoFan', 'rating' => 2795, 'wins' => 98],
    ['rank' => 3, 'name' => 'HikaruNakamura', 'rating' => 2788, 'wins' => 112],
    ['rank' => 4, 'name' => 'CaruanaFan', 'rating' => 2782, 'wins' => 95],
    ['rank' => 5, 'name' => 'AronianLover', 'rating' => 2775, 'wins' => 103],
];

// Get recent comments (example data)
$recentComments = [
    ['author' => 'Mike R.', 'text' => 'Great lesson! Really helped me understand the Italian Game.', 'rating' => 5, 'date' => '2 days ago'],
    ['author' => 'Sarah K.', 'text' => 'The daily puzzles are getting harder - I love it!', 'rating' => 4, 'date' => '3 days ago'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --sidebar-width: 250px;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
            --light-square: #f0d9b5;
            --dark-square: #b58863;
        }
        body {
            min-height:100vh;
            background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505);
            color:#f0e0d0;
            padding-top:var(--nav-height);
            display:flex;
            flex-direction:column;
        }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
            display:flex; align-items:center; justify-content:space-between;
        }
        .navbar-fixed.scrolled {
            background:rgba(10,5,5,0.98);
            box-shadow:0 4px 30px rgba(0,0,0,0.5);
        }
        .navbar-left { display:flex; align-items:center; gap:1rem; }
        .navbar-logo {
            display:flex; align-items:center; gap:0.8rem;
            text-decoration:none;
        }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .navbar-right { display:flex; align-items:center; gap:1rem; }
        .navbar-right .notification-btn {
            position:relative;
            background:rgba(255,255,255,0.05);
            border:1px solid var(--border-color);
            border-radius:50%;
            width:40px; height:40px;
            display:flex; align-items:center; justify-content:center;
            color:#d4c0b0; transition:0.3s;
            cursor:pointer;
        }
        .navbar-right .notification-btn:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        .navbar-right .notification-btn .badge {
            position:absolute; top:-5px; right:-5px;
            background:var(--danger); color:white;
            border-radius:50%; width:20px; height:20px;
            font-size:0.7rem; font-weight:700;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-right .user-menu {
            display:flex; align-items:center; gap:0.5rem;
            cursor:pointer; padding:0.3rem 0.8rem;
            border-radius:2rem; transition:0.3s;
            border:1px solid transparent;
        }
        .navbar-right .user-menu:hover {
            border-color:var(--border-color);
            background:rgba(255,255,255,0.05);
        }
        .navbar-right .user-avatar {
            width:36px; height:36px; border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex; align-items:center; justify-content:center;
            font-weight:700; color:white; font-size:1rem;
        }
        .navbar-right .user-name {
            color:#f0d6b0; font-weight:600; font-size:0.9rem;
        }
        .navbar-right .user-name span {
            color:#7a6a5a; font-weight:400; font-size:0.75rem;
        }

        /* ===== DASHBOARD LAYOUT ===== */
        .dashboard-container {
            display:flex;
            flex:1;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width:var(--sidebar-width);
            background:rgba(10,5,5,0.8);
            backdrop-filter:blur(16px);
            border-right:1px solid var(--border-color);
            padding:1.5rem 0;
            position:fixed;
            top:var(--nav-height);
            bottom:0;
            left:0;
            overflow-y:auto;
            transition:transform 0.3s ease;
            z-index:1000;
        }
        .sidebar::-webkit-scrollbar { width:4px; }
        .sidebar::-webkit-scrollbar-track { background:transparent; }
        .sidebar::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }

        .sidebar .sidebar-section {
            padding:0 1rem 1rem;
            border-bottom:1px solid rgba(255,255,255,0.05);
            margin-bottom:1rem;
        }
        .sidebar .sidebar-section:last-child { border-bottom:none; }

        .sidebar .section-title {
            font-size:0.7rem;
            text-transform:uppercase;
            letter-spacing:1px;
            color:#5a4a3a;
            font-weight:600;
            padding:0 0.5rem;
            margin-bottom:0.5rem;
        }

        .sidebar .sidebar-item {
            display:flex;
            align-items:center;
            gap:0.8rem;
            padding:0.6rem 1rem;
            border-radius:0.5rem;
            color:#a09080;
            transition:all 0.3s;
            cursor:pointer;
            text-decoration:none;
            margin-bottom:0.2rem;
            position:relative;
        }
        .sidebar .sidebar-item:hover {
            color:#f0d6b0;
            background:rgba(139,26,26,0.2);
        }
        .sidebar .sidebar-item.active {
            color:#f0d6b0;
            background:rgba(139,26,26,0.3);
            border-left:3px solid var(--secondary);
        }
        .sidebar .sidebar-item i {
            width:20px;
            text-align:center;
            font-size:1rem;
            color:var(--secondary);
        }
        .sidebar .sidebar-item .item-badge {
            margin-left:auto;
            background:var(--danger);
            color:white;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .sidebar .sidebar-item .item-count {
            margin-left:auto;
            color:#5a4a3a;
            font-size:0.75rem;
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left:var(--sidebar-width);
            flex:1;
            padding:2rem;
            min-height:calc(100vh - var(--nav-height));
        }

        /* ===== PAGE HEADER ===== */
        .page-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:2rem;
            flex-wrap:wrap;
            gap:1rem;
        }
        .page-header h1 {
            font-size:1.8rem;
            font-weight:700;
            color:#f0d6b0;
        }
        .page-header h1 i {
            color:var(--secondary);
            margin-right:0.5rem;
        }
        .page-header .header-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
        }
        .page-header .header-actions .btn {
            padding:0.6rem 1.2rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            font-size:0.85rem;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .page-header .header-actions .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .page-header .header-actions .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 6px 25px rgba(139,26,26,0.5);
        }
        .page-header .header-actions .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .page-header .header-actions .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
        }
        .page-header .header-actions .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .page-header .header-actions .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }

        /* ===== STATS GRID ===== */
        .stats-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
            gap:1rem;
            margin-bottom:2rem;
        }
        .stat-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            transition:all 0.3s;
        }
        .stat-card:hover {
            border-color:rgba(201,168,124,0.3);
            transform:translateY(-3px);
        }
        .stat-card .stat-icon {
            font-size:1.8rem;
            color:var(--secondary);
            margin-bottom:0.3rem;
        }
        .stat-card .stat-value {
            font-size:1.8rem;
            font-weight:700;
            color:#f0d6b0;
        }
        .stat-card .stat-label {
            font-size:0.8rem;
            color:#7a6a5a;
        }
        .stat-card .stat-change {
            display:inline-block;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
            margin-top:0.3rem;
        }
        .stat-card .stat-change.positive {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .stat-card .stat-change.negative {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
        }

        /* ===== WELCOME CARD ===== */
        .welcome-card {
            background:linear-gradient(145deg, rgba(139,26,26,0.3), rgba(10,5,5,0.5));
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
            margin-bottom:2rem;
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:1rem;
        }
        .welcome-card .welcome-text h2 {
            font-size:1.5rem;
            color:#f0d6b0;
        }
        .welcome-card .welcome-text p {
            color:#a09080;
            margin-top:0.3rem;
        }
        .welcome-card .welcome-text .rating-badge {
            display:inline-block;
            background:rgba(201,168,124,0.15);
            padding:0.2rem 1rem;
            border-radius:1rem;
            border:1px solid rgba(201,168,124,0.2);
            font-weight:600;
            color:var(--secondary);
            margin-top:0.5rem;
        }
        .welcome-card .welcome-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
        }
        .welcome-card .welcome-actions .btn {
            padding:0.7rem 1.5rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .welcome-card .welcome-actions .btn-play {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .welcome-card .welcome-actions .btn-play:hover {
            transform:translateY(-2px);
            box-shadow:0 6px 25px rgba(139,26,26,0.5);
        }
        .welcome-card .welcome-actions .btn-puzzle {
            border:1px solid var(--secondary);
            background:transparent;
            color:var(--secondary);
        }
        .welcome-card .welcome-actions .btn-puzzle:hover {
            background:rgba(201,168,124,0.1);
            transform:translateY(-2px);
        }
        .welcome-card .welcome-actions .btn-learn {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .welcome-card .welcome-actions .btn-learn:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
            transform:translateY(-2px);
        }
        .welcome-card .welcome-actions .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .welcome-card .welcome-actions .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }

        /* ===== CONTENT GRID ===== */
        .content-grid {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:1.5rem;
            margin-bottom:2rem;
        }
        .content-grid .grid-2-1 { grid-template-columns:2fr 1fr; }
        .content-grid .grid-1-1 { grid-template-columns:1fr 1fr; }
        .content-grid .grid-1-2 { grid-template-columns:1fr 2fr; }
        .content-grid .grid-full { grid-template-columns:1fr; }

        @media (max-width:992px) {
            .content-grid { grid-template-columns:1fr; }
        }

        /* ===== CARDS ===== */
        .card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.5rem;
            transition:all 0.3s;
        }
        .card:hover {
            border-color:rgba(201,168,124,0.2);
        }
        .card .card-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:1rem;
        }
        .card .card-header h3 {
            color:#f0d6b0;
            font-size:1.1rem;
        }
        .card .card-header .card-action {
            color:var(--secondary);
            font-size:0.85rem;
            transition:0.3s;
            cursor:pointer;
        }
        .card .card-header .card-action:hover {
            color:#f0d6b0;
        }
        .card .card-body { color:#d4c0b0; }

        /* ===== GAME LIST ===== */
        .game-item {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:0.6rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .game-item:last-child { border-bottom:none; }
        .game-item .game-info {
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .game-item .game-result {
            padding:0.1rem 0.6rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .game-item .game-result.win {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .game-item .game-result.loss {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
        }
        .game-item .game-result.draw {
            background:rgba(241,196,15,0.2);
            color:var(--warning);
        }
        .game-item .game-date {
            color:#5a4a3a;
            font-size:0.75rem;
        }

        /* ===== FRIENDS LIST ===== */
        .friend-item {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:0.5rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .friend-item:last-child { border-bottom:none; }
        .friend-item .friend-info {
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .friend-item .friend-avatar {
            width:32px; height:32px; border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex; align-items:center; justify-content:center;
            font-weight:700; color:white; font-size:0.8rem;
        }
        .friend-item .friend-status {
            width:8px; height:8px; border-radius:50%;
            display:inline-block;
        }
        .friend-item .friend-status.online { background:var(--success); }
        .friend-item .friend-status.offline { background:#5a4a3a; }
        .friend-item .friend-actions {
            display:flex;
            gap:0.5rem;
        }
        .friend-item .friend-actions .btn {
            padding:0.2rem 0.6rem;
            border-radius:0.5rem;
            border:1px solid var(--border-color);
            background:transparent;
            color:#7a6a5a;
            font-size:0.75rem;
            cursor:pointer;
            transition:0.3s;
        }
        .friend-item .friend-actions .btn:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        .friend-item .friend-actions .btn-chess:hover {
            border-color:var(--gold);
            color:var(--gold);
        }

        /* ===== ACHIEVEMENTS ===== */
        .achievement-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(140px,1fr));
            gap:0.8rem;
        }
        .achievement-item {
            background:rgba(255,255,255,0.03);
            border:1px solid var(--border-color);
            border-radius:0.8rem;
            padding:1rem;
            text-align:center;
            transition:all 0.3s;
        }
        .achievement-item:hover {
            border-color:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }
        .achievement-item .ach-icon {
            font-size:2rem;
            margin-bottom:0.3rem;
        }
        .achievement-item .ach-icon.locked {
            opacity:0.3;
        }
        .achievement-item .ach-icon.unlocked {
            color:var(--gold);
        }
        .achievement-item .ach-name {
            font-size:0.8rem;
            color:#f0d6b0;
            font-weight:600;
        }
        .achievement-item .ach-desc {
            font-size:0.65rem;
            color:#5a4a3a;
        }

        /* ===== NOTIFICATIONS ===== */
        .notification-item {
            display:flex;
            gap:0.8rem;
            padding:0.6rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .notification-item:last-child { border-bottom:none; }
        .notification-item .notif-icon {
            width:32px; height:32px; border-radius:50%;
            background:rgba(139,26,26,0.3);
            display:flex; align-items:center; justify-content:center;
            color:var(--secondary);
            flex-shrink:0;
        }
        .notification-item .notif-content {
            flex:1;
        }
        .notification-item .notif-content .notif-text {
            font-size:0.9rem;
            color:#d4c0b0;
        }
        .notification-item .notif-content .notif-text strong {
            color:#f0d6b0;
        }
        .notification-item .notif-content .notif-time {
            font-size:0.75rem;
            color:#5a4a3a;
        }
        .notification-item .notif-content .notif-time i {
            margin-right:0.3rem;
        }
        .notification-item.unread {
            background:rgba(139,26,26,0.1);
            border-radius:0.5rem;
            padding:0.6rem 0.8rem;
        }

        /* ===== TAB CONTENT ===== */
        .tab-content {
            display:none;
            animation:fadeIn 0.3s ease;
        }
        .tab-content.active {
            display:block;
        }
        @keyframes fadeIn {
            from { opacity:0; transform:translateY(10px); }
            to { opacity:1; transform:translateY(0); }
        }

        /* ===== FORMS ===== */
        .form-group {
            margin-bottom:1.2rem;
        }
        .form-group label {
            display:block;
            color:#d4c0b0;
            font-weight:500;
            margin-bottom:0.3rem;
            font-size:0.9rem;
        }
        .form-group .form-control {
            width:100%;
            padding:0.7rem 1rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0d6b0;
            font-size:0.95rem;
            transition:all 0.3s;
        }
        .form-group .form-control:focus {
            outline:none;
            border-color:var(--secondary);
            background:rgba(255,255,255,0.08);
        }
        .form-group .form-control::placeholder {
            color:#5a4a3a;
        }
        .form-group .form-control:disabled {
            opacity:0.5;
            cursor:not-allowed;
        }
        .form-group textarea.form-control {
            min-height:100px;
            resize:vertical;
        }
        .form-group .form-hint {
            font-size:0.75rem;
            color:#5a4a3a;
            margin-top:0.3rem;
        }

        /* ===== BUTTONS ===== */
        .btn {
            padding:0.6rem 1.2rem;
            border-radius:0.8rem;
            border:none;
            font-weight:600;
            font-size:0.85rem;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
        }
        .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.4);
        }
        .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
        }
        .btn-success {
            background:rgba(46,204,113,0.2);
            color:var(--success);
            border:1px solid rgba(46,204,113,0.3);
        }
        .btn-success:hover {
            background:rgba(46,204,113,0.3);
        }
        .btn-danger {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
            border:1px solid rgba(231,76,60,0.3);
        }
        .btn-danger:hover {
            background:rgba(231,76,60,0.3);
        }
        .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }

        /* ===== MESSAGES ===== */
        .message {
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            margin-bottom:1.5rem;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .message-success {
            background:rgba(46,204,113,0.15);
            border:1px solid rgba(46,204,113,0.2);
            color:var(--success);
        }
        .message-error {
            background:rgba(231,76,60,0.15);
            border:1px solid rgba(231,76,60,0.2);
            color:var(--danger);
        }
        .message-info {
            background:rgba(52,152,219,0.15);
            border:1px solid rgba(52,152,219,0.2);
            color:var(--info);
        }

        /* ===== TABLE ===== */
        .table {
            width:100%;
            border-collapse:collapse;
        }
        .table th {
            text-align:left;
            padding:0.6rem 0.8rem;
            color:#5a4a3a;
            font-weight:600;
            font-size:0.8rem;
            text-transform:uppercase;
            letter-spacing:0.5px;
            border-bottom:1px solid var(--border-color);
        }
        .table td {
            padding:0.6rem 0.8rem;
            border-bottom:1px solid rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .table tr:hover td {
            background:rgba(255,255,255,0.02);
        }
        .table .status-badge {
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .table .status-badge.in_progress {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .table .status-badge.completed {
            background:rgba(52,152,219,0.2);
            color:var(--info);
        }

        /* ===== CHESS BOARD ===== */
        .chess-board-container {
            display:flex;
            justify-content:center;
            padding:0.5rem;
        }
        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:500px;
            aspect-ratio:1;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.5rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
        }
        .chess-board .square.light {
            background:var(--light-square);
        }
        .chess-board .square.dark {
            background:var(--dark-square);
        }
        .chess-board .square.selected {
            background:rgba(255,255,0,0.4) !important;
        }
        .chess-board .square.legal-move {
            position:relative;
        }
        .chess-board .square.legal-move::after {
            content:'';
            position:absolute;
            width:30%;
            height:30%;
            background:rgba(0,0,0,0.15);
            border-radius:50%;
        }
        .chess-board .square.legal-capture {
            position:relative;
        }
        .chess-board .square.legal-capture::after {
            content:'';
            position:absolute;
            width:100%;
            height:100%;
            border:6px solid rgba(0,0,0,0.15);
            border-radius:50%;
            box-sizing:border-box;
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }

        /* ===== GAME OVERSIGHT ===== */
        .game-oversight {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:1rem;
        }
        @media (max-width:768px) {
            .game-oversight {
                grid-template-columns:1fr;
            }
        }

        .game-status-bar {
            display:flex;
            justify-content:space-between;
            padding:0.5rem 0;
            border-bottom:1px solid var(--border-color);
            margin-bottom:0.5rem;
        }
        .game-status-bar .player {
            font-weight:600;
            color:#f0d6b0;
        }
        .game-status-bar .player i {
            margin-right:0.3rem;
        }
        .game-status-bar .move-info {
            color:#7a6a5a;
            font-size:0.85rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:768px) {
            :root { --nav-height:60px; --sidebar-width:0px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .navbar-left .logo-text { font-size:1rem; }
            .navbar-right .user-name { display:none; }
            
            .sidebar {
                transform:translateX(-100%);
                width:280px;
            }
            .sidebar.open {
                transform:translateX(0);
            }
            .sidebar-overlay {
                display:none;
                position:fixed;
                top:var(--nav-height);
                left:0; right:0; bottom:0;
                background:rgba(0,0,0,0.5);
                z-index:999;
            }
            .sidebar-overlay.active {
                display:block;
            }
            
            .main-content {
                margin-left:0;
                padding:1rem;
            }
            .welcome-card {
                flex-direction:column;
                text-align:center;
            }
            .welcome-card .welcome-actions {
                justify-content:center;
            }
            .stats-grid {
                grid-template-columns:repeat(2,1fr);
            }
            .content-grid {
                grid-template-columns:1fr;
            }
            .page-header {
                flex-direction:column;
                align-items:flex-start;
            }
            .page-header .header-actions {
                width:100%;
            }
            .page-header .header-actions .btn {
                flex:1;
                justify-content:center;
            }
            .achievement-grid {
                grid-template-columns:repeat(2,1fr);
            }
            .chess-board .square .piece {
                font-size:2rem;
            }
            .game-oversight {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:480px) {
            .stats-grid {
                grid-template-columns:1fr;
            }
            .achievement-grid {
                grid-template-columns:1fr 1fr;
            }
            .game-item {
                flex-direction:column;
                align-items:flex-start;
                gap:0.3rem;
            }
            .friend-item {
                flex-direction:column;
                align-items:flex-start;
                gap:0.3rem;
            }
            .chess-board .square .piece {
                font-size:1.5rem;
            }
        }

        /* ===== MOBILE SIDEBAR TOGGLE ===== */
        .sidebar-toggle {
            display:none;
            background:rgba(255,255,255,0.05);
            border:1px solid var(--border-color);
            border-radius:0.5rem;
            color:#d4c0b0;
            padding:0.5rem 0.8rem;
            cursor:pointer;
            transition:0.3s;
            font-size:1.2rem;
        }
        .sidebar-toggle:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        @media (max-width:768px) {
            .sidebar-toggle {
                display:block;
            }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-left">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
        </div>
        <div class="navbar-right">
            <div class="notification-btn" onclick="switchTab('notifications')">
                <i class="fas fa-bell"></i>
                <?php if ($notificationCount > 0): ?>
                    <span class="badge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </div>
            <div class="user-menu" onclick="switchTab('profile')">
                <div class="user-avatar"><?php echo strtoupper(substr($displayName, 0, 1)); ?></div>
                <span class="user-name"><?php echo e($displayName); ?> <span>· <?php echo ucfirst($role); ?></span></span>
            </div>
            <a href="logout.php" class="btn" style="border:1px solid var(--border-color);background:transparent;color:#7a6a5a;padding:0.4rem 0.8rem;border-radius:0.5rem;font-size:0.8rem;">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>

    <!-- ===== SIDEBAR OVERLAY (mobile) ===== -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ===== SIDEBAR ===== -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-section">
            <div class="section-title">Main</div>
            <a class="sidebar-item <?php echo $activeTab === 'dashboard' ? 'active' : ''; ?>" href="?tab=dashboard">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'profile' ? 'active' : ''; ?>" href="?tab=profile">
                <i class="fas fa-user"></i> My Profile
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'play' ? 'active' : ''; ?>" href="?tab=play">
                <i class="fas fa-chess"></i> Play Chess
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'history' ? 'active' : ''; ?>" href="?tab=history">
                <i class="fas fa-history"></i> Game History
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'analysis' ? 'active' : ''; ?>" href="?tab=analysis">
                <i class="fas fa-chart-line"></i> Analysis
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Learn</div>
            <a class="sidebar-item <?php echo $activeTab === 'puzzles' ? 'active' : ''; ?>" href="?tab=puzzles">
                <i class="fas fa-puzzle-piece"></i> Daily Puzzles
                <span class="item-badge">New</span>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'learning' ? 'active' : ''; ?>" href="?tab=learning">
                <i class="fas fa-graduation-cap"></i> Learning Center
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'openings' ? 'active' : ''; ?>" href="?tab=openings">
                <i class="fas fa-book"></i> Opening Repertoire
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Community</div>
            <a class="sidebar-item <?php echo $activeTab === 'tournaments' ? 'active' : ''; ?>" href="?tab=tournaments">
                <i class="fas fa-trophy"></i> Tournaments
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'friends' ? 'active' : ''; ?>" href="?tab=friends">
                <i class="fas fa-user-friends"></i> Friends
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'messages' ? 'active' : ''; ?>" href="?tab=messages">
                <i class="fas fa-envelope"></i> Messages
                <span class="item-badge">2</span>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'leaderboard' ? 'active' : ''; ?>" href="?tab=leaderboard">
                <i class="fas fa-list-ol"></i> Leaderboards
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Chess Play</div>
            <a class="sidebar-item <?php echo $activeTab === 'play' ? 'active' : ''; ?>" href="?tab=play">
                <i class="fas fa-chess-king"></i> Play Chess
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'oversee' ? 'active' : ''; ?>" href="?tab=oversee">
                <i class="fas fa-eye"></i> Oversee Games
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'challenge' ? 'active' : ''; ?>" href="?tab=challenge">
                <i class="fas fa-handshake"></i> Challenge Players
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Account</div>
            <a class="sidebar-item <?php echo $activeTab === 'achievements' ? 'active' : ''; ?>" href="?tab=achievements">
                <i class="fas fa-medal"></i> Achievements
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'notifications' ? 'active' : ''; ?>" href="?tab=notifications">
                <i class="fas fa-bell"></i> Notifications
                <?php if ($notificationCount > 0): ?>
                    <span class="item-badge"><?php echo $notificationCount; ?></span>
                <?php endif; ?>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'bookmarks' ? 'active' : ''; ?>" href="?tab=bookmarks">
                <i class="fas fa-bookmark"></i> Bookmarks
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'comments' ? 'active' : ''; ?>" href="?tab=comments">
                <i class="fas fa-comment"></i> Comments & Reviews
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'statistics' ? 'active' : ''; ?>" href="?tab=statistics">
                <i class="fas fa-chart-bar"></i> Statistics
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'settings' ? 'active' : ''; ?>" href="?tab=settings">
                <i class="fas fa-cog"></i> Settings
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'help' ? 'active' : ''; ?>" href="?tab=help">
                <i class="fas fa-question-circle"></i> Help & Support
            </a>
        </div>
        
        <div class="sidebar-section" style="border-bottom:none;padding-top:0.5rem;">
            <a class="sidebar-item" href="logout.php" style="color:var(--danger);">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <!-- ===== MAIN CONTENT ===== -->
    <main class="main-content">
        <!-- ====== DASHBOARD TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'dashboard' ? 'active' : ''; ?>" id="tab-dashboard">
            <div class="page-header">
                <h1><i class="fas fa-th-large"></i> Dashboard</h1>
                <div class="header-actions">
                    <a href="?tab=play" class="btn btn-primary"><i class="fas fa-chess"></i> Play Now</a>
                    <a href="?tab=puzzles" class="btn btn-secondary"><i class="fas fa-puzzle-piece"></i> Daily Puzzle</a>
                    <a href="?tab=challenge" class="btn btn-chess"><i class="fas fa-handshake"></i> Challenge</a>
                </div>
            </div>

            <!-- Welcome Card -->
            <div class="welcome-card">
                <div class="welcome-text">
                    <h2>Welcome back, <?php echo e($displayName); ?>! 👋</h2>
                    <p>Ready to improve your chess game today?</p>
                    <div class="rating-badge">
                        <i class="fas fa-star"></i> Rating: <?php echo $rating; ?> · <?php echo ucfirst($membershipType); ?> Member
                    </div>
                </div>
                <div class="welcome-actions">
                    <a href="?tab=play" class="btn btn-play"><i class="fas fa-chess"></i> Play</a>
                    <a href="?tab=puzzles" class="btn btn-puzzle"><i class="fas fa-puzzle-piece"></i> Puzzle</a>
                    <a href="?tab=learning" class="btn btn-learn"><i class="fas fa-graduation-cap"></i> Learn</a>
                    <a href="?tab=challenge" class="btn btn-chess"><i class="fas fa-handshake"></i> Challenge</a>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-chess-king"></i></div>
                    <div class="stat-value"><?php echo $rating; ?></div>
                    <div class="stat-label">Current Rating</div>
                    <span class="stat-change positive"><i class="fas fa-arrow-up"></i> +12 this month</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-trophy"></i></div>
                    <div class="stat-value"><?php echo $gamesWon; ?></div>
                    <div class="stat-label">Games Won</div>
                    <span class="stat-change positive"><?php echo $winPercentage; ?>% win rate</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-gamepad"></i></div>
                    <div class="stat-value"><?php echo $gamesPlayed; ?></div>
                    <div class="stat-label">Games Played</div>
                    <span class="stat-change"><?php echo $gamesDrawn; ?> draws</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-fire"></i></div>
                    <div class="stat-value"><?php echo $_SESSION['current_streak'] ?? 0; ?></div>
                    <div class="stat-label">Current Streak</div>
                    <span class="stat-change positive">Best: <?php echo $_SESSION['best_streak'] ?? 0; ?></span>
                </div>
            </div>

            <!-- Content Grid -->
            <div class="content-grid">
                <!-- Recent Games -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-clock"></i> Recent Games</h3>
                        <a href="?tab=history" class="card-action">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($recentGames)): ?>
                            <?php foreach ($recentGames as $game): ?>
                                <div class="game-item">
                                    <div class="game-info">
                                        <span class="game-result <?php echo strtolower($game['result'] ?? 'draw'); ?>">
                                            <?php echo ucfirst($game['result'] ?? 'Draw'); ?>
                                        </span>
                                        <span><?php echo e($game['opponent'] ?? 'vs Computer'); ?></span>
                                    </div>
                                    <span class="game-date"><?php echo e($game['date'] ?? ''); ?></span>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="color:#5a4a3a;text-align:center;padding:1rem 0;">
                                <i class="fas fa-info-circle"></i> No games played yet. Start playing!
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Daily Puzzle -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-puzzle-piece"></i> Daily Puzzle</h3>
                        <a href="?tab=puzzles" class="card-action">Solve <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="card-body">
                        <h4 style="color:#f0d6b0;margin-bottom:0.3rem;"><?php echo e($dailyPuzzle['title'] ?? 'Mate in 2'); ?></h4>
                        <p style="color:#7a6a5a;font-size:0.9rem;"><?php echo e($dailyPuzzle['description'] ?? 'Find the winning move. White to play.'); ?></p>
                        <div style="margin-top:0.8rem;display:flex;gap:0.5rem;">
                            <span style="background:rgba(201,168,124,0.15);padding:0.2rem 0.8rem;border-radius:1rem;font-size:0.75rem;color:var(--secondary);">
                                <i class="fas fa-star"></i> <?php echo ucfirst($dailyPuzzle['difficulty'] ?? 'medium'); ?>
                            </span>
                            <a href="?tab=puzzles" class="btn btn-secondary" style="padding:0.2rem 0.8rem;font-size:0.75rem;">
                                View Solution <i class="fas fa-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Friends & Achievements -->
            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-friends"></i> Friends Online</h3>
                        <a href="?tab=friends" class="card-action">View All</a>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($friends)): ?>
                            <?php foreach ($friends as $friend): ?>
                                <div class="friend-item">
                                    <div class="friend-info">
                                        <div class="friend-avatar"><?php echo strtoupper(substr($friend['name'], 0, 1)); ?></div>
                                        <div>
                                            <strong><?php echo e($friend['name']); ?></strong>
                                            <span style="font-size:0.75rem;color:#5a4a3a;display:block;">Rating: <?php echo $friend['rating']; ?></span>
                                        </div>
                                    </div>
                                    <div>
                                        <span class="friend-status <?php echo $friend['online'] ? 'online' : 'offline'; ?>"></span>
                                        <span style="font-size:0.7rem;color:#5a4a3a;"><?php echo $friend['online'] ? 'Online' : 'Offline'; ?></span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <p style="color:#5a4a3a;text-align:center;padding:1rem 0;">
                                <i class="fas fa-info-circle"></i> No friends yet. Start connecting!
                            </p>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-medal"></i> Recent Achievements</h3>
                        <a href="?tab=achievements" class="card-action">View All</a>
                    </div>
                    <div class="card-body">
                        <div class="achievement-grid">
                            <?php foreach ($achievements as $ach): ?>
                                <div class="achievement-item">
                                    <div class="ach-icon <?php echo $ach['unlocked'] ? 'unlocked' : 'locked'; ?>">
                                        <i class="fas <?php echo $ach['icon']; ?>"></i>
                                    </div>
                                    <div class="ach-name"><?php echo e($ach['name']); ?></div>
                                    <div class="ach-desc"><?php echo e($ach['description']); ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== PROFILE TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'profile' ? 'active' : ''; ?>" id="tab-profile">
            <div class="page-header">
                <h1><i class="fas fa-user"></i> My Profile</h1>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="document.getElementById('profileForm').submit();">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'profile'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid" style="grid-template-columns:1fr 2fr;">
                <div class="card" style="text-align:center;">
                    <div class="user-avatar" style="width:120px;height:120px;border-radius:50%;margin:0 auto 1rem;font-size:3rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));display:flex;align-items:center;justify-content:center;color:white;">
                        <?php echo strtoupper(substr($displayName, 0, 1)); ?>
                    </div>
                    <h3 style="color:#f0d6b0;"><?php echo e($displayName); ?></h3>
                    <p style="color:#7a6a5a;">@<?php echo e($username); ?></p>
                    <p style="color:var(--secondary);">
                        <i class="fas fa-star"></i> Rating: <?php echo $rating; ?>
                    </p>
                    <p style="color:#5a4a3a;font-size:0.85rem;">
                        <i class="fas fa-user-tag"></i> <?php echo ucfirst($membershipType); ?> Member
                    </p>
                    <button class="btn btn-secondary" style="margin-top:0.8rem;width:100%;">
                        <i class="fas fa-camera"></i> Change Photo
                    </button>
                </div>

                <div class="card">
                    <form id="profileForm" method="POST">
                        <input type="hidden" name="update_profile" value="1">
                        <div class="form-group">
                            <label>Display Name</label>
                            <input type="text" name="display_name" class="form-control" value="<?php echo e($displayName); ?>">
                        </div>
                        <div class="form-group">
                            <label>Bio</label>
                            <textarea name="bio" class="form-control" placeholder="Tell us about yourself"><?php echo e($bio); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label>Country</label>
                            <input type="text" name="country" class="form-control" value="<?php echo e($country); ?>" placeholder="Your country">
                        </div>
                        <div class="form-group">
                            <label>City</label>
                            <input type="text" name="city" class="form-control" value="<?php echo e($city); ?>" placeholder="Your city">
                        </div>
                        <div class="form-group">
                            <label>Favorite Opening</label>
                            <input type="text" name="favorite_opening" class="form-control" value="<?php echo e($favoriteOpening); ?>" placeholder="e.g., Italian Game">
                        </div>
                        <div class="form-group">
                            <label>Favorite Piece</label>
                            <input type="text" name="favorite_piece" class="form-control" value="<?php echo e($favoritePiece); ?>" placeholder="e.g., Knight">
                        </div>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-lock"></i> Change Password</h3>
                </div>
                <div class="card-body">
                    <form method="POST" style="max-width:400px;">
                        <input type="hidden" name="change_password" value="1">
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Min 6 characters" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ====== PLAY CHESS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'play' ? 'active' : ''; ?>" id="tab-play">
            <div class="page-header">
                <h1><i class="fas fa-chess-king"></i> Play Chess</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary" onclick="resetBoard()"><i class="fas fa-undo"></i> Reset Board</button>
                    <button class="btn btn-chess" onclick="flipBoard()"><i class="fas fa-arrows-alt-h"></i> Flip Board</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'play'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chess-board"></i> Chess Board</h3>
                        <span id="turn-indicator" style="color:var(--gold);font-weight:600;">
                            <i class="fas fa-circle" style="color:#f0d9b5;"></i> White's Turn
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="chess-board-container">
                            <div class="chess-board" id="chessBoard"></div>
                        </div>
                        <div style="display:flex;justify-content:space-between;margin-top:0.8rem;padding:0.5rem;background:rgba(255,255,255,0.03);border-radius:0.5rem;">
                            <span id="move-count" style="color:#7a6a5a;">Moves: 0</span>
                            <span id="game-status" style="color:var(--gold);">Game in progress</span>
                            <button class="btn btn-chess" style="padding:0.3rem 0.8rem;font-size:0.75rem;" onclick="undoMove()">
                                <i class="fas fa-undo-alt"></i> Undo
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-exchange-alt"></i> Game Controls</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Play Against</label>
                            <select class="form-control" id="playMode" onchange="changePlayMode()">
                                <option value="ai">Computer (AI)</option>
                                <option value="local">Local (2 Players)</option>
                                <option value="online">Online Player</option>
                            </select>
                        </div>
                        <div id="online-opponent-section" style="display:none;">
                            <div class="form-group">
                                <label>Select Opponent</label>
                                <select class="form-control" id="opponentSelect">
                                    <?php foreach ($onlineUsers as $opponent): ?>
                                        <option value="<?php echo $opponent['id']; ?>">
                                            <?php echo e($opponent['username']); ?> (<?php echo $opponent['role']; ?>) - <?php echo $opponent['rating']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Time Control (minutes)</label>
                                <select class="form-control" id="timeControl">
                                    <option value="5">5 min (Blitz)</option>
                                    <option value="10" selected>10 min (Rapid)</option>
                                    <option value="30">30 min (Classical)</option>
                                    <option value="60">60 min (Long)</option>
                                </select>
                            </div>
                            <button class="btn btn-chess" onclick="requestOnlineGame()" style="width:100%;">
                                <i class="fas fa-handshake"></i> Request Game
                            </button>
                        </div>
                        <div id="ai-section">
                            <div class="form-group">
                                <label>AI Difficulty</label>
                                <select class="form-control" id="aiDifficulty">
                                    <option value="easy">Easy</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="hard">Hard</option>
                                </select>
                            </div>
                            <button class="btn btn-chess" onclick="playAIMove()" style="width:100%;">
                                <i class="fas fa-robot"></i> AI Makes Move
                            </button>
                        </div>
                        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color);">
                            <div class="form-group">
                                <label>Piece Color</label>
                                <select class="form-control" id="playerColor">
                                    <option value="white">White</option>
                                    <option value="black">Black</option>
                                    <option value="random">Random</option>
                                </select>
                            </div>
                            <button class="btn btn-primary" onclick="startNewGame()" style="width:100%;">
                                <i class="fas fa-play"></i> Start New Game
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== OVERSEE GAMES TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'oversee' ? 'active' : ''; ?>" id="tab-oversee">
            <div class="page-header">
                <h1><i class="fas fa-eye"></i> Oversee Games</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-refresh"></i> Refresh</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'oversee'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid game-oversight">
                <!-- Active Games List -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-gamepad"></i> Active Games</h3>
                        <span class="card-action"><?php echo count($activeGames); ?> games</span>
                    </div>
                    <div class="card-body">
                        <?php foreach ($activeGames as $game): ?>
                            <div class="activity-item" style="border-bottom:1px solid rgba(255,255,255,0.05);padding:0.8rem 0;">
                                <div class="activity-icon">
                                    <i class="fas fa-chess"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-text">
                                        <strong><?php echo e($game['white']); ?></strong> 
                                        <span style="color:#7a6a5a;">vs</span> 
                                        <strong><?php echo e($game['black']); ?></strong>
                                    </div>
                                    <div style="display:flex;gap:1rem;font-size:0.8rem;color:#5a4a3a;margin-top:0.2rem;">
                                        <span><i class="fas fa-chess-knight"></i> Move <?php echo $game['move']; ?></span>
                                        <span><i class="fas fa-clock"></i> <?php echo $game['time']; ?></span>
                                        <span><span class="status-badge in_progress"><?php echo str_replace('_', ' ', $game['status']); ?></span></span>
                                    </div>
                                </div>
                                <form method="POST" style="margin-left:auto;">
                                    <input type="hidden" name="game_id" value="<?php echo $game['id']; ?>">
                                    <button type="submit" name="oversee_game" class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i> Oversee
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Game Oversight View -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-desktop"></i> Game Oversight</h3>
                        <span class="card-action" id="oversee-game-id">No game selected</span>
                    </div>
                    <div class="card-body" id="overseeBoardContainer">
                        <div style="text-align:center;padding:2rem;color:#5a4a3a;">
                            <i class="fas fa-eye" style="font-size:3rem;display:block;margin-bottom:1rem;"></i>
                            <p>Select a game above to oversee it in real-time.</p>
                            <p style="font-size:0.85rem;">You can view all moves and monitor the game progress.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== CHALLENGE PLAYERS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'challenge' ? 'active' : ''; ?>" id="tab-challenge">
            <div class="page-header">
                <h1><i class="fas fa-handshake"></i> Challenge Players</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-filter"></i> Filter</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'challenge'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-users"></i> Online Players</h3>
                    <span class="card-action"><?php echo count($onlineUsers); ?> online</span>
                </div>
                <div class="card-body">
                    <?php foreach ($onlineUsers as $player): ?>
                        <div class="user-item" style="display:flex;justify-content:space-between;align-items:center;padding:0.5rem 0;border-bottom:1px solid rgba(255,255,255,0.05);">
                            <div style="display:flex;align-items:center;gap:0.8rem;">
                                <div class="user-avatar-sm" style="width:32px;height:32px;border-radius:50%;background:linear-gradient(145deg,var(--primary),var(--primary-dark));display:flex;align-items:center;justify-content:center;font-weight:700;color:white;font-size:0.8rem;">
                                    <?php echo strtoupper(substr($player['username'], 0, 1)); ?>
                                </div>
                                <div>
                                    <strong style="color:#f0d6b0;"><?php echo e($player['username']); ?></strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;"> · <?php echo ucfirst($player['role']); ?></span>
                                    <div style="font-size:0.75rem;color:#7a6a5a;">
                                        <i class="fas fa-star" style="color:var(--gold);"></i> <?php echo $player['rating']; ?>
                                    </div>
                                </div>
                            </div>
                            <div style="display:flex;gap:0.5rem;align-items:center;">
                                <span class="user-status online" style="font-size:0.7rem;padding:0.1rem 0.5rem;border-radius:1rem;background:rgba(46,204,113,0.2);color:var(--success);">
                                    <i class="fas fa-circle"></i> Online
                                </span>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="opponent_id" value="<?php echo $player['id']; ?>">
                                    <input type="hidden" name="time_control" value="10">
                                    <input type="hidden" name="color" value="random">
                                    <button type="submit" name="request_game" class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-handshake"></i> Challenge
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> Recent Challenges</h3>
                </div>
                <div class="card-body">
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-handshake"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>You</strong> challenged <strong>GrandMaster99</strong> to a game</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 5 minutes ago · <span style="color:var(--warning);">Awaiting response</span></div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-check-circle" style="color:var(--success);"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>ChessPro2024</strong> accepted your challenge</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 1 hour ago · <span style="color:var(--success);">Game in progress</span></div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-times-circle" style="color:var(--danger);"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>QueenSlayer</strong> declined your challenge</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 3 hours ago · <span style="color:var(--danger);">Declined</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== GAME HISTORY TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'history' ? 'active' : ''; ?>" id="tab-history">
            <div class="page-header">
                <h1><i class="fas fa-history"></i> Game History</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-download"></i> Export</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> All Games</h3>
                    <div style="display:flex;gap:0.5rem;">
                        <select class="form-control" style="padding:0.3rem 0.8rem;width:auto;background:rgba(255,255,255,0.05);border:1px solid var(--border-color);border-radius:0.5rem;color:#d4c0b0;">
                            <option>All Games</option>
                            <option>Wins</option>
                            <option>Losses</option>
                            <option>Draws</option>
                        </select>
                    </div>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Opponent</th>
                                <th>Result</th>
                                <th>Moves</th>
                                <th>Rating Change</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($recentGames)): ?>
                                <?php foreach ($recentGames as $game): ?>
                                    <tr>
                                        <td><?php echo e($game['date'] ?? 'N/A'); ?></td>
                                        <td><?php echo e($game['opponent'] ?? 'vs Computer'); ?></td>
                                        <td>
                                            <span class="game-result <?php echo strtolower($game['result'] ?? 'draw'); ?>">
                                                <?php echo ucfirst($game['result'] ?? 'Draw'); ?>
                                            </span>
                                        </td>
                                        <td><?php echo $game['moves'] ?? '-'; ?></td>
                                        <td style="color:<?php echo (($game['rating_change'] ?? 0) > 0) ? 'var(--success)' : 'var(--danger)'; ?>;">
                                            <?php echo ($game['rating_change'] ?? 0) > 0 ? '+' : ''; ?><?php echo $game['rating_change'] ?? 0; ?>
                                        </td>
                                        <td>
                                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                                <i class="fas fa-eye"></i> Replay
                                            </button>
                                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                                <i class="fas fa-chart-line"></i> Analyze
                                            </button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="6" style="text-align:center;color:#5a4a3a;padding:2rem 0;">
                                        <i class="fas fa-info-circle"></i> No games found. Start playing!
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== ANALYSIS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'analysis' ? 'active' : ''; ?>" id="tab-analysis">
            <div class="page-header">
                <h1><i class="fas fa-chart-line"></i> Chess Analysis</h1>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-microchip"></i> Engine Analysis</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Enter PGN or FEN</label>
                            <textarea class="form-control" placeholder="Paste your game notation here..."></textarea>
                        </div>
                        <button class="btn btn-primary" style="width:100%;">
                            <i class="fas fa-play"></i> Analyze Game
                        </button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Recent Analyses</h3>
                    </div>
                    <div class="card-body">
                        <div class="game-item">
                            <div class="game-info">
                                <span style="color:#f0d6b0;">Game #1245</span>
                                <span style="color:#5a4a3a;font-size:0.8rem;">vs GrandMaster99</span>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.8rem;font-size:0.75rem;">
                                <i class="fas fa-chart-line"></i> Review
                            </button>
                        </div>
                        <div class="game-item">
                            <div class="game-info">
                                <span style="color:#f0d6b0;">Game #1243</span>
                                <span style="color:#5a4a3a;font-size:0.8rem;">vs ChessPro2024</span>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.8rem;font-size:0.75rem;">
                                <i class="fas fa-chart-line"></i> Review
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-lightbulb"></i> Improvement Suggestions</h3>
                </div>
                <div class="card-body">
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">
                        <div style="background:rgba(255,255,255,0.03);padding:1rem;border-radius:0.8rem;border-left:3px solid var(--danger);">
                            <h4 style="color:var(--danger);">Mistake Found</h4>
                            <p style="color:#7a6a5a;font-size:0.9rem;">Move 12: You missed a tactical fork. Consider playing Nc6 instead.</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.03);padding:1rem;border-radius:0.8rem;border-left:3px solid var(--warning);">
                            <h4 style="color:var(--warning);">Inaccuracy</h4>
                            <p style="color:#7a6a5a;font-size:0.9rem;">Move 8: Better to develop your bishop before moving the same piece twice.</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.03);padding:1rem;border-radius:0.8rem;border-left:3px solid var(--success);">
                            <h4 style="color:var(--success);">Good Move</h4>
                            <p style="color:#7a6a5a;font-size:0.9rem;">Move 15: Excellent positional play. You controlled the center effectively.</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.03);padding:1rem;border-radius:0.8rem;border-left:3px solid var(--info);">
                            <h4 style="color:var(--info);">Suggested Study</h4>
                            <p style="color:#7a6a5a;font-size:0.9rem;">Review pawn endgame techniques. You missed a winning pawn promotion.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== DAILY PUZZLES TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'puzzles' ? 'active' : ''; ?>" id="tab-puzzles">
            <div class="page-header">
                <h1><i class="fas fa-puzzle-piece"></i> Daily Puzzles</h1>
                <div class="header-actions">
                    <span class="stat-card" style="padding:0.5rem 1rem;">
                        <i class="fas fa-fire" style="color:var(--warning);"></i>
                        Streak: <?php echo $_SESSION['current_streak'] ?? 0; ?> days
                    </span>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-star"></i> Today's Puzzle</h3>
                        <span style="color:var(--secondary);font-size:0.85rem;"><?php echo ucfirst($dailyPuzzle['difficulty'] ?? 'medium'); ?></span>
                    </div>
                    <div class="card-body">
                        <div style="background:rgba(255,255,255,0.03);border-radius:0.8rem;padding:1rem;text-align:center;margin-bottom:1rem;">
                            <div style="font-size:4rem;color:var(--secondary);">
                                <i class="fas fa-chess-king"></i>
                            </div>
                            <h4 style="color:#f0d6b0;"><?php echo e($dailyPuzzle['title'] ?? 'Mate in 2'); ?></h4>
                            <p style="color:#7a6a5a;font-size:0.9rem;"><?php echo e($dailyPuzzle['description'] ?? 'Find the winning move. White to play.'); ?></p>
                            <div style="margin-top:0.5rem;">
                                <span style="background:rgba(46,204,113,0.2);padding:0.2rem 0.8rem;border-radius:1rem;font-size:0.75rem;color:var(--success);">
                                    <i class="fas fa-check"></i> 78% solved
                                </span>
                            </div>
                        </div>
                        <button class="btn btn-primary" style="width:100%;">
                            <i class="fas fa-play"></i> Solve Puzzle
                        </button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Puzzle History</h3>
                    </div>
                    <div class="card-body">
                        <div class="game-item">
                            <div class="game-info">
                                <span style="color:#f0d6b0;">Puzzle #1245</span>
                                <span style="color:#5a4a3a;font-size:0.8rem;">Mate in 3</span>
                            </div>
                            <span style="color:var(--success);"><i class="fas fa-check"></i> Solved</span>
                        </div>
                        <div class="game-item">
                            <div class="game-info">
                                <span style="color:#f0d6b0;">Puzzle #1244</span>
                                <span style="color:#5a4a3a;font-size:0.8rem;">Fork</span>
                            </div>
                            <span style="color:var(--success);"><i class="fas fa-check"></i> Solved</span>
                        </div>
                        <div class="game-item">
                            <div class="game-info">
                                <span style="color:#f0d6b0;">Puzzle #1243</span>
                                <span style="color:#5a4a3a;font-size:0.8rem;">Pin</span>
                            </div>
                            <span style="color:var(--danger);"><i class="fas fa-times"></i> Failed</span>
                        </div>
                        <div class="game-item">
                            <div class="game-info">
                                <span style="color:#f0d6b0;">Puzzle #1242</span>
                                <span style="color:#5a4a3a;font-size:0.8rem;">Skewer</span>
                            </div>
                            <span style="color:var(--success);"><i class="fas fa-check"></i> Solved</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-trophy"></i> Puzzle Leaderboard</h3>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Player</th>
                                <th>Rating</th>
                                <th>Solved</th>
                                <th>Streak</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1</td>
                                <td><strong style="color:#f0d6b0;">TacticalMaster</strong></td>
                                <td>2450</td>
                                <td>342</td>
                                <td>15</td>
                            </tr>
                            <tr>
                                <td>2</td>
                                <td><strong style="color:#f0d6b0;">PuzzleKing</strong></td>
                                <td>2380</td>
                                <td>298</td>
                                <td>12</td>
                            </tr>
                            <tr>
                                <td>3</td>
                                <td><strong style="color:#f0d6b0;">ChessTactician</strong></td>
                                <td>2315</td>
                                <td>276</td>
                                <td>8</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== LEARNING CENTER TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'learning' ? 'active' : ''; ?>" id="tab-learning">
            <div class="page-header">
                <h1><i class="fas fa-graduation-cap"></i> Learning Center</h1>
                <div class="header-actions">
                    <span class="stat-card" style="padding:0.5rem 1rem;">
                        <i class="fas fa-book"></i> Progress: <?php echo $learningProgress['completed_lessons']; ?>/<?php echo $learningProgress['total_lessons']; ?>
                    </span>
                </div>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-book"></i></div>
                    <div class="stat-value"><?php echo $learningProgress['completed_lessons']; ?>/<?php echo $learningProgress['total_lessons']; ?></div>
                    <div class="stat-label">Lessons Completed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-dumbbell"></i></div>
                    <div class="stat-value"><?php echo $learningProgress['completed_exercises']; ?>/<?php echo $learningProgress['total_exercises']; ?></div>
                    <div class="stat-label">Exercises Completed</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-fire"></i></div>
                    <div class="stat-value"><?php echo $learningProgress['streak_days']; ?> days</div>
                    <div class="stat-label">Learning Streak</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-value"><?php echo $learningProgress['total_hours']; ?> hrs</div>
                    <div class="stat-label">Total Learning Time</div>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chess-king"></i> Beginner</h3>
                    </div>
                    <div class="card-body">
                        <div class="game-item">
                            <span>Chess Rules</span>
                            <span style="color:var(--success);"><i class="fas fa-check"></i></span>
                        </div>
                        <div class="game-item">
                            <span>Piece Movement</span>
                            <span style="color:var(--success);"><i class="fas fa-check"></i></span>
                        </div>
                        <div class="game-item">
                            <span>Basic Tactics</span>
                            <span style="color:var(--warning);"><i class="fas fa-clock"></i> In Progress</span>
                        </div>
                        <div class="game-item">
                            <span>Opening Principles</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chess-queen"></i> Intermediate</h3>
                    </div>
                    <div class="card-body">
                        <div class="game-item">
                            <span>Opening Theory</span>
                            <span style="color:var(--warning);"><i class="fas fa-clock"></i> In Progress</span>
                        </div>
                        <div class="game-item">
                            <span>Middlegame Strategy</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                        <div class="game-item">
                            <span>Endgame Basics</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                        <div class="game-item">
                            <span>Positional Play</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chess-king"></i> Advanced</h3>
                    </div>
                    <div class="card-body">
                        <div class="game-item">
                            <span>Advanced Tactics</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                        <div class="game-item">
                            <span>Grandmaster Strategies</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                        <div class="game-item">
                            <span>Endgame Mastery</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                        <div class="game-item">
                            <span>Opening Repertoire</span>
                            <span style="color:#5a4a3a;"><i class="fas fa-lock"></i> Locked</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-video"></i> Recommended Videos</h3>
                </div>
                <div class="card-body">
                    <div class="content-grid" style="grid-template-columns:1fr 1fr 1fr;">
                        <div style="background:rgba(255,255,255,0.03);padding:1rem;border-radius:0.8rem;text-align:center;">
                            <i class="fas fa-play-circle" style="font-size:2rem;color:var(--secondary);"></i>
                            <h4 style="color:#f0d6b0;font-size:0.9rem;margin-top:0.5rem;">Understanding Pawn Structure</h4>
                            <p style="color:#5a4a3a;font-size:0.8rem;">15 min · GM Magnus</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.03);padding:1rem;border-radius:0.8rem;text-align:center;">
                            <i class="fas fa-play-circle" style="font-size:2rem;color:var(--secondary);"></i>
                            <h4 style="color:#f0d6b0;font-size:0.9rem;margin-top:0.5rem;">Queen Sacrifice Patterns</h4>
                            <p style="color:#5a4a3a;font-size:0.8rem;">20 min · GM Kasparov</p>
                        </div>
                        <div style="background:rgba(255,255,255,0.03);padding:1rem;border-radius:0.8rem;text-align:center;">
                            <i class="fas fa-play-circle" style="font-size:2rem;color:var(--secondary);"></i>
                            <h4 style="color:#f0d6b0;font-size:0.9rem;margin-top:0.5rem;">Knight Fork Mastery</h4>
                            <p style="color:#5a4a3a;font-size:0.8rem;">12 min · IM Sarah</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== OPENINGS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'openings' ? 'active' : ''; ?>" id="tab-openings">
            <div class="page-header">
                <h1><i class="fas fa-book"></i> Opening Repertoire</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Add Opening</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-star"></i> Saved Openings</h3>
                    </div>
                    <div class="card-body">
                        <div class="game-item">
                            <div>
                                <strong style="color:#f0d6b0;">Italian Game</strong>
                                <span style="color:#5a4a3a;font-size:0.8rem;display:block;">1.e4 e5 2.Nf3 Nc6 3.Bc4</span>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-play"></i> Practice
                            </button>
                        </div>
                        <div class="game-item">
                            <div>
                                <strong style="color:#f0d6b0;">Ruy Lopez</strong>
                                <span style="color:#5a4a3a;font-size:0.8rem;display:block;">1.e4 e5 2.Nf3 Nc6 3.Bb5</span>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-play"></i> Practice
                            </button>
                        </div>
                        <div class="game-item">
                            <div>
                                <strong style="color:#f0d6b0;">Sicilian Defense</strong>
                                <span style="color:#5a4a3a;font-size:0.8rem;display:block;">1.e4 c5</span>
                            </div>
                            <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                <i class="fas fa-play"></i> Practice
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-bar"></i> Opening Statistics</h3>
                    </div>
                    <div class="card-body">
                        <div class="game-item">
                            <span>Italian Game</span>
                            <span style="color:var(--success);">Win: 65%</span>
                        </div>
                        <div class="game-item">
                            <span>Ruy Lopez</span>
                            <span style="color:var(--success);">Win: 58%</span>
                        </div>
                        <div class="game-item">
                            <span>Sicilian Defense</span>
                            <span style="color:var(--warning);">Win: 52%</span>
                        </div>
                        <div class="game-item">
                            <span>Queen's Gambit</span>
                            <span style="color:var(--danger);">Win: 45%</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== TOURNAMENTS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'tournaments' ? 'active' : ''; ?>" id="tab-tournaments">
            <div class="page-header">
                <h1><i class="fas fa-trophy"></i> Tournaments</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Register</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-calendar-plus"></i> Upcoming Tournaments</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach ($upcomingTournaments as $tournament): ?>
                            <div class="game-item">
                                <div>
                                    <strong style="color:#f0d6b0;"><?php echo e($tournament['name']); ?></strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;display:block;">
                                        <i class="fas fa-calendar"></i> <?php echo e($tournament['date']); ?> · 
                                        <i class="fas fa-clock"></i> <?php echo e($tournament['time']); ?>
                                    </span>
                                    <span style="color:#7a6a5a;font-size:0.8rem;">
                                        <i class="fas fa-users"></i> <?php echo $tournament['players']; ?> players
                                    </span>
                                </div>
                                <button class="btn btn-primary" style="padding:0.2rem 0.8rem;font-size:0.75rem;">
                                    <?php echo $tournament['status'] === 'open' ? 'Join' : 'View'; ?>
                                </button>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-flag-checkered"></i> My Tournaments</h3>
                    </div>
                    <div class="card-body">
                        <p style="color:#5a4a3a;text-align:center;padding:2rem 0;">
                            <i class="fas fa-info-circle"></i> You haven't registered for any tournaments yet.
                        </p>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> Tournament Results</h3>
                </div>
                <div class="card-body">
                    <p style="color:#5a4a3a;text-align:center;padding:1rem 0;">
                        <i class="fas fa-info-circle"></i> No tournament results available.
                    </p>
                </div>
            </div>
        </div>

        <!-- ====== FRIENDS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'friends' ? 'active' : ''; ?>" id="tab-friends">
            <div class="page-header">
                <h1><i class="fas fa-user-friends"></i> Friends</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-search"></i> Find Players</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Friends List</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach ($friends as $friend): ?>
                            <div class="friend-item">
                                <div class="friend-info">
                                    <div class="friend-avatar"><?php echo strtoupper(substr($friend['name'], 0, 1)); ?></div>
                                    <div>
                                        <strong><?php echo e($friend['name']); ?></strong>
                                        <span style="color:#5a4a3a;font-size:0.8rem;display:block;">
                                            Rating: <?php echo $friend['rating']; ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="friend-actions">
                                    <span class="friend-status <?php echo $friend['online'] ? 'online' : 'offline'; ?>"></span>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-chess"></i>
                                    </button>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-envelope"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-user-plus"></i> Friend Requests</h3>
                    </div>
                    <div class="card-body">
                        <div class="friend-item">
                            <div class="friend-info">
                                <div class="friend-avatar">C</div>
                                <div>
                                    <strong>ChessPro2024</strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Rating: 1850</span>
                                </div>
                            </div>
                            <div class="friend-actions">
                                <button class="btn btn-success" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                    <i class="fas fa-check"></i>
                                </button>
                                <button class="btn btn-danger" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                        <div class="friend-item">
                            <div class="friend-info">
                                <div class="friend-avatar">M</div>
                                <div>
                                    <strong>MasterMind</strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Rating: 2100</span>
                                </div>
                            </div>
                            <div class="friend-actions">
                                <button class="btn btn-success" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                    <i class="fas fa-check"></i>
                                </button>
                                <button class="btn btn-danger" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                    <i class="fas fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== MESSAGES TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'messages' ? 'active' : ''; ?>" id="tab-messages">
            <div class="page-header">
                <h1><i class="fas fa-envelope"></i> Messages</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> New Message</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 2fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-users"></i> Conversations</h3>
                    </div>
                    <div class="card-body">
                        <div class="friend-item" style="cursor:pointer;padding:0.8rem 0.5rem;border-radius:0.5rem;transition:0.3s;">
                            <div class="friend-info">
                                <div class="friend-avatar">G</div>
                                <div>
                                    <strong>GrandMaster99</strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Good game!</span>
                                </div>
                            </div>
                            <span style="color:#5a4a3a;font-size:0.7rem;">2m ago</span>
                        </div>
                        <div class="friend-item" style="cursor:pointer;padding:0.8rem 0.5rem;border-radius:0.5rem;transition:0.3s;background:rgba(139,26,26,0.1);">
                            <div class="friend-info">
                                <div class="friend-avatar">C</div>
                                <div>
                                    <strong>ChessPro2024</strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;display:block;">Want to play?</span>
                                </div>
                            </div>
                            <span style="color:#5a4a3a;font-size:0.7rem;">1h ago</span>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-comment"></i> Chat</h3>
                    </div>
                    <div class="card-body">
                        <div style="min-height:200px;display:flex;flex-direction:column;gap:0.5rem;margin-bottom:1rem;">
                            <div style="background:rgba(255,255,255,0.05);padding:0.8rem;border-radius:0.8rem;align-self:flex-start;max-width:80%;">
                                <span style="color:#f0d6b0;font-weight:600;">GrandMaster99</span>
                                <p style="color:#d4c0b0;font-size:0.9rem;">Great game! Want a rematch?</p>
                                <span style="color:#5a4a3a;font-size:0.7rem;">2 minutes ago</span>
                            </div>
                            <div style="background:rgba(139,26,26,0.2);padding:0.8rem;border-radius:0.8rem;align-self:flex-end;max-width:80%;">
                                <p style="color:#f0d6b0;font-size:0.9rem;">Sure! Same time control?</p>
                                <span style="color:#5a4a3a;font-size:0.7rem;">1 minute ago</span>
                            </div>
                        </div>
                        <div style="display:flex;gap:0.5rem;">
                            <input type="text" class="form-control" placeholder="Type a message..." style="flex:1;">
                            <button class="btn btn-primary"><i class="fas fa-paper-plane"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== LEADERBOARD TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'leaderboard' ? 'active' : ''; ?>" id="tab-leaderboard">
            <div class="page-header">
                <h1><i class="fas fa-list-ol"></i> Leaderboards</h1>
                <div class="header-actions">
                    <select class="form-control" style="padding:0.4rem 1rem;width:auto;background:rgba(255,255,255,0.05);border:1px solid var(--border-color);border-radius:0.5rem;color:#d4c0b0;">
                        <option>Global</option>
                        <option>Local</option>
                    </select>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-trophy"></i> Top Players</h3>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Player</th>
                                <th>Rating</th>
                                <th>Wins</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($leaderboard as $player): ?>
                                <tr>
                                    <td>
                                        <?php if ($player['rank'] <= 3): ?>
                                            <span style="color:var(--gold);font-weight:700;">#<?php echo $player['rank']; ?></span>
                                        <?php else: ?>
                                            #<?php echo $player['rank']; ?>
                                        <?php endif; ?>
                                    </td>
                                    <td><strong style="color:#f0d6b0;"><?php echo e($player['name']); ?></strong></td>
                                    <td><?php echo $player['rating']; ?></td>
                                    <td><?php echo $player['wins']; ?></td>
                                    <td>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-chess"></i> Challenge
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="stats-grid" style="margin-top:1.5rem;">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-chess-king"></i></div>
                    <div class="stat-value"><?php echo $rating; ?></div>
                    <div class="stat-label">Your Rating</div>
                    <span class="stat-change">Rank: #<?php echo rand(100, 500); ?></span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-arrow-up"></i></div>
                    <div class="stat-value">+12</div>
                    <div class="stat-label">Monthly Change</div>
                    <span class="stat-change positive">Improving</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-percent"></i></div>
                    <div class="stat-value"><?php echo $winPercentage; ?>%</div>
                    <div class="stat-label">Win Rate</div>
                    <span class="stat-change positive">Top 30%</span>
                </div>
            </div>
        </div>

        <!-- ====== ACHIEVEMENTS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'achievements' ? 'active' : ''; ?>" id="tab-achievements">
            <div class="page-header">
                <h1><i class="fas fa-medal"></i> Achievements</h1>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-medal"></i></div>
                    <div class="stat-value"><?php echo count(array_filter($achievements, function($a) { return $a['unlocked']; })); ?></div>
                    <div class="stat-label">Unlocked</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-lock"></i></div>
                    <div class="stat-value"><?php echo count(array_filter($achievements, function($a) { return !$a['unlocked']; })); ?></div>
                    <div class="stat-label">Locked</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-trophy"></i></div>
                    <div class="stat-value"><?php echo rand(0, 5); ?></div>
                    <div class="stat-label">Special Awards</div>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-medal"></i> All Achievements</h3>
                </div>
                <div class="card-body">
                    <div class="achievement-grid" style="grid-template-columns:repeat(auto-fill,minmax(200px,1fr));">
                        <?php foreach ($achievements as $ach): ?>
                            <div class="achievement-item">
                                <div class="ach-icon <?php echo $ach['unlocked'] ? 'unlocked' : 'locked'; ?>" style="font-size:3rem;">
                                    <i class="fas <?php echo $ach['icon']; ?>"></i>
                                </div>
                                <div class="ach-name"><?php echo e($ach['name']); ?></div>
                                <div class="ach-desc"><?php echo e($ach['description']); ?></div>
                                <div style="margin-top:0.3rem;">
                                    <span style="font-size:0.7rem;color:<?php echo $ach['unlocked'] ? 'var(--success)' : '#5a4a3a'; ?>;">
                                        <?php echo $ach['unlocked'] ? '<i class="fas fa-check"></i> Unlocked' : '<i class="fas fa-lock"></i> Locked'; ?>
                                    </span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== NOTIFICATIONS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'notifications' ? 'active' : ''; ?>" id="tab-notifications">
            <div class="page-header">
                <h1><i class="fas fa-bell"></i> Notifications</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-check-double"></i> Mark All Read</button>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <?php foreach ($notifications as $notif): ?>
                        <div class="notification-item <?php echo !$notif['read'] ? 'unread' : ''; ?>">
                            <div class="notif-icon">
                                <i class="fas <?php echo $notif['type'] === 'friend_request' ? 'fa-user-plus' : ($notif['type'] === 'game_invite' ? 'fa-chess' : 'fa-trophy'); ?>"></i>
                            </div>
                            <div class="notif-content">
                                <div class="notif-text">
                                    <strong><?php echo e($notif['from']); ?></strong> <?php echo e($notif['message']); ?>
                                </div>
                                <div class="notif-time">
                                    <i class="fas fa-clock"></i> <?php echo e($notif['time']); ?>
                                </div>
                            </div>
                            <?php if (!$notif['read']): ?>
                                <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                    <i class="fas fa-check"></i>
                                </button>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <!-- ====== BOOKMARKS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'bookmarks' ? 'active' : ''; ?>" id="tab-bookmarks">
            <div class="page-header">
                <h1><i class="fas fa-bookmark"></i> Bookmarks</h1>
            </div>

            <div class="card">
                <div class="card-body">
                    <?php if (!empty($bookmarks)): ?>
                        <?php foreach ($bookmarks as $bookmark): ?>
                            <div class="game-item">
                                <div class="game-info">
                                    <i class="fas fa-<?php echo $bookmark['type'] === 'lesson' ? 'graduation-cap' : 'puzzle-piece'; ?>" style="color:var(--secondary);"></i>
                                    <div>
                                        <strong style="color:#f0d6b0;"><?php echo e($bookmark['title']); ?></strong>
                                        <span style="color:#5a4a3a;font-size:0.8rem;display:block;">
                                            <?php echo ucfirst($bookmark['type']); ?>
                                        </span>
                                    </div>
                                </div>
                                <div>
                                    <a href="<?php echo e($bookmark['url']); ?>" class="btn btn-secondary" style="padding:0.2rem 0.8rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i> View
                                    </a>
                                    <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-times"></i>
                                    </button>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p style="color:#5a4a3a;text-align:center;padding:2rem 0;">
                            <i class="fas fa-info-circle"></i> No bookmarks yet. Start saving your favorites!
                        </p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- ====== COMMENTS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'comments' ? 'active' : ''; ?>" id="tab-comments">
            <div class="page-header">
                <h1><i class="fas fa-comment"></i> Comments & Reviews</h1>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-pen"></i> Write a Review</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Rating</label>
                            <div style="display:flex;gap:0.5rem;font-size:1.5rem;color:var(--gold);">
                                <i class="fas fa-star" onclick="setRating(1)"></i>
                                <i class="fas fa-star" onclick="setRating(2)"></i>
                                <i class="fas fa-star" onclick="setRating(3)"></i>
                                <i class="fas fa-star" onclick="setRating(4)"></i>
                                <i class="fas fa-star" onclick="setRating(5)"></i>
                                <span id="ratingDisplay" style="color:#5a4a3a;font-size:0.9rem;">Click to rate</span>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Review</label>
                            <textarea class="form-control" placeholder="Write your review here..." rows="4"></textarea>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-paper-plane"></i> Submit Review</button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> My Reviews</h3>
                    </div>
                    <div class="card-body">
                        <?php foreach ($recentComments as $comment): ?>
                            <div style="padding:0.8rem 0;border-bottom:1px solid rgba(255,255,255,0.05);">
                                <div style="display:flex;justify-content:space-between;">
                                    <strong style="color:#f0d6b0;"><?php echo e($comment['author']); ?></strong>
                                    <span style="color:var(--gold);">
                                        <?php echo str_repeat('★', $comment['rating']) . str_repeat('☆', 5 - $comment['rating']); ?>
                                    </span>
                                </div>
                                <p style="color:#d4c0b0;font-size:0.9rem;margin:0.3rem 0;"><?php echo e($comment['text']); ?></p>
                                <span style="color:#5a4a3a;font-size:0.75rem;"><?php echo e($comment['date']); ?></span>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== STATISTICS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'statistics' ? 'active' : ''; ?>" id="tab-statistics">
            <div class="page-header">
                <h1><i class="fas fa-chart-bar"></i> Statistics</h1>
            </div>

            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-gamepad"></i></div>
                    <div class="stat-value"><?php echo $gamesPlayed; ?></div>
                    <div class="stat-label">Total Games</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-trophy"></i></div>
                    <div class="stat-value"><?php echo $gamesWon; ?></div>
                    <div class="stat-label">Wins</div>
                    <span class="stat-change positive"><?php echo $winPercentage; ?>%</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-handshake"></i></div>
                    <div class="stat-value"><?php echo $gamesDrawn; ?></div>
                    <div class="stat-label">Draws</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-times"></i></div>
                    <div class="stat-value"><?php echo $gamesLost; ?></div>
                    <div class="stat-label">Losses</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-star"></i></div>
                    <div class="stat-value"><?php echo $rating; ?></div>
                    <div class="stat-label">Current Rating</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-fire"></i></div>
                    <div class="stat-value"><?php echo $_SESSION['current_streak'] ?? 0; ?></div>
                    <div class="stat-label">Current Streak</div>
                    <span class="stat-change positive">Best: <?php echo $_SESSION['best_streak'] ?? 0; ?></span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-clock"></i></div>
                    <div class="stat-value"><?php echo rand(10, 30); ?> min</div>
                    <div class="stat-label">Avg Game Duration</div>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-puzzle-piece"></i></div>
                    <div class="stat-value"><?php echo rand(20, 50); ?></div>
                    <div class="stat-label">Puzzles Solved</div>
                    <span class="stat-change positive">+<?php echo rand(1, 5); ?> this week</span>
                </div>
            </div>
        </div>

        <!-- ====== SETTINGS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'settings' ? 'active' : ''; ?>" id="tab-settings">
            <div class="page-header">
                <h1><i class="fas fa-cog"></i> Settings</h1>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-bell"></i> Notification Preferences</h3>
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <input type="hidden" name="update_notifications" value="1">
                            <div class="form-group">
                                <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                    <input type="checkbox" name="email_notifications" checked>
                                    Email Notifications
                                </label>
                            </div>
                            <div class="form-group">
                                <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                    <input type="checkbox" name="game_invites" checked>
                                    Game Invitations
                                </label>
                            </div>
                            <div class="form-group">
                                <label style="display:flex;align-items:center;gap:0.8rem;cursor:pointer;">
                                    <input type="checkbox" name="tournament_reminders" checked>
                                    Tournament Reminders
                                </label>
                            </div>
                            <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Save Preferences</button>
                        </form>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-palette"></i> Appearance</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Theme</label>
                            <select class="form-control">
                                <option>Dark Mode</option>
                                <option>Light Mode</option>
                                <option>System Default</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Language</label>
                            <select class="form-control">
                                <option>English</option>
                                <option>Spanish</option>
                                <option>French</option>
                                <option>German</option>
                            </select>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-save"></i> Save Preferences</button>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-shield-alt"></i> Security</h3>
                </div>
                <div class="card-body">
                    <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                        <div>
                            <div class="form-group">
                                <label>Two-Factor Authentication</label>
                                <button class="btn btn-secondary"><i class="fas fa-shield-alt"></i> Enable 2FA</button>
                            </div>
                            <div class="form-group">
                                <label>Session Management</label>
                                <button class="btn btn-secondary"><i class="fas fa-sign-out-alt"></i> Logout All Devices</button>
                            </div>
                        </div>
                        <div>
                            <div class="form-group">
                                <label>Account Deletion</label>
                                <button class="btn btn-danger"><i class="fas fa-trash"></i> Delete Account</button>
                                <div class="form-hint">This action cannot be undone. All data will be permanently removed.</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== HELP TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'help' ? 'active' : ''; ?>" id="tab-help">
            <div class="page-header">
                <h1><i class="fas fa-question-circle"></i> Help & Support</h1>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-question"></i> FAQs</h3>
                    </div>
                    <div class="card-body">
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I play chess on Chess Heaven?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">You can play as a guest or sign up for a free account. Go to the Play section and start playing against the computer or other players.</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">Is Chess Heaven free to use?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Yes! Chess Heaven is completely free for all users. We are a non-profit organization dedicated to promoting chess education.</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How can I improve my chess skills?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Use our Learning Center with lessons from beginner to advanced. Practice with puzzles, study openings, and analyze featured games.</p>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-headset"></i> Contact Support</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Subject</label>
                            <input type="text" class="form-control" placeholder="Brief description of your issue">
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea class="form-control" placeholder="Describe your issue in detail..." rows="4"></textarea>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Message</button>
                        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color);">
                            <p style="color:#5a4a3a;font-size:0.85rem;">
                                <i class="fas fa-envelope"></i> support@chessheaven.org
                            </p>
                            <p style="color:#5a4a3a;font-size:0.85rem;">
                                <i class="fas fa-clock"></i> Response time: 24-48 hours
                            </p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-bug"></i> Report a Problem</h3>
                </div>
                <div class="card-body">
                    <div class="form-group">
                        <label>Problem Type</label>
                        <select class="form-control">
                            <option>Technical Issue</option>
                            <option>Bug</option>
                            <option>Account Issue</option>
                            <option>Payment Issue</option>
                            <option>Other</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" placeholder="Describe the problem you're experiencing..." rows="3"></textarea>
                    </div>
                    <button class="btn btn-primary"><i class="fas fa-bug"></i> Report Issue</button>
                </div>
            </div>
        </div>
    </main>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== SIDEBAR TOGGLE (Mobile) =====
        const sidebarToggle = document.getElementById('sidebarToggle');
        const sidebar = document.getElementById('sidebar');
        const sidebarOverlay = document.getElementById('sidebarOverlay');

        if (sidebarToggle) {
            sidebarToggle.addEventListener('click', function() {
                sidebar.classList.toggle('open');
                sidebarOverlay.classList.toggle('active');
            });
        }

        if (sidebarOverlay) {
            sidebarOverlay.addEventListener('click', function() {
                sidebar.classList.remove('open');
                sidebarOverlay.classList.remove('active');
            });
        }

        // Close sidebar on window resize (if going from mobile to desktop)
        window.addEventListener('resize', function() {
            if (window.innerWidth > 768) {
                sidebar.classList.remove('open');
                sidebarOverlay.classList.remove('active');
            }
        });

        // ===== STAR RATING =====
        let selectedRating = 0;
        function setRating(rating) {
            selectedRating = rating;
            const stars = document.querySelectorAll('.fa-star');
            stars.forEach((star, index) => {
                if (index < rating) {
                    star.style.color = 'var(--gold)';
                } else {
                    star.style.color = '';
                }
            });
            document.getElementById('ratingDisplay').textContent = rating + ' ★';
        }

        // ===== ACTIVE NAVIGATION =====
        document.querySelectorAll('.sidebar-item').forEach(item => {
            item.addEventListener('click', function() {
                document.querySelectorAll('.sidebar-item').forEach(i => i.classList.remove('active'));
                this.classList.add('active');
                
                // Close mobile sidebar
                if (window.innerWidth <= 768) {
                    sidebar.classList.remove('open');
                    sidebarOverlay.classList.remove('active');
                }
            });
        });

        // ===== NAVBAR SCROLL EFFECT =====
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) {
                navbar.classList.add('scrolled');
            } else {
                navbar.classList.remove('scrolled');
            }
        });

        // ===== CHESS ENGINE =====
        // Chess piece symbols
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // Initial board setup
        const INITIAL_BOARD = [
            ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
            ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
            ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R']
        ];

        // State
        let board = JSON.parse(JSON.stringify(INITIAL_BOARD));
        let currentTurn = 'white';
        let selectedSquare = null;
        let moveHistory = [];
        let moveCount = 0;
        let isFlipped = false;
        let gameOver = false;
        let playMode = 'ai';
        let playerColor = 'white';
        let moveList = [];
        let isAIMoving = false;
        let gameOverseeId = null;

        // File ranks for notation
        const FILES = 'abcdefgh';

        // ===== BOARD RENDERING =====
        function renderBoard() {
            const boardEl = document.getElementById('chessBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isFlipped ? 7 - row : row;
                    const actualCol = isFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    square.dataset.row = actualRow;
                    square.dataset.col = actualCol;
                    
                    const piece = board[actualRow][actualCol];
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    // Highlight selected square
                    if (selectedSquare && selectedSquare.row === actualRow && selectedSquare.col === actualCol) {
                        square.classList.add('selected');
                    }
                    
                    // Show legal moves
                    if (selectedSquare) {
                        const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                        for (const move of legalMoves) {
                            if (move.row === actualRow && move.col === actualCol) {
                                if (board[actualRow][actualCol]) {
                                    square.classList.add('legal-capture');
                                } else {
                                    square.classList.add('legal-move');
                                }
                            }
                        }
                    }
                    
                    square.addEventListener('click', () => onSquareClick(actualRow, actualCol));
                    boardEl.appendChild(square);
                }
            }
            
            updateTurnIndicator();
        }

        // ===== TURN INDICATOR =====
        function updateTurnIndicator() {
            const indicator = document.getElementById('turn-indicator');
            if (!indicator) return;
            if (gameOver) {
                indicator.innerHTML = '<i class="fas fa-flag-checkered"></i> Game Over';
                return;
            }
            const colorName = currentTurn === 'white' ? 'White' : 'Black';
            const colorIcon = currentTurn === 'white' ? '#f0d9b5' : '#1a1a1a';
            indicator.innerHTML = `<i class="fas fa-circle" style="color:${colorIcon};"></i> ${colorName}'s Turn`;
        }

        // ===== MOVE GENERATION =====
        function getLegalMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const direction = isWhite ? -1 : 1;
                    if (row + direction >= 0 && row + direction < 8 && !board[row + direction][col]) {
                        moves.push({row: row + direction, col: col});
                        const startRow = isWhite ? 6 : 1;
                        if (row === startRow && !board[row + 2 * direction][col]) {
                            moves.push({row: row + 2 * direction, col: col});
                        }
                    }
                    for (const dcol of [-1, 1]) {
                        const newCol = col + dcol;
                        if (newCol >= 0 && newCol < 8 && row + direction >= 0 && row + direction < 8) {
                            const target = board[row + direction][newCol];
                            if (target && (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: row + direction, col: newCol});
                            }
                        }
                    }
                    break;
                case 'n':
                    const knightMoves = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
                    for (const [dr, dc] of knightMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
                case 'b':
                case 'r':
                case 'q':
                    const directions = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                                      piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                                      [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of directions) {
                        for (let i = 1; i < 8; i++) {
                            const newRow = row + dr * i, newCol = col + dc * i;
                            if (newRow < 0 || newRow >= 8 || newCol < 0 || newCol >= 8) break;
                            const target = board[newRow][newCol];
                            if (target) {
                                if (isWhite ? target === target.toLowerCase() : target === target.toUpperCase()) {
                                    moves.push({row: newRow, col: newCol});
                                }
                                break;
                            }
                            moves.push({row: newRow, col: newCol});
                        }
                    }
                    break;
                case 'k':
                    const kingMoves = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of kingMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
            }
            
            return moves.filter(move => !wouldBeInCheck(row, col, move.row, move.col));
        }

        function wouldBeInCheck(fromRow, fromCol, toRow, toCol) {
            const piece = board[fromRow][fromCol];
            const isWhite = piece === piece.toUpperCase();
            
            const captured = board[toRow][toCol];
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            let kingRow, kingCol;
            const kingPiece = isWhite ? 'K' : 'k';
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    if (board[r][c] === kingPiece) {
                        kingRow = r; kingCol = c;
                        break;
                    }
                }
                if (kingRow !== undefined) break;
            }
            
            let inCheck = false;
            if (kingRow !== undefined) {
                const opponent = isWhite ? 'black' : 'white';
                for (let r = 0; r < 8; r++) {
                    for (let c = 0; c < 8; c++) {
                        const p = board[r][c];
                        if (p && (opponent === 'white' ? p === p.toUpperCase() : p === p.toLowerCase())) {
                            const attacks = getRawMoves(r, c);
                            for (const attack of attacks) {
                                if (attack.row === kingRow && attack.col === kingCol) {
                                    inCheck = true;
                                    break;
                                }
                            }
                        }
                        if (inCheck) break;
                    }
                    if (inCheck) break;
                }
            }
            
            board[fromRow][fromCol] = piece;
            board[toRow][toCol] = captured;
            
            return inCheck;
        }

        function getRawMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const dir = isWhite ? -1 : 1;
                    if (row + dir >= 0 && row + dir < 8 && !board[row + dir][col]) {
                        moves.push({row: row + dir, col: col});
                    }
                    for (const dc of [-1, 1]) {
                        const nc = col + dc;
                        if (nc >= 0 && nc < 8 && row + dir >= 0 && row + dir < 8) {
                            if (board[row + dir][nc]) moves.push({row: row + dir, col: nc});
                        }
                    }
                    break;
                case 'n':
                    const nm = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
                    for (const [dr, dc] of nm) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
                case 'b':
                case 'r':
                case 'q':
                    const dirs = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                               piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                               [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of dirs) {
                        for (let i = 1; i < 8; i++) {
                            const nr = row + dr * i, nc = col + dc * i;
                            if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
                            moves.push({row: nr, col: nc});
                            if (board[nr][nc]) break;
                        }
                    }
                    break;
                case 'k':
                    const km = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of km) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
            }
            return moves;
        }

        // ===== GAME LOGIC =====
        function onSquareClick(row, col) {
            if (gameOver || isAIMoving) return;
            
            const piece = board[row][col];
            const isWhiteTurn = currentTurn === 'white';
            const isWhitePiece = piece && piece === piece.toUpperCase();
            
            if (selectedSquare) {
                const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                const isLegal = legalMoves.some(m => m.row === row && m.col === col);
                
                if (isLegal) {
                    makeMove(selectedSquare.row, selectedSquare.col, row, col);
                    selectedSquare = null;
                    renderBoard();
                    return;
                }
                
                if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                    selectedSquare = {row, col};
                    renderBoard();
                    return;
                }
                
                selectedSquare = null;
                renderBoard();
                return;
            }
            
            if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                selectedSquare = {row, col};
                renderBoard();
            }
        }

        function makeMove(fromRow, fromCol, toRow, toCol) {
            const piece = board[fromRow][fromCol];
            const captured = board[toRow][toCol];
            
            moveHistory.push({
                fromRow, fromCol, toRow, toCol,
                piece, captured,
                previousBoard: JSON.parse(JSON.stringify(board))
            });
            
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            if (piece.toLowerCase() === 'p' && (toRow === 0 || toRow === 7)) {
                board[toRow][toCol] = piece === 'P' ? 'Q' : 'q';
            }
            
            moveCount++;
            moveList.push(`${FILES[fromCol]}${8 - fromRow}${FILES[toCol]}${8 - toRow}`);
            
            const moveCountEl = document.getElementById('move-count');
            if (moveCountEl) moveCountEl.textContent = `Moves: ${moveCount}`;
            
            currentTurn = currentTurn === 'white' ? 'black' : 'white';
            
            checkGameOver();
            
            if (playMode === 'ai' && !gameOver && currentTurn !== playerColor) {
                setTimeout(() => playAIMove(), 300);
            }
        }

        function checkGameOver() {
            const hasLegalMoves = hasAnyLegalMoves(currentTurn);
            const statusEl = document.getElementById('game-status');
            
            if (!hasLegalMoves) {
                gameOver = true;
                const isWhite = currentTurn === 'white';
                const winner = isWhite ? 'Black' : 'White';
                if (statusEl) {
                    statusEl.textContent = `🏆 ${winner} wins! (Checkmate)`;
                    statusEl.style.color = 'var(--success)';
                }
                updateTurnIndicator();
                return;
            }
            
            if (!hasLegalMoves) {
                gameOver = true;
                if (statusEl) {
                    statusEl.textContent = '🤝 Stalemate!';
                    statusEl.style.color = 'var(--warning)';
                }
                updateTurnIndicator();
            }
        }

        function hasAnyLegalMoves(color) {
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((color === 'white' && isWhite) || (color === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            if (moves.length > 0) return true;
                        }
                    }
                }
            }
            return false;
        }

        // ===== AI =====
        function playAIMove() {
            if (isAIMoving || gameOver || playMode !== 'ai') return;
            isAIMoving = true;
            
            const aiColor = playerColor === 'white' ? 'black' : 'white';
            if (currentTurn !== aiColor) {
                isAIMoving = false;
                return;
            }
            
            const allMoves = [];
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((aiColor === 'white' && isWhite) || (aiColor === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            for (const move of moves) {
                                allMoves.push({fromRow: r, fromCol: c, toRow: move.row, toCol: move.col});
                            }
                        }
                    }
                }
            }
            
            if (allMoves.length === 0) {
                isAIMoving = false;
                checkGameOver();
                return;
            }
            
            const difficulty = document.getElementById('aiDifficulty')?.value || 'medium';
            
            const scoredMoves = allMoves.map(move => {
                let score = 0;
                const target = board[move.toRow][move.toCol];
                if (target) {
                    const pieceValues = {'p': 1, 'n': 3, 'b': 3, 'r': 5, 'q': 9, 'k': 100};
                    const val = pieceValues[target.toLowerCase()] || 0;
                    score += val * 10;
                }
                const centerDist = Math.abs(move.toRow - 3.5) + Math.abs(move.toCol - 3.5);
                score += (7 - centerDist) * 2;
                if (difficulty === 'easy') score += Math.random() * 10;
                if (difficulty === 'medium') score += Math.random() * 5;
                if (difficulty === 'hard') score += Math.random() * 2;
                return {move, score};
            });
            
            scoredMoves.sort((a, b) => b.score - a.score);
            
            let selectedMove;
            if (difficulty === 'easy') {
                const topN = Math.min(5, Math.floor(scoredMoves.length * 0.3) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else if (difficulty === 'medium') {
                const topN = Math.min(3, Math.floor(scoredMoves.length * 0.15) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else {
                selectedMove = scoredMoves[0].move;
            }
            
            makeMove(selectedMove.fromRow, selectedMove.fromCol, selectedMove.toRow, selectedMove.toCol);
            renderBoard();
            isAIMoving = false;
        }

        // ===== GAME CONTROLS =====
        function startNewGame() {
            board = JSON.parse(JSON.stringify(INITIAL_BOARD));
            currentTurn = 'white';
            moveHistory = [];
            moveCount = 0;
            gameOver = false;
            selectedSquare = null;
            moveList = [];
            isAIMoving = false;
            
            const colorSelect = document.getElementById('playerColor');
            if (colorSelect) {
                const val = colorSelect.value;
                if (val === 'random') {
                    playerColor = Math.random() < 0.5 ? 'white' : 'black';
                } else {
                    playerColor = val;
                }
            }
            
            if (playMode === 'ai' && playerColor === 'black') {
                setTimeout(() => playAIMove(), 500);
            }
            
            const statusEl = document.getElementById('game-status');
            if (statusEl) {
                statusEl.textContent = 'Game in progress';
                statusEl.style.color = 'var(--gold)';
            }
            const moveCountEl = document.getElementById('move-count');
            if (moveCountEl) moveCountEl.textContent = 'Moves: 0';
            
            renderBoard();
        }

        function resetBoard() {
            startNewGame();
        }

        function flipBoard() {
            isFlipped = !isFlipped;
            renderBoard();
        }

        function undoMove() {
            if (moveHistory.length === 0 || isAIMoving) return;
            const lastMove = moveHistory.pop();
            board = lastMove.previousBoard;
            currentTurn = currentTurn === 'white' ? 'black' : 'white';
            moveCount--;
            selectedSquare = null;
            gameOver = false;
            const statusEl = document.getElementById('game-status');
            if (statusEl) {
                statusEl.textContent = 'Game in progress';
                statusEl.style.color = 'var(--gold)';
            }
            renderBoard();
        }

        function changePlayMode() {
            const mode = document.getElementById('playMode')?.value || 'ai';
            playMode = mode;
            document.getElementById('ai-section').style.display = mode === 'ai' ? 'block' : 'none';
            document.getElementById('online-opponent-section').style.display = mode === 'online' ? 'block' : 'none';
            startNewGame();
        }

        function requestOnlineGame() {
            const opponentId = document.getElementById('opponentSelect')?.value;
            const timeControl = document.getElementById('timeControl')?.value;
            if (!opponentId) {
                alert('Please select an opponent.');
                return;
            }
            const form = document.createElement('form');
            form.method = 'POST';
            const fields = {
                'request_game': '1',
                'opponent_id': opponentId,
                'time_control': timeControl,
                'color': 'random'
            };
            for (const [key, value] of Object.entries(fields)) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = value;
                form.appendChild(input);
            }
            document.body.appendChild(form);
            form.submit();
        }

        // ===== OVERSIGHT =====
        function loadOversightGame(gameId) {
            gameOverseeId = gameId;
            const container = document.getElementById('overseeBoardContainer');
            const idDisplay = document.getElementById('oversee-game-id');
            if (idDisplay) idDisplay.textContent = `Game #${gameId}`;
            
            container.innerHTML = `
                <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                    <div style="flex:1;min-width:200px;">
                        <div class="game-status-bar">
                            <span class="player"><i class="fas fa-circle" style="color:#f0d9b5;"></i> White</span>
                            <span class="move-info">Move 12</span>
                        </div>
                        <div style="display:grid;grid-template-columns:repeat(8,1fr);max-width:300px;aspect-ratio:1;border:2px solid var(--secondary);border-radius:4px;margin:0 auto;">
                            ${Array.from({length:64}, (_, i) => {
                                const row = Math.floor(i/8), col = i%8;
                                const isLight = (row+col)%2===0;
                                const piece = (row+col)%3===0 ? (Math.random()>0.5 ? '♙' : '♟') : '';
                                return `<div class="square ${isLight?'light':'dark'}" style="display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:${isLight?'#1a1a1a':'#f0d9b5'};">${piece}</div>`;
                            }).join('')}
                        </div>
                    </div>
                    <div style="flex:1;min-width:150px;">
                        <div style="background:rgba(255,255,255,0.03);padding:0.8rem;border-radius:0.5rem;margin-bottom:0.5rem;">
                            <div style="display:flex;justify-content:space-between;font-size:0.85rem;">
                                <span>⏱️ White</span>
                                <span style="color:var(--gold);">12:34</span>
                            </div>
                            <div style="display:flex;justify-content:space-between;font-size:0.85rem;margin-top:0.2rem;">
                                <span>⏱️ Black</span>
                                <span style="color:var(--gold);">15:21</span>
                            </div>
                        </div>
                        <div style="max-height:200px;overflow-y:auto;font-size:0.8rem;color:#7a6a5a;">
                            ${Array.from({length:12}, (_, i) => 
                                `<div style="padding:0.2rem 0;border-bottom:1px solid rgba(255,255,255,0.03);">
                                    ${i+1}. ${String.fromCharCode(97 + (i%8))}${8 - (i%8)} ${String.fromCharCode(97 + ((i+3)%8))}${8 - ((i+5)%8)}
                                </div>`
                            ).join('')}
                        </div>
                    </div>
                </div>
                <div style="margin-top:0.8rem;padding-top:0.8rem;border-top:1px solid var(--border-color);display:flex;gap:0.5rem;flex-wrap:wrap;">
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-play"></i> Play
                    </button>
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-pause"></i> Pause
                    </button>
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-step-forward"></i> Forward
                    </button>
                    <span style="color:#5a4a3a;font-size:0.75rem;display:flex;align-items:center;margin-left:auto;">
                        <i class="fas fa-eye" style="color:var(--gold);margin-right:0.3rem;"></i> Overseeing in real-time
                    </span>
                </div>
            `;
        }

        // ===== INITIALIZATION =====
        document.addEventListener('DOMContentLoaded', function() {
            renderBoard();
            
            const overseeMessage = document.querySelector('#tab-oversee .message');
            if (overseeMessage && overseeMessage.textContent.includes('overseeing game')) {
                const gameId = parseInt(overseeMessage.textContent.match(/#(\d+)/)?.[1] || 101);
                loadOversightGame(gameId);
            }
            
            if (document.getElementById('tab-play')?.classList.contains('active')) {
                const hasPieces = board.some(row => row.some(cell => cell !== ''));
                if (hasPieces) {
                    if (playMode === 'ai' && playerColor === 'black' && currentTurn === 'black') {
                        setTimeout(() => playAIMove(), 500);
                    }
                }
            }
        });

        // Override for oversight form submission
        document.querySelectorAll('form input[name="oversee_game"]').forEach(input => {
            const form = input.closest('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const gameId = parseInt(this.querySelector('input[name="game_id"]')?.value || 101);
                    loadOversightGame(gameId);
                    if (window.history && window.history.pushState) {
                        window.history.pushState({}, '', '?tab=oversee&game=' + gameId);
                    }
                });
            }
        });
    </script>
</body>
</html>