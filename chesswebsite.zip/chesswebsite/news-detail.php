<?php
/**
 * Chess Heaven - News Detail Page
 * Displays full news articles with comments, related content, and sharing features
 */

require_once 'config.php';

// Get news ID from URL
$newsId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get news details
$newsDetails = getNewsDetails($newsId);
$relatedNews = getRelatedNews($newsId, 4);
$newsComments = getNewsComments($newsId, 10);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · <?php echo e($newsDetails ? $newsDetails['title'] : 'News'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }
        .card .badge {
            position:absolute;
            top:1rem;
            right:1rem;
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .badge-tournament { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .badge-achievement { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .badge-interview { background:rgba(52,152,219,0.2); color:#3498db; }
        .badge-analysis { background:rgba(155,89,182,0.2); color:#9b59b6; }
        .badge-breaking { background:rgba(231,76,60,0.2); color:#e74c3c; }
        .badge-update { background:rgba(198,151,107,0.2); color:#C6976B; }

        /* ===== ARTICLE ===== */
        .article-container {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:2rem;
        }
        .article-main {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
        }
        .article-header {
            margin-bottom:2rem;
        }
        .article-header .article-category {
            display:inline-block;
            padding:0.3rem 1rem;
            border-radius:2rem;
            font-size:0.75rem;
            font-weight:600;
            margin-bottom:0.8rem;
        }
        .article-header h1 {
            font-size:2.2rem;
            color:#f0d6b0;
            line-height:1.3;
        }
        .article-header .article-meta {
            display:flex;
            gap:1.5rem;
            flex-wrap:wrap;
            margin-top:1rem;
            color:#7a6a5a;
            font-size:0.85rem;
        }
        .article-header .article-meta span {
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .article-header .article-meta .author-name {
            color:#f0d6b0;
            font-weight:600;
        }
        .article-body {
            color:#c0b0a0;
            line-height:1.9;
            font-size:1.05rem;
        }
        .article-body p {
            margin-bottom:1.2rem;
        }
        .article-body .featured-image {
            text-align:center;
            padding:2rem;
            background:rgba(0,0,0,0.2);
            border-radius:1rem;
            margin:1.5rem 0;
        }
        .article-body .featured-image i {
            font-size:5rem;
            color:var(--secondary);
            opacity:0.3;
        }
        .article-body .featured-image figcaption {
            color:#7a6a5a;
            font-size:0.85rem;
            margin-top:0.5rem;
        }
        .article-body h2 {
            color:#f0d6b0;
            font-size:1.5rem;
            margin:1.5rem 0 0.8rem;
        }
        .article-body h3 {
            color:#f0d6b0;
            font-size:1.2rem;
            margin:1.2rem 0 0.5rem;
        }
        .article-body ul, .article-body ol {
            margin:0.8rem 0 1rem 1.5rem;
            color:#c0b0a0;
        }
        .article-body li {
            margin-bottom:0.4rem;
        }
        .article-body .highlight-box {
            background:rgba(139,26,26,0.15);
            border-left:4px solid var(--secondary);
            padding:1rem 1.5rem;
            border-radius:0.5rem;
            margin:1.2rem 0;
        }
        .article-body .highlight-box strong {
            color:var(--gold);
        }
        .article-body .quote-block {
            font-style:italic;
            padding:1rem 2rem;
            border-left:4px solid var(--gold);
            margin:1.2rem 0;
            color:#d4c0b0;
            font-size:1.1rem;
        }
        .article-body .quote-block .quote-author {
            display:block;
            text-align:right;
            color:#7a6a5a;
            font-size:0.9rem;
            margin-top:0.3rem;
            font-style:normal;
        }

        /* ===== SHARE ===== */
        .share-section {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            align-items:center;
            padding:1.5rem 0;
            border-top:1px solid var(--border-color);
            margin-top:2rem;
        }
        .share-section .share-label {
            color:#7a6a5a;
            font-size:0.85rem;
        }
        .share-section .share-btn {
            padding:0.4rem 1rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
            font-size:0.8rem;
        }
        .share-btn.twitter { background:#1DA1F2; color:white; }
        .share-btn.facebook { background:#4267B2; color:white; }
        .share-btn.linkedin { background:#0077B5; color:white; }
        .share-btn.whatsapp { background:#25D366; color:white; }
        .share-btn.email { background:rgba(255,255,255,0.1); color:#a09080; border:1px solid var(--border-color); }
        .share-btn:hover { transform:translateY(-2px); opacity:0.9; }

        /* ===== TAGS ===== */
        .article-tags {
            display:flex;
            gap:0.5rem;
            flex-wrap:wrap;
            margin-top:1rem;
        }
        .article-tags .tag {
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            color:#a09080;
            font-size:0.75rem;
            transition:0.3s;
        }
        .article-tags .tag:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }

        /* ===== COMMENTS ===== */
        .comments-section {
            margin-top:2rem;
            padding-top:2rem;
            border-top:1px solid var(--border-color);
        }
        .comments-section h3 {
            color:#f0d6b0;
            font-size:1.2rem;
            margin-bottom:1rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .comments-section h3 i { color:var(--secondary); }
        .comment-item {
            padding:1rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
        }
        .comment-item:last-child { border-bottom:none; }
        .comment-item .comment-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:0.3rem;
        }
        .comment-item .comment-author {
            color:#f0d6b0;
            font-weight:600;
        }
        .comment-item .comment-date {
            color:#7a6a5a;
            font-size:0.75rem;
        }
        .comment-item .comment-text {
            color:#a09080;
            font-size:0.9rem;
            line-height:1.6;
        }
        .comment-item .comment-actions {
            display:flex;
            gap:0.8rem;
            margin-top:0.3rem;
        }
        .comment-item .comment-actions button {
            background:transparent;
            border:none;
            color:#7a6a5a;
            font-size:0.75rem;
            cursor:pointer;
            transition:0.3s;
        }
        .comment-item .comment-actions button:hover {
            color:var(--secondary);
        }
        .comment-form {
            margin-top:1.5rem;
        }
        .comment-form textarea {
            width:100%;
            padding:0.8rem 1rem;
            border-radius:1rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-size:0.9rem;
            resize:vertical;
            min-height:100px;
        }
        .comment-form textarea:focus {
            outline:none;
            border-color:var(--secondary);
        }
        .comment-form .form-row {
            display:flex;
            gap:1rem;
            margin-top:0.8rem;
            flex-wrap:wrap;
        }
        .comment-form .form-row input {
            flex:1;
            padding:0.6rem 1rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
        }
        .comment-form .form-row input:focus {
            outline:none;
            border-color:var(--secondary);
        }
        .comment-form .submit-btn {
            padding:0.6rem 2rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            margin-top:0.8rem;
        }
        .comment-form .submit-btn:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .sidebar-widget {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
        }
        .sidebar-widget h3 {
            color:#f0d6b0;
            font-size:1.1rem;
            margin-bottom:1rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .sidebar-widget h3 i { color:var(--secondary); }
        .sidebar-widget .widget-item {
            padding:0.6rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            transition:0.3s;
        }
        .sidebar-widget .widget-item:last-child { border-bottom:none; }
        .sidebar-widget .widget-item:hover { color:var(--secondary); }
        .sidebar-widget .widget-item .widget-title {
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .sidebar-widget .widget-item .widget-meta {
            color:#7a6a5a;
            font-size:0.75rem;
            margin-top:0.2rem;
        }
        .sidebar-widget .widget-item .widget-badge {
            display:inline-block;
            padding:0.1rem 0.5rem;
            border-radius:2rem;
            font-size:0.65rem;
            font-weight:600;
            margin-top:0.2rem;
        }

        /* ===== BACK TO NEWS ===== */
        .back-link {
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
            color:var(--secondary);
            font-weight:500;
            transition:0.3s;
            margin-bottom:1.5rem;
        }
        .back-link:hover {
            color:#f0d6b0;
            transform:translateX(-5px);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .article-container {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .article-main { padding:1.5rem; }
            .article-header h1 { font-size:1.5rem; }
            .article-body { font-size:0.95rem; }
            .share-section { flex-direction:column; align-items:stretch; }
            .share-section .share-btn { justify-content:center; }
            .comment-form .form-row { flex-direction:column; }
            .card-grid { grid-template-columns:1fr; }
        }
        @media (max-width:480px) {
            .article-header h1 { font-size:1.3rem; }
            .article-header .article-meta { font-size:0.75rem; gap:0.8rem; }
            .article-body .featured-image i { font-size:3rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php" class="active-link"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== ARTICLE ===== -->
    <section class="section">
        <a href="news.php" class="back-link">
            <i class="fas fa-arrow-left"></i> Back to News
        </a>

        <?php if ($newsDetails): ?>
            <div class="article-container">
                <!-- Main Article -->
                <div class="article-main">
                    <div class="article-header">
                        <span class="article-category badge badge-<?php echo e($newsDetails['badge'] ?? 'update'); ?>">
                            <?php echo e(ucfirst($newsDetails['category'] ?? 'Update')); ?>
                        </span>
                        <h1><?php echo e($newsDetails['title']); ?></h1>
                        <div class="article-meta">
                            <span><i class="fas fa-user"></i> By <span class="author-name"><?php echo e($newsDetails['author']); ?></span></span>
                            <span><i class="fas fa-calendar"></i> <?php echo e($newsDetails['date_formatted']); ?></span>
                            <span><i class="fas fa-clock"></i> <?php echo e($newsDetails['read_time'] ?? '5 min read'); ?></span>
                            <span><i class="fas fa-comment"></i> <?php echo e(count($newsComments)); ?> comments</span>
                            <span><i class="fas fa-eye"></i> <?php echo e(number_format($newsDetails['views'] ?? 0)); ?> views</span>
                        </div>
                    </div>

                    <div class="article-body">
                        <?php if (!empty($newsDetails['featured_image'])): ?>
                            <div class="featured-image">
                                <i class="fas fa-<?php echo e($newsDetails['image_icon'] ?? 'newspaper'); ?>"></i>
                                <figcaption><?php echo e($newsDetails['image_caption'] ?? 'Featured Image'); ?></figcaption>
                            </div>
                        <?php endif; ?>

                        <?php if (!empty($newsDetails['content'])): ?>
                            <?php echo $newsDetails['content']; ?>
                        <?php else: ?>
                            <p>The World Chess Championship match has been officially announced. Magnus Carlsen will defend his title against Ian Nepomniachtchi in a 14-game match starting November 2025. This highly anticipated event will take place in Dubai, UAE, with a record prize fund of $2.5 million.</p>

                            <div class="highlight-box">
                                <strong>📌 Key Details:</strong><br>
                                • <strong>Date:</strong> November 25 - December 15, 2025<br>
                                • <strong>Location:</strong> Dubai, UAE<br>
                                • <strong>Prize Fund:</strong> $2.5 million<br>
                                • <strong>Format:</strong> 14-game match, first to 7.5 points
                            </div>

                            <p>The match will follow the traditional 14-game format, with players having 120 minutes for the first 40 moves, followed by 60 minutes for the next 20 moves, and then 15 minutes for the rest of the game with a 30-second increment from move 61.</p>

                            <div class="quote-block">
                                "I'm excited to defend my title in Dubai. Ian is a formidable opponent, and I'm preparing thoroughly for this challenge."
                                <span class="quote-author">— Magnus Carlsen, World Champion</span>
                            </div>

                            <p>Carlsen, who has dominated the chess world for over a decade, will be looking to extend his reign. Nepomniachtchi, who earned his spot by winning the Candidates Tournament, has been in exceptional form and is eager to claim the title.</p>

                            <h2>What to Expect</h2>
                            <p>The match is expected to feature high-quality chess with both players known for their aggressive playing styles. Carlsen's universal approach and endgame mastery will be tested against Nepomniachtchi's tactical prowess and deep opening preparation.</p>

                            <h3>Opening Choices</h3>
                            <p>Both players are known for their extensive opening repertoires. Carlsen often plays flexible openings like the Ruy Lopez and the Sicilian Defense, while Nepomniachtchi is famous for his fearless choices, including the Najdorf Sicilian and the Grünfeld Defense.</p>

                            <ul>
                                <li><strong>Carlsen's likely openings:</strong> Ruy Lopez, Sicilian Defense, Queen's Gambit</li>
                                <li><strong>Nepomniachtchi's likely openings:</strong> Najdorf Sicilian, Grünfeld Defense, Nimzo-Indian</li>
                                <li><strong>Expected style:</strong> Sharp, tactical, and double-edged</li>
                            </ul>

                            <div class="highlight-box">
                                <strong>💡 Did You Know?</strong><br>
                                This will be the first World Chess Championship held in the Middle East, highlighting chess's growing global popularity.
                            </div>

                            <h2>How to Follow</h2>
                            <p>Chess Heaven will provide comprehensive coverage of the match, including:</p>
                            <ul>
                                <li>Live game commentary with expert analysis</li>
                                <li>Post-game press conferences and interviews</li>
                                <li>Video highlights and game recaps</li>
                                <li>Interactive position analysis</li>
                            </ul>
                        <?php endif; ?>
                    </div>

                    <!-- Tags -->
                    <div class="article-tags">
                        <?php if (!empty($newsDetails['tags'])): ?>
                            <?php foreach ($newsDetails['tags'] as $tag): ?>
                                <a href="topic.php?tag=<?php echo e($tag); ?>" class="tag">#<?php echo e($tag); ?></a>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <a href="topic.php?tag=worldchampionship" class="tag">#WorldChampionship</a>
                            <a href="topic.php?tag=carlsen" class="tag">#Carlsen</a>
                            <a href="topic.php?tag=nepomniachtchi" class="tag">#Nepomniachtchi</a>
                            <a href="topic.php?tag=chess" class="tag">#Chess</a>
                            <a href="topic.php?tag=dubai" class="tag">#Dubai</a>
                        <?php endif; ?>
                    </div>

                    <!-- Share -->
                    <div class="share-section">
                        <span class="share-label"><i class="fas fa-share-alt"></i> Share this article:</span>
                        <button class="share-btn twitter" onclick="shareArticle('twitter')">
                            <i class="fab fa-twitter"></i> Twitter
                        </button>
                        <button class="share-btn facebook" onclick="shareArticle('facebook')">
                            <i class="fab fa-facebook"></i> Facebook
                        </button>
                        <button class="share-btn linkedin" onclick="shareArticle('linkedin')">
                            <i class="fab fa-linkedin"></i> LinkedIn
                        </button>
                        <button class="share-btn whatsapp" onclick="shareArticle('whatsapp')">
                            <i class="fab fa-whatsapp"></i> WhatsApp
                        </button>
                        <button class="share-btn email" onclick="shareArticle('email')">
                            <i class="fas fa-envelope"></i> Email
                        </button>
                    </div>

                    <!-- Comments -->
                    <div class="comments-section">
                        <h3><i class="fas fa-comments"></i> Comments (<?php echo e(count($newsComments)); ?>)</h3>
                        
                        <?php if (!empty($newsComments)): ?>
                            <?php foreach ($newsComments as $comment): ?>
                                <div class="comment-item">
                                    <div class="comment-header">
                                        <span class="comment-author"><?php echo e($comment['author']); ?></span>
                                        <span class="comment-date"><?php echo e($comment['date_formatted']); ?></span>
                                    </div>
                                    <div class="comment-text"><?php echo e($comment['text']); ?></div>
                                    <div class="comment-actions">
                                        <button onclick="likeComment(<?php echo e($comment['id']); ?>)">
                                            <i class="fas fa-thumbs-up"></i> <span id="like-count-<?php echo e($comment['id']); ?>"><?php echo e($comment['likes'] ?? 0); ?></span>
                                        </button>
                                        <button onclick="replyToComment(<?php echo e($comment['id']); ?>)">
                                            <i class="fas fa-reply"></i> Reply
                                        </button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="color:#7a6a5a;text-align:center;padding:1rem;">No comments yet. Be the first to comment!</div>
                        <?php endif; ?>

                        <!-- Comment Form -->
                        <div class="comment-form">
                            <h4 style="color:#f0d6b0;margin-bottom:0.5rem;">Leave a Comment</h4>
                            <textarea placeholder="Share your thoughts on this article..." id="commentText"></textarea>
                            <div class="form-row">
                                <input type="text" placeholder="Your name" id="commentName">
                                <input type="email" placeholder="Your email" id="commentEmail">
                            </div>
                            <button class="submit-btn" onclick="submitComment()">
                                <i class="fas fa-paper-plane"></i> Post Comment
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="sidebar">
                    <!-- Related News -->
                    <div class="sidebar-widget">
                        <h3><i class="fas fa-connectdevelop"></i> Related News</h3>
                        <?php if (!empty($relatedNews)): ?>
                            <?php foreach ($relatedNews as $news): ?>
                                <div class="widget-item">
                                    <a href="news-detail.php?id=<?php echo e($news['id']); ?>" class="widget-title"><?php echo e($news['title']); ?></a>
                                    <div class="widget-meta">
                                        <span><?php echo e($news['date_formatted']); ?></span>
                                        <span class="widget-badge badge badge-<?php echo e($news['badge'] ?? 'update'); ?>" style="position:static;display:inline-block;padding:0.1rem 0.5rem;font-size:0.6rem;">
                                            <?php echo e(ucfirst($news['category'] ?? 'Update')); ?>
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="widget-item">
                                <a href="news-detail.php?id=1" class="widget-title">Grand Chess Tour 2026 Announced</a>
                                <div class="widget-meta"><span>Dec 20, 2025</span></div>
                            </div>
                            <div class="widget-item">
                                <a href="news-detail.php?id=2" class="widget-title">New Grandmaster Title Earned</a>
                                <div class="widget-meta"><span>Dec 18, 2025</span></div>
                            </div>
                            <div class="widget-item">
                                <a href="news-detail.php?id=3" class="widget-title">Exclusive: Interview with Magnus Carlsen</a>
                                <div class="widget-meta"><span>Dec 15, 2025</span></div>
                            </div>
                            <div class="widget-item">
                                <a href="news-detail.php?id=4" class="widget-title">Game Analysis: Carlsen vs Caruana</a>
                                <div class="widget-meta"><span>Dec 12, 2025</span></div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Author Info -->
                    <div class="sidebar-widget">
                        <h3><i class="fas fa-user-circle"></i> About the Author</h3>
                        <div style="text-align:center;padding:0.5rem 0;">
                            <div style="font-size:3rem;color:var(--secondary);margin-bottom:0.5rem;">
                                <i class="fas fa-user"></i>
                            </div>
                            <h4 style="color:#f0d6b0;"><?php echo e($newsDetails['author'] ?? 'Chess Heaven Staff'); ?></h4>
                            <p style="color:#a09080;font-size:0.85rem;line-height:1.6;">
                                <?php echo e($newsDetails['author_bio'] ?? 'Chess journalist and analyst with over 10 years of experience covering major tournaments.'); ?>
                            </p>
                            <div style="display:flex;gap:0.8rem;justify-content:center;margin-top:0.5rem;">
                                <a href="#" style="color:var(--secondary);"><i class="fab fa-twitter"></i></a>
                                <a href="#" style="color:var(--secondary);"><i class="fab fa-linkedin"></i></a>
                                <a href="#" style="color:var(--secondary);"><i class="fas fa-envelope"></i></a>
                            </div>
                        </div>
                    </div>

                    <!-- Popular Tags -->
                    <div class="sidebar-widget">
                        <h3><i class="fas fa-tags"></i> Popular Tags</h3>
                        <div style="display:flex;flex-wrap:wrap;gap:0.4rem;">
                            <a href="topic.php?tag=worldchampionship" class="tag" style="padding:0.3rem 0.8rem;border-radius:2rem;border:1px solid var(--border-color);color:#a09080;font-size:0.75rem;">#WorldChampionship</a>
                            <a href="topic.php?tag=carlsen" class="tag" style="padding:0.3rem 0.8rem;border-radius:2rem;border:1px solid var(--border-color);color:#a09080;font-size:0.75rem;">#Carlsen</a>
                            <a href="topic.php?tag=grandchess" class="tag" style="padding:0.3rem 0.8rem;border-radius:2rem;border:1px solid var(--border-color);color:#a09080;font-size:0.75rem;">#GrandChess</a>
                            <a href="topic.php?tag=tactics" class="tag" style="padding:0.3rem 0.8rem;border-radius:2rem;border:1px solid var(--border-color);color:#a09080;font-size:0.75rem;">#Tactics</a>
                            <a href="topic.php?tag=openings" class="tag" style="padding:0.3rem 0.8rem;border-radius:2rem;border:1px solid var(--border-color);color:#a09080;font-size:0.75rem;">#Openings</a>
                            <a href="topic.php?tag=endgame" class="tag" style="padding:0.3rem 0.8rem;border-radius:2rem;border:1px solid var(--border-color);color:#a09080;font-size:0.75rem;">#Endgame</a>
                        </div>
                    </div>

                    <!-- Newsletter -->
                    <div class="sidebar-widget">
                        <h3><i class="fas fa-envelope"></i> Newsletter</h3>
                        <p style="color:#a09080;font-size:0.85rem;margin-bottom:0.8rem;">Get the latest chess news delivered to your inbox.</p>
                        <input type="email" placeholder="Your email" style="width:100%;padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;margin-bottom:0.5rem;" id="sidebarNewsletter">
                        <button onclick="subscribeSidebarNewsletter()" style="width:100%;padding:0.6rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;transition:all 0.3s;">
                            <i class="fas fa-paper-plane"></i> Subscribe
                        </button>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div style="text-align:center;padding:4rem 2rem;">
                <i class="fas fa-exclamation-triangle" style="font-size:4rem;color:var(--secondary);"></i>
                <h2 style="color:#f0d6b0;margin:1rem 0;">Article Not Found</h2>
                <p style="color:#a09080;">The article you're looking for doesn't exist or has been removed.</p>
                <a href="news.php" class="btn-read-more" style="display:inline-block;margin-top:1.5rem;padding:0.8rem 2rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-decoration:none;">
                    <i class="fas fa-arrow-left"></i> Back to News
                </a>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // ===== NAVBAR SCROLL =====
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== SHARE =====
        function shareArticle(platform) {
            const url = encodeURIComponent(window.location.href);
            const title = encodeURIComponent(document.querySelector('.article-header h1')?.textContent || 'Chess News');
            
            const shareUrls = {
                twitter: `https://twitter.com/intent/tweet?url=${url}&text=${title}`,
                facebook: `https://www.facebook.com/sharer/sharer.php?u=${url}`,
                linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${url}`,
                whatsapp: `https://api.whatsapp.com/send?text=${title}%20${url}`,
                email: `mailto:?subject=${title}&body=Check out this article: ${url}`
            };
            
            if (shareUrls[platform]) {
                window.open(shareUrls[platform], '_blank', 'width=600,height=500');
            }
        }

        // ===== COMMENTS =====
        let commentCount = <?php echo e(count($newsComments)); ?>;

        function submitComment() {
            const text = document.getElementById('commentText').value.trim();
            const name = document.getElementById('commentName').value.trim() || 'Anonymous';
            const email = document.getElementById('commentEmail').value.trim();
            
            if (!text) {
                alert('Please write a comment before posting.');
                return;
            }
            
            // Add comment to UI
            const commentsSection = document.querySelector('.comments-section');
            const commentList = commentsSection.querySelector('.comment-item:last-child')?.parentElement || commentsSection;
            
            const newComment = document.createElement('div');
            newComment.className = 'comment-item';
            newComment.style.animation = 'fadeInUp 0.5s ease-out';
            newComment.innerHTML = `
                <div class="comment-header">
                    <span class="comment-author">${name}</span>
                    <span class="comment-date">Just now</span>
                </div>
                <div class="comment-text">${text}</div>
                <div class="comment-actions">
                    <button onclick="likeComment(${Date.now()})">
                        <i class="fas fa-thumbs-up"></i> <span>0</span>
                    </button>
                    <button onclick="replyToComment(${Date.now()})">
                        <i class="fas fa-reply"></i> Reply
                    </button>
                </div>
            `;
            
            // Insert before the comment form
            const commentForm = document.querySelector('.comment-form');
            commentsSection.insertBefore(newComment, commentForm);
            
            // Update count
            commentCount++;
            const countSpan = document.querySelector('.comments-section h3');
            if (countSpan) {
                countSpan.innerHTML = `<i class="fas fa-comments"></i> Comments (${commentCount})`;
            }
            
            // Clear form
            document.getElementById('commentText').value = '';
            document.getElementById('commentName').value = '';
            document.getElementById('commentEmail').value = '';
            
            alert('✅ Your comment has been posted!');
        }

        function likeComment(id) {
            const likeSpan = document.getElementById(`like-count-${id}`);
            if (likeSpan) {
                const currentLikes = parseInt(likeSpan.textContent);
                likeSpan.textContent = currentLikes + 1;
            }
        }

        function replyToComment(id) {
            const commentText = document.getElementById('commentText');
            commentText.focus();
            commentText.value = `@user${id} `;
        }

        // ===== NEWSLETTER =====
        function subscribeSidebarNewsletter() {
            const email = document.getElementById('sidebarNewsletter').value;
            if (email && email.includes('@')) {
                alert(`✅ Thank you for subscribing with ${email}!`);
                document.getElementById('sidebarNewsletter').value = '';
            } else {
                alert('❌ Please enter a valid email address.');
            }
        }

        // ===== KEYBOARD SHORTCUTS =====
        document.addEventListener('keydown', function(e) {
            if (e.ctrlKey && e.key === 'Enter') {
                const commentText = document.getElementById('commentText');
                if (commentText && document.activeElement === commentText) {
                    submitComment();
                }
            }
        });

        // ===== ADD ANIMATION STYLES =====
        const styleEl = document.createElement('style');
        styleEl.textContent = `
            @keyframes fadeInUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(styleEl);
    </script>
</body>
</html>
<?php
/**
 * Helper functions for news detail page
 */
function getNewsDetails($id) {
    // Simulated news data
    $newsItems = [
        1 => [
            'id' => 1,
            'title' => 'World Chess Championship 2025: Carlsen to Face Nepomniachtchi',
            'author' => 'Chess Heaven Staff',
            'author_bio' => 'Senior chess journalist with over 10 years of experience covering major tournaments and championships worldwide.',
            'category' => 'tournament',
            'badge' => 'tournament',
            'date' => '2025-11-25',
            'date_formatted' => 'November 25, 2025',
            'read_time' => '6 min read',
            'views' => 2847,
            'tags' => ['WorldChampionship', 'Carlsen', 'Nepomniachtchi', 'Dubai', 'Chess'],
            'image_icon' => 'trophy',
            'image_caption' => 'The World Chess Championship trophy awaiting its winner',
            'content' => null // Will use default content
        ],
        2 => [
            'id' => 2,
            'title' => 'Grand Chess Tour 2026 Announced with Record Prize Pool',
            'author' => 'Michael Thompson',
            'author_bio' => 'Chess analyst and former international master with a passion for tournament coverage.',
            'category' => 'tournament',
            'badge' => 'tournament',
            'date' => '2025-12-20',
            'date_formatted' => 'December 20, 2025',
            'read_time' => '4 min read',
            'views' => 1200,
            'tags' => ['GrandChess', 'Tournament', 'PrizePool'],
            'image_icon' => 'chess-queen',
            'image_caption' => 'Grand Chess Tour 2026 logo',
            'content' => '<p>The Grand Chess Tour 2026 has been officially announced with a record-breaking prize pool of $5 million. The tour will feature stops in Paris, Dubai, and New York.</p><p>Top players including Carlsen, Nakamura, and Caruana have already confirmed their participation in this prestigious event.</p>'
        ],
        3 => [
            'id' => 3,
            'title' => 'Exclusive: Interview with Magnus Carlsen',
            'author' => 'Sarah Williams',
            'author_bio' => 'Chess journalist and interviewer who has conducted exclusive interviews with top grandmasters.',
            'category' => 'interview',
            'badge' => 'interview',
            'date' => '2025-12-15',
            'date_formatted' => 'December 15, 2025',
            'read_time' => '8 min read',
            'views' => 3800,
            'tags' => ['Interview', 'Carlsen', 'Exclusive'],
            'image_icon' => 'microphone',
            'image_caption' => 'Magnus Carlsen during the exclusive interview',
            'content' => '<p>In an exclusive interview with Chess Heaven, World Champion Magnus Carlsen discusses his preparation for the upcoming title match.</p><div class="quote-block">"I feel more motivated than ever. Each match brings new challenges and opportunities to grow as a player."<span class="quote-author">— Magnus Carlsen</span></div>'
        ],
        4 => [
            'id' => 4,
            'title' => 'Game Analysis: Carlsen vs Caruana - Strategic Masterclass',
            'author' => 'GM Anna Petrova',
            'author_bio' => 'Grandmaster and chess analyst, providing deep insights into top-level chess games.',
            'category' => 'analysis',
            'badge' => 'analysis',
            'date' => '2025-12-12',
            'date_formatted' => 'December 12, 2025',
            'read_time' => '10 min read',
            'views' => 1800,
            'tags' => ['Analysis', 'Carlsen', 'Caruana', 'Strategy'],
            'image_icon' => 'chess-board',
            'image_caption' => 'Position from the Carlsen vs Caruana game',
            'content' => '<p>Deep analysis of the decisive game from the recent tournament between Carlsen and Caruana.</p><div class="highlight-box"><strong>Key Position:</strong><br>White to move. What is the winning strategy?</div>'
        ]
    ];
    
    return $newsItems[$id] ?? null;
}

function getRelatedNews($id, $limit = 4) {
    // Return related news (simulated)
    $allNews = [
        ['id' => 1, 'title' => 'World Chess Championship 2025: Carlsen to Face Nepomniachtchi', 'category' => 'tournament', 'badge' => 'tournament', 'date' => '2025-11-25', 'date_formatted' => 'Nov 25, 2025'],
        ['id' => 2, 'title' => 'Grand Chess Tour 2026 Announced with Record Prize Pool', 'category' => 'tournament', 'badge' => 'tournament', 'date' => '2025-12-20', 'date_formatted' => 'Dec 20, 2025'],
        ['id' => 3, 'title' => 'Exclusive: Interview with Magnus Carlsen', 'category' => 'interview', 'badge' => 'interview', 'date' => '2025-12-15', 'date_formatted' => 'Dec 15, 2025'],
        ['id' => 4, 'title' => 'Game Analysis: Carlsen vs Caruana', 'category' => 'analysis', 'badge' => 'analysis', 'date' => '2025-12-12', 'date_formatted' => 'Dec 12, 2025'],
        ['id' => 5, 'title' => 'Chess Heaven Platform Update: New Features', 'category' => 'update', 'badge' => 'update', 'date' => '2025-12-10', 'date_formatted' => 'Dec 10, 2025'],
        ['id' => 6, 'title' => 'Community Tournament a Success', 'category' => 'community', 'badge' => 'update', 'date' => '2025-12-08', 'date_formatted' => 'Dec 8, 2025']
    ];
    
    // Filter out current news and return related
    $related = array_filter($allNews, function($item) use ($id) {
        return $item['id'] !== $id;
    });
    
    return array_slice(array_values($related), 0, $limit);
}

function getNewsComments($id, $limit = 10) {
    // Simulated comments
    if ($id == 1) {
        return [
            ['id' => 1, 'author' => 'Mike R.', 'text' => 'This is going to be an epic match! Carlsen vs Nepomniachtchi never disappoints.', 'date' => '2025-11-26', 'date_formatted' => 'Nov 26, 2025', 'likes' => 34],
            ['id' => 2, 'author' => 'Sarah K.', 'text' => 'I think Nepomniachtchi has a real chance this time. His form has been incredible.', 'date' => '2025-11-26', 'date_formatted' => 'Nov 26, 2025', 'likes' => 28],
            ['id' => 3, 'author' => 'James P.', 'text' => 'Dubai is a great venue for the championship. Looking forward to the coverage!', 'date' => '2025-11-25', 'date_formatted' => 'Nov 25, 2025', 'likes' => 15],
            ['id' => 4, 'author' => 'Lisa M.', 'text' => 'Carlsen has been dominant for so long. It would be amazing to see a new champion.', 'date' => '2025-11-25', 'date_formatted' => 'Nov 25, 2025', 'likes' => 22],
            ['id' => 5, 'author' => 'David L.', 'text' => 'The prize fund is incredible! Chess is really growing globally.', 'date' => '2025-11-24', 'date_formatted' => 'Nov 24, 2025', 'likes' => 19]
        ];
    }
    
    return [
        ['id' => 1, 'author' => 'Alex R.', 'text' => 'Great article! Really insightful analysis.', 'date' => date('Y-m-d'), 'date_formatted' => date('M d, Y'), 'likes' => 5],
        ['id' => 2, 'author' => 'Emma W.', 'text' => 'Thanks for the comprehensive coverage.', 'date' => date('Y-m-d', strtotime('-1 day')), 'date_formatted' => date('M d, Y', strtotime('-1 day')), 'likes' => 3]
    ];
}
?>