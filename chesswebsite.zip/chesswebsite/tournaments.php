<?php
/**
 * Chess Heaven - Tournaments Page
 * Complete tournament hub with live events, upcoming tournaments, and results
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get tournament data
$liveTournaments = getLiveTournaments(3);
$upcomingTournaments = getUpcomingTournaments(6);
$pastTournaments = getPastTournaments(4);
$tournamentCategories = getTournamentCategories();
$featuredTournament = getFeaturedTournament();
$tournamentStats = getTournamentStats();
$prizePools = getPrizePools();
$tournamentLeaderboard = getTournamentLeaderboard(5);
$recentResults = getRecentTournamentResults(5);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Tournaments</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
            position:relative;
            overflow:hidden;
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }
        .card .badge {
            position:absolute;
            top:1rem;
            right:1rem;
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .badge-live { background:rgba(231,76,60,0.3); color:#e74c3c; animation:pulse-badge 2s infinite; }
        .badge-upcoming { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .badge-open { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .badge-finished { background:rgba(155,155,155,0.2); color:#999; }
        .badge-premium { background:rgba(198,151,107,0.2); color:#C6976B; }
        .badge-free { background:rgba(52,152,219,0.2); color:#3498db; }

        @keyframes pulse-badge {
            0%, 100% { opacity:1; }
            50% { opacity:0.5; }
        }

        /* ===== HERO ===== */
        .tournament-hero {
            text-align:center;
            padding:3rem 2rem;
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem;
            border:1px solid var(--border-color);
            margin:2rem;
        }
        .tournament-hero h1 {
            font-size:2.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:1rem;
        }
        .tournament-hero p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
        }
        .tournament-hero .stats-row {
            display:flex;
            justify-content:center;
            gap:3rem;
            margin-top:1.5rem;
            flex-wrap:wrap;
        }
        .tournament-hero .stats-row .stat-item {
            text-align:center;
        }
        .tournament-hero .stats-row .stat-item .stat-number {
            font-size:2rem;
            font-weight:700;
            color:var(--gold);
        }
        .tournament-hero .stats-row .stat-item .stat-label {
            color:#7a6a5a;
            font-size:0.85rem;
        }

        /* ===== FEATURED TOURNAMENT ===== */
        .featured-tournament {
            background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));
            border-radius:2rem;
            padding:2rem;
            border:2px solid var(--gold);
            margin-bottom:2rem;
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
            align-items:center;
        }
        .featured-tournament .featured-content h2 {
            color:#f0d6b0;
            font-size:1.8rem;
            margin-bottom:0.5rem;
        }
        .featured-tournament .featured-content p {
            color:#a09080;
            line-height:1.8;
        }
        .featured-tournament .featured-content .tournament-meta {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            margin:1rem 0;
        }
        .featured-tournament .featured-content .tournament-meta span {
            color:var(--secondary);
            font-size:0.85rem;
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .featured-tournament .featured-image {
            text-align:center;
            padding:2rem;
        }
        .featured-tournament .featured-image i {
            font-size:6rem;
            color:var(--secondary);
            opacity:0.3;
        }
        .btn-register {
            display:inline-block;
            padding:0.8rem 2rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            margin-top:1rem;
        }
        .btn-register:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.5);
        }
        .btn-watch {
            display:inline-block;
            padding:0.8rem 2rem;
            border-radius:2rem;
            border:2px solid var(--secondary);
            background:transparent;
            color:var(--secondary);
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            margin-top:1rem;
            margin-left:0.5rem;
        }
        .btn-watch:hover {
            background:rgba(198,151,107,0.1);
            transform:translateY(-2px);
        }

        /* ===== CATEGORY FILTERS ===== */
        .category-filters {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            justify-content:center;
            margin:1rem 0 2rem;
        }
        .category-filters button {
            padding:0.5rem 1.5rem;
            border-radius:2rem;
            border:2px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.85rem;
        }
        .category-filters button:hover,
        .category-filters button.active {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }

        /* ===== PRIZE POOLS ===== */
        .prize-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
            gap:1rem;
        }
        .prize-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            text-align:center;
            transition:all 0.3s;
        }
        .prize-item:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--gold);
            transform:translateY(-3px);
        }
        .prize-item .prize-amount {
            font-size:2rem;
            font-weight:700;
            color:var(--gold);
        }
        .prize-item .prize-label {
            color:#7a6a5a;
            font-size:0.85rem;
            margin-top:0.3rem;
        }
        .prize-item .prize-icon {
            font-size:2rem;
            color:var(--secondary);
            margin-bottom:0.5rem;
        }

        /* ===== LEADERBOARD ===== */
        .leaderboard-table {
            background:var(--card-bg); border-radius:1.5rem;
            padding:1.5rem; border:1px solid var(--border-color);
            overflow-x:auto;
        }
        .leaderboard-table table { width:100%; border-collapse:collapse; }
        .leaderboard-table th {
            color:#7a6a5a; border-bottom:1px solid var(--border-color);
            padding:0.8rem; text-align:left;
        }
        .leaderboard-table td { padding:0.8rem; border-bottom:1px solid rgba(255,255,255,0.03); }
        .leaderboard-table tr:last-child td { border-bottom:none; }
        .rank-gold { color:var(--gold); font-weight:700; }
        .rank-silver { color:#c0c0c0; font-weight:700; }
        .rank-bronze { color:#cd7f32; font-weight:700; }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .featured-tournament {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .tournament-hero { margin:1rem; padding:2rem 1rem; }
            .tournament-hero h1 { font-size:2rem; flex-direction:column; }
            .tournament-hero .stats-row { gap:1.5rem; }
            .tournament-hero .stats-row .stat-item .stat-number { font-size:1.5rem; }
            .featured-tournament { padding:1.5rem; }
            .card-grid { grid-template-columns:1fr; }
            .category-filters button { padding:0.3rem 1rem; font-size:0.75rem; }
            .prize-grid { grid-template-columns:repeat(2,1fr); }
        }
        @media (max-width:480px) {
            .section-header h2 { font-size:1.3rem; }
            .tournament-hero h1 { font-size:1.5rem; }
            .prize-grid { grid-template-columns:1fr; }
            .featured-tournament .featured-content h2 { font-size:1.3rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php" class="active-link"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <div class="tournament-hero">
        <h1>
            <i class="fas fa-trophy"></i>
            Chess Tournaments
            <i class="fas fa-chess"></i>
        </h1>
        <p>Compete in live tournaments, track results, and climb the leaderboard. Join the chess community today!</p>
        <div class="stats-row">
            <div class="stat-item">
                <div class="stat-number"><?php echo e($tournamentStats['total'] ?? 24); ?></div>
                <div class="stat-label">Total Tournaments</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo e($tournamentStats['live'] ?? 3); ?></div>
                <div class="stat-label">Live Now</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo e($tournamentStats['players'] ?? 1250); ?></div>
                <div class="stat-label">Active Players</div>
            </div>
            <div class="stat-item">
                <div class="stat-number">$<?php echo e($tournamentStats['prize_pool'] ?? 50000); ?></div>
                <div class="stat-label">Total Prize Pool</div>
            </div>
        </div>
    </div>

    <!-- ===== FEATURED TOURNAMENT ===== -->
    <section class="section" style="padding-top:0;">
        <div class="featured-tournament">
            <div class="featured-content">
                <span class="badge badge-live" style="position:static;display:inline-block;margin-bottom:0.5rem;">● LIVE NOW</span>
                <h2><?php echo e($featuredTournament['name'] ?? 'World Chess Championship 2025'); ?></h2>
                <p><?php echo e($featuredTournament['description'] ?? 'The most prestigious chess tournament in the world. Watch the world\'s best players compete for the ultimate title and a $2,000,000 prize pool.'); ?></p>
                <div class="tournament-meta">
                    <span><i class="fas fa-calendar"></i> <?php echo e($featuredTournament['date'] ?? 'Nov 25 - Dec 15, 2025'); ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?php echo e($featuredTournament['location'] ?? 'Dubai, UAE'); ?></span>
                    <span><i class="fas fa-users"></i> <?php echo e($featuredTournament['players'] ?? '64'); ?> players</span>
                    <span><i class="fas fa-trophy"></i> $<?php echo e($featuredTournament['prize'] ?? '2,000,000'); ?></span>
                </div>
                <div>
                    <a href="tournament-register.php?id=<?php echo e($featuredTournament['id'] ?? 1); ?>" class="btn-register"><i class="fas fa-user-plus"></i> Register Now</a>
                    <a href="tournament-watch.php?id=<?php echo e($featuredTournament['id'] ?? 1); ?>" class="btn-watch"><i class="fas fa-eye"></i> Watch Live</a>
                </div>
            </div>
            <div class="featured-image">
                <i class="fas fa-trophy"></i>
                <p style="color:#7a6a5a;margin-top:0.5rem;">Featured Tournament</p>
            </div>
        </div>
    </section>

    <!-- ===== CATEGORY FILTERS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="category-filters" id="categoryFilters">
            <button class="active" onclick="filterCategory('all')">All Tournaments</button>
            <?php if (!empty($tournamentCategories)): ?>
                <?php foreach ($tournamentCategories as $category): ?>
                    <button onclick="filterCategory('<?php echo e($category['slug']); ?>')"><?php echo e($category['name']); ?></button>
                <?php endforeach; ?>
            <?php else: ?>
                <button onclick="filterCategory('live')">Live</button>
                <button onclick="filterCategory('upcoming')">Upcoming</button>
                <button onclick="filterCategory('finished')">Finished</button>
                <button onclick="filterCategory('online')">Online</button>
                <button onclick="filterCategory('otb')">Over-the-Board</button>
                <button onclick="filterCategory('blitz')">Blitz</button>
                <button onclick="filterCategory('rapid')">Rapid</button>
                <button onclick="filterCategory('classical')">Classical</button>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LIVE TOURNAMENTS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="section-header">
            <h2><i class="fas fa-broadcast-tower"></i> Live Tournaments</h2>
            <a href="live-tournaments.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid" id="tournamentGrid">
            <?php if (!empty($liveTournaments)): ?>
                <?php foreach ($liveTournaments as $tournament): ?>
                    <a href="tournament.php?id=<?php echo e($tournament['id']); ?>" class="card" data-category="<?php echo e($tournament['category'] ?? 'live'); ?>" style="border-color:var(--danger);">
                        <span class="badge badge-live">● LIVE</span>
                        <i class="fas fa-<?php echo e($tournament['icon'] ?? 'broadcast-tower'); ?>"></i>
                        <h3><?php echo e($tournament['name']); ?></h3>
                        <p><?php echo e($tournament['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-users"></i> <?php echo e($tournament['players'] ?? 0); ?> watching</span>
                            <span><i class="fas fa-clock"></i> Round <?php echo e($tournament['round'] ?? 1); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="tournament.php?id=1" class="card" data-category="live" style="border-color:var(--danger);">
                    <span class="badge badge-live">● LIVE</span>
                    <i class="fas fa-broadcast-tower"></i>
                    <h3>World Chess Championship</h3>
                    <p>Watch the world's best players compete for the ultimate title.</p>
                    <div class="meta"><span><i class="fas fa-users"></i> 1,247 watching</span><span><i class="fas fa-clock"></i> Round 7</span></div>
                </a>
                <a href="tournament.php?id=2" class="card" data-category="live" style="border-color:var(--danger);">
                    <span class="badge badge-live">● LIVE</span>
                    <i class="fas fa-broadcast-tower"></i>
                    <h3>Grand Chess Tour - Paris</h3>
                    <p>Elite tournament featuring top 10 players in the world.</p>
                    <div class="meta"><span><i class="fas fa-users"></i> 856 watching</span><span><i class="fas fa-clock"></i> Round 4</span></div>
                </a>
                <a href="tournament.php?id=3" class="card" data-category="live" style="border-color:var(--danger);">
                    <span class="badge badge-live">● LIVE</span>
                    <i class="fas fa-broadcast-tower"></i>
                    <h3>Chess Heaven Open</h3>
                    <p>Annual charity tournament with players from around the world.</p>
                    <div class="meta"><span><i class="fas fa-users"></i> 432 watching</span><span><i class="fas fa-clock"></i> Round 3</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== UPCOMING TOURNAMENTS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-calendar-plus"></i> Upcoming Tournaments</h2>
            <a href="upcoming-tournaments.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($upcomingTournaments)): ?>
                <?php foreach ($upcomingTournaments as $tournament): ?>
                    <a href="tournament.php?id=<?php echo e($tournament['id']); ?>" class="card" data-category="<?php echo e($tournament['category'] ?? 'upcoming'); ?>">
                        <span class="badge badge-<?php echo e($tournament['status'] ?? 'upcoming'); ?>"><?php echo e(ucfirst($tournament['status'] ?? 'Upcoming')); ?></span>
                        <i class="fas fa-<?php echo e($tournament['icon'] ?? 'calendar-plus'); ?>"></i>
                        <h3><?php echo e($tournament['name']); ?></h3>
                        <p><?php echo e($tournament['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($tournament['date']))); ?></span>
                            <span><i class="fas fa-map-marker-alt"></i> <?php echo e($tournament['location']); ?></span>
                            <span><i class="fas fa-users"></i> <?php echo e($tournament['slots'] ?? 'Open'); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="tournament.php?id=4" class="card" data-category="upcoming">
                    <span class="badge badge-upcoming">Upcoming</span>
                    <i class="fas fa-calendar-plus"></i>
                    <h3>Grand Chess Tour 2026</h3>
                    <p>Elite tournament featuring top 10 players in the world.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Jan 15, 2026</span><span><i class="fas fa-map-marker-alt"></i> Paris</span><span><i class="fas fa-users"></i> 32 slots</span></div>
                </a>
                <a href="tournament.php?id=5" class="card" data-category="upcoming">
                    <span class="badge badge-open">Open</span>
                    <i class="fas fa-calendar-plus"></i>
                    <h3>Women's World Championship</h3>
                    <p>The premier event for women's chess.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Feb 1, 2026</span><span><i class="fas fa-map-marker-alt"></i> London</span><span><i class="fas fa-users"></i> 16 slots</span></div>
                </a>
                <a href="tournament.php?id=6" class="card" data-category="upcoming">
                    <span class="badge badge-open">Open</span>
                    <i class="fas fa-calendar-plus"></i>
                    <h3>Chess Heaven Open 2026</h3>
                    <p>Annual charity tournament open to all players.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Mar 10, 2026</span><span><i class="fas fa-map-marker-alt"></i> Online</span><span><i class="fas fa-users"></i> 256 slots</span></div>
                </a>
                <a href="tournament.php?id=7" class="card" data-category="upcoming">
                    <span class="badge badge-upcoming">Upcoming</span>
                    <i class="fas fa-calendar-plus"></i>
                    <h3>World Blitz Championship</h3>
                    <p>Fast-paced blitz chess at the highest level.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Apr 5, 2026</span><span><i class="fas fa-map-marker-alt"></i> Moscow</span><span><i class="fas fa-users"></i> 64 slots</span></div>
                </a>
                <a href="tournament.php?id=8" class="card" data-category="upcoming">
                    <span class="badge badge-upcoming">Upcoming</span>
                    <i class="fas fa-calendar-plus"></i>
                    <h3>Rapid Chess Championship</h3>
                    <p>Rapid chess tournament with a $100,000 prize pool.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> May 20, 2026</span><span><i class="fas fa-map-marker-alt"></i> New York</span><span><i class="fas fa-users"></i> 48 slots</span></div>
                </a>
                <a href="tournament.php?id=9" class="card" data-category="upcoming">
                    <span class="badge badge-free">Free Entry</span>
                    <i class="fas fa-calendar-plus"></i>
                    <h3>Chess Heaven Amateur Cup</h3>
                    <p>Free tournament for amateur players under 2000 ELO.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Jun 15, 2026</span><span><i class="fas fa-map-marker-alt"></i> Online</span><span><i class="fas fa-users"></i> 128 slots</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== PAST TOURNAMENTS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-history"></i> Past Tournaments</h2>
            <a href="past-tournaments.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($pastTournaments)): ?>
                <?php foreach ($pastTournaments as $tournament): ?>
                    <a href="tournament-results.php?id=<?php echo e($tournament['id']); ?>" class="card" data-category="<?php echo e($tournament['category'] ?? 'finished'); ?>">
                        <span class="badge badge-finished">Finished</span>
                        <i class="fas fa-<?php echo e($tournament['icon'] ?? 'history'); ?>"></i>
                        <h3><?php echo e($tournament['name']); ?></h3>
                        <p>Winner: <?php echo e($tournament['winner'] ?? 'TBD'); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($tournament['date']))); ?></span>
                            <span><i class="fas fa-trophy"></i> $<?php echo e($tournament['prize'] ?? '0'); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="tournament-results.php?id=1" class="card" data-category="finished">
                    <span class="badge badge-finished">Finished</span>
                    <i class="fas fa-history"></i>
                    <h3>World Chess Championship 2024</h3>
                    <p>Winner: Magnus Carlsen</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Dec 15, 2024</span><span><i class="fas fa-trophy"></i> $2,000,000</span></div>
                </a>
                <a href="tournament-results.php?id=2" class="card" data-category="finished">
                    <span class="badge badge-finished">Finished</span>
                    <i class="fas fa-history"></i>
                    <h3>Grand Chess Tour 2025</h3>
                    <p>Winner: Fabiano Caruana</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Nov 30, 2025</span><span><i class="fas fa-trophy"></i> $500,000</span></div>
                </a>
                <a href="tournament-results.php?id=3" class="card" data-category="finished">
                    <span class="badge badge-finished">Finished</span>
                    <i class="fas fa-history"></i>
                    <h3>Chess Heaven Open 2025</h3>
                    <p>Winner: GM Hikaru Nakamura</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Dec 1, 2025</span><span><i class="fas fa-trophy"></i> $50,000</span></div>
                </a>
                <a href="tournament-results.php?id=4" class="card" data-category="finished">
                    <span class="badge badge-finished">Finished</span>
                    <i class="fas fa-history"></i>
                    <h3>World Rapid Championship</h3>
                    <p>Winner: GM Ian Nepomniachtchi</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Oct 20, 2025</span><span><i class="fas fa-trophy"></i> $150,000</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== PRIZE POOLS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-gem"></i> Prize Pools</h2>
            <a href="prizes.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="prize-grid">
            <?php if (!empty($prizePools)): ?>
                <?php foreach ($prizePools as $prize): ?>
                    <div class="prize-item">
                        <div class="prize-icon"><i class="fas fa-<?php echo e($prize['icon'] ?? 'trophy'); ?>"></i></div>
                        <div class="prize-amount">$<?php echo e($prize['amount']); ?></div>
                        <div class="prize-label"><?php echo e($prize['label']); ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="prize-item">
                    <div class="prize-icon"><i class="fas fa-trophy"></i></div>
                    <div class="prize-amount">$2,000,000</div>
                    <div class="prize-label">World Championship</div>
                </div>
                <div class="prize-item">
                    <div class="prize-icon"><i class="fas fa-medal"></i></div>
                    <div class="prize-amount">$500,000</div>
                    <div class="prize-label">Grand Chess Tour</div>
                </div>
                <div class="prize-item">
                    <div class="prize-icon"><i class="fas fa-star"></i></div>
                    <div class="prize-amount">$150,000</div>
                    <div class="prize-label">Rapid Championship</div>
                </div>
                <div class="prize-item">
                    <div class="prize-icon"><i class="fas fa-gem"></i></div>
                    <div class="prize-amount">$50,000</div>
                    <div class="prize-label">Chess Heaven Open</div>
                </div>
                <div class="prize-item">
                    <div class="prize-icon"><i class="fas fa-award"></i></div>
                    <div class="prize-amount">$25,000</div>
                    <div class="prize-label">Amateur Cup</div>
                </div>
                <div class="prize-item">
                    <div class="prize-icon"><i class="fas fa-chess-queen"></i></div>
                    <div class="prize-amount">$100,000</div>
                    <div class="prize-label">Women's Championship</div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LEADERBOARD ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-list-ol"></i> Tournament Leaderboard</h2>
            <a href="tournament-rankings.php" class="view-all">Full Rankings <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="leaderboard-table">
            <table>
                <thead>
                    <tr>
                        <th style="text-align:left;">#</th>
                        <th style="text-align:left;">Player</th>
                        <th style="text-align:center;">Tournaments</th>
                        <th style="text-align:center;">Wins</th>
                        <th style="text-align:center;">Prize Money</th>
                        <th style="text-align:center;">Rating</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($tournamentLeaderboard)): ?>
                        <?php foreach ($tournamentLeaderboard as $index => $player): ?>
                            <tr>
                                <td class="<?php echo $index < 3 ? 'rank-' . ['gold','silver','bronze'][$index] : ''; ?>"><?php echo e($index + 1); ?></td>
                                <td style="color:#f0d6b0;"><?php echo e($player['name']); ?></td>
                                <td style="text-align:center;color:#a09080;"><?php echo e($player['tournaments']); ?></td>
                                <td style="text-align:center;color:var(--gold);"><?php echo e($player['wins']); ?></td>
                                <td style="text-align:center;color:var(--secondary);">$<?php echo e($player['prize']); ?></td>
                                <td style="text-align:center;color:#3498db;"><?php echo e($player['rating']); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td class="rank-gold">1</td><td style="color:#f0d6b0;">Magnus Carlsen</td><td style="text-align:center;color:#a09080;">12</td><td style="text-align:center;color:var(--gold);">8</td><td style="text-align:center;color:var(--secondary);">$3,450,000</td><td style="text-align:center;color:#3498db;">2847</td></tr>
                        <tr><td class="rank-silver">2</td><td style="color:#f0d6b0;">Ian Nepomniachtchi</td><td style="text-align:center;color:#a09080;">10</td><td style="text-align:center;color:var(--gold);">5</td><td style="text-align:center;color:var(--secondary);">$2,100,000</td><td style="text-align:center;color:#3498db;">2795</td></tr>
                        <tr><td class="rank-bronze">3</td><td style="color:#f0d6b0;">Hikaru Nakamura</td><td style="text-align:center;color:#a09080;">14</td><td style="text-align:center;color:var(--gold);">6</td><td style="text-align:center;color:var(--secondary);">$1,800,000</td><td style="text-align:center;color:#3498db;">2788</td></tr>
                        <tr><td>4</td><td style="color:#f0d6b0;">Fabiano Caruana</td><td style="text-align:center;color:#a09080;">11</td><td style="text-align:center;color:var(--gold);">4</td><td style="text-align:center;color:var(--secondary);">$1,200,000</td><td style="text-align:center;color:#3498db;">2782</td></tr>
                        <tr><td>5</td><td style="color:#f0d6b0;">Levon Aronian</td><td style="text-align:center;color:#a09080;">9</td><td style="text-align:center;color:var(--gold);">3</td><td style="text-align:center;color:var(--secondary);">$950,000</td><td style="text-align:center;color:#3498db;">2775</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- ===== RECENT RESULTS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-clock"></i> Recent Results</h2>
            <a href="results.php" class="view-all">All Results <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($recentResults)): ?>
                <?php foreach ($recentResults as $result): ?>
                    <div class="card">
                        <i class="fas fa-<?php echo e($result['icon'] ?? 'chess'); ?>"></i>
                        <h3><?php echo e($result['tournament']); ?></h3>
                        <p><strong>Winner:</strong> <?php echo e($result['winner']); ?></p>
                        <p style="font-size:0.8rem;color:#7a6a5a;"><?php echo e($result['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($result['date']))); ?></span>
                            <span><i class="fas fa-trophy"></i> $<?php echo e($result['prize'] ?? '0'); ?></span>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="card">
                    <i class="fas fa-chess-king"></i>
                    <h3>World Chess Championship 2024</h3>
                    <p><strong>Winner:</strong> Magnus Carlsen</p>
                    <p style="font-size:0.8rem;color:#7a6a5a;">Carlsen defends his title in a thrilling 12-game match.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Dec 15, 2024</span><span><i class="fas fa-trophy"></i> $2,000,000</span></div>
                </div>
                <div class="card">
                    <i class="fas fa-chess-queen"></i>
                    <h3>Grand Chess Tour 2025</h3>
                    <p><strong>Winner:</strong> Fabiano Caruana</p>
                    <p style="font-size:0.8rem;color:#7a6a5a;">Caruana wins the tour with a dominant performance.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Nov 30, 2025</span><span><i class="fas fa-trophy"></i> $500,000</span></div>
                </div>
                <div class="card">
                    <i class="fas fa-chess-knight"></i>
                    <h3>Chess Heaven Open 2025</h3>
                    <p><strong>Winner:</strong> GM Hikaru Nakamura</p>
                    <p style="font-size:0.8rem;color:#7a6a5a;">Nakamura wins the charity tournament with a perfect score.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Dec 1, 2025</span><span><i class="fas fa-trophy"></i> $50,000</span></div>
                </div>
                <div class="card">
                    <i class="fas fa-chess-rook"></i>
                    <h3>World Rapid Championship 2025</h3>
                    <p><strong>Winner:</strong> GM Ian Nepomniachtchi</p>
                    <p style="font-size:0.8rem;color:#7a6a5a;">Nepomniachtchi wins the rapid chess championship.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Oct 20, 2025</span><span><i class="fas fa-trophy"></i> $150,000</span></div>
                </div>
                <div class="card">
                    <i class="fas fa-chess-pawn"></i>
                    <h3>Chess Heaven Amateur Cup</h3>
                    <p><strong>Winner:</strong> IM Alex Rodriguez</p>
                    <p style="font-size:0.8rem;color:#7a6a5a;">Rodriguez wins the amateur tournament with an undefeated record.</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Nov 15, 2025</span><span><i class="fas fa-trophy"></i> $10,000</span></div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:var(--card-bg);border-radius:1.5rem;padding:2rem;border:1px solid var(--border-color);text-align:center;">
            <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--secondary);"></i>
            <h3 style="color:#f0d6b0;margin:0.5rem 0;">Tournament Tips</h3>
            <p style="color:#a09080;max-width:600px;margin:0 auto;">
                <i class="fas fa-chess-pawn"></i> Prepare thoroughly, manage your time well, and stay focused.
                <br>
                <span style="color:var(--secondary);font-size:0.85rem;">"In chess, as in life, the one who prepares the best wins."</span>
            </p>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // Category filter for tournaments
        function filterCategory(category) {
            document.querySelectorAll('.category-filters button').forEach(btn => {
                btn.classList.toggle('active', btn.textContent.toLowerCase() === category || 
                    (category === 'all' && btn.textContent === 'All Tournaments'));
            });

            // Filter tournaments in the live section
            const cards = document.querySelectorAll('#tournamentGrid .card');
            cards.forEach(card => {
                if (category === 'all' || card.dataset.category === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }
    </script>
</body>
</html>