<?php
/**
 * Chess Heaven - Tournament Detail Page
 * Displays detailed tournament information, standings, matches, and registration
 */

require_once 'config.php';

// Get tournament ID from URL
$tournamentId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get tournament details
$tournamentDetails = getTournamentDetail($tournamentId);
$tournamentStandings = getTournamentStandings($tournamentId, 10);
$tournamentMatches = getTournamentMatches($tournamentId, 8);
$tournamentSchedule = getTournamentSchedule($tournamentId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · <?php echo e($tournamentDetails ? $tournamentDetails['name'] : 'Tournament'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
            position:relative;
            overflow:hidden;
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }
        .card .badge {
            position:absolute;
            top:1rem;
            right:1rem;
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .badge-live { background:rgba(231,76,60,0.3); color:#e74c3c; animation:pulse-badge 2s infinite; }
        .badge-upcoming { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .badge-open { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .badge-finished { background:rgba(155,155,155,0.2); color:#999; }

        @keyframes pulse-badge {
            0%, 100% { opacity:1; }
            50% { opacity:0.5; }
        }

        /* ===== TOURNAMENT HEADER ===== */
        .tournament-header {
            background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));
            border-radius:2rem;
            padding:2rem;
            border:2px solid var(--gold);
            margin-bottom:2rem;
        }
        .tournament-header .header-top {
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:1rem;
        }
        .tournament-header h1 {
            color:#f0d6b0;
            font-size:2.2rem;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .tournament-header .status-badge {
            padding:0.3rem 1.2rem;
            border-radius:2rem;
            font-weight:700;
            font-size:0.85rem;
        }
        .status-badge.live { background:rgba(231,76,60,0.3); color:#e74c3c; animation:pulse-badge 2s infinite; }
        .status-badge.upcoming { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .status-badge.finished { background:rgba(155,155,155,0.2); color:#999; }
        .status-badge.open { background:rgba(46,204,113,0.2); color:#2ecc71; }

        .tournament-header .header-meta {
            display:flex;
            gap:1.5rem;
            flex-wrap:wrap;
            margin-top:1rem;
            color:#a09080;
            font-size:0.9rem;
        }
        .tournament-header .header-meta span {
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .tournament-header .header-meta span i { color:var(--secondary); }

        .tournament-header .header-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            margin-top:1rem;
        }
        .btn-register {
            display:inline-block;
            padding:0.8rem 2rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            text-decoration:none;
        }
        .btn-register:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.5);
        }
        .btn-watch {
            display:inline-block;
            padding:0.8rem 2rem;
            border-radius:2rem;
            border:2px solid var(--secondary);
            background:transparent;
            color:var(--secondary);
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            text-decoration:none;
        }
        .btn-watch:hover {
            background:rgba(198,151,107,0.1);
            transform:translateY(-2px);
        }
        .btn-back {
            display:inline-block;
            padding:0.8rem 2rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            text-decoration:none;
        }
        .btn-back:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            transform:translateY(-2px);
        }

        /* ===== TOURNAMENT STATS ===== */
        .stats-grid {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
            gap:1rem;
            margin:1.5rem 0;
        }
        .stat-box {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            text-align:center;
        }
        .stat-box .stat-number {
            font-size:1.8rem;
            font-weight:700;
            color:var(--gold);
        }
        .stat-box .stat-label {
            color:#7a6a5a;
            font-size:0.8rem;
            margin-top:0.2rem;
        }

        /* ===== STANDINGS ===== */
        .standings-table-wrapper {
            background:var(--card-bg);
            border-radius:1.5rem;
            padding:1.5rem;
            border:1px solid var(--border-color);
            overflow-x:auto;
        }
        .standings-table {
            width:100%;
            border-collapse:collapse;
        }
        .standings-table th {
            color:#7a6a5a;
            border-bottom:1px solid var(--border-color);
            padding:0.8rem;
            text-align:left;
            font-size:0.85rem;
        }
        .standings-table td {
            padding:0.8rem;
            border-bottom:1px solid rgba(255,255,255,0.03);
            font-size:0.85rem;
        }
        .standings-table tr:last-child td { border-bottom:none; }
        .standings-table .rank {
            font-weight:700;
            color:#5a4a3a;
        }
        .standings-table .rank-1 { color:var(--gold); }
        .standings-table .rank-2 { color:#c0c0c0; }
        .standings-table .rank-3 { color:#cd7f32; }
        .standings-table .player-name {
            color:#f0d6b0;
            font-weight:500;
        }
        .standings-table .points {
            color:var(--gold);
            font-weight:600;
        }
        .standings-table .wins { color:var(--success); }
        .standings-table .draws { color:var(--warning); }
        .standings-table .losses { color:var(--danger); }

        /* ===== MATCHES ===== */
        .match-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            margin-bottom:0.8rem;
            transition:all 0.3s;
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:1rem;
        }
        .match-item:hover {
            background:rgba(139,26,26,0.08);
            border-color:var(--secondary);
        }
        .match-item .match-players {
            display:flex;
            align-items:center;
            gap:1rem;
        }
        .match-item .match-players .player {
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .match-item .match-players .player .avatar {
            width:30px;
            height:30px;
            border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:0.7rem;
            color:var(--secondary);
        }
        .match-item .match-players .vs {
            color:#5a4a3a;
            font-weight:700;
            font-size:0.8rem;
        }
        .match-item .match-result {
            font-weight:600;
            font-size:0.9rem;
        }
        .match-item .match-result .win { color:var(--success); }
        .match-item .match-result .loss { color:var(--danger); }
        .match-item .match-result .draw { color:var(--warning); }
        .match-item .match-info {
            color:#7a6a5a;
            font-size:0.75rem;
        }

        /* ===== SCHEDULE ===== */
        .schedule-item {
            display:flex;
            gap:1rem;
            padding:0.8rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            align-items:center;
        }
        .schedule-item:last-child { border-bottom:none; }
        .schedule-item .schedule-time {
            min-width:80px;
            color:#7a6a5a;
            font-size:0.8rem;
        }
        .schedule-item .schedule-event {
            flex:1;
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .schedule-item .schedule-status {
            font-size:0.7rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .tournament-header { padding:1.5rem; }
            .tournament-header h1 { font-size:1.5rem; }
            .stats-grid { grid-template-columns:repeat(2,1fr); }
            .match-item { flex-direction:column; align-items:stretch; text-align:center; }
            .match-item .match-players { justify-content:center; }
            .card-grid { grid-template-columns:1fr; }
            .standings-table-wrapper { padding:1rem; }
            .standings-table th, .standings-table td { padding:0.5rem; font-size:0.75rem; }
        }
        @media (max-width:480px) {
            .tournament-header h1 { font-size:1.2rem; }
            .stats-grid { grid-template-columns:1fr 1fr; }
            .tournament-header .header-actions { flex-direction:column; }
            .tournament-header .header-actions a { text-align:center; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php" class="active-link"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <?php if ($tournamentDetails): ?>
        <!-- ===== TOURNAMENT HEADER ===== -->
        <section class="section" style="padding-top:2rem;">
            <div class="tournament-header">
                <div class="header-top">
                    <h1>
                        <i class="fas fa-trophy" style="color:var(--gold);"></i>
                        <?php echo e($tournamentDetails['name']); ?>
                    </h1>
                    <span class="status-badge <?php echo e($tournamentDetails['status'] ?? 'upcoming'); ?>">
                        <?php echo e(ucfirst($tournamentDetails['status'] ?? 'Upcoming')); ?>
                    </span>
                </div>
                <div class="header-meta">
                    <span><i class="fas fa-calendar"></i> <?php echo e($tournamentDetails['date']); ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?php echo e($tournamentDetails['location']); ?></span>
                    <span><i class="fas fa-users"></i> <?php echo e($tournamentDetails['players']); ?> players</span>
                    <span><i class="fas fa-trophy"></i> $<?php echo e($tournamentDetails['prize']); ?> prize pool</span>
                    <span><i class="fas fa-clock"></i> <?php echo e($tournamentDetails['time_control'] ?? 'Standard'); ?></span>
                    <span><i class="fas fa-globe"></i> <?php echo e($tournamentDetails['type'] ?? 'International'); ?></span>
                </div>
                <div class="header-actions">
                    <?php if (($tournamentDetails['status'] ?? 'upcoming') === 'open' || ($tournamentDetails['status'] ?? 'upcoming') === 'upcoming'): ?>
                        <a href="tournament-register.php?id=<?php echo e($tournamentId); ?>" class="btn-register">
                            <i class="fas fa-user-plus"></i> Register Now
                        </a>
                    <?php endif; ?>
                    <?php if (($tournamentDetails['status'] ?? 'upcoming') === 'live'): ?>
                        <a href="tournament-watch.php?id=<?php echo e($tournamentId); ?>" class="btn-watch">
                            <i class="fas fa-eye"></i> Watch Live
                        </a>
                    <?php endif; ?>
                    <?php if (($tournamentDetails['status'] ?? 'upcoming') === 'finished'): ?>
                        <a href="tournament-results.php?id=<?php echo e($tournamentId); ?>" class="btn-watch">
                            <i class="fas fa-list"></i> View Results
                        </a>
                    <?php endif; ?>
                    <a href="tournaments.php" class="btn-back">
                        <i class="fas fa-arrow-left"></i> Back to Tournaments
                    </a>
                </div>
            </div>
        </section>

        <!-- ===== TOURNAMENT STATS ===== -->
        <section class="section" style="padding-top:0;">
            <div class="stats-grid">
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentDetails['total_rounds'] ?? 11); ?></div>
                    <div class="stat-label">Total Rounds</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentDetails['current_round'] ?? 0); ?>/<?php echo e($tournamentDetails['total_rounds'] ?? 11); ?></div>
                    <div class="stat-label">Current Round</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentDetails['registered_players'] ?? 64); ?></div>
                    <div class="stat-label">Registered Players</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentDetails['countries'] ?? 25); ?></div>
                    <div class="stat-label">Countries Represented</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number">$<?php echo e($tournamentDetails['prize']); ?></div>
                    <div class="stat-label">Total Prize Pool</div>
                </div>
                <div class="stat-box">
                    <div class="stat-number"><?php echo e($tournamentDetails['viewers'] ?? 0); ?></div>
                    <div class="stat-label">Viewers</div>
                </div>
            </div>
        </section>

        <!-- ===== TOURNAMENT STANDINGS ===== -->
        <section class="section" style="padding-top:0;">
            <div class="section-header">
                <h2><i class="fas fa-list-ol"></i> Tournament Standings</h2>
                <a href="standings.php?id=<?php echo e($tournamentId); ?>" class="view-all">Full Standings <i class="fas fa-arrow-right"></i></a>
            </div>
            <div class="standings-table-wrapper">
                <table class="standings-table">
                    <thead>
                        <tr>
                            <th style="text-align:left;">#</th>
                            <th style="text-align:left;">Player</th>
                            <th style="text-align:center;">Rating</th>
                            <th style="text-align:center;">Points</th>
                            <th style="text-align:center;">Wins</th>
                            <th style="text-align:center;">Draws</th>
                            <th style="text-align:center;">Losses</th>
                            <th style="text-align:center;">Score</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($tournamentStandings)): ?>
                            <?php foreach ($tournamentStandings as $index => $player): ?>
                                <tr>
                                    <td class="rank rank-<?php echo $index + 1 <= 3 ? $index + 1 : ''; ?>"><?php echo e($index + 1); ?></td>
                                    <td class="player-name"><?php echo e($player['name']); ?></td>
                                    <td style="text-align:center;color:#a09080;"><?php echo e($player['rating']); ?></td>
                                    <td class="points" style="text-align:center;"><?php echo e($player['points']); ?></td>
                                    <td class="wins" style="text-align:center;"><?php echo e($player['wins']); ?></td>
                                    <td class="draws" style="text-align:center;"><?php echo e($player['draws']); ?></td>
                                    <td class="losses" style="text-align:center;"><?php echo e($player['losses']); ?></td>
                                    <td style="text-align:center;color:#3498db;"><?php echo e($player['score'] ?? ($player['points'])); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td class="rank rank-1">1</td><td class="player-name">Magnus Carlsen</td><td style="text-align:center;color:#a09080;">2847</td><td class="points" style="text-align:center;">6.5</td><td class="wins" style="text-align:center;">5</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">1</td><td style="text-align:center;color:#3498db;">6.5</td></tr>
                            <tr><td class="rank rank-2">2</td><td class="player-name">Ian Nepomniachtchi</td><td style="text-align:center;color:#a09080;">2795</td><td class="points" style="text-align:center;">5.5</td><td class="wins" style="text-align:center;">4</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">2</td><td style="text-align:center;color:#3498db;">5.5</td></tr>
                            <tr><td class="rank rank-3">3</td><td class="player-name">Hikaru Nakamura</td><td style="text-align:center;color:#a09080;">2788</td><td class="points" style="text-align:center;">5.0</td><td class="wins" style="text-align:center;">3</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">2</td><td style="text-align:center;color:#3498db;">5.0</td></tr>
                            <tr><td>4</td><td class="player-name">Fabiano Caruana</td><td style="text-align:center;color:#a09080;">2782</td><td class="points" style="text-align:center;">4.5</td><td class="wins" style="text-align:center;">3</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">3</td><td style="text-align:center;color:#3498db;">4.5</td></tr>
                            <tr><td>5</td><td class="player-name">Levon Aronian</td><td style="text-align:center;color:#a09080;">2775</td><td class="points" style="text-align:center;">4.0</td><td class="wins" style="text-align:center;">2</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">3</td><td style="text-align:center;color:#3498db;">4.0</td></tr>
                            <tr><td>6</td><td class="player-name">Wesley So</td><td style="text-align:center;color:#a09080;">2760</td><td class="points" style="text-align:center;">4.0</td><td class="wins" style="text-align:center;">2</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">3</td><td style="text-align:center;color:#3498db;">4.0</td></tr>
                            <tr><td>7</td><td class="player-name">Anish Giri</td><td style="text-align:center;color:#a09080;">2745</td><td class="points" style="text-align:center;">3.5</td><td class="wins" style="text-align:center;">2</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">4</td><td style="text-align:center;color:#3498db;">3.5</td></tr>
                            <tr><td>8</td><td class="player-name">Alireza Firouzja</td><td style="text-align:center;color:#a09080;">2730</td><td class="points" style="text-align:center;">3.0</td><td class="wins" style="text-align:center;">1</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">4</td><td style="text-align:center;color:#3498db;">3.0</td></tr>
                            <tr><td>9</td><td class="player-name">Maxime Vachier-Lagrave</td><td style="text-align:center;color:#a09080;">2720</td><td class="points" style="text-align:center;">2.5</td><td class="wins" style="text-align:center;">1</td><td class="draws" style="text-align:center;">3</td><td class="losses" style="text-align:center;">5</td><td style="text-align:center;color:#3498db;">2.5</td></tr>
                            <tr><td>10</td><td class="player-name">Shakhriyar Mamedyarov</td><td style="text-align:center;color:#a09080;">2715</td><td class="points" style="text-align:center;">2.0</td><td class="wins" style="text-align:center;">0</td><td class="draws" style="text-align:center;">4</td><td class="losses" style="text-align:center;">5</td><td style="text-align:center;color:#3498db;">2.0</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <!-- ===== MATCHES ===== -->
        <section class="section" style="padding-top:0;">
            <div class="section-header">
                <h2><i class="fas fa-chess"></i> Featured Matches</h2>
                <a href="matches.php?id=<?php echo e($tournamentId); ?>" class="view-all">All Matches <i class="fas fa-arrow-right"></i></a>
            </div>
            <div>
                <?php if (!empty($tournamentMatches)): ?>
                    <?php foreach ($tournamentMatches as $match): ?>
                        <div class="match-item">
                            <div class="match-players">
                                <div class="player">
                                    <div class="avatar"><i class="fas fa-user"></i></div>
                                    <span style="color:#f0d6b0;"><?php echo e($match['white']); ?></span>
                                    <span style="color:#7a6a5a;font-size:0.7rem;">(<?php echo e($match['white_rating'] ?? '---'); ?>)</span>
                                </div>
                                <span class="vs">VS</span>
                                <div class="player">
                                    <div class="avatar"><i class="fas fa-user"></i></div>
                                    <span style="color:#f0d6b0;"><?php echo e($match['black']); ?></span>
                                    <span style="color:#7a6a5a;font-size:0.7rem;">(<?php echo e($match['black_rating'] ?? '---'); ?>)</span>
                                </div>
                            </div>
                            <div style="text-align:center;">
                                <div class="match-result">
                                    <?php if ($match['result'] === 'win'): ?>
                                        <span class="win"><?php echo e($match['winner'] ?? 'White'); ?> wins</span>
                                    <?php elseif ($match['result'] === 'loss'): ?>
                                        <span class="loss"><?php echo e($match['winner'] ?? 'Black'); ?> wins</span>
                                    <?php elseif ($match['result'] === 'draw'): ?>
                                        <span class="draw">Draw</span>
                                    <?php else: ?>
                                        <span style="color:#3498db;">In Progress</span>
                                    <?php endif; ?>
                                </div>
                                <div class="match-info">
                                    <?php if (isset($match['moves'])): ?>
                                        <span><i class="fas fa-exchange-alt"></i> <?php echo e($match['moves']); ?> moves</span>
                                    <?php endif; ?>
                                    <?php if (isset($match['board'])): ?>
                                        <span><i class="fas fa-chess-board"></i> Board <?php echo e($match['board']); ?></span>
                                    <?php endif; ?>
                                    <?php if (isset($match['round'])): ?>
                                        <span><i class="fas fa-sync"></i> Round <?php echo e($match['round']); ?></span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <a href="tournament-watch.php?id=<?php echo e($tournamentId); ?>&match=<?php echo e($match['id'] ?? 1); ?>" class="btn-watch" style="padding:0.4rem 1.2rem;font-size:0.8rem;">
                                <i class="fas fa-eye"></i> Watch
                            </a>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="match-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Magnus Carlsen</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2847)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Ian Nepomniachtchi</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2795)</span>
                            </div>
                        </div>
                        <div style="text-align:center;">
                            <div class="match-result"><span style="color:#3498db;">In Progress</span></div>
                            <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 35 moves</span><span><i class="fas fa-chess-board"></i> Board 1</span></div>
                        </div>
                        <a href="tournament-watch.php?id=<?php echo e($tournamentId); ?>&match=1" class="btn-watch" style="padding:0.4rem 1.2rem;font-size:0.8rem;"><i class="fas fa-eye"></i> Watch</a>
                    </div>
                    <div class="match-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Hikaru Nakamura</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2788)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Fabiano Caruana</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2782)</span>
                            </div>
                        </div>
                        <div style="text-align:center;">
                            <div class="match-result"><span class="draw">Draw</span></div>
                            <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 62 moves</span><span><i class="fas fa-chess-board"></i> Board 2</span></div>
                        </div>
                        <a href="tournament-watch.php?id=<?php echo e($tournamentId); ?>&match=2" class="btn-watch" style="padding:0.4rem 1.2rem;font-size:0.8rem;"><i class="fas fa-eye"></i> Watch</a>
                    </div>
                    <div class="match-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Levon Aronian</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2775)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Wesley So</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2760)</span>
                            </div>
                        </div>
                        <div style="text-align:center;">
                            <div class="match-result"><span class="win">White wins</span></div>
                            <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 48 moves</span><span><i class="fas fa-chess-board"></i> Board 3</span></div>
                        </div>
                        <a href="tournament-watch.php?id=<?php echo e($tournamentId); ?>&match=3" class="btn-watch" style="padding:0.4rem 1.2rem;font-size:0.8rem;"><i class="fas fa-eye"></i> Watch</a>
                    </div>
                    <div class="match-item">
                        <div class="match-players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Anish Giri</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2745)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span style="color:#f0d6b0;">Alireza Firouzja</span>
                                <span style="color:#7a6a5a;font-size:0.7rem;">(2730)</span>
                            </div>
                        </div>
                        <div style="text-align:center;">
                            <div class="match-result"><span class="loss">Black wins</span></div>
                            <div class="match-info"><span><i class="fas fa-exchange-alt"></i> 41 moves</span><span><i class="fas fa-chess-board"></i> Board 4</span></div>
                        </div>
                        <a href="tournament-watch.php?id=<?php echo e($tournamentId); ?>&match=4" class="btn-watch" style="padding:0.4rem 1.2rem;font-size:0.8rem;"><i class="fas fa-eye"></i> Watch</a>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- ===== SCHEDULE ===== -->
        <section class="section" style="padding-top:0;">
            <div class="section-header">
                <h2><i class="fas fa-clock"></i> Schedule</h2>
                <a href="schedule.php?id=<?php echo e($tournamentId); ?>" class="view-all">Full Schedule <i class="fas fa-arrow-right"></i></a>
            </div>
            <div style="background:var(--card-bg);border:1px solid var(--border-color);border-radius:1.2rem;padding:1.5rem;">
                <?php if (!empty($tournamentSchedule)): ?>
                    <?php foreach ($tournamentSchedule as $event): ?>
                        <div class="schedule-item">
                            <div class="schedule-time"><?php echo e($event['time']); ?></div>
                            <div class="schedule-event"><?php echo e($event['event']); ?></div>
                            <div class="schedule-status">
                                <?php if ($event['status'] === 'completed'): ?>
                                    <span style="color:var(--success);">✓ Completed</span>
                                <?php elseif ($event['status'] === 'live'): ?>
                                    <span style="color:var(--danger);animation:pulse-badge 2s infinite;">● Live</span>
                                <?php elseif ($event['status'] === 'upcoming'): ?>
                                    <span style="color:var(--warning);">⏳ Upcoming</span>
                                <?php else: ?>
                                    <span style="color:#7a6a5a;">Scheduled</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="schedule-item">
                        <div class="schedule-time">10:00 AM</div>
                        <div class="schedule-event">Round 1 - Opening Ceremony</div>
                        <div class="schedule-status"><span style="color:var(--success);">✓ Completed</span></div>
                    </div>
                    <div class="schedule-item">
                        <div class="schedule-time">11:30 AM</div>
                        <div class="schedule-event">Round 2 - Main Games</div>
                        <div class="schedule-status"><span style="color:var(--success);">✓ Completed</span></div>
                    </div>
                    <div class="schedule-item">
                        <div class="schedule-time">2:00 PM</div>
                        <div class="schedule-event">Round 3 - Featured Match</div>
                        <div class="schedule-status"><span style="color:var(--danger);animation:pulse-badge 2s infinite;">● Live</span></div>
                    </div>
                    <div class="schedule-item">
                        <div class="schedule-time">4:30 PM</div>
                        <div class="schedule-event">Round 4 - Afternoon Session</div>
                        <div class="schedule-status"><span style="color:var(--warning);">⏳ Upcoming</span></div>
                    </div>
                    <div class="schedule-item">
                        <div class="schedule-time">7:00 PM</div>
                        <div class="schedule-event">Round 5 - Evening Session</div>
                        <div class="schedule-status"><span style="color:#7a6a5a;">Scheduled</span></div>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <!-- ===== ABOUT TOURNAMENT ===== -->
        <section class="section" style="padding-top:0;">
            <div style="background:var(--card-bg);border:1px solid var(--border-color);border-radius:1.2rem;padding:1.5rem;">
                <h3 style="color:#f0d6b0;margin-bottom:0.8rem;display:flex;align-items:center;gap:0.5rem;">
                    <i class="fas fa-info-circle" style="color:var(--secondary);"></i> About This Tournament
                </h3>
                <p style="color:#a09080;line-height:1.8;"><?php echo e($tournamentDetails['description'] ?? 'A prestigious chess tournament featuring the world\'s best players competing for the championship title.'); ?></p>
                
                <?php if (!empty($tournamentDetails['rules'])): ?>
                    <div style="margin-top:1rem;">
                        <h4 style="color:#f0d6b0;font-size:1rem;margin-bottom:0.3rem;">Tournament Rules:</h4>
                        <ul style="color:#a09080;line-height:1.8;list-style:none;padding-left:1rem;">
                            <?php foreach ($tournamentDetails['rules'] as $rule): ?>
                                <li style="padding:0.2rem 0;"><i class="fas fa-check-circle" style="color:var(--secondary);margin-right:0.5rem;"></i> <?php echo e($rule); ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </section>

    <?php else: ?>
        <section class="section" style="padding-top:3rem;">
            <div style="text-align:center;padding:4rem 2rem;">
                <i class="fas fa-exclamation-triangle" style="font-size:4rem;color:var(--secondary);"></i>
                <h2 style="color:#f0d6b0;margin:1rem 0;">Tournament Not Found</h2>
                <p style="color:#a09080;">The tournament you're looking for doesn't exist or has been removed.</p>
                <a href="tournaments.php" class="btn-register" style="display:inline-block;margin-top:1.5rem;padding:0.8rem 2rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-decoration:none;">
                    <i class="fas fa-arrow-left"></i> Back to Tournaments
                </a>
            </div>
        </section>
    <?php endif; ?>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:2rem;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });
    </script>
</body>
</html>
<?php
/**
 * Helper functions for tournament detail page
 */
function getTournamentDetail($id) {
    // Simulated tournament data
    $tournaments = [
        1 => [
            'id' => 1,
            'name' => 'World Chess Championship 2025',
            'status' => 'live',
            'date' => 'Nov 25 - Dec 15, 2025',
            'location' => 'Dubai, UAE',
            'players' => 64,
            'prize' => '2,000,000',
            'time_control' => '90+30',
            'type' => 'Classical',
            'total_rounds' => 14,
            'current_round' => 7,
            'registered_players' => 64,
            'countries' => 32,
            'viewers' => 1247,
            'description' => 'The World Chess Championship is the most prestigious event in chess. This year, the match features defending champion Magnus Carlsen against challenger Ian Nepomniachtchi in a 14-game classical chess match.',
            'rules' => [
                '14-game classical match',
                'First to 7.5 points wins',
                '120 minutes for first 40 moves',
                '60 minutes for next 20 moves',
                '15 minutes for rest of game',
                '30-second increment from move 61'
            ]
        ],
        2 => [
            'id' => 2,
            'name' => 'Grand Chess Tour 2025',
            'status' => 'live',
            'date' => 'Dec 5-10, 2025',
            'location' => 'Paris, France',
            'players' => 32,
            'prize' => '500,000',
            'time_control' => '120+30',
            'type' => 'Rapid',
            'total_rounds' => 8,
            'current_round' => 4,
            'registered_players' => 32,
            'countries' => 18,
            'viewers' => 856,
            'description' => 'The Grand Chess Tour brings together the world\'s elite players in a series of rapid chess events.',
            'rules' => [
                '8-round rapid tournament',
                '25 minutes per player',
                '10-second increment',
                'Double round-robin format',
                'Prize money distributed to top 16'
            ]
        ],
        3 => [
            'id' => 3,
            'name' => 'Chess Heaven Open 2025',
            'status' => 'open',
            'date' => 'Dec 1-8, 2025',
            'location' => 'Online',
            'players' => 200,
            'prize' => '50,000',
            'time_control' => '60+15',
            'type' => 'Classical',
            'total_rounds' => 11,
            'current_round' => 0,
            'registered_players' => 156,
            'countries' => 45,
            'viewers' => 432,
            'description' => 'The Chess Heaven Open is an annual charity tournament open to players of all levels. Proceeds support chess education in underserved communities.',
            'rules' => [
                '11-round Swiss system',
                '60 minutes per player',
                '15-second increment',
                'Open to all players',
                'Charity contribution included'
            ]
        ],
        4 => [
            'id' => 4,
            'name' => 'Grand Chess Tour 2026',
            'status' => 'upcoming',
            'date' => 'Jan 15-20, 2026',
            'location' => 'Paris, France',
            'players' => 32,
            'prize' => '500,000',
            'time_control' => '120+30',
            'type' => 'Rapid',
            'total_rounds' => 8,
            'current_round' => 0,
            'registered_players' => 28,
            'countries' => 16,
            'viewers' => 0,
            'description' => 'The Grand Chess Tour returns with stops in Paris, Dubai, and New York. Top players including Carlsen, Nakamura, and Caruana have confirmed their participation.',
            'rules' => [
                '8-round rapid tournament',
                '25 minutes per player',
                '10-second increment',
                'Double round-robin format',
                'Live broadcast on Chess Heaven'
            ]
        ],
        5 => [
            'id' => 5,
            'name' => "Women's World Championship 2026",
            'status' => 'upcoming',
            'date' => 'Feb 1-12, 2026',
            'location' => 'London, UK',
            'players' => 16,
            'prize' => '150,000',
            'time_control' => '90+30',
            'type' => 'Classical',
            'total_rounds' => 14,
            'current_round' => 0,
            'registered_players' => 16,
            'countries' => 12,
            'viewers' => 0,
            'description' => 'The premier event for women\'s chess. Featuring the top female players competing for the World Championship title.',
            'rules' => [
                '14-game classical match',
                'First to 7.5 points wins',
                '90 minutes for first 40 moves',
                '30-second increment from move 1',
                'Official FIDE regulations apply'
            ]
        ],
        6 => [
            'id' => 6,
            'name' => 'Chess Heaven Open 2026',
            'status' => 'open',
            'date' => 'Mar 10-17, 2026',
            'location' => 'Online',
            'players' => 256,
            'prize' => '50,000',
            'time_control' => '60+15',
            'type' => 'Classical',
            'total_rounds' => 11,
            'current_round' => 0,
            'registered_players' => 189,
            'countries' => 52,
            'viewers' => 0,
            'description' => 'Annual charity tournament open to all players. Now in its 8th year, the Chess Heaven Open continues to grow and support chess education.',
            'rules' => [
                '11-round Swiss system',
                '60 minutes per player',
                '15-second increment',
                'Open to all players',
                'Online platform provided'
            ]
        ],
        7 => [
            'id' => 7,
            'name' => 'World Blitz Championship 2026',
            'status' => 'upcoming',
            'date' => 'Apr 5-8, 2026',
            'location' => 'Moscow, Russia',
            'players' => 64,
            'prize' => '200,000',
            'time_control' => '3+2',
            'type' => 'Blitz',
            'total_rounds' => 21,
            'current_round' => 0,
            'registered_players' => 58,
            'countries' => 28,
            'viewers' => 0,
            'description' => 'The World Blitz Championship features fast-paced chess at the highest level. Players have 3 minutes with a 2-second increment.',
            'rules' => [
                '21-round Swiss system',
                '3 minutes per player',
                '2-second increment',
                'Double round-robin for top 8',
                'Live broadcast on Chess Heaven'
            ]
        ],
        8 => [
            'id' => 8,
            'name' => 'Rapid Chess Championship 2026',
            'status' => 'upcoming',
            'date' => 'May 20-25, 2026',
            'location' => 'New York, USA',
            'players' => 48,
            'prize' => '100,000',
            'time_control' => '15+10',
            'type' => 'Rapid',
            'total_rounds' => 13,
            'current_round' => 0,
            'registered_players' => 42,
            'countries' => 22,
            'viewers' => 0,
            'description' => 'A prestigious rapid chess tournament with a $100,000 prize pool. Featuring top players from around the world.',
            'rules' => [
                '13-round Swiss system',
                '15 minutes per player',
                '10-second increment',
                'FIDE approved tournament',
                'Live commentary available'
            ]
        ],
        9 => [
            'id' => 9,
            'name' => 'Chess Heaven Amateur Cup 2026',
            'status' => 'open',
            'date' => 'Jun 15-22, 2026',
            'location' => 'Online',
            'players' => 128,
            'prize' => '10,000',
            'time_control' => '30+10',
            'type' => 'Classical',
            'total_rounds' => 9,
            'current_round' => 0,
            'registered_players' => 87,
            'countries' => 34,
            'viewers' => 0,
            'description' => 'Free tournament for amateur players under 2000 ELO. A great opportunity to gain tournament experience and win prizes.',
            'rules' => [
                '9-round Swiss system',
                '30 minutes per player',
                '10-second increment',
                'Under 2000 ELO only',
                'Free registration'
            ]
        ],
        10 => [
            'id' => 10,
            'name' => 'World Chess Championship 2024',
            'status' => 'finished',
            'date' => 'Nov 25 - Dec 15, 2024',
            'location' => 'Dubai, UAE',
            'players' => 64,
            'prize' => '2,000,000',
            'time_control' => '90+30',
            'type' => 'Classical',
            'total_rounds' => 14,
            'current_round' => 14,
            'registered_players' => 64,
            'countries' => 32,
            'viewers' => 0,
            'description' => 'The 2024 World Chess Championship was won by Magnus Carlsen, who defeated Ian Nepomniachtchi in a dramatic 12-game match.',
            'rules' => [
                '14-game classical match',
                'First to 7.5 points wins',
                '120 minutes for first 40 moves',
                '60 minutes for next 20 moves',
                '15 minutes for rest of game'
            ]
        ]
    ];
    
    return $tournaments[$id] ?? $tournaments[1];
}

function getTournamentStandings($tournamentId, $limit = 10) {
    // Simulated standings for each tournament
    if ($tournamentId == 1) {
        return [
            ['name' => 'Magnus Carlsen', 'rating' => 2847, 'points' => 6.5, 'wins' => 5, 'draws' => 3, 'losses' => 1, 'score' => 6.5],
            ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'points' => 5.5, 'wins' => 4, 'draws' => 3, 'losses' => 2, 'score' => 5.5],
            ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 5.0, 'wins' => 3, 'draws' => 4, 'losses' => 2, 'score' => 5.0],
            ['name' => 'Fabiano Caruana', 'rating' => 2782, 'points' => 4.5, 'wins' => 3, 'draws' => 3, 'losses' => 3, 'score' => 4.5],
            ['name' => 'Levon Aronian', 'rating' => 2775, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 3, 'score' => 4.0],
            ['name' => 'Wesley So', 'rating' => 2760, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 3, 'score' => 4.0],
            ['name' => 'Anish Giri', 'rating' => 2745, 'points' => 3.5, 'wins' => 2, 'draws' => 3, 'losses' => 4, 'score' => 3.5],
            ['name' => 'Alireza Firouzja', 'rating' => 2730, 'points' => 3.0, 'wins' => 1, 'draws' => 4, 'losses' => 4, 'score' => 3.0],
            ['name' => 'Maxime Vachier-Lagrave', 'rating' => 2720, 'points' => 2.5, 'wins' => 1, 'draws' => 3, 'losses' => 5, 'score' => 2.5],
            ['name' => 'Shakhriyar Mamedyarov', 'rating' => 2715, 'points' => 2.0, 'wins' => 0, 'draws' => 4, 'losses' => 5, 'score' => 2.0]
        ];
    } elseif ($tournamentId == 2) {
        return [
            ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 6.0, 'wins' => 5, 'draws' => 2, 'losses' => 1, 'score' => 6.0],
            ['name' => 'Fabiano Caruana', 'rating' => 2782, 'points' => 5.5, 'wins' => 4, 'draws' => 3, 'losses' => 1, 'score' => 5.5],
            ['name' => 'Magnus Carlsen', 'rating' => 2847, 'points' => 5.0, 'wins' => 3, 'draws' => 4, 'losses' => 1, 'score' => 5.0],
            ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'points' => 4.5, 'wins' => 3, 'draws' => 3, 'losses' => 2, 'score' => 4.5],
            ['name' => 'Levon Aronian', 'rating' => 2775, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 2, 'score' => 4.0],
            ['name' => 'Wesley So', 'rating' => 2760, 'points' => 3.5, 'wins' => 2, 'draws' => 3, 'losses' => 3, 'score' => 3.5],
            ['name' => 'Anish Giri', 'rating' => 2745, 'points' => 3.0, 'wins' => 1, 'draws' => 4, 'losses' => 3, 'score' => 3.0],
            ['name' => 'Alireza Firouzja', 'rating' => 2730, 'points' => 2.5, 'wins' => 1, 'draws' => 3, 'losses' => 4, 'score' => 2.5]
        ];
    } elseif ($tournamentId == 3) {
        return [
            ['name' => 'GM Alex Rodriguez', 'rating' => 2650, 'points' => 9.5, 'wins' => 9, 'draws' => 1, 'losses' => 1, 'score' => 9.5],
            ['name' => 'IM Sarah Lee', 'rating' => 2450, 'points' => 8.5, 'wins' => 7, 'draws' => 3, 'losses' => 1, 'score' => 8.5],
            ['name' => 'FM David Chen', 'rating' => 2380, 'points' => 8.0, 'wins' => 7, 'draws' => 2, 'losses' => 2, 'score' => 8.0],
            ['name' => 'CM Emma Watson', 'rating' => 2350, 'points' => 7.5, 'wins' => 6, 'draws' => 3, 'losses' => 2, 'score' => 7.5],
            ['name' => 'James Thompson', 'rating' => 2280, 'points' => 7.0, 'wins' => 6, 'draws' => 2, 'losses' => 3, 'score' => 7.0]
        ];
    } else {
        return [
            ['name' => 'Magnus Carlsen', 'rating' => 2847, 'points' => 6.5, 'wins' => 5, 'draws' => 3, 'losses' => 1, 'score' => 6.5],
            ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'points' => 5.5, 'wins' => 4, 'draws' => 3, 'losses' => 2, 'score' => 5.5],
            ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 5.0, 'wins' => 3, 'draws' => 4, 'losses' => 2, 'score' => 5.0],
            ['name' => 'Fabiano Caruana', 'rating' => 2782, 'points' => 4.5, 'wins' => 3, 'draws' => 3, 'losses' => 3, 'score' => 4.5],
            ['name' => 'Levon Aronian', 'rating' => 2775, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 3, 'score' => 4.0],
            ['name' => 'Wesley So', 'rating' => 2760, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 3, 'score' => 4.0],
            ['name' => 'Anish Giri', 'rating' => 2745, 'points' => 3.5, 'wins' => 2, 'draws' => 3, 'losses' => 4, 'score' => 3.5],
            ['name' => 'Alireza Firouzja', 'rating' => 2730, 'points' => 3.0, 'wins' => 1, 'draws' => 4, 'losses' => 4, 'score' => 3.0],
            ['name' => 'Maxime Vachier-Lagrave', 'rating' => 2720, 'points' => 2.5, 'wins' => 1, 'draws' => 3, 'losses' => 5, 'score' => 2.5],
            ['name' => 'Shakhriyar Mamedyarov', 'rating' => 2715, 'points' => 2.0, 'wins' => 0, 'draws' => 4, 'losses' => 5, 'score' => 2.0]
        ];
    }
}

function getTournamentMatches($tournamentId, $limit = 8) {
    // Simulated matches
    if ($tournamentId == 1) {
        return [
            ['id' => 1, 'board' => 1, 'round' => 7, 'white' => 'Magnus Carlsen', 'white_rating' => '2847', 'black' => 'Ian Nepomniachtchi', 'black_rating' => '2795', 'result' => 'in_progress', 'moves' => 35],
            ['id' => 2, 'board' => 2, 'round' => 7, 'white' => 'Hikaru Nakamura', 'white_rating' => '2788', 'black' => 'Fabiano Caruana', 'black_rating' => '2782', 'result' => 'draw', 'moves' => 62],
            ['id' => 3, 'board' => 3, 'round' => 7, 'white' => 'Levon Aronian', 'white_rating' => '2775', 'black' => 'Wesley So', 'black_rating' => '2760', 'result' => 'win', 'winner' => 'White', 'moves' => 48],
            ['id' => 4, 'board' => 4, 'round' => 7, 'white' => 'Anish Giri', 'white_rating' => '2745', 'black' => 'Alireza Firouzja', 'black_rating' => '2730', 'result' => 'loss', 'winner' => 'Black', 'moves' => 41]
        ];
    } elseif ($tournamentId == 2) {
        return [
            ['id' => 1, 'board' => 1, 'round' => 4, 'white' => 'Hikaru Nakamura', 'white_rating' => '2788', 'black' => 'Fabiano Caruana', 'black_rating' => '2782', 'result' => 'in_progress', 'moves' => 28],
            ['id' => 2, 'board' => 2, 'round' => 4, 'white' => 'Magnus Carlsen', 'white_rating' => '2847', 'black' => 'Ian Nepomniachtchi', 'black_rating' => '2795', 'result' => 'win', 'winner' => 'White', 'moves' => 34],
            ['id' => 3, 'board' => 3, 'round' => 4, 'white' => 'Levon Aronian', 'white_rating' => '2775', 'black' => 'Wesley So', 'black_rating' => '2760', 'result' => 'draw', 'moves' => 45],
            ['id' => 4, 'board' => 4, 'round' => 4, 'white' => 'Anish Giri', 'white_rating' => '2745', 'black' => 'Alireza Firouzja', 'black_rating' => '2730', 'result' => 'loss', 'winner' => 'Black', 'moves' => 38]
        ];
    } else {
        return [
            ['id' => 1, 'board' => 1, 'round' => 1, 'white' => 'Magnus Carlsen', 'white_rating' => '2847', 'black' => 'Ian Nepomniachtchi', 'black_rating' => '2795', 'result' => 'in_progress', 'moves' => 0],
            ['id' => 2, 'board' => 2, 'round' => 1, 'white' => 'Hikaru Nakamura', 'white_rating' => '2788', 'black' => 'Fabiano Caruana', 'black_rating' => '2782', 'result' => 'in_progress', 'moves' => 0]
        ];
    }
}

function getTournamentSchedule($tournamentId) {
    // Simulated schedule
    if ($tournamentId == 1) {
        return [
            ['time' => '10:00 AM', 'event' => 'Round 1 - Opening Ceremony', 'status' => 'completed'],
            ['time' => '11:30 AM', 'event' => 'Round 2 - Main Games', 'status' => 'completed'],
            ['time' => '2:00 PM', 'event' => 'Round 3 - Featured Match', 'status' => 'completed'],
            ['time' => '4:30 PM', 'event' => 'Round 4 - Afternoon Session', 'status' => 'completed'],
            ['time' => '7:00 PM', 'event' => 'Round 5 - Evening Session', 'status' => 'completed'],
            ['time' => '9:30 PM', 'event' => 'Round 6 - Night Session', 'status' => 'completed'],
            ['time' => '11:00 AM', 'event' => 'Round 7 - Day 2 Opening', 'status' => 'live']
        ];
    } else {
        return [
            ['time' => '10:00 AM', 'event' => 'Opening Ceremony', 'status' => 'completed'],
            ['time' => '11:30 AM', 'event' => 'Round 1', 'status' => 'completed'],
            ['time' => '2:00 PM', 'event' => 'Round 2', 'status' => 'completed'],
            ['time' => '4:30 PM', 'event' => 'Round 3', 'status' => 'live'],
            ['time' => '7:00 PM', 'event' => 'Round 4', 'status' => 'upcoming'],
            ['time' => '9:30 PM', 'event' => 'Round 5', 'status' => 'upcoming']
        ];
    }
}
?>