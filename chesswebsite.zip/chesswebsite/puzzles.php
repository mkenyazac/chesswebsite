<?php
/**
 * Chess Heaven - Puzzles Page
 * Complete puzzle hub with daily puzzles, tactical challenges, and interactive chess board
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get puzzle data
$dailyPuzzle = getDailyPuzzle();
$puzzleCategories = getPuzzleCategories();
$tacticalPuzzles = getTacticalPuzzles(12);
$puzzleStats = getPuzzleStats();
$puzzleLeaderboard = getPuzzleLeaderboard(5);
$featuredPuzzles = getFeaturedPuzzles(4);
$puzzleThemes = getPuzzleThemes();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Chess Puzzles</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
            position:relative;
            overflow:hidden;
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }
        .card .badge {
            position:absolute;
            top:1rem;
            right:1rem;
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .badge-easy { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .badge-medium { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .badge-hard { background:rgba(231,76,60,0.2); color:#e74c3c; }
        .badge-expert { background:rgba(155,89,182,0.2); color:#9b59b6; }
        .badge-solved { background:rgba(46,204,113,0.2); color:#2ecc71; }

        /* ===== HERO ===== */
        .puzzle-hero {
            text-align:center;
            padding:3rem 2rem;
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem;
            border:1px solid var(--border-color);
            margin:2rem;
        }
        .puzzle-hero h1 {
            font-size:2.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:1rem;
        }
        .puzzle-hero p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
        }
        .puzzle-hero .stats-row {
            display:flex;
            justify-content:center;
            gap:3rem;
            margin-top:1.5rem;
            flex-wrap:wrap;
        }
        .puzzle-hero .stats-row .stat-item {
            text-align:center;
        }
        .puzzle-hero .stats-row .stat-item .stat-number {
            font-size:2rem;
            font-weight:700;
            color:var(--gold);
        }
        .puzzle-hero .stats-row .stat-item .stat-label {
            color:#7a6a5a;
            font-size:0.85rem;
        }

        /* ===== DAILY PUZZLE ===== */
        .daily-puzzle-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));
            border-radius:2rem;
            padding:2rem;
            border:2px solid var(--gold);
            margin-bottom:2rem;
        }
        .daily-puzzle-container {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
            align-items:start;
        }
        .puzzle-board-wrapper {
            background:rgba(0,0,0,0.4);
            border-radius:1.5rem;
            padding:1.5rem;
            border:2px solid var(--border-color);
        }
        .puzzle-board-wrapper .board-title {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:0.8rem;
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .puzzle-board-wrapper .board-title .turn-indicator {
            display:flex;
            align-items:center;
            gap:0.5rem;
            color:var(--secondary);
            font-size:0.85rem;
        }
        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:500px;
            aspect-ratio:1;
            margin:0 auto;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
            transition:transform 0.3s ease;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.8rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
            position:relative;
        }
        .chess-board .square.light { background:var(--light-square); }
        .chess-board .square.dark { background:var(--dark-square); }
        .chess-board .square.highlight {
            background:rgba(255,255,0,0.4) !important;
            box-shadow:inset 0 0 20px rgba(255,255,0,0.3);
        }
        .chess-board .square.last-move {
            background:rgba(255,255,100,0.3) !important;
        }
        .chess-board .square.legal-move::after {
            content:'';
            position:absolute;
            width:30%;
            height:30%;
            background:rgba(0,0,0,0.2);
            border-radius:50%;
            pointer-events:none;
        }
        .chess-board .square.legal-capture {
            box-shadow:inset 0 0 0 4px rgba(0,0,0,0.3);
            border-radius:50%;
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
            pointer-events:none;
            z-index:1;
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }
        .chess-board .square .coords {
            position:absolute;
            font-size:0.55rem;
            color:rgba(0,0,0,0.3);
            pointer-events:none;
            font-weight:600;
        }
        .chess-board .square .coords.file { bottom:2px; right:4px; }
        .chess-board .square .coords.rank { top:2px; left:4px; }
        .chess-board .square.dark .coords { color:rgba(255,255,255,0.3); }
        .chess-board .square.check {
            background:rgba(255,0,0,0.3) !important;
        }

        .board-controls {
            display:flex;
            gap:0.6rem;
            flex-wrap:wrap;
            justify-content:center;
            margin-top:0.8rem;
            width:100%;
        }
        .board-controls button {
            padding:0.4rem 0.9rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.75rem;
            display:inline-flex;
            align-items:center;
            gap:0.4rem;
        }
        .btn-nav {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-nav:hover { background:rgba(198,151,107,0.25); }
        .btn-nav:disabled {
            opacity:0.3;
            cursor:not-allowed;
        }
        .btn-reset-board {
            background:rgba(255,255,255,0.05);
            color:#a09080;
            border:1px solid rgba(255,255,255,0.1) !important;
        }
        .btn-reset-board:hover { background:rgba(255,255,255,0.1); }
        .btn-flip-board {
            background:rgba(46,204,113,0.15);
            color:#2ecc71;
            border:1px solid #2ecc71 !important;
        }
        .btn-flip-board:hover { background:rgba(46,204,113,0.25); }

        .puzzle-info h2 {
            color:#f0d6b0;
            font-size:1.8rem;
            margin-bottom:0.5rem;
        }
        .puzzle-info .puzzle-meta {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            margin:0.5rem 0;
        }
        .puzzle-info .puzzle-meta span {
            color:#a09080;
            font-size:0.85rem;
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .puzzle-info .puzzle-description {
            color:#a09080;
            line-height:1.8;
            margin:0.8rem 0;
        }
        .puzzle-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            margin-top:1rem;
        }
        .puzzle-actions button {
            padding:0.7rem 1.5rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .btn-hint {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-hint:hover { background:rgba(198,151,107,0.25); transform:translateY(-2px); }
        .btn-solution {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .btn-solution:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .btn-next {
            background:rgba(52,152,219,0.15);
            color:#3498db;
            border:1px solid #3498db !important;
        }
        .btn-next:hover { background:rgba(52,152,219,0.25); transform:translateY(-2px); }
        .btn-correct {
            background:rgba(46,204,113,0.15);
            color:#2ecc71;
            border:1px solid #2ecc71 !important;
        }
        .btn-correct:hover { background:rgba(46,204,113,0.25); transform:translateY(-2px); }
        .btn-wrong {
            background:rgba(231,76,60,0.15);
            color:#e74c3c;
            border:1px solid #e74c3c !important;
        }
        .btn-wrong:hover { background:rgba(231,76,60,0.25); transform:translateY(-2px); }

        .feedback-display {
            margin-top:0.8rem;
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            font-size:0.9rem;
            display:none;
        }
        .feedback-display.success {
            display:block;
            background:rgba(46,204,113,0.15);
            border:1px solid rgba(46,204,113,0.3);
            color:#2ecc71;
        }
        .feedback-display.error {
            display:block;
            background:rgba(231,76,60,0.15);
            border:1px solid rgba(231,76,60,0.3);
            color:#e74c3c;
        }
        .feedback-display.info {
            display:block;
            background:rgba(52,152,219,0.15);
            border:1px solid rgba(52,152,219,0.3);
            color:#3498db;
        }

        /* ===== CATEGORY FILTERS ===== */
        .category-filters {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            justify-content:center;
            margin:1rem 0 2rem;
        }
        .category-filters button {
            padding:0.5rem 1.5rem;
            border-radius:2rem;
            border:2px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.85rem;
        }
        .category-filters button:hover,
        .category-filters button.active {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }

        /* ===== THEME CARDS ===== */
        .theme-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            text-align:center;
            transition:all 0.3s;
            cursor:pointer;
        }
        .theme-card:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-5px);
        }
        .theme-card i {
            font-size:2.5rem;
            color:var(--secondary);
            margin-bottom:0.5rem;
        }
        .theme-card h3 {
            color:#f0d6b0;
            font-size:1rem;
        }
        .theme-card p {
            color:#a09080;
            font-size:0.85rem;
        }
        .theme-card .theme-count {
            color:#7a6a5a;
            font-size:0.75rem;
            margin-top:0.5rem;
        }

        /* ===== LEADERBOARD ===== */
        .leaderboard-table {
            background:var(--card-bg); border-radius:1.5rem;
            padding:1.5rem; border:1px solid var(--border-color);
            overflow-x:auto;
        }
        .leaderboard-table table { width:100%; border-collapse:collapse; }
        .leaderboard-table th {
            color:#7a6a5a; border-bottom:1px solid var(--border-color);
            padding:0.8rem; text-align:left;
        }
        .leaderboard-table td { padding:0.8rem; border-bottom:1px solid rgba(255,255,255,0.03); }
        .leaderboard-table tr:last-child td { border-bottom:none; }
        .rank-gold { color:var(--gold); font-weight:700; }
        .rank-silver { color:#c0c0c0; font-weight:700; }
        .rank-bronze { color:#cd7f32; font-weight:700; }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .daily-puzzle-container {
                grid-template-columns:1fr;
            }
            .chess-board { max-width:400px; }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .puzzle-hero { margin:1rem; padding:2rem 1rem; }
            .puzzle-hero h1 { font-size:2rem; flex-direction:column; }
            .puzzle-hero .stats-row { gap:1.5rem; }
            .puzzle-hero .stats-row .stat-item .stat-number { font-size:1.5rem; }
            .daily-puzzle-section { padding:1.5rem; }
            .card-grid { grid-template-columns:1fr; }
            .category-filters button { padding:0.3rem 1rem; font-size:0.75rem; }
            .chess-board .square .piece { font-size:2rem; }
            .chess-board { max-width:100%; }
            .puzzle-board-wrapper { padding:0.8rem; }
        }
        @media (max-width:480px) {
            .section-header h2 { font-size:1.3rem; }
            .puzzle-hero h1 { font-size:1.5rem; }
            .puzzle-actions { flex-direction:column; }
            .puzzle-actions button { width:100%; justify-content:center; }
            .chess-board .square .piece { font-size:1.5rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php" class="active-link"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="openings.php"><i class="fas fa-book-open"></i> Openings</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <div class="puzzle-hero">
        <h1>
            <i class="fas fa-puzzle-piece"></i>
            Chess Puzzles
            <i class="fas fa-brain"></i>
        </h1>
        <p>Sharpen your tactical skills with our collection of chess puzzles. From beginner to expert level.</p>
        <div class="stats-row">
            <div class="stat-item">
                <div class="stat-number"><?php echo e($puzzleStats['total'] ?? 150); ?></div>
                <div class="stat-label">Total Puzzles</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo e($puzzleStats['solved'] ?? 42); ?></div>
                <div class="stat-label">Solved</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo e($puzzleStats['streak'] ?? 7); ?></div>
                <div class="stat-label">Current Streak</div>
            </div>
            <div class="stat-item">
                <div class="stat-number"><?php echo e($puzzleStats['rating'] ?? 1850); ?></div>
                <div class="stat-label">Puzzle Rating</div>
            </div>
        </div>
    </div>

    <!-- ===== DAILY PUZZLE ===== -->
    <section class="section" style="padding-top:0;">
        <div class="daily-puzzle-section">
            <div class="section-header">
                <h2><i class="fas fa-calendar-day"></i> Daily Puzzle</h2>
                <span style="color:var(--gold);font-size:0.85rem;"><?php echo date('F j, Y'); ?></span>
            </div>
            <div class="daily-puzzle-container">
                <div class="puzzle-board-wrapper">
                    <div class="board-title">
                        <span class="turn-indicator">
                            <span id="puzzleTurnIndicator">⚪ White to move</span>
                        </span>
                        <span style="color:#7a6a5a;font-size:0.75rem;" id="puzzleMoveCounter">Move 0</span>
                    </div>
                    <div class="chess-board" id="puzzleBoard"></div>
                    <div class="board-controls">
                        <button class="btn-nav" id="puzzlePrevBtn" onclick="prevPuzzleMove()">
                            <i class="fas fa-chevron-left"></i> Prev
                        </button>
                        <button class="btn-nav" id="puzzleNextBtn" onclick="nextPuzzleMove()">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                        <button class="btn-reset-board" onclick="resetPuzzleBoard()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                        <button class="btn-flip-board" onclick="flipPuzzleBoard()">
                            <i class="fas fa-sync-alt"></i> Flip
                        </button>
                        <button class="btn-nav" onclick="togglePuzzleAutoPlay()" id="puzzleAutoBtn">
                            <i class="fas fa-play"></i> Auto
                        </button>
                    </div>
                </div>
                <div class="puzzle-info">
                    <h2 id="puzzleTitle"><?php echo e($dailyPuzzle['title'] ?? 'Mate in 2'); ?></h2>
                    <div class="puzzle-meta">
                        <span><i class="fas fa-signal"></i> Difficulty: <span class="badge badge-<?php echo e($dailyPuzzle['difficulty'] ?? 'medium'); ?>" style="position:static;display:inline-block;padding:0.1rem 0.6rem;"><?php echo e(ucfirst($dailyPuzzle['difficulty'] ?? 'Medium')); ?></span></span>
                        <span><i class="fas fa-users"></i> <span id="puzzleAttempts"><?php echo e($dailyPuzzle['attempts'] ?? 342); ?></span> attempts</span>
                        <span><i class="fas fa-check-circle"></i> <span id="puzzleSuccessRate"><?php echo e($dailyPuzzle['success_rate'] ?? 45); ?></span>% solved</span>
                    </div>
                    <p class="puzzle-description" id="puzzleDescription"><?php echo e($dailyPuzzle['description'] ?? 'Find the winning move. White to play and mate in 2.'); ?></p>
                    
                    <div class="puzzle-actions">
                        <button class="btn-hint" onclick="showPuzzleHint()"><i class="fas fa-lightbulb"></i> Hint</button>
                        <button class="btn-solution" onclick="showPuzzleSolution()"><i class="fas fa-eye"></i> Show Solution</button>
                        <button class="btn-next" onclick="nextPuzzle()"><i class="fas fa-forward"></i> Next</button>
                        <button class="btn-correct" onclick="markPuzzleCorrect()"><i class="fas fa-check"></i> Correct</button>
                        <button class="btn-wrong" onclick="markPuzzleWrong()"><i class="fas fa-times"></i> Wrong</button>
                    </div>
                    
                    <div class="feedback-display" id="puzzleFeedback"></div>
                    <div id="puzzleHintDisplay" style="margin-top:0.5rem;color:var(--secondary);font-size:0.9rem;display:none;"></div>
                    <div id="puzzleSolutionDisplay" style="margin-top:0.5rem;color:var(--gold);font-size:0.9rem;display:none;"></div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== CATEGORY FILTERS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="category-filters" id="categoryFilters">
            <button class="active" onclick="filterCategory('all')">All Puzzles</button>
            <?php if (!empty($puzzleCategories)): ?>
                <?php foreach ($puzzleCategories as $category): ?>
                    <button onclick="filterCategory('<?php echo e($category['slug']); ?>')"><?php echo e($category['name']); ?></button>
                <?php endforeach; ?>
            <?php else: ?>
                <button onclick="filterCategory('mate')">Checkmate</button>
                <button onclick="filterCategory('fork')">Forks</button>
                <button onclick="filterCategory('pin')">Pins</button>
                <button onclick="filterCategory('skewer')">Skewers</button>
                <button onclick="filterCategory('sacrifice')">Sacrifices</button>
                <button onclick="filterCategory('endgame')">Endgame</button>
                <button onclick="filterCategory('opening')">Opening Traps</button>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== TACTICAL PUZZLES ===== -->
    <section class="section" style="padding-top:0;">
        <div class="section-header">
            <h2><i class="fas fa-bolt"></i> Tactical Puzzles</h2>
            <a href="all-puzzles.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid" id="puzzleGrid">
            <?php if (!empty($tacticalPuzzles)): ?>
                <?php foreach ($tacticalPuzzles as $puzzle): ?>
                    <a href="puzzle.php?id=<?php echo e($puzzle['id']); ?>" class="card" data-category="<?php echo e($puzzle['category'] ?? 'all'); ?>" onclick="loadPuzzle(<?php echo e($puzzle['id']); ?>); return false;">
                        <span class="badge badge-<?php echo e($puzzle['difficulty'] ?? 'medium'); ?>"><?php echo e(ucfirst($puzzle['difficulty'] ?? 'Medium')); ?></span>
                        <?php if ($puzzle['solved'] ?? false): ?>
                            <span class="badge badge-solved" style="right:5.5rem;">Solved</span>
                        <?php endif; ?>
                        <i class="fas fa-<?php echo e($puzzle['icon'] ?? 'chess'); ?>"></i>
                        <h3><?php echo e($puzzle['title']); ?></h3>
                        <p><?php echo e($puzzle['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-signal"></i> <?php echo e(ucfirst($puzzle['difficulty'] ?? 'Medium')); ?></span>
                            <span><i class="fas fa-check-circle"></i> <?php echo e($puzzle['solved_percent'] ?? 60); ?>% solved</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="#" class="card" data-category="mate" onclick="loadPuzzlePreset('mate1'); return false;">
                    <span class="badge badge-easy">Easy</span>
                    <i class="fas fa-chess-king"></i>
                    <h3>Checkmate in 1</h3>
                    <p>Find the immediate checkmate. White to play.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Easy</span><span><i class="fas fa-check-circle"></i> 78% solved</span></div>
                </a>
                <a href="#" class="card" data-category="fork" onclick="loadPuzzlePreset('fork'); return false;">
                    <span class="badge badge-medium">Medium</span>
                    <i class="fas fa-chess-knight"></i>
                    <h3>Royal Fork</h3>
                    <p>Use a knight fork to win the queen.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Medium</span><span><i class="fas fa-check-circle"></i> 55% solved</span></div>
                </a>
                <a href="#" class="card" data-category="pin" onclick="loadPuzzlePreset('pin'); return false;">
                    <span class="badge badge-medium">Medium</span>
                    <i class="fas fa-chess-queen"></i>
                    <h3>Pin to Win</h3>
                    <p>Exploit a pin to win material.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Medium</span><span><i class="fas fa-check-circle"></i> 48% solved</span></div>
                </a>
                <a href="#" class="card" data-category="skewer" onclick="loadPuzzlePreset('skewer'); return false;">
                    <span class="badge badge-medium">Medium</span>
                    <i class="fas fa-chess-rook"></i>
                    <h3>Skewer Tactic</h3>
                    <p>Use a skewer to win the queen.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Medium</span><span><i class="fas fa-check-circle"></i> 52% solved</span></div>
                </a>
                <a href="#" class="card" data-category="sacrifice" onclick="loadPuzzlePreset('sacrifice'); return false;">
                    <span class="badge badge-hard">Hard</span>
                    <i class="fas fa-fire"></i>
                    <h3>Queen Sacrifice</h3>
                    <p>Sacrifice your queen for a winning attack.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Hard</span><span><i class="fas fa-check-circle"></i> 32% solved</span></div>
                </a>
                <a href="#" class="card" data-category="endgame" onclick="loadPuzzlePreset('endgame'); return false;">
                    <span class="badge badge-hard">Hard</span>
                    <i class="fas fa-chess-pawn"></i>
                    <h3>Endgame Position</h3>
                    <p>Convert the winning endgame.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Hard</span><span><i class="fas fa-check-circle"></i> 28% solved</span></div>
                </a>
                <a href="#" class="card" data-category="mate" onclick="loadPuzzlePreset('mate2'); return false;">
                    <span class="badge badge-medium">Medium</span>
                    <i class="fas fa-chess-queen"></i>
                    <h3>Mate in 2</h3>
                    <p>Find the forced mate in 2 moves.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Medium</span><span><i class="fas fa-check-circle"></i> 62% solved</span></div>
                </a>
                <a href="#" class="card" data-category="sacrifice" onclick="loadPuzzlePreset('discovered'); return false;">
                    <span class="badge badge-hard">Hard</span>
                    <i class="fas fa-bolt"></i>
                    <h3>Discovered Attack</h3>
                    <p>Unleash a devastating discovered attack.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Hard</span><span><i class="fas fa-check-circle"></i> 35% solved</span></div>
                </a>
                <a href="#" class="card" data-category="opening" onclick="loadPuzzlePreset('opening'); return false;">
                    <span class="badge badge-easy">Easy</span>
                    <i class="fas fa-chess-knight"></i>
                    <h3>Opening Trap</h3>
                    <p>Win material with an opening trap.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Easy</span><span><i class="fas fa-check-circle"></i> 72% solved</span></div>
                </a>
                <a href="#" class="card" data-category="sacrifice" onclick="loadPuzzlePreset('zwischenzug'); return false;">
                    <span class="badge badge-expert">Expert</span>
                    <i class="fas fa-brain"></i>
                    <h3>Zwischenzug</h3>
                    <p>Find the intermediate move that wins.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Expert</span><span><i class="fas fa-check-circle"></i> 18% solved</span></div>
                </a>
                <a href="#" class="card" data-category="endgame" onclick="loadPuzzlePreset('endgame2'); return false;">
                    <span class="badge badge-medium">Medium</span>
                    <i class="fas fa-chess-king"></i>
                    <h3>King and Pawn Endgame</h3>
                    <p>Win the key king and pawn endgame.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Medium</span><span><i class="fas fa-check-circle"></i> 44% solved</span></div>
                </a>
                <a href="#" class="card" data-category="mate" onclick="loadPuzzlePreset('mate3'); return false;">
                    <span class="badge badge-hard">Hard</span>
                    <i class="fas fa-chess-king"></i>
                    <h3>Mate in 3</h3>
                    <p>Find the beautiful mate in 3 moves.</p>
                    <div class="meta"><span><i class="fas fa-signal"></i> Hard</span><span><i class="fas fa-check-circle"></i> 25% solved</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== PUZZLE THEMES ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-tags"></i> Puzzle Themes</h2>
            <a href="themes.php" class="view-all">All Themes <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($puzzleThemes)): ?>
                <?php foreach ($puzzleThemes as $theme): ?>
                    <a href="theme.php?id=<?php echo e($theme['id']); ?>" class="theme-card">
                        <i class="fas fa-<?php echo e($theme['icon'] ?? 'tag'); ?>"></i>
                        <h3><?php echo e($theme['name']); ?></h3>
                        <p><?php echo e($theme['description']); ?></p>
                        <div class="theme-count"><?php echo e($theme['count'] ?? 0); ?> puzzles</div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="theme-mate.php" class="theme-card">
                    <i class="fas fa-chess-king"></i>
                    <h3>Checkmate</h3>
                    <p>Practice checkmate patterns</p>
                    <div class="theme-count">24 puzzles</div>
                </a>
                <a href="theme-fork.php" class="theme-card">
                    <i class="fas fa-chess-knight"></i>
                    <h3>Forks</h3>
                    <p>Master the fork tactic</p>
                    <div class="theme-count">18 puzzles</div>
                </a>
                <a href="theme-pin.php" class="theme-card">
                    <i class="fas fa-chess-queen"></i>
                    <h3>Pins</h3>
                    <p>Practice pinning pieces</p>
                    <div class="theme-count">15 puzzles</div>
                </a>
                <a href="theme-skewer.php" class="theme-card">
                    <i class="fas fa-chess-rook"></i>
                    <h3>Skewers</h3>
                    <p>Master the skewer tactic</p>
                    <div class="theme-count">12 puzzles</div>
                </a>
                <a href="theme-sacrifice.php" class="theme-card">
                    <i class="fas fa-fire"></i>
                    <h3>Sacrifices</h3>
                    <p>Learn when to sacrifice</p>
                    <div class="theme-count">20 puzzles</div>
                </a>
                <a href="theme-endgame.php" class="theme-card">
                    <i class="fas fa-chess-pawn"></i>
                    <h3>Endgame</h3>
                    <p>Endgame position puzzles</p>
                    <div class="theme-count">16 puzzles</div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== FEATURED PUZZLES ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-star"></i> Featured Puzzles</h2>
            <a href="featured.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($featuredPuzzles)): ?>
                <?php foreach ($featuredPuzzles as $puzzle): ?>
                    <a href="puzzle.php?id=<?php echo e($puzzle['id']); ?>" class="card" style="border-color:var(--gold);" onclick="loadPuzzle(<?php echo e($puzzle['id']); ?>); return false;">
                        <span class="badge badge-<?php echo e($puzzle['difficulty'] ?? 'medium'); ?>"><?php echo e(ucfirst($puzzle['difficulty'] ?? 'Medium')); ?></span>
                        <i class="fas fa-<?php echo e($puzzle['icon'] ?? 'star'); ?>" style="color:var(--gold);"></i>
                        <h3><?php echo e($puzzle['title']); ?></h3>
                        <p><?php echo e($puzzle['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-user"></i> <?php echo e($puzzle['author'] ?? 'Chess Heaven'); ?></span>
                            <span><i class="fas fa-check-circle"></i> <?php echo e($puzzle['solved_percent'] ?? 65); ?>% solved</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="#" class="card" style="border-color:var(--gold);" onclick="loadPuzzlePreset('immortal'); return false;">
                    <span class="badge badge-medium">Medium</span>
                    <i class="fas fa-star" style="color:var(--gold);"></i>
                    <h3>Immortal Puzzle</h3>
                    <p>Find the famous move from the Immortal Game.</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Anderssen</span><span><i class="fas fa-check-circle"></i> 72% solved</span></div>
                </a>
                <a href="#" class="card" style="border-color:var(--gold);" onclick="loadPuzzlePreset('sacrifice2'); return false;">
                    <span class="badge badge-hard">Hard</span>
                    <i class="fas fa-star" style="color:var(--gold);"></i>
                    <h3>Queen's Sacrifice</h3>
                    <p>The brilliant queen sacrifice that won the game.</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Fischer</span><span><i class="fas fa-check-circle"></i> 34% solved</span></div>
                </a>
                <a href="#" class="card" style="border-color:var(--gold);" onclick="loadPuzzlePreset('matebeautiful'); return false;">
                    <span class="badge badge-easy">Easy</span>
                    <i class="fas fa-star" style="color:var(--gold);"></i>
                    <h3>Beautiful Mate</h3>
                    <p>A stunning checkmate pattern.</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Morphy</span><span><i class="fas fa-check-circle"></i> 81% solved</span></div>
                </a>
                <a href="#" class="card" style="border-color:var(--gold);" onclick="loadPuzzlePreset('kasparov'); return false;">
                    <span class="badge badge-expert">Expert</span>
                    <i class="fas fa-star" style="color:var(--gold);"></i>
                    <h3>Kasparov's Masterpiece</h3>
                    <p>Find the winning combination from Kasparov's immortal.</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Kasparov</span><span><i class="fas fa-check-circle"></i> 22% solved</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LEADERBOARD ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-trophy"></i> Puzzle Leaderboard</h2>
            <a href="puzzle-rankings.php" class="view-all">Full Rankings <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="leaderboard-table">
            <table>
                <thead>
                    <tr>
                        <th style="text-align:left;">#</th>
                        <th style="text-align:left;">Player</th>
                        <th style="text-align:center;">Puzzle Rating</th>
                        <th style="text-align:center;">Solved</th>
                        <th style="text-align:center;">Streak</th>
                        <th style="text-align:center;">Accuracy</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($puzzleLeaderboard)): ?>
                        <?php foreach ($puzzleLeaderboard as $index => $player): ?>
                            <tr>
                                <td class="<?php echo $index < 3 ? 'rank-' . ['gold','silver','bronze'][$index] : ''; ?>"><?php echo e($index + 1); ?></td>
                                <td style="color:#f0d6b0;"><?php echo e($player['name']); ?></td>
                                <td style="text-align:center;color:var(--secondary);font-weight:600;"><?php echo e($player['rating']); ?></td>
                                <td style="text-align:center;color:var(--success);"><?php echo e($player['solved']); ?></td>
                                <td style="text-align:center;color:#f1c40f;"><?php echo e($player['streak']); ?>🔥</td>
                                <td style="text-align:center;color:#3498db;"><?php echo e($player['accuracy']); ?>%</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td class="rank-gold">1</td><td style="color:#f0d6b0;">TacticalMaster</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2450</td><td style="text-align:center;color:var(--success);">342</td><td style="text-align:center;color:#f1c40f;">15🔥</td><td style="text-align:center;color:#3498db;">92%</td></tr>
                        <tr><td class="rank-silver">2</td><td style="color:#f0d6b0;">PuzzleKing</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2380</td><td style="text-align:center;color:var(--success);">298</td><td style="text-align:center;color:#f1c40f;">12🔥</td><td style="text-align:center;color:#3498db;">88%</td></tr>
                        <tr><td class="rank-bronze">3</td><td style="color:#f0d6b0;">ChessTactician</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2315</td><td style="text-align:center;color:var(--success);">276</td><td style="text-align:center;color:#f1c40f;">8🔥</td><td style="text-align:center;color:#3498db;">85%</td></tr>
                        <tr><td>4</td><td style="color:#f0d6b0;">StrategyPro</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2250</td><td style="text-align:center;color:var(--success);">245</td><td style="text-align:center;color:#f1c40f;">6🔥</td><td style="text-align:center;color:#3498db;">82%</td></tr>
                        <tr><td>5</td><td style="color:#f0d6b0;">TacticalGenius</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2190</td><td style="text-align:center;color:var(--success);">212</td><td style="text-align:center;color:#f1c40f;">4🔥</td><td style="text-align:center;color:#3498db;">79%</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- ===== TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:var(--card-bg);border-radius:1.5rem;padding:2rem;border:1px solid var(--border-color);text-align:center;">
            <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--secondary);"></i>
            <h3 style="color:#f0d6b0;margin:0.5rem 0;">Puzzle Solving Tips</h3>
            <p style="color:#a09080;max-width:600px;margin:0 auto;">
                <i class="fas fa-chess-pawn"></i> Look for forcing moves: checks, captures, and threats.
                <br>
                <span style="color:var(--secondary);font-size:0.85rem;">"Tactics flow from a superior position." — Bobby Fischer</span>
            </p>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== PIECE SYMBOLS =====
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // ===== PUZZLE BOARD STATE =====
        let puzzleBoard = [];
        let puzzleStep = 0;
        let puzzleSteps = [];
        let isPuzzleFlipped = false;
        let puzzleAutoInterval = null;
        let isPuzzleAutoPlaying = false;
        let selectedPuzzleSquare = null;

        // ===== PUZZLE DATA =====
        const PUZZLE_PRESETS = {
            'mate1': {
                title: 'Checkmate in 1',
                description: 'Find the immediate checkmate. White to play.',
                difficulty: 'easy',
                icon: 'chess-king',
                attempts: 456,
                success_rate: 78,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','p','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qh5+! Kd8 2. Qe8#',
                hint: 'Look for a move that attacks the king and can\'t be blocked.'
            },
            'fork': {
                title: 'Royal Fork',
                description: 'Use a knight fork to win the queen.',
                difficulty: 'medium',
                icon: 'chess-knight',
                attempts: 320,
                success_rate: 55,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','N','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','','B','Q','K','B','N','R']
                ],
                solution: '1. Nf7+! Rxf7 2. Qxf7+ Kxf7 3. Rxf7#',
                hint: 'The knight can jump to f7 to attack both the king and queen.'
            },
            'pin': {
                title: 'Pin to Win',
                description: 'Exploit a pin to win material.',
                difficulty: 'medium',
                icon: 'chess-queen',
                attempts: 280,
                success_rate: 48,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','B','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Bxf7+! Kxf7 2. Qe6+ Kf8 3. Qe8#',
                hint: 'The bishop can capture on f7, exposing the queen\'s attack.'
            },
            'skewer': {
                title: 'Skewer Tactic',
                description: 'Use a skewer to win the queen.',
                difficulty: 'medium',
                icon: 'chess-rook',
                attempts: 300,
                success_rate: 52,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Rxh7+! Kxh7 2. Qh5+ Kg8 3. Qh8#',
                hint: 'The rook can sacrifice itself on h7 to open the h-file.'
            },
            'sacrifice': {
                title: 'Queen Sacrifice',
                description: 'Sacrifice your queen for a winning attack.',
                difficulty: 'hard',
                icon: 'fire',
                attempts: 200,
                success_rate: 32,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'The queen can capture on f7, forcing the rook to take.'
            },
            'endgame': {
                title: 'Endgame Position',
                description: 'Convert the winning endgame.',
                difficulty: 'hard',
                icon: 'chess-pawn',
                attempts: 180,
                success_rate: 28,
                board: [
                    ['','','','k','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','K','','','','']
                ],
                solution: '1. Kc2 Kd4 2. Kd2 Ke4 3. Ke2',
                hint: 'Use opposition to force the king back.'
            }
        };

        const PUZZLE_COLLECTION = {
            'mate2': {
                title: 'Mate in 2',
                description: 'Find the forced mate in 2 moves.',
                difficulty: 'medium',
                icon: 'chess-queen',
                attempts: 340,
                success_rate: 62,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'Look for a forcing move that leads to mate.'
            },
            'discovered': {
                title: 'Discovered Attack',
                description: 'Unleash a devastating discovered attack.',
                difficulty: 'hard',
                icon: 'bolt',
                attempts: 210,
                success_rate: 35,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Bxf7+! Kxf7 2. Qe6+ Kf8 3. Qe8#',
                hint: 'Move a piece to uncover an attack from behind.'
            },
            'opening': {
                title: 'Opening Trap',
                description: 'Win material with an opening trap.',
                difficulty: 'easy',
                icon: 'chess-knight',
                attempts: 380,
                success_rate: 72,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Nxf7! Rxf7 2. Qxf7+ Kxf7 3. Rxf7#',
                hint: 'Watch for the knight fork on f7.'
            },
            'zwischenzug': {
                title: 'Zwischenzug',
                description: 'Find the intermediate move that wins.',
                difficulty: 'expert',
                icon: 'brain',
                attempts: 150,
                success_rate: 18,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'Look for an intermediate check or capture.'
            },
            'endgame2': {
                title: 'King and Pawn Endgame',
                description: 'Win the key king and pawn endgame.',
                difficulty: 'medium',
                icon: 'chess-king',
                attempts: 260,
                success_rate: 44,
                board: [
                    ['','','','k','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','K','','','','']
                ],
                solution: '1. Kc2 Kd4 2. Kd2 Ke4 3. Ke2',
                hint: 'Use opposition to win the pawn race.'
            },
            'mate3': {
                title: 'Mate in 3',
                description: 'Find the beautiful mate in 3 moves.',
                difficulty: 'hard',
                icon: 'chess-king',
                attempts: 190,
                success_rate: 25,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'Work backwards from the checkmate position.'
            },
            'immortal': {
                title: 'Immortal Puzzle',
                description: 'Find the famous move from the Immortal Game.',
                difficulty: 'medium',
                icon: 'star',
                attempts: 350,
                success_rate: 72,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'The move that sacrificed the queen for a winning attack.'
            },
            'sacrifice2': {
                title: "Queen's Sacrifice",
                description: 'The brilliant queen sacrifice that won the game.',
                difficulty: 'hard',
                icon: 'star',
                attempts: 220,
                success_rate: 34,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'Fischer\'s famous queen sacrifice.'
            },
            'matebeautiful': {
                title: 'Beautiful Mate',
                description: 'A stunning checkmate pattern.',
                difficulty: 'easy',
                icon: 'star',
                attempts: 400,
                success_rate: 81,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'Morphy\'s beautiful checkmate pattern.'
            },
            'kasparov': {
                title: "Kasparov's Masterpiece",
                description: 'Find the winning combination from Kasparov\'s immortal.',
                difficulty: 'expert',
                icon: 'star',
                attempts: 160,
                success_rate: 22,
                board: [
                    ['r','n','b','q','k','b','n','r'],
                    ['p','p','p','p','p','p','p','p'],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['','','','','','','',''],
                    ['P','P','P','P','P','P','P','P'],
                    ['R','N','B','Q','K','B','N','R']
                ],
                solution: '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7',
                hint: 'Kasparov\'s famous winning combination.'
            }
        };

        // Merge all puzzles
        const ALL_PUZZLES = { ...PUZZLE_PRESETS, ...PUZZLE_COLLECTION };

        // ===== BOARD RENDER =====
        function renderPuzzleBoard() {
            const boardEl = document.getElementById('puzzleBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            const board = puzzleSteps[puzzleStep]?.board || puzzleBoard;
            if (!board || board.length === 0) return;
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isPuzzleFlipped ? 7 - row : row;
                    const actualCol = isPuzzleFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    square.dataset.row = actualRow;
                    square.dataset.col = actualCol;
                    
                    const piece = board[actualRow]?.[actualCol] || '';
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    // Coordinates
                    if (col === 0) {
                        const rank = document.createElement('span');
                        rank.className = 'coords rank';
                        rank.textContent = 8 - actualRow;
                        square.appendChild(rank);
                    }
                    if (row === 7) {
                        const file = document.createElement('span');
                        file.className = 'coords file';
                        file.textContent = 'abcdefgh'[actualCol];
                        square.appendChild(file);
                    }
                    
                    // Highlight selected
                    if (selectedPuzzleSquare && selectedPuzzleSquare.row === actualRow && selectedPuzzleSquare.col === actualCol) {
                        square.classList.add('highlight');
                    }
                    
                    square.addEventListener('click', () => onPuzzleSquareClick(actualRow, actualCol));
                    boardEl.appendChild(square);
                }
            }
            
            updatePuzzleUI();
        }

        function updatePuzzleUI() {
            const totalSteps = puzzleSteps.length;
            document.getElementById('puzzleMoveCounter').textContent = `Move ${puzzleStep}/${totalSteps}`;
            
            // Update turn indicator
            const isWhiteTurn = puzzleStep % 2 === 0;
            document.getElementById('puzzleTurnIndicator').innerHTML = isWhiteTurn ? '⚪ White to move' : '⚫ Black to move';
            
            document.getElementById('puzzlePrevBtn').disabled = puzzleStep === 0;
            document.getElementById('puzzleNextBtn').disabled = puzzleStep >= totalSteps;
        }

        // ===== SQUARE CLICK =====
        function onPuzzleSquareClick(row, col) {
            const board = puzzleSteps[puzzleStep]?.board || puzzleBoard;
            const piece = board[row]?.[col];
            
            if (selectedPuzzleSquare) {
                // Check if this is a valid move (simplified)
                const fromRow = selectedPuzzleSquare.row;
                const fromCol = selectedPuzzleSquare.col;
                const fromPiece = board[fromRow]?.[fromCol];
                
                if (fromPiece && (row !== fromRow || col !== fromCol)) {
                    // Try to make a move
                    const moveResult = tryPuzzleMove(fromRow, fromCol, row, col);
                    if (moveResult) {
                        selectedPuzzleSquare = null;
                        renderPuzzleBoard();
                        return;
                    }
                }
                
                selectedPuzzleSquare = null;
                renderPuzzleBoard();
                return;
            }
            
            if (piece) {
                selectedPuzzleSquare = { row, col };
                renderPuzzleBoard();
            }
        }

        function tryPuzzleMove(fromRow, fromCol, toRow, toCol) {
            const board = puzzleSteps[puzzleStep]?.board || puzzleBoard;
            const piece = board[fromRow]?.[fromCol];
            if (!piece) return false;
            
            // Simple validation - just check if target is empty or enemy piece
            const target = board[toRow]?.[toCol];
            const isWhite = piece === piece.toUpperCase();
            
            if (target) {
                const isTargetWhite = target === target.toUpperCase();
                if (isWhite === isTargetWhite) return false;
            }
            
            // Execute the move
            const newBoard = board.map(row => [...row]);
            newBoard[toRow][toCol] = piece;
            newBoard[fromRow][fromCol] = '';
            
            // Pawn promotion (simplified)
            if (piece.toLowerCase() === 'p' && (toRow === 0 || toRow === 7)) {
                newBoard[toRow][toCol] = piece === 'P' ? 'Q' : 'q';
            }
            
            // Add to steps
            if (puzzleStep < puzzleSteps.length - 1) {
                puzzleSteps = puzzleSteps.slice(0, puzzleStep + 1);
            }
            puzzleSteps.push(newBoard);
            puzzleStep++;
            
            // Show feedback
            showPuzzleFeedback('Move made!', 'success');
            
            return true;
        }

        // ===== NAVIGATION =====
        function nextPuzzleMove() {
            if (puzzleStep < puzzleSteps.length - 1) {
                puzzleStep++;
                renderPuzzleBoard();
                if (isPuzzleAutoPlaying) {
                    clearTimeout(puzzleAutoInterval);
                    puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
                }
            }
        }

        function prevPuzzleMove() {
            if (puzzleStep > 0) {
                puzzleStep--;
                renderPuzzleBoard();
                if (isPuzzleAutoPlaying) {
                    clearTimeout(puzzleAutoInterval);
                    puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
                }
            }
        }

        function resetPuzzleBoard() {
            puzzleStep = 0;
            selectedPuzzleSquare = null;
            renderPuzzleBoard();
            if (isPuzzleAutoPlaying) {
                clearTimeout(puzzleAutoInterval);
                puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
            }
            document.getElementById('puzzleFeedback').className = 'feedback-display';
            document.getElementById('puzzleFeedback').style.display = 'none';
        }

        function flipPuzzleBoard() {
            isPuzzleFlipped = !isPuzzleFlipped;
            renderPuzzleBoard();
        }

        function togglePuzzleAutoPlay() {
            isPuzzleAutoPlaying = !isPuzzleAutoPlaying;
            const btn = document.getElementById('puzzleAutoBtn');
            if (isPuzzleAutoPlaying) {
                btn.innerHTML = '<i class="fas fa-pause"></i> Pause';
                if (puzzleStep < puzzleSteps.length - 1) {
                    puzzleAutoInterval = setTimeout(() => nextPuzzleMove(), 1500);
                }
            } else {
                btn.innerHTML = '<i class="fas fa-play"></i> Auto';
                clearTimeout(puzzleAutoInterval);
            }
        }

        // ===== LOAD PUZZLE =====
        function loadPuzzlePreset(presetKey) {
            const preset = ALL_PUZZLES[presetKey];
            if (!preset) return;
            
            // Update puzzle info
            document.getElementById('puzzleTitle').textContent = preset.title;
            document.getElementById('puzzleDescription').textContent = preset.description;
            
            // Update meta
            const metaSpans = document.querySelectorAll('.puzzle-meta span');
            if (metaSpans.length >= 3) {
                metaSpans[1].innerHTML = `<i class="fas fa-users"></i> ${preset.attempts} attempts`;
                metaSpans[2].innerHTML = `<i class="fas fa-check-circle"></i> ${preset.success_rate}% solved`;
            }
            
            // Set board
            puzzleBoard = preset.board.map(row => [...row]);
            puzzleSteps = [puzzleBoard.map(row => [...row])];
            puzzleStep = 0;
            selectedPuzzleSquare = null;
            
            // Update difficulty badge
            const badge = document.querySelector('.puzzle-meta .badge');
            if (badge) {
                const difficultyMap = {
                    'easy': 'badge-easy',
                    'medium': 'badge-medium',
                    'hard': 'badge-hard',
                    'expert': 'badge-expert'
                };
                badge.className = `badge ${difficultyMap[preset.difficulty] || 'badge-medium'}`;
                badge.textContent = preset.difficulty.charAt(0).toUpperCase() + preset.difficulty.slice(1);
            }
            
            // Reset feedback
            document.getElementById('puzzleFeedback').className = 'feedback-display';
            document.getElementById('puzzleFeedback').style.display = 'none';
            document.getElementById('puzzleHintDisplay').style.display = 'none';
            document.getElementById('puzzleSolutionDisplay').style.display = 'none';
            
            if (isPuzzleAutoPlaying) {
                clearTimeout(puzzleAutoInterval);
                isPuzzleAutoPlaying = false;
                document.getElementById('puzzleAutoBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
            }
            
            renderPuzzleBoard();
            
            // Scroll to puzzle
            document.querySelector('.daily-puzzle-section').scrollIntoView({ behavior: 'smooth', block: 'start' });
            
            // Store current preset for hint/solution
            window.currentPuzzlePreset = preset;
            
            return false;
        }

        function loadPuzzle(id) {
            // Try to find puzzle by ID
            const keys = Object.keys(ALL_PUZZLES);
            for (const key of keys) {
                if (ALL_PUZZLES[key].id === id) {
                    loadPuzzlePreset(key);
                    return false;
                }
            }
            // Load random if not found
            const randomKey = keys[Math.floor(Math.random() * keys.length)];
            loadPuzzlePreset(randomKey);
            return false;
        }

        // ===== PUZZLE ACTIONS =====
        function showPuzzleHint() {
            const preset = window.currentPuzzlePreset || PUZZLE_PRESETS['mate1'];
            const hintDisplay = document.getElementById('puzzleHintDisplay');
            hintDisplay.style.display = 'block';
            hintDisplay.innerHTML = '💡 <strong>Hint:</strong> ' + (preset.hint || 'Look for a forcing move.');
            hintDisplay.style.animation = 'none';
            setTimeout(() => {
                hintDisplay.style.animation = 'fadeInUp 0.5s ease-out';
            }, 10);
        }

        function showPuzzleSolution() {
            const preset = window.currentPuzzlePreset || PUZZLE_PRESETS['mate1'];
            const solutionDisplay = document.getElementById('puzzleSolutionDisplay');
            solutionDisplay.style.display = 'block';
            solutionDisplay.innerHTML = '✅ <strong>Solution:</strong> ' + (preset.solution || '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7');
            solutionDisplay.style.animation = 'none';
            setTimeout(() => {
                solutionDisplay.style.animation = 'fadeInUp 0.5s ease-out';
            }, 10);
        }

        function showPuzzleFeedback(message, type = 'info') {
            const feedback = document.getElementById('puzzleFeedback');
            feedback.className = `feedback-display ${type}`;
            feedback.textContent = message;
            feedback.style.display = 'block';
        }

        function markPuzzleCorrect() {
            showPuzzleFeedback('✅ Correct! Well done!', 'success');
            // Update stats
            const attempts = document.getElementById('puzzleAttempts');
            const rate = document.getElementById('puzzleSuccessRate');
            attempts.textContent = parseInt(attempts.textContent) + 1;
        }

        function markPuzzleWrong() {
            showPuzzleFeedback('❌ Not quite right. Try again!', 'error');
            const attempts = document.getElementById('puzzleAttempts');
            const rate = document.getElementById('puzzleSuccessRate');
            attempts.textContent = parseInt(attempts.textContent) + 1;
            rate.textContent = Math.max(0, parseInt(rate.textContent) - 1);
        }

        function nextPuzzle() {
            const keys = Object.keys(ALL_PUZZLES);
            const randomKey = keys[Math.floor(Math.random() * keys.length)];
            loadPuzzlePreset(randomKey);
        }

        // ===== KEYBOARD SHORTCUTS =====
        document.addEventListener('keydown', function(e) {
            if (document.activeElement?.tagName === 'INPUT') return;
            
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                nextPuzzleMove();
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                prevPuzzleMove();
            } else if (e.key === 'r' || e.key === 'R') {
                resetPuzzleBoard();
            } else if (e.key === 'f' || e.key === 'F') {
                if (!e.ctrlKey && !e.metaKey) {
                    e.preventDefault();
                    flipPuzzleBoard();
                }
            } else if (e.key === ' ') {
                e.preventDefault();
                togglePuzzleAutoPlay();
            } else if (e.key === 'h' || e.key === 'H') {
                showPuzzleHint();
            } else if (e.key === 's' || e.key === 'S') {
                showPuzzleSolution();
            }
        });

        // ===== CATEGORY FILTER =====
        function filterCategory(category) {
            document.querySelectorAll('.category-filters button').forEach(btn => {
                btn.classList.toggle('active', btn.textContent.toLowerCase() === category || 
                    (category === 'all' && btn.textContent === 'All Puzzles'));
            });

            const cards = document.querySelectorAll('#puzzleGrid .card');
            cards.forEach(card => {
                if (category === 'all' || card.dataset.category === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // ===== NAVBAR SCROLL =====
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== ADD ANIMATION STYLES =====
        const styleEl = document.createElement('style');
        styleEl.textContent = `
            @keyframes fadeInUp {
                from { opacity: 0; transform: translateY(20px); }
                to { opacity: 1; transform: translateY(0); }
            }
        `;
        document.head.appendChild(styleEl);

        // ===== INIT =====
        document.addEventListener('DOMContentLoaded', function() {
            // Load first puzzle
            loadPuzzlePreset('mate1');
            
            // Make functions globally accessible
            window.loadPuzzlePreset = loadPuzzlePreset;
            window.loadPuzzle = loadPuzzle;
            window.nextPuzzleMove = nextPuzzleMove;
            window.prevPuzzleMove = prevPuzzleMove;
            window.resetPuzzleBoard = resetPuzzleBoard;
            window.flipPuzzleBoard = flipPuzzleBoard;
            window.togglePuzzleAutoPlay = togglePuzzleAutoPlay;
            window.showPuzzleHint = showPuzzleHint;
            window.showPuzzleSolution = showPuzzleSolution;
            window.markPuzzleCorrect = markPuzzleCorrect;
            window.markPuzzleWrong = markPuzzleWrong;
            window.nextPuzzle = nextPuzzle;
            window.filterCategory = filterCategory;
            window.onPuzzleSquareClick = onPuzzleSquareClick;
        });
    </script>
</body>
</html>