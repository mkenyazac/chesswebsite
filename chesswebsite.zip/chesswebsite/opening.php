<?php
/**
 * Chess Heaven - Opening Detail Page
 * Displays detailed information about a specific chess opening
 */

require_once 'config.php';

// Get opening ID from URL
$openingId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get opening details
$openingDetails = getOpeningDetails($openingId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · <?php echo e($openingDetails ? $openingDetails['name'] : 'Opening'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== OPENING DETAIL ===== */
        .opening-container {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
            align-items:start;
        }
        .opening-main {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
        }
        .opening-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:1.5rem;
            flex-wrap:wrap;
            gap:1rem;
        }
        .opening-header h1 {
            font-size:2rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .opening-header .eco-code {
            padding:0.3rem 1rem;
            background:rgba(198,151,107,0.15);
            border:1px solid var(--secondary);
            border-radius:2rem;
            color:var(--secondary);
            font-weight:600;
            font-size:0.85rem;
        }
        .opening-meta {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(120px,1fr));
            gap:1rem;
            margin:1.5rem 0;
            padding:1rem;
            background:rgba(0,0,0,0.15);
            border-radius:0.8rem;
        }
        .opening-meta .meta-item {
            text-align:center;
        }
        .opening-meta .meta-item .label {
            color:#7a6a5a;
            font-size:0.75rem;
            text-transform:uppercase;
            letter-spacing:1px;
        }
        .opening-meta .meta-item .value {
            color:#f0d6b0;
            font-size:1rem;
            font-weight:600;
            margin-top:0.2rem;
        }
        .opening-description {
            color:#a09080;
            line-height:1.8;
            margin:1rem 0;
            font-size:0.95rem;
        }
        .opening-description strong {
            color:#f0d6b0;
        }

        /* ===== MOVE SEQUENCE ===== */
        .move-sequence {
            background:rgba(0,0,0,0.2);
            border-radius:0.8rem;
            padding:1.5rem;
            margin:1.5rem 0;
        }
        .move-sequence h3 {
            color:#f0d6b0;
            margin-bottom:0.8rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .move-sequence h3 i { color:var(--secondary); }
        .move-sequence .moves-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(120px,1fr));
            gap:0.5rem;
        }
        .move-sequence .move-item {
            display:flex;
            gap:0.3rem;
            padding:0.3rem 0.5rem;
            background:rgba(255,255,255,0.03);
            border-radius:0.3rem;
            font-size:0.85rem;
            font-family:monospace;
        }
        .move-sequence .move-item .move-num {
            color:#5a4a3a;
            min-width:25px;
        }
        .move-sequence .move-item .move-white {
            color:#f0d6b0;
        }
        .move-sequence .move-item .move-black {
            color:#a09080;
        }

        /* ===== VARIATIONS ===== */
        .variations {
            margin:1.5rem 0;
        }
        .variation-card {
            background:rgba(0,0,0,0.15);
            border-left:3px solid var(--secondary);
            border-radius:0.5rem;
            padding:1rem;
            margin-bottom:0.8rem;
        }
        .variation-card h4 {
            color:#f0d6b0;
            font-size:0.95rem;
            margin-bottom:0.3rem;
        }
        .variation-card p {
            color:#a09080;
            font-size:0.85rem;
            line-height:1.6;
        }
        .variation-card .var-moves {
            color:var(--secondary);
            font-family:monospace;
            font-size:0.8rem;
            margin-top:0.3rem;
        }

        /* ===== MINI BOARD ===== */
        .mini-board-wrapper {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
            display:flex;
            flex-direction:column;
            align-items:center;
            gap:1.5rem;
        }
        .mini-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:450px;
            aspect-ratio:1;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
            cursor:pointer;
        }
        .mini-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.2rem;
            aspect-ratio:1;
            user-select:none;
            transition:all 0.2s;
            position:relative;
        }
        .mini-board .square.light { background:var(--light-square); }
        .mini-board .square.dark { background:var(--dark-square); }
        .mini-board .square .piece {
            font-size:2.2rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
            pointer-events:none;
            z-index:1;
        }
        .mini-board .square .piece.white-piece { color:#fff; filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5)); }
        .mini-board .square .piece.black-piece { color:#1a1a1a; filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3)); }
        .mini-board .square.highlight {
            background:rgba(255,255,100,0.4) !important;
        }
        .mini-board .square .coords {
            position:absolute;
            font-size:0.5rem;
            color:rgba(0,0,0,0.3);
            pointer-events:none;
            font-weight:600;
        }
        .mini-board .square .coords.file { bottom:2px; right:4px; }
        .mini-board .square .coords.rank { top:2px; left:4px; }
        .mini-board .square.dark .coords { color:rgba(255,255,255,0.3); }

        .board-controls {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            justify-content:center;
            width:100%;
        }
        .board-controls button {
            padding:0.5rem 1.2rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.8rem;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .btn-nav {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-nav:hover { background:rgba(198,151,107,0.25); }
        .btn-nav:disabled {
            opacity:0.3;
            cursor:not-allowed;
        }
        .btn-reset {
            background:rgba(255,255,255,0.05);
            color:#a09080;
            border:1px solid rgba(255,255,255,0.1) !important;
        }
        .btn-reset:hover { background:rgba(255,255,255,0.1); }
        .btn-flip {
            background:rgba(46,204,113,0.15);
            color:#2ecc71;
            border:1px solid #2ecc71 !important;
        }
        .btn-flip:hover { background:rgba(46,204,113,0.25); }

        /* ===== RELATED OPENINGS ===== */
        .related-openings {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(200px,1fr));
            gap:1rem;
            margin-top:1rem;
        }
        .related-opening-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:0.8rem;
            padding:1rem;
            transition:0.3s;
            cursor:pointer;
            text-align:center;
        }
        .related-opening-item:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-3px);
        }
        .related-opening-item .icon {
            font-size:2rem;
            color:var(--secondary);
            margin-bottom:0.3rem;
        }
        .related-opening-item h4 {
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .related-opening-item p {
            color:#7a6a5a;
            font-size:0.75rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .opening-container {
                grid-template-columns:1fr;
            }
            .mini-board { max-width:350px; }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .opening-main { padding:1rem; }
            .opening-header h1 { font-size:1.5rem; }
            .mini-board { max-width:280px; }
            .mini-board .square .piece { font-size:1.5rem; }
            .move-sequence .moves-grid {
                grid-template-columns:repeat(auto-fill,minmax(100px,1fr));
            }
            .opening-meta {
                grid-template-columns:1fr 1fr;
            }
        }
        @media (max-width:480px) {
            .mini-board { max-width:220px; }
            .mini-board .square .piece { font-size:1.2rem; }
            .opening-meta { grid-template-columns:1fr; }
            .related-openings { grid-template-columns:1fr; }
        }

        /* ===== SCROLLBAR ===== */
        .move-sequence::-webkit-scrollbar { width:4px; }
        .move-sequence::-webkit-scrollbar-track { background:transparent; }
        .move-sequence::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== OPENING DETAIL ===== -->
    <section class="section">
        <?php if ($openingDetails): ?>
            <div class="opening-container">
                <!-- Main Content -->
                <div class="opening-main">
                    <!-- Header -->
                    <div class="opening-header">
                        <h1>
                            <i class="fas fa-chess-<?php echo $openingDetails['icon'] ?? 'pawn'; ?>"></i>
                            <?php echo e($openingDetails['name']); ?>
                        </h1>
                        <span class="eco-code"><?php echo e($openingDetails['eco'] ?? 'ECO: —'); ?></span>
                    </div>

                    <!-- Meta -->
                    <div class="opening-meta">
                        <div class="meta-item">
                            <div class="label">Category</div>
                            <div class="value"><?php echo e($openingDetails['category']); ?></div>
                        </div>
                        <div class="meta-item">
                            <div class="label">Popularity</div>
                            <div class="value"><?php echo e($openingDetails['popularity']); ?>%</div>
                        </div>
                        <div class="meta-item">
                            <div class="label">Difficulty</div>
                            <div class="value"><?php echo e($openingDetails['difficulty'] ?? 'Intermediate'); ?></div>
                        </div>
                        <div class="meta-item">
                            <div class="label">Games Played</div>
                            <div class="value"><?php echo e(number_format($openingDetails['games_played'] ?? 0)); ?></div>
                        </div>
                    </div>

                    <!-- Description -->
                    <div class="opening-description">
                        <?php echo e($openingDetails['description']); ?>
                    </div>

                    <!-- Move Sequence -->
                    <div class="move-sequence">
                        <h3><i class="fas fa-list"></i> Main Line</h3>
                        <div class="moves-grid" id="movesGrid">
                            <?php if (!empty($openingDetails['moves'])): ?>
                                <?php 
                                    $movePairs = array_chunk($openingDetails['moves'], 2);
                                    foreach ($movePairs as $index => $pair): 
                                ?>
                                    <div class="move-item">
                                        <span class="move-num"><?php echo e($index + 1); ?>.</span>
                                        <span class="move-white"><?php echo e($pair[0] ?? ''); ?></span>
                                        <span class="move-black"><?php echo e($pair[1] ?? ''); ?></span>
                                    </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div style="color:#5a4a3a;grid-column:1/-1;text-align:center;padding:0.5rem;">No moves recorded</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Variations -->
                    <?php if (!empty($openingDetails['variations'])): ?>
                        <div class="variations">
                            <h3 style="color:#f0d6b0;margin-bottom:0.8rem;display:flex;align-items:center;gap:0.5rem;">
                                <i class="fas fa-code-branch" style="color:var(--secondary);"></i> Variations
                            </h3>
                            <?php foreach ($openingDetails['variations'] as $variation): ?>
                                <div class="variation-card">
                                    <h4><?php echo e($variation['name']); ?></h4>
                                    <p><?php echo e($variation['description']); ?></p>
                                    <div class="var-moves"><?php echo e($variation['moves']); ?></div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>

                    <!-- Key Concepts -->
                    <?php if (!empty($openingDetails['key_concepts'])): ?>
                        <div style="margin-top:1.5rem;">
                            <h3 style="color:#f0d6b0;margin-bottom:0.8rem;display:flex;align-items:center;gap:0.5rem;">
                                <i class="fas fa-lightbulb" style="color:var(--secondary);"></i> Key Concepts
                            </h3>
                            <ul style="list-style:none;display:grid;gap:0.5rem;">
                                <?php foreach ($openingDetails['key_concepts'] as $concept): ?>
                                    <li style="padding:0.5rem 1rem;background:rgba(0,0,0,0.15);border-radius:0.5rem;color:#a09080;font-size:0.9rem;display:flex;align-items:center;gap:0.5rem;">
                                        <i class="fas fa-check-circle" style="color:var(--secondary);"></i>
                                        <?php echo e($concept); ?>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Sidebar with Board -->
                <div class="mini-board-wrapper">
                    <h3 style="color:#f0d6b0;display:flex;align-items:center;gap:0.5rem;font-size:1.2rem;">
                        <i class="fas fa-chess-board" style="color:var(--secondary);"></i> Opening Explorer
                    </h3>
                    <div class="mini-board" id="miniBoard"></div>
                    <div style="color:#a09080;font-size:0.85rem;text-align:center;" id="moveCounter">
                        Move 0/<?php echo e(count($openingDetails['moves'] ?? [])); ?>
                    </div>
                    <div class="board-controls">
                        <button class="btn-nav" id="prevMoveBtn" onclick="prevMove()">
                            <i class="fas fa-chevron-left"></i> Prev
                        </button>
                        <button class="btn-nav" id="nextMoveBtn" onclick="nextMove()">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                        <button class="btn-reset" onclick="resetBoard()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                        <button class="btn-flip" onclick="flipBoard()">
                            <i class="fas fa-sync-alt"></i> Flip
                        </button>
                    </div>
                    <div style="width:100%;padding:0.8rem;background:rgba(0,0,0,0.2);border-radius:0.5rem;text-align:center;color:#7a6a5a;font-size:0.8rem;">
                        <i class="fas fa-mouse-pointer"></i> Click board to step through moves
                    </div>

                    <!-- Quick Stats -->
                    <div style="width:100%;display:grid;grid-template-columns:1fr 1fr 1fr;gap:0.5rem;margin-top:0.5rem;">
                        <div style="text-align:center;padding:0.5rem;background:rgba(0,0,0,0.15);border-radius:0.5rem;">
                            <div style="color:#7a6a5a;font-size:0.6rem;text-transform:uppercase;">Win Rate</div>
                            <div style="color:#2ecc71;font-weight:700;"><?php echo e($openingDetails['win_rate'] ?? '52'); ?>%</div>
                        </div>
                        <div style="text-align:center;padding:0.5rem;background:rgba(0,0,0,0.15);border-radius:0.5rem;">
                            <div style="color:#7a6a5a;font-size:0.6rem;text-transform:uppercase;">Draw Rate</div>
                            <div style="color:#f1c40f;font-weight:700;"><?php echo e($openingDetails['draw_rate'] ?? '24'); ?>%</div>
                        </div>
                        <div style="text-align:center;padding:0.5rem;background:rgba(0,0,0,0.15);border-radius:0.5rem;">
                            <div style="color:#7a6a5a;font-size:0.6rem;text-transform:uppercase;">Loss Rate</div>
                            <div style="color:#e74c3c;font-weight:700;"><?php echo e($openingDetails['loss_rate'] ?? '24'); ?>%</div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Related Openings -->
            <?php if (!empty($openingDetails['related_openings'])): ?>
                <div style="margin-top:3rem;">
                    <div class="section-header">
                        <h2><i class="fas fa-link"></i> Related Openings</h2>
                        <a href="openings.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="related-openings">
                        <?php foreach ($openingDetails['related_openings'] as $related): ?>
                            <a href="opening.php?id=<?php echo e($related['id']); ?>" class="related-opening-item">
                                <div class="icon"><i class="fas fa-chess-<?php echo $related['icon'] ?? 'pawn'; ?>"></i></div>
                                <h4><?php echo e($related['name']); ?></h4>
                                <p><?php echo e($related['category']); ?></p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div style="text-align:center;padding:4rem 2rem;">
                <i class="fas fa-exclamation-triangle" style="font-size:4rem;color:var(--secondary);"></i>
                <h2 style="color:#f0d6b0;margin:1rem 0;">Opening Not Found</h2>
                <p style="color:#a09080;">The opening you're looking for doesn't exist in our database.</p>
                <a href="openings.php" class="btn-play" style="display:inline-block;margin-top:1.5rem;padding:0.8rem 2rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-decoration:none;">
                    <i class="fas fa-book-open"></i> Browse Openings
                </a>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== OPENING EXPLORER =====
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // Get opening data from PHP
        const openingData = <?php echo json_encode($openingDetails ? [
            'moves' => $openingDetails['moves'] ?? [],
            'initial_position' => [
                ['r','n','b','q','k','b','n','r'],
                ['p','p','p','p','p','p','p','p'],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['P','P','P','P','P','P','P','P'],
                ['R','N','B','Q','K','B','N','R']
            ]
        ] : []); ?>;

        let board = JSON.parse(JSON.stringify(openingData.initial_position || [
            ['r','n','b','q','k','b','n','r'],
            ['p','p','p','p','p','p','p','p'],
            ['','','','','','','',''],
            ['','','','','','','',''],
            ['','','','','','','',''],
            ['','','','','','','',''],
            ['P','P','P','P','P','P','P','P'],
            ['R','N','B','Q','K','B','N','R']
        ]));
        const moves = openingData.moves || [];
        let currentMoveIndex = 0;
        let isFlipped = false;

        const FILES = 'abcdefgh';

        function renderMiniBoard() {
            const boardEl = document.getElementById('miniBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isFlipped ? 7 - row : row;
                    const actualCol = isFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    
                    // Coordinates
                    if (col === 0) {
                        const rank = document.createElement('span');
                        rank.className = 'coords rank';
                        rank.textContent = 8 - actualRow;
                        square.appendChild(rank);
                    }
                    if (row === 7) {
                        const file = document.createElement('span');
                        file.className = 'coords file';
                        file.textContent = FILES[actualCol];
                        square.appendChild(file);
                    }
                    
                    const piece = board[actualRow][actualCol];
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    square.addEventListener('click', () => {
                        const totalMoves = moves.length;
                        if (currentMoveIndex < totalMoves) {
                            nextMove();
                        } else {
                            resetBoard();
                        }
                    });
                    
                    boardEl.appendChild(square);
                }
            }
            
            // Update move counter
            const counter = document.getElementById('moveCounter');
            if (counter) {
                counter.textContent = `Move ${currentMoveIndex}/${moves.length}`;
            }
            
            // Update buttons
            document.getElementById('prevMoveBtn').disabled = currentMoveIndex === 0;
            document.getElementById('nextMoveBtn').disabled = currentMoveIndex >= moves.length;
        }

        function applyMove(index) {
            // Reset to initial position
            board = JSON.parse(JSON.stringify(openingData.initial_position || [
                ['r','n','b','q','k','b','n','r'],
                ['p','p','p','p','p','p','p','p'],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['P','P','P','P','P','P','P','P'],
                ['R','N','B','Q','K','B','N','R']
            ]));
            
            // Apply moves up to index
            for (let i = 0; i < index && i < moves.length; i++) {
                const move = moves[i];
                const from = move.substring(0, 2);
                const to = move.substring(2, 4);
                const fromRow = 8 - parseInt(from[1]);
                const fromCol = FILES.indexOf(from[0]);
                const toRow = 8 - parseInt(to[1]);
                const toCol = FILES.indexOf(to[0]);
                
                if (fromRow >= 0 && fromRow < 8 && fromCol >= 0 && fromCol < 8 &&
                    toRow >= 0 && toRow < 8 && toCol >= 0 && toCol < 8) {
                    board[toRow][toCol] = board[fromRow][fromCol];
                    board[fromRow][fromCol] = '';
                }
            }
        }

        function goToMove(index) {
            currentMoveIndex = Math.max(0, Math.min(index, moves.length));
            applyMove(currentMoveIndex);
            renderMiniBoard();
        }

        function nextMove() {
            if (currentMoveIndex < moves.length) {
                goToMove(currentMoveIndex + 1);
            }
        }

        function prevMove() {
            if (currentMoveIndex > 0) {
                goToMove(currentMoveIndex - 1);
            }
        }

        function resetBoard() {
            goToMove(0);
        }

        function flipBoard() {
            isFlipped = !isFlipped;
            renderMiniBoard();
        }

        // ===== KEYBOARD SHORTCUTS =====
        document.addEventListener('keydown', function(e) {
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                nextMove();
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                prevMove();
            } else if (e.key === 'r' || e.key === 'R') {
                resetBoard();
            } else if (e.key === 'f' || e.key === 'F') {
                flipBoard();
            }
        });

        // ===== INIT =====
        document.addEventListener('DOMContentLoaded', function() {
            goToMove(0);
        });
    </script>
</body>
</html>
<?php
/**
 * Helper function to get opening details
 */
function getOpeningDetails($id) {
    // Simulated opening data for demo purposes
    $openings = [
        1 => [
            'id' => 1,
            'name' => 'Italian Game',
            'eco' => 'C50',
            'category' => 'Open Game',
            'popularity' => 92,
            'difficulty' => 'Beginner',
            'games_played' => 1250000,
            'win_rate' => 52,
            'draw_rate' => 24,
            'loss_rate' => 24,
            'icon' => 'king',
            'description' => 'The Italian Game is one of the oldest recorded chess openings, dating back to the 16th century. It is characterized by the moves 1.e4 e5 2.Nf3 Nc6 3.Bc4. This opening aims for rapid development and control of the center, making it an excellent choice for players of all levels. The Italian Game often leads to rich positional play with opportunities for both tactical and strategic battles.',
            'moves' => [
                'e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'd3', 'Nf6', 'Bg5', 'h6', 'Bh4', 'g5', 'Bg3', 'd5', 'exd5', 'Nxd5'
            ],
            'variations' => [
                [
                    'name' => 'Giuoco Piano (Main Line)',
                    'description' => 'The most traditional line of the Italian Game, leading to slow, positional play with chances for both sides.',
                    'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bc4 Bc5 4.c3 Nf6 5.d4 exd4 6.cxd4 Bb6 7.O-O d6'
                ],
                [
                    'name' => 'Two Knights Defense',
                    'description' => 'A sharp, tactical line where Black immediately challenges the bishop with Ng4, leading to complex positions.',
                    'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bc4 Nf6 4.Ng5 d5 5.exd5 Nxd5 6.Nxf7 Kxf7'
                ],
                [
                    'name' => 'Ponziani Variation',
                    'description' => 'A solid, less common line that aims for a favorable endgame through careful piece placement.',
                    'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bc4 Bc5 4.d4 exd4 5.O-O'
                ]
            ],
            'key_concepts' => [
                'Control the center with pawns and pieces',
                'Develop knights before bishops',
                'Castle early for king safety',
                'Maintain pressure on the f7 square',
                'Look for tactical opportunities with d4'
            ],
            'related_openings' => [
                ['id' => 2, 'name' => 'Ruy Lopez', 'category' => 'Open Game', 'icon' => 'queen'],
                ['id' => 3, 'name' => 'Sicilian Defense', 'category' => 'Semi-Open', 'icon' => 'knight'],
                ['id' => 4, 'name' => 'French Defense', 'category' => 'Semi-Open', 'icon' => 'pawn']
            ]
        ],
        2 => [
            'id' => 2,
            'name' => 'Ruy Lopez',
            'eco' => 'C60-C99',
            'category' => 'Open Game',
            'popularity' => 88,
            'difficulty' => 'Intermediate',
            'games_played' => 980000,
            'win_rate' => 50,
            'draw_rate' => 30,
            'loss_rate' => 20,
            'icon' => 'queen',
            'description' => 'The Ruy Lopez, also known as the Spanish Opening, is one of the most respected and heavily analyzed openings in chess. It begins with 1.e4 e5 2.Nf3 Nc6 3.Bb5. This opening aims to pressure the knight on c6 and the pawn on e5, creating long-term strategic advantages. The Ruy Lopez has been a favorite of world champions for centuries.',
            'moves' => [
                'e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6', 'O-O', 'Be7', 'Re1', 'b5', 'Bb3', 'O-O', 'c3', 'd6'
            ],
            'variations' => [
                [
                    'name' => 'Closed Ruy Lopez',
                    'description' => 'The main line of the Ruy Lopez, characterized by slow, maneuvering play with strategic depth.',
                    'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bb5 a6 4.Ba4 Nf6 5.O-O Be7 6.Re1 b5 7.Bb3 O-O 8.c3 d6'
                ],
                [
                    'name' => 'Open Ruy Lopez',
                    'description' => 'A sharp line that leads to immediate tactical complications and open positions.',
                    'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bb5 a6 4.Ba4 Nf6 5.O-O Nxe4 6.d4 b5 7.Bb3 d5 8.dxe5 Be6'
                ],
                [
                    'name' => 'Marshall Attack',
                    'description' => 'A famous gambit line where Black sacrifices a pawn for active piece play and attacking chances.',
                    'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bb5 a6 4.Ba4 Nf6 5.O-O Be7 6.Re1 b5 7.Bb3 O-O 8.c3 d5'
                ]
            ],
            'key_concepts' => [
                'Pressure on the e5 pawn',
                'Strategic maneuvering of pieces',
                'Pawn structure determination',
                'King safety and pawn breaks',
                'Opposition and endgame play'
            ],
            'related_openings' => [
                ['id' => 1, 'name' => 'Italian Game', 'category' => 'Open Game', 'icon' => 'king'],
                ['id' => 3, 'name' => 'Sicilian Defense', 'category' => 'Semi-Open', 'icon' => 'knight'],
                ['id' => 4, 'name' => 'French Defense', 'category' => 'Semi-Open', 'icon' => 'pawn']
            ]
        ],
        3 => [
            'id' => 3,
            'name' => 'Sicilian Defense',
            'eco' => 'B20-B99',
            'category' => 'Semi-Open',
            'popularity' => 85,
            'difficulty' => 'Advanced',
            'games_played' => 2100000,
            'win_rate' => 51,
            'draw_rate' => 26,
            'loss_rate' => 23,
            'icon' => 'knight',
            'description' => 'The Sicilian Defense is the most popular and dynamic response to 1.e4. It begins with 1.e4 c5, immediately challenging White\'s control of the center. The Sicilian is known for its asymmetrical positions, tactical complexity, and rich strategic play. It has been the choice of many world champions and attacking players.',
            'moves' => [
                'e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'a6', 'Be3', 'e5', 'Nb3', 'Be6', 'f3', 'Be7'
            ],
            'variations' => [
                [
                    'name' => 'Najdorf Variation',
                    'description' => 'The most popular and aggressive line of the Sicilian, named after the legendary grandmaster Miguel Najdorf.',
                    'moves' => '1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3 a6'
                ],
                [
                    'name' => 'Dragon Variation',
                    'description' => 'A sharp, attacking line characterized by the fianchetto of the bishop on g7, leading to opposite-side castling races.',
                    'moves' => '1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3 g6'
                ],
                [
                    'name' => 'Classical Variation',
                    'description' => 'A solid, positional line that aims for a stable center and gradual development.',
                    'moves' => '1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3 Nc6'
                ],
                [
                    'name' => 'Scheveningen Variation',
                    'description' => 'A flexible system that creates a solid pawn structure with opportunities for counterplay.',
                    'moves' => '1.e4 c5 2.Nf3 d6 3.d4 cxd4 4.Nxd4 Nf6 5.Nc3 e6'
                ]
            ],
            'key_concepts' => [
                'Imbalance and asymmetrical positions',
                'Strategic pawn structures',
                'Opposite-side castling attacks',
                'Open c-file for counterplay',
                'Tactical awareness and calculation'
            ],
            'related_openings' => [
                ['id' => 1, 'name' => 'Italian Game', 'category' => 'Open Game', 'icon' => 'king'],
                ['id' => 2, 'name' => 'Ruy Lopez', 'category' => 'Open Game', 'icon' => 'queen'],
                ['id' => 4, 'name' => 'French Defense', 'category' => 'Semi-Open', 'icon' => 'pawn']
            ]
        ],
        4 => [
            'id' => 4,
            'name' => 'French Defense',
            'eco' => 'C00-C19',
            'category' => 'Semi-Open',
            'popularity' => 78,
            'difficulty' => 'Intermediate',
            'games_played' => 890000,
            'win_rate' => 48,
            'draw_rate' => 28,
            'loss_rate' => 24,
            'icon' => 'pawn',
            'description' => 'The French Defense is a solid and reliable opening for Black, starting with 1.e4 e6. It aims to create a strong pawn center and counterplay on the queenside. Known for its defensive resilience, the French often leads to closed positions with strategic maneuvering and endgame battles.',
            'moves' => [
                'e4', 'e6', 'd4', 'd5', 'Nc3', 'Nf6', 'Bg5', 'Be7', 'e5', 'Nfd7', 'Bxe7', 'Qxe7', 'f4', 'c5', 'Nf3', 'Nc6'
            ],
            'variations' => [
                [
                    'name' => 'Classical Variation',
                    'description' => 'The main line of the French Defense, featuring solid development and pawn structure.',
                    'moves' => '1.e4 e6 2.d4 d5 3.Nc3 Nf6 4.Bg5 Be7 5.e5 Nfd7 6.Bxe7 Qxe7 7.f4'
                ],
                [
                    'name' => 'Winawer Variation',
                    'description' => 'A sharp, tactical line where Black pinning the knight on c3 leads to complex and double-edged positions.',
                    'moves' => '1.e4 e6 2.d4 d5 3.Nc3 Bb4 4.e5 c5 5.a3 Bxc3+ 6.bxc3 Ne7 7.Qg4'
                ],
                [
                    'name' => 'Tarrasch Variation',
                    'description' => 'A more positional approach, named after Siegbert Tarrasch, featuring careful piece development.',
                    'moves' => '1.e4 e6 2.d4 d5 3.Nd2 Nf6 4.e5 Nfd7 5.Bd3 c5 6.c3 Nc6'
                ]
            ],
            'key_concepts' => [
                'Solid pawn center',
                'Queenside counterplay',
                'King safety and pawn breaks',
                'Strategic maneuver in closed positions',
                'Endgame precision and technique'
            ],
            'related_openings' => [
                ['id' => 1, 'name' => 'Italian Game', 'category' => 'Open Game', 'icon' => 'king'],
                ['id' => 2, 'name' => 'Ruy Lopez', 'category' => 'Open Game', 'icon' => 'queen'],
                ['id' => 3, 'name' => 'Sicilian Defense', 'category' => 'Semi-Open', 'icon' => 'knight']
            ]
        ],
        5 => [
            'id' => 5,
            'name' => 'Caro-Kann Defense',
            'eco' => 'B10-B19',
            'category' => 'Semi-Open',
            'popularity' => 76,
            'difficulty' => 'Intermediate',
            'games_played' => 720000,
            'win_rate' => 49,
            'draw_rate' => 29,
            'loss_rate' => 22,
            'icon' => 'rook',
            'description' => 'The Caro-Kann Defense is a solid and reliable opening for Black, beginning with 1.e4 c6. It is known for its resilience and ability to create a strong pawn structure. The Caro-Kann often leads to positions with strategic depth and fewer tactical complications than other defenses.',
            'moves' => [
                'e4', 'c6', 'd4', 'd5', 'Nc3', 'dxe4', 'Nxe4', 'Bf5', 'Ng3', 'Bg6', 'Nf3', 'e6', 'Bd3', 'Bxd3', 'Qxd3', 'Nf6'
            ],
            'variations' => [
                [
                    'name' => 'Classical Variation',
                    'description' => 'The main line of the Caro-Kann, featuring solid development and positional play.',
                    'moves' => '1.e4 c6 2.d4 d5 3.Nc3 dxe4 4.Nxe4 Bf5 5.Ng3 Bg6 6.Nf3 e6 7.Bd3'
                ],
                [
                    'name' => 'Panov-Botvinnik Attack',
                    'description' => 'An aggressive line for White that aims for rapid development and attacking chances.',
                    'moves' => '1.e4 c6 2.d4 d5 3.exd5 cxd5 4.c4 Nf6 5.Nc3 e6'
                ],
                [
                    'name' => 'Advance Variation',
                    'description' => 'A sharp line where White immediately advances the pawn to e5, creating immediate tactical complications.',
                    'moves' => '1.e4 c6 2.d4 d5 3.e5 Bf5 4.Nf3 e6 5.Be2 c5'
                ]
            ],
            'key_concepts' => [
                'Solid pawn structure',
                'Piece development and coordination',
                'Endgame advantages',
                'Positional understanding',
                'Strategic planning and execution'
            ],
            'related_openings' => [
                ['id' => 3, 'name' => 'Sicilian Defense', 'category' => 'Semi-Open', 'icon' => 'knight'],
                ['id' => 4, 'name' => 'French Defense', 'category' => 'Semi-Open', 'icon' => 'pawn']
            ]
        ],
        6 => [
            'id' => 6,
            'name' => "Queen's Gambit",
            'eco' => 'D10-D69',
            'category' => 'Closed Game',
            'popularity' => 82,
            'difficulty' => 'Intermediate',
            'games_played' => 1100000,
            'win_rate' => 51,
            'draw_rate' => 30,
            'loss_rate' => 19,
            'icon' => 'bishop',
            'description' => "The Queen's Gambit is one of the most respected and popular openings in chess, beginning with 1.d4 d5 2.c4. It's known for its strategic depth and rich history, having been used by many world champions. The opening aims to control the center and create positional advantages.",
            'moves' => [
                'd4', 'd5', 'c4', 'e6', 'Nc3', 'Nf6', 'Bg5', 'Be7', 'e3', 'Nbd7', 'Nf3', 'O-O', 'Rc1', 'c6', 'Bd3', 'dxc4'
            ],
            'variations' => [
                [
                    'name' => 'Slav Defense',
                    'description' => 'A solid and popular line for Black, characterized by the move c6, leading to strategic positions.',
                    'moves' => '1.d4 d5 2.c4 c6 3.Nf3 Nf6 4.Nc3 dxc4 5.a4 Bf5'
                ],
                [
                    'name' => "Queen's Gambit Accepted",
                    'description' => 'A line where Black captures the c4 pawn, leading to open and tactical positions.',
                    'moves' => '1.d4 d5 2.c4 dxc4 3.Nf3 Nf6 4.e3 e6 5.Bxc4 c5'
                ],
                [
                    'name' => "Queen's Gambit Declined",
                    'description' => 'The main line where Black maintains the pawn on d5, leading to closed, positional play.',
                    'moves' => '1.d4 d5 2.c4 e6 3.Nc3 Nf6 4.Bg5 Be7 5.e3 O-O 6.Nf3 Nbd7'
                ]
            ],
            'key_concepts' => [
                'Pawn structure management',
                'Piece development and coordination',
                'Strategic planning and execution',
                'Center control and pawn breaks',
                'Endgame technique and precision'
            ],
            'related_openings' => [
                ['id' => 3, 'name' => 'Sicilian Defense', 'category' => 'Semi-Open', 'icon' => 'knight'],
                ['id' => 4, 'name' => 'French Defense', 'category' => 'Semi-Open', 'icon' => 'pawn'],
                ['id' => 5, 'name' => 'Caro-Kann Defense', 'category' => 'Semi-Open', 'icon' => 'rook']
            ]
        ]
    ];
    
    return $openings[$id] ?? null;
}
?>