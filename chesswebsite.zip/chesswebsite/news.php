<?php
/**
 * Chess Heaven - News Page
 * Complete news hub with chess news, articles, and updates
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']); // Fixed: added missing closing parenthesis

// Get news data
$featuredNews = getFeaturedNews();
$allNews = getChessNews(12);
$newsCategories = getNewsCategories();
$upcomingEvents = getUpcomingEvents(4);
$recentComments = getRecentComments(5);
$newsletterSubscribers = getNewsletterStats();
$trendingTopics = getTrendingTopics();
$tournamentNews = getTournamentNews(4);
$videoNews = getVideoNews(3);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Chess News</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
            position:relative;
            overflow:hidden;
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }
        .card .badge {
            position:absolute;
            top:1rem;
            right:1rem;
            padding:0.2rem 0.8rem;
            border-radius:2rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .badge-tournament { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .badge-achievement { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .badge-interview { background:rgba(52,152,219,0.2); color:#3498db; }
        .badge-analysis { background:rgba(155,89,182,0.2); color:#9b59b6; }
        .badge-breaking { background:rgba(231,76,60,0.2); color:#e74c3c; }
        .badge-update { background:rgba(198,151,107,0.2); color:#C6976B; }
        .badge-live { background:rgba(231,76,60,0.3); color:#e74c3c; animation:pulse-badge 2s infinite; }

        @keyframes pulse-badge {
            0%, 100% { opacity:1; }
            50% { opacity:0.6; }
        }

        /* ===== HERO ===== */
        .news-hero {
            text-align:center;
            padding:3rem 2rem;
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem;
            border:1px solid var(--border-color);
            margin:2rem;
        }
        .news-hero h1 {
            font-size:2.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:1rem;
        }
        .news-hero p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
        }
        .news-hero .search-box {
            max-width:500px;
            margin:1.5rem auto;
            display:flex;
            gap:0.5rem;
        }
        .news-hero .search-box input {
            flex:1;
            padding:0.8rem 1.2rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-size:0.9rem;
        }
        .news-hero .search-box input:focus {
            outline:none;
            border-color:var(--secondary);
        }
        .news-hero .search-box button {
            padding:0.8rem 1.5rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
        }
        .news-hero .search-box button:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }

        /* ===== FEATURED NEWS ===== */
        .featured-news {
            background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));
            border-radius:2rem;
            padding:2rem;
            border:2px solid var(--gold);
            margin-bottom:2rem;
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
            align-items:center;
        }
        .featured-news .featured-content h2 {
            color:#f0d6b0;
            font-size:1.8rem;
            margin-bottom:0.5rem;
        }
        .featured-news .featured-content p {
            color:#a09080;
            line-height:1.8;
        }
        .featured-news .featured-content .news-meta {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            margin:1rem 0;
        }
        .featured-news .featured-content .news-meta span {
            color:var(--secondary);
            font-size:0.85rem;
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .featured-news .featured-image {
            text-align:center;
            padding:2rem;
        }
        .featured-news .featured-image i {
            font-size:6rem;
            color:var(--secondary);
            opacity:0.3;
        }
        .btn-read-more {
            display:inline-block;
            padding:0.8rem 2rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            margin-top:1rem;
        }
        .btn-read-more:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.5);
        }

        /* ===== CATEGORY FILTERS ===== */
        .category-filters {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
            justify-content:center;
            margin:1rem 0 2rem;
        }
        .category-filters button {
            padding:0.5rem 1.5rem;
            border-radius:2rem;
            border:2px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.85rem;
        }
        .category-filters button:hover,
        .category-filters button.active {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }

        /* ===== SIDEBAR ===== */
        .news-grid {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:2rem;
        }
        .sidebar {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .sidebar-widget {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
        }
        .sidebar-widget h3 {
            color:#f0d6b0;
            font-size:1.1rem;
            margin-bottom:1rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .sidebar-widget h3 i { color:var(--secondary); }
        .sidebar-widget .widget-item {
            padding:0.6rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            transition:0.3s;
        }
        .sidebar-widget .widget-item:last-child { border-bottom:none; }
        .sidebar-widget .widget-item:hover { color:var(--secondary); }
        .sidebar-widget .widget-item .widget-title {
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .sidebar-widget .widget-item .widget-meta {
            color:#7a6a5a;
            font-size:0.75rem;
            margin-top:0.2rem;
        }
        .sidebar-widget .widget-item .widget-tag {
            display:inline-block;
            padding:0.1rem 0.5rem;
            border-radius:2rem;
            font-size:0.65rem;
            font-weight:600;
            margin-top:0.2rem;
        }
        .trending-tag {
            display:inline-block;
            padding:0.3rem 0.8rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            color:#a09080;
            font-size:0.8rem;
            margin:0.2rem;
            transition:0.3s;
        }
        .trending-tag:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }

        /* ===== NEWSLETTER ===== */
        .newsletter-widget input {
            width:100%;
            padding:0.6rem 1rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            margin-bottom:0.5rem;
        }
        .newsletter-widget input:focus {
            outline:none;
            border-color:var(--secondary);
        }
        .newsletter-widget button {
            width:100%;
            padding:0.6rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
        }
        .newsletter-widget button:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }

        /* ===== VIDEO NEWS ===== */
        .video-news-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            overflow:hidden;
            transition:all 0.3s;
        }
        .video-news-card:hover {
            transform:translateY(-5px);
            border-color:var(--secondary);
        }
        .video-news-card .video-thumbnail {
            background:rgba(0,0,0,0.4);
            padding:1.5rem;
            text-align:center;
            position:relative;
            border-bottom:1px solid var(--border-color);
        }
        .video-news-card .video-thumbnail i {
            font-size:3rem;
            color:var(--secondary);
            opacity:0.3;
        }
        .video-news-card .video-thumbnail .play-btn {
            position:absolute;
            top:50%;
            left:50%;
            transform:translate(-50%,-50%);
            width:50px;
            height:50px;
            background:rgba(139,26,26,0.8);
            border-radius:50%;
            display:flex;
            align-items:center;
            justify-content:center;
            color:white;
            font-size:1.2rem;
            transition:0.3s;
        }
        .video-news-card .video-thumbnail .play-btn:hover {
            background:var(--primary);
            transform:translate(-50%,-50%) scale(1.1);
        }
        .video-news-card .video-info {
            padding:1.2rem;
        }
        .video-news-card .video-info h4 {
            color:#f0d6b0;
            font-size:0.95rem;
        }
        .video-news-card .video-info p {
            color:#a09080;
            font-size:0.85rem;
        }
        .video-news-card .video-info .video-meta {
            display:flex;
            gap:1rem;
            margin-top:0.5rem;
            color:#7a6a5a;
            font-size:0.75rem;
        }

        /* ===== LOAD MORE ===== */
        .load-more {
            text-align:center;
            margin-top:2rem;
        }
        .load-more button {
            padding:0.8rem 2.5rem;
            border-radius:2rem;
            border:2px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
        }
        .load-more button:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .featured-news {
                grid-template-columns:1fr;
            }
            .news-grid {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .news-hero { margin:1rem; padding:2rem 1rem; }
            .news-hero h1 { font-size:2rem; flex-direction:column; }
            .news-hero .search-box { flex-direction:column; }
            .featured-news { padding:1.5rem; }
            .card-grid { grid-template-columns:1fr; }
            .category-filters button { padding:0.3rem 1rem; font-size:0.75rem; }
        }
        @media (max-width:480px) {
            .section-header h2 { font-size:1.3rem; }
            .news-hero h1 { font-size:1.5rem; }
            .featured-news .featured-content h2 { font-size:1.3rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php" class="active-link"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <div class="news-hero">
        <h1>
            <i class="fas fa-newspaper"></i>
            Chess News
            <i class="fas fa-chess"></i>
        </h1>
        <p>Stay updated with the latest chess news, tournament results, interviews, and analysis from around the world.</p>
        <div class="search-box">
            <input type="text" placeholder="Search news, players, tournaments..." id="newsSearch" onkeyup="searchNews()">
            <button onclick="searchNews()"><i class="fas fa-search"></i> Search</button>
        </div>
    </div>

    <!-- ===== FEATURED NEWS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="featured-news">
            <div class="featured-content">
                <span class="badge badge-breaking" style="position:static;display:inline-block;margin-bottom:0.5rem;">Breaking News</span>
                <h2><?php echo e($featuredNews['title'] ?? 'World Chess Championship 2025: Carlsen to Face Nepomniachtchi'); ?></h2>
                <p><?php echo e($featuredNews['excerpt'] ?? 'The World Chess Championship match has been officially announced. Magnus Carlsen will defend his title against Ian Nepomniachtchi in a 14-game match starting November 2025.'); ?></p>
                <div class="news-meta">
                    <span><i class="fas fa-calendar"></i> <?php echo e($featuredNews['date'] ?? 'Nov 25, 2025'); ?></span>
                    <span><i class="fas fa-user"></i> <?php echo e($featuredNews['author'] ?? 'Chess Heaven Staff'); ?></span>
                    <span><i class="fas fa-tag"></i> <?php echo e($featuredNews['category'] ?? 'Tournament'); ?></span>
                    <span><i class="fas fa-comment"></i> <?php echo e($featuredNews['comments'] ?? 42); ?> comments</span>
                </div>
                <a href="news-detail.php?id=<?php echo e($featuredNews['id'] ?? 1); ?>" class="btn-read-more">
                    <i class="fas fa-arrow-right"></i> Read Full Story
                </a>
            </div>
            <div class="featured-image">
                <i class="fas fa-trophy"></i>
                <p style="color:#7a6a5a;margin-top:0.5rem;">World Championship</p>
            </div>
        </div>
    </section>

    <!-- ===== CATEGORY FILTERS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="category-filters" id="categoryFilters">
            <button class="active" onclick="filterCategory('all')">All News</button>
            <?php if (!empty($newsCategories)): ?>
                <?php foreach ($newsCategories as $category): ?>
                    <button onclick="filterCategory('<?php echo e($category['slug']); ?>')"><?php echo e($category['name']); ?></button>
                <?php endforeach; ?>
            <?php else: ?>
                <button onclick="filterCategory('tournament')">Tournaments</button>
                <button onclick="filterCategory('achievement')">Achievements</button>
                <button onclick="filterCategory('interview')">Interviews</button>
                <button onclick="filterCategory('analysis')">Analysis</button>
                <button onclick="filterCategory('update')">Updates</button>
                <button onclick="filterCategory('community')">Community</button>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== NEWS GRID ===== -->
    <section class="section" style="padding-top:0;">
        <div class="news-grid">
            <!-- Main News -->
            <div>
                <div class="section-header">
                    <h2><i class="fas fa-clock"></i> Latest News</h2>
                </div>
                <div class="card-grid" id="newsGrid">
                    <?php if (!empty($allNews)): ?>
                        <?php foreach ($allNews as $news): ?>
                            <a href="news-detail.php?id=<?php echo e($news['id']); ?>" class="card" data-category="<?php echo e($news['category'] ?? 'all'); ?>">
                                <span class="badge badge-<?php echo e($news['badge'] ?? 'update'); ?>"><?php echo e(ucfirst($news['category'] ?? 'Update')); ?></span>
                                <i class="fas fa-<?php echo e($news['icon'] ?? 'newspaper'); ?>"></i>
                                <h3><?php echo e($news['title']); ?></h3>
                                <p><?php echo e($news['excerpt']); ?></p>
                                <div class="meta">
                                    <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($news['date']))); ?></span>
                                    <span><i class="fas fa-comment"></i> <?php echo e($news['comments'] ?? 0); ?></span>
                                    <span><i class="fas fa-eye"></i> <?php echo e($news['views'] ?? 0); ?></span>
                                </div>
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <a href="news-detail.php?id=1" class="card" data-category="tournament">
                            <span class="badge badge-tournament">Tournament</span>
                            <i class="fas fa-trophy"></i>
                            <h3>Grand Chess Tour 2026 Announced</h3>
                            <p>The Grand Chess Tour returns with stops in Paris, Dubai, and New York.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 20, 2025</span><span><i class="fas fa-comment"></i> 28</span><span><i class="fas fa-eye"></i> 1.2k</span></div>
                        </a>
                        <a href="news-detail.php?id=2" class="card" data-category="achievement">
                            <span class="badge badge-achievement">Achievement</span>
                            <i class="fas fa-medal"></i>
                            <h3>New Grandmaster Title Earned</h3>
                            <p>18-year-old prodigy becomes the youngest GM in history.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 18, 2025</span><span><i class="fas fa-comment"></i> 45</span><span><i class="fas fa-eye"></i> 2.4k</span></div>
                        </a>
                        <a href="news-detail.php?id=3" class="card" data-category="interview">
                            <span class="badge badge-interview">Interview</span>
                            <i class="fas fa-microphone"></i>
                            <h3>Exclusive: Interview with Magnus Carlsen</h3>
                            <p>World champion talks about his preparation for the upcoming match.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 15, 2025</span><span><i class="fas fa-comment"></i> 67</span><span><i class="fas fa-eye"></i> 3.8k</span></div>
                        </a>
                        <a href="news-detail.php?id=4" class="card" data-category="analysis">
                            <span class="badge badge-analysis">Analysis</span>
                            <i class="fas fa-chess-board"></i>
                            <h3>Game Analysis: Carlsen vs Caruana</h3>
                            <p>Deep analysis of the decisive game from the recent tournament.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 12, 2025</span><span><i class="fas fa-comment"></i> 34</span><span><i class="fas fa-eye"></i> 1.8k</span></div>
                        </a>
                        <a href="news-detail.php?id=5" class="card" data-category="update">
                            <span class="badge badge-update">Update</span>
                            <i class="fas fa-chess-king"></i>
                            <h3>Chess Heaven Platform Update</h3>
                            <p>New features and improvements to your favorite chess platform.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 10, 2025</span><span><i class="fas fa-comment"></i> 19</span><span><i class="fas fa-eye"></i> 856</span></div>
                        </a>
                        <a href="news-detail.php?id=6" class="card" data-category="community">
                            <span class="badge badge-update">Community</span>
                            <i class="fas fa-users"></i>
                            <h3>Community Tournament a Success</h3>
                            <p>Over 200 players participated in the annual charity tournament.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 8, 2025</span><span><i class="fas fa-comment"></i> 52</span><span><i class="fas fa-eye"></i> 1.5k</span></div>
                        </a>
                        <a href="news-detail.php?id=7" class="card" data-category="tournament">
                            <span class="badge badge-tournament">Tournament</span>
                            <i class="fas fa-chess-queen"></i>
                            <h3>Women's World Championship Qualifiers</h3>
                            <p>The qualifiers for the Women's World Championship have concluded.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 5, 2025</span><span><i class="fas fa-comment"></i> 23</span><span><i class="fas fa-eye"></i> 967</span></div>
                        </a>
                        <a href="news-detail.php?id=8" class="card" data-category="achievement">
                            <span class="badge badge-achievement">Achievement</span>
                            <i class="fas fa-star"></i>
                            <h3>Chess Heaven Hits 100,000 Users</h3>
                            <p>Our community has reached a milestone of 100,000 registered users.</p>
                            <div class="meta"><span><i class="fas fa-calendar"></i> Dec 3, 2025</span><span><i class="fas fa-comment"></i> 31</span><span><i class="fas fa-eye"></i> 1.1k</span></div>
                        </a>
                    <?php endif; ?>
                </div>
                <div class="load-more">
                    <button onclick="loadMoreNews()"><i class="fas fa-plus"></i> Load More News</button>
                </div>
            </div>

            <!-- Sidebar -->
            <div class="sidebar">
                <!-- Trending Topics -->
                <div class="sidebar-widget">
                    <h3><i class="fas fa-fire"></i> Trending Topics</h3>
                    <?php if (!empty($trendingTopics)): ?>
                        <?php foreach ($trendingTopics as $topic): ?>
                            <a href="topic.php?tag=<?php echo e($topic['slug']); ?>" class="trending-tag">
                                #<?php echo e($topic['name']); ?> (<?php echo e($topic['count'] ?? 0); ?>)
                            </a>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <a href="topic.php?tag=worldchampionship" class="trending-tag">#WorldChampionship (156)</a>
                        <a href="topic.php?tag=carlsen" class="trending-tag">#Carlsen (142)</a>
                        <a href="topic.php?tag=grandchess" class="trending-tag">#GrandChess (98)</a>
                        <a href="topic.php?tag=gm" class="trending-tag">#Grandmaster (87)</a>
                        <a href="topic.php?tag=opening" class="trending-tag">#OpeningTheory (76)</a>
                        <a href="topic.php?tag=womenchess" class="trending-tag">#WomenInChess (65)</a>
                    <?php endif; ?>
                </div>

                <!-- Tournament News -->
                <div class="sidebar-widget">
                    <h3><i class="fas fa-trophy"></i> Tournament News</h3>
                    <?php if (!empty($tournamentNews)): ?>
                        <?php foreach ($tournamentNews as $news): ?>
                            <div class="widget-item">
                                <a href="news-detail.php?id=<?php echo e($news['id']); ?>" class="widget-title"><?php echo e($news['title']); ?></a>
                                <div class="widget-meta">
                                    <span><i class="fas fa-calendar"></i> <?php echo e(date('M d', strtotime($news['date']))); ?></span>
                                    <?php if ($news['live'] ?? false): ?>
                                        <span class="widget-tag" style="background:rgba(231,76,60,0.2);color:#e74c3c;animation:pulse-badge 2s infinite;">LIVE</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="widget-item">
                            <a href="news-detail.php?id=1" class="widget-title">World Chess Championship 2025</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Nov 25</span><span class="widget-tag" style="background:rgba(231,76,60,0.2);color:#e74c3c;animation:pulse-badge 2s infinite;">LIVE</span></div>
                        </div>
                        <div class="widget-item">
                            <a href="news-detail.php?id=2" class="widget-title">Grand Chess Tour 2026</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Jan 15</span></div>
                        </div>
                        <div class="widget-item">
                            <a href="news-detail.php?id=3" class="widget-title">Women's World Championship</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Feb 1</span></div>
                        </div>
                        <div class="widget-item">
                            <a href="news-detail.php?id=4" class="widget-title">Chess Heaven Open 2025</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Dec 30</span></div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Video News -->
                <div class="sidebar-widget">
                    <h3><i class="fas fa-video"></i> Video News</h3>
                    <?php if (!empty($videoNews)): ?>
                        <?php foreach ($videoNews as $video): ?>
                            <div class="video-news-card" style="margin-bottom:0.8rem;">
                                <div class="video-thumbnail" style="padding:1rem;">
                                    <i class="fas fa-<?php echo e($video['icon'] ?? 'video'); ?>"></i>
                                    <div class="play-btn" style="width:40px;height:40px;font-size:1rem;"><i class="fas fa-play"></i></div>
                                </div>
                                <div class="video-info" style="padding:0.8rem;">
                                    <h4 style="font-size:0.85rem;"><?php echo e($video['title']); ?></h4>
                                    <div class="video-meta"><span><?php echo e($video['duration'] ?? '10 min'); ?></span><span><?php echo e($video['views'] ?? '500'); ?> views</span></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="video-news-card" style="margin-bottom:0.8rem;">
                            <div class="video-thumbnail" style="padding:1rem;">
                                <i class="fas fa-chess-king"></i>
                                <div class="play-btn" style="width:40px;height:40px;font-size:1rem;"><i class="fas fa-play"></i></div>
                            </div>
                            <div class="video-info" style="padding:0.8rem;">
                                <h4 style="font-size:0.85rem;">Carlsen's Best Games Compilation</h4>
                                <div class="video-meta"><span>15 min</span><span>2.4k views</span></div>
                            </div>
                        </div>
                        <div class="video-news-card" style="margin-bottom:0.8rem;">
                            <div class="video-thumbnail" style="padding:1rem;">
                                <i class="fas fa-chess-queen"></i>
                                <div class="play-btn" style="width:40px;height:40px;font-size:1rem;"><i class="fas fa-play"></i></div>
                            </div>
                            <div class="video-info" style="padding:0.8rem;">
                                <h4 style="font-size:0.85rem;">World Championship Press Conference</h4>
                                <div class="video-meta"><span>22 min</span><span>1.8k views</span></div>
                            </div>
                        </div>
                        <div class="video-news-card">
                            <div class="video-thumbnail" style="padding:1rem;">
                                <i class="fas fa-chess-knight"></i>
                                <div class="play-btn" style="width:40px;height:40px;font-size:1rem;"><i class="fas fa-play"></i></div>
                            </div>
                            <div class="video-info" style="padding:0.8rem;">
                                <h4 style="font-size:0.85rem;">Opening Analysis: Queen's Gambit</h4>
                                <div class="video-meta"><span>18 min</span><span>1.2k views</span></div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Newsletter -->
                <div class="sidebar-widget newsletter-widget">
                    <h3><i class="fas fa-envelope"></i> Newsletter</h3>
                    <p style="color:#a09080;font-size:0.85rem;margin-bottom:0.8rem;">Subscribe for weekly chess news and updates.</p>
                    <input type="email" placeholder="Your email address" id="newsletterEmail">
                    <button onclick="subscribeNewsletter()"><i class="fas fa-paper-plane"></i> Subscribe</button>
                    <p style="color:#7a6a5a;font-size:0.7rem;margin-top:0.5rem;">Join <?php echo e($newsletterSubscribers ?? '2,500'); ?> subscribers</p>
                </div>

                <!-- Upcoming Events -->
                <div class="sidebar-widget">
                    <h3><i class="fas fa-calendar-alt"></i> Upcoming Events</h3>
                    <?php if (!empty($upcomingEvents)): ?>
                        <?php foreach ($upcomingEvents as $event): ?>
                            <div class="widget-item">
                                <a href="event.php?id=<?php echo e($event['id']); ?>" class="widget-title"><?php echo e($event['title']); ?></a>
                                <div class="widget-meta">
                                    <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($event['date']))); ?></span>
                                    <span><i class="fas fa-map-marker-alt"></i> <?php echo e($event['location']); ?></span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="widget-item">
                            <a href="event.php?id=1" class="widget-title">World Chess Championship</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Nov 25, 2025</span><span><i class="fas fa-map-marker-alt"></i> Dubai</span></div>
                        </div>
                        <div class="widget-item">
                            <a href="event.php?id=2" class="widget-title">Chess Heaven Open</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Dec 30, 2025</span><span><i class="fas fa-map-marker-alt"></i> Online</span></div>
                        </div>
                        <div class="widget-item">
                            <a href="event.php?id=3" class="widget-title">Grand Chess Tour</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Jan 15, 2026</span><span><i class="fas fa-map-marker-alt"></i> Paris</span></div>
                        </div>
                        <div class="widget-item">
                            <a href="event.php?id=4" class="widget-title">Women's World Championship</a>
                            <div class="widget-meta"><span><i class="fas fa-calendar"></i> Feb 1, 2026</span><span><i class="fas fa-map-marker-alt"></i> London</span></div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Recent Comments -->
                <div class="sidebar-widget">
                    <h3><i class="fas fa-comments"></i> Recent Comments</h3>
                    <?php if (!empty($recentComments)): ?>
                        <?php foreach ($recentComments as $comment): ?>
                            <div class="widget-item">
                                <div style="color:#f0d6b0;font-size:0.85rem;"><?php echo e($comment['author']); ?></div>
                                <div style="color:#a09080;font-size:0.8rem;">"<?php echo e(substr($comment['text'], 0, 60)); ?>..."</div>
                                <div class="widget-meta"><span><i class="fas fa-clock"></i> <?php echo e(date('M d', strtotime($comment['date']))); ?></span></div>
                            </div>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <div class="widget-item">
                            <div style="color:#f0d6b0;font-size:0.85rem;">Mike R.</div>
                            <div style="color:#a09080;font-size:0.8rem;">"Great analysis of the game!"</div>
                            <div class="widget-meta"><span><i class="fas fa-clock"></i> Dec 20</span></div>
                        </div>
                        <div class="widget-item">
                            <div style="color:#f0d6b0;font-size:0.85rem;">Sarah K.</div>
                            <div style="color:#a09080;font-size:0.8rem;">"Excited for the championship!"</div>
                            <div class="widget-meta"><span><i class="fas fa-clock"></i> Dec 19</span></div>
                        </div>
                        <div class="widget-item">
                            <div style="color:#f0d6b0;font-size:0.85rem;">James P.</div>
                            <div style="color:#a09080;font-size:0.8rem;">"Thanks for the coverage!"</div>
                            <div class="widget-meta"><span><i class="fas fa-clock"></i> Dec 18</span></div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:var(--card-bg);border-radius:1.5rem;padding:2rem;border:1px solid var(--border-color);text-align:center;">
            <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--secondary);"></i>
            <h3 style="color:#f0d6b0;margin:0.5rem 0;">Stay Informed</h3>
            <p style="color:#a09080;max-width:600px;margin:0 auto;">
                <i class="fas fa-chess-pawn"></i> Follow us on social media for real-time updates and breaking chess news.
                <br>
                <span style="color:var(--secondary);font-size:0.85rem;">"Knowledge is power in chess and in life."</span>
            </p>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // Category filter for news
        function filterCategory(category) {
            document.querySelectorAll('.category-filters button').forEach(btn => {
                btn.classList.toggle('active', btn.textContent.toLowerCase() === category || 
                    (category === 'all' && btn.textContent === 'All News'));
            });

            const cards = document.querySelectorAll('#newsGrid .card');
            cards.forEach(card => {
                if (category === 'all' || card.dataset.category === category) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Search news
        function searchNews() {
            const searchTerm = document.getElementById('newsSearch').value.toLowerCase();
            const cards = document.querySelectorAll('#newsGrid .card');
            
            cards.forEach(card => {
                const title = card.querySelector('h3')?.textContent?.toLowerCase() || '';
                const desc = card.querySelector('p')?.textContent?.toLowerCase() || '';
                
                if (title.includes(searchTerm) || desc.includes(searchTerm)) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        // Load more news
        let newsCount = 0;
        function loadMoreNews() {
            newsCount++;
            const button = document.querySelector('.load-more button');
            button.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
            
            setTimeout(() => {
                button.innerHTML = '<i class="fas fa-plus"></i> Load More News';
                alert('More news loaded! (Demo)');
            }, 1000);
        }

        // Newsletter subscription
        function subscribeNewsletter() {
            const email = document.getElementById('newsletterEmail').value;
            if (email && email.includes('@')) {
                alert('Thank you for subscribing with ' + email + '!');
                document.getElementById('newsletterEmail').value = '';
            } else {
                alert('Please enter a valid email address.');
            }
        }

        // Enter key for search
        document.getElementById('newsSearch').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                searchNews();
            }
        });

        // Enter key for newsletter
        document.getElementById('newsletterEmail').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                subscribeNewsletter();
            }
        });
    </script>
</body>
</html>