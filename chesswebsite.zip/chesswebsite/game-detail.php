<?php
/**
 * Chess Heaven - Game Detail Page
 * Displays detailed information about a specific chess game
 */

require_once 'config.php';

// Get game ID from URL
$gameId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get game details (simulated data for demo)
$gameDetails = getGameDetails($gameId);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Game Details</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== GAME DETAIL ===== */
        .game-detail-container {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:2rem;
            align-items:start;
        }
        .game-main {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
        }
        .game-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:1.5rem;
            flex-wrap:wrap;
            gap:1rem;
        }
        .game-header h1 {
            font-size:1.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .game-header .result-badge {
            padding:0.5rem 1.5rem;
            border-radius:2rem;
            font-weight:700;
            font-size:0.9rem;
        }
        .result-badge.win { background:rgba(46,204,113,0.2); color:#2ecc71; border:1px solid #2ecc71; }
        .result-badge.loss { background:rgba(231,76,60,0.2); color:#e74c3c; border:1px solid #e74c3c; }
        .result-badge.draw { background:rgba(241,196,15,0.2); color:#f1c40f; border:1px solid #f1c40f; }

        .game-players {
            display:grid;
            grid-template-columns:1fr auto 1fr;
            gap:1rem;
            align-items:center;
            padding:1.5rem;
            background:rgba(0,0,0,0.2);
            border-radius:1rem;
            margin-bottom:1.5rem;
        }
        .player-card {
            text-align:center;
        }
        .player-card .avatar {
            width:60px;
            height:60px;
            border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex;
            align-items:center;
            justify-content:center;
            margin:0 auto 0.5rem;
            font-size:1.8rem;
            color:var(--secondary);
        }
        .player-card .name {
            color:#f0d6b0;
            font-weight:600;
            font-size:1rem;
        }
        .player-card .rating {
            color:#a09080;
            font-size:0.85rem;
        }
        .player-card .score {
            font-size:1.5rem;
            font-weight:700;
            color:var(--secondary);
            margin-top:0.3rem;
        }
        .vs-badge {
            font-size:1.5rem;
            color:var(--secondary);
            font-weight:700;
            padding:0 1rem;
        }

        .game-meta {
            display:grid;
            grid-template-columns:repeat(auto-fit,minmax(150px,1fr));
            gap:1rem;
            margin:1.5rem 0;
            padding:1rem;
            background:rgba(0,0,0,0.15);
            border-radius:0.8rem;
        }
        .game-meta .meta-item {
            text-align:center;
        }
        .game-meta .meta-item .label {
            color:#7a6a5a;
            font-size:0.75rem;
            text-transform:uppercase;
            letter-spacing:1px;
        }
        .game-meta .meta-item .value {
            color:#f0d6b0;
            font-size:1rem;
            font-weight:600;
            margin-top:0.2rem;
        }

        /* ===== MOVE HISTORY ===== */
        .move-history-container {
            background:rgba(0,0,0,0.2);
            border-radius:0.8rem;
            padding:1rem;
            max-height:400px;
            overflow-y:auto;
            margin-top:1rem;
        }
        .move-history-container::-webkit-scrollbar { width:6px; }
        .move-history-container::-webkit-scrollbar-track { background:transparent; }
        .move-history-container::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:3px; }
        
        .move-history-container .move-row {
            display:grid;
            grid-template-columns:40px 1fr 1fr;
            gap:0.5rem;
            padding:0.3rem 0.5rem;
            border-bottom:1px solid rgba(255,255,255,0.03);
            font-size:0.85rem;
        }
        .move-history-container .move-row:hover {
            background:rgba(255,255,255,0.03);
        }
        .move-number { color:#5a4a3a; font-weight:600; }
        .move-white { color:#f0d6b0; }
        .move-black { color:#a09080; }

        /* ===== SIDEBAR ===== */
        .game-sidebar {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .sidebar-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
        }
        .sidebar-card h3 {
            color:#f0d6b0;
            font-size:1rem;
            margin-bottom:0.8rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .sidebar-card h3 i { color:var(--secondary); }
        .sidebar-card .stat-row {
            display:flex;
            justify-content:space-between;
            padding:0.5rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            color:#a09080;
            font-size:0.85rem;
        }
        .sidebar-card .stat-row:last-child { border-bottom:none; }
        .sidebar-card .stat-row span:last-child { color:#f0d6b0; font-weight:500; }

        .similar-games {
            display:flex;
            flex-direction:column;
            gap:0.8rem;
        }
        .similar-game-item {
            display:flex;
            justify-content:space-between;
            padding:0.6rem;
            background:rgba(0,0,0,0.15);
            border-radius:0.5rem;
            transition:0.3s;
            cursor:pointer;
        }
        .similar-game-item:hover {
            background:rgba(139,26,26,0.2);
        }
        .similar-game-item .game-info {
            display:flex;
            flex-direction:column;
        }
        .similar-game-item .game-info .opponent {
            color:#f0d6b0;
            font-weight:500;
        }
        .similar-game-item .game-info .date {
            color:#7a6a5a;
            font-size:0.75rem;
        }
        .similar-game-item .result {
            font-weight:600;
            font-size:0.85rem;
            align-self:center;
        }

        /* ===== CHESS BOARD MINI ===== */
        .mini-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:300px;
            aspect-ratio:1;
            margin:0 auto;
            border:2px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
        }
        .mini-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:1.5rem;
            aspect-ratio:1;
            user-select:none;
        }
        .mini-board .square.light { background:var(--light-square); }
        .mini-board .square.dark { background:var(--dark-square); }
        .mini-board .square .piece {
            font-size:1.5rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
        }
        .mini-board .square .piece.white-piece { color:#fff; filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5)); }
        .mini-board .square .piece.black-piece { color:#1a1a1a; filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3)); }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .game-detail-container {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .game-main { padding:1rem; }
            .game-players {
                grid-template-columns:1fr;
                gap:0.5rem;
            }
            .vs-badge { padding:0.5rem 0; }
            .game-header h1 { font-size:1.3rem; }
            .game-meta { grid-template-columns:1fr 1fr; }
            .move-history-container .move-row {
                grid-template-columns:30px 1fr 1fr;
                font-size:0.75rem;
            }
        }
        @media (max-width:480px) {
            .game-meta { grid-template-columns:1fr; }
            .mini-board { max-width:200px; }
            .mini-board .square .piece { font-size:1.2rem; }
        }

        /* ===== SCROLLBAR ===== */
        .move-history-container::-webkit-scrollbar { width:4px; }
        .move-history-container::-webkit-scrollbar-track { background:transparent; }
        .move-history-container::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== GAME DETAIL ===== -->
    <section class="section">
        <?php if ($gameDetails): ?>
            <div class="game-detail-container">
                <!-- Main Content -->
                <div class="game-main">
                    <!-- Header -->
                    <div class="game-header">
                        <h1>
                            <i class="fas fa-chess-<?php echo $gameDetails['result'] === 'win' ? 'king' : ($gameDetails['result'] === 'loss' ? 'queen' : 'knight'); ?>"></i>
                            Game #<?php echo e($gameId); ?>
                        </h1>
                        <span class="result-badge <?php echo $gameDetails['result']; ?>">
                            <?php echo ucfirst($gameDetails['result']); ?>
                        </span>
                    </div>

                    <!-- Players -->
                    <div class="game-players">
                        <div class="player-card">
                            <div class="avatar"><i class="fas fa-user"></i></div>
                            <div class="name"><?php echo e($gameDetails['player_name']); ?></div>
                            <div class="rating">Rating: <?php echo e($gameDetails['player_rating']); ?></div>
                            <div class="score"><?php echo e($gameDetails['result'] === 'win' ? '1' : ($gameDetails['result'] === 'loss' ? '0' : '½')); ?></div>
                        </div>
                        <div class="vs-badge">VS</div>
                        <div class="player-card">
                            <div class="avatar"><i class="fas fa-robot"></i></div>
                            <div class="name"><?php echo e($gameDetails['opponent']); ?></div>
                            <div class="rating">Rating: <?php echo e($gameDetails['opponent_rating']); ?></div>
                            <div class="score"><?php echo e($gameDetails['result'] === 'loss' ? '1' : ($gameDetails['result'] === 'win' ? '0' : '½')); ?></div>
                        </div>
                    </div>

                    <!-- Game Meta -->
                    <div class="game-meta">
                        <div class="meta-item">
                            <div class="label">Date</div>
                            <div class="value"><i class="far fa-calendar-alt"></i> <?php echo e($gameDetails['date']); ?></div>
                        </div>
                        <div class="meta-item">
                            <div class="label">Time Control</div>
                            <div class="value"><i class="far fa-clock"></i> <?php echo e($gameDetails['time_control']); ?></div>
                        </div>
                        <div class="meta-item">
                            <div class="label">Moves</div>
                            <div class="value"><i class="fas fa-exchange-alt"></i> <?php echo e($gameDetails['total_moves']); ?></div>
                        </div>
                        <div class="meta-item">
                            <div class="label">Opening</div>
                            <div class="value"><i class="fas fa-book-open"></i> <?php echo e($gameDetails['opening']); ?></div>
                        </div>
                    </div>

                    <!-- Mini Board -->
                    <div style="text-align:center;margin:1rem 0;">
                        <div class="mini-board" id="miniBoard"></div>
                    </div>

                    <!-- Move History -->
                    <h3 style="color:#f0d6b0;margin:1rem 0 0.5rem;">
                        <i class="fas fa-list"></i> Move History
                    </h3>
                    <div class="move-history-container" id="moveHistoryContainer">
                        <?php if (!empty($gameDetails['moves'])): ?>
                            <?php foreach ($gameDetails['moves'] as $index => $move): ?>
                                <?php if ($index % 2 === 0): ?>
                                    <div class="move-row">
                                        <span class="move-number"><?php echo e(floor($index / 2) + 1); ?>.</span>
                                        <span class="move-white"><?php echo e($move); ?></span>
                                        <?php if (isset($gameDetails['moves'][$index + 1])): ?>
                                            <span class="move-black"><?php echo e($gameDetails['moves'][$index + 1]); ?></span>
                                        <?php else: ?>
                                            <span class="move-black">—</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div style="color:#5a4a3a;text-align:center;padding:1rem;">No moves recorded</div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="game-sidebar">
                    <!-- Game Stats -->
                    <div class="sidebar-card">
                        <h3><i class="fas fa-chart-bar"></i> Game Statistics</h3>
                        <div class="stat-row">
                            <span>Accuracy</span>
                            <span><?php echo e($gameDetails['accuracy'] ?? '—'); ?>%</span>
                        </div>
                        <div class="stat-row">
                            <span>Captures</span>
                            <span><?php echo e($gameDetails['captures'] ?? '—'); ?></span>
                        </div>
                        <div class="stat-row">
                            <span>Checks</span>
                            <span><?php echo e($gameDetails['checks'] ?? '—'); ?></span>
                        </div>
                        <div class="stat-row">
                            <span>Blunders</span>
                            <span><?php echo e($gameDetails['blunders'] ?? '—'); ?></span>
                        </div>
                        <div class="stat-row">
                            <span>Best Move</span>
                            <span><?php echo e($gameDetails['best_move'] ?? '—'); ?></span>
                        </div>
                    </div>

                    <!-- Similar Games -->
                    <div class="sidebar-card">
                        <h3><i class="fas fa-history"></i> Similar Games</h3>
                        <div class="similar-games">
                            <?php if (!empty($gameDetails['similar_games'])): ?>
                                <?php foreach ($gameDetails['similar_games'] as $similar): ?>
                                    <a href="game-detail.php?id=<?php echo e($similar['id']); ?>" class="similar-game-item">
                                        <div class="game-info">
                                            <span class="opponent">vs <?php echo e($similar['opponent']); ?></span>
                                            <span class="date"><?php echo e($similar['date']); ?></span>
                                        </div>
                                        <span class="result" style="color:<?php echo $similar['result'] === 'win' ? '#2ecc71' : ($similar['result'] === 'loss' ? '#e74c3c' : '#f1c40f'); ?>;">
                                            <?php echo ucfirst($similar['result']); ?>
                                        </span>
                                    </a>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div style="color:#5a4a3a;text-align:center;padding:1rem;">No similar games found</div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="sidebar-card">
                        <h3><i class="fas fa-cog"></i> Actions</h3>
                        <div style="display:flex;flex-direction:column;gap:0.5rem;">
                            <a href="play.php" class="btn-play" style="display:flex;align-items:center;justify-content:center;gap:0.5rem;padding:0.7rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-align:center;transition:0.3s;">
                                <i class="fas fa-play"></i> Play Again
                            </a>
                            <a href="history.php" class="btn-restart" style="display:flex;align-items:center;justify-content:center;gap:0.5rem;padding:0.7rem;border-radius:2rem;background:rgba(198,151,107,0.15);color:var(--secondary);border:1px solid var(--secondary);font-weight:600;text-align:center;transition:0.3s;">
                                <i class="fas fa-list"></i> View All Games
                            </a>
                            <button onclick="window.print()" class="btn-print" style="display:flex;align-items:center;justify-content:center;gap:0.5rem;padding:0.7rem;border-radius:2rem;background:rgba(255,255,255,0.05);color:#a09080;border:1px solid rgba(255,255,255,0.1);font-weight:600;text-align:center;transition:0.3s;cursor:pointer;">
                                <i class="fas fa-print"></i> Print Game
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div style="text-align:center;padding:4rem 2rem;">
                <i class="fas fa-exclamation-triangle" style="font-size:4rem;color:var(--secondary);"></i>
                <h2 style="color:#f0d6b0;margin:1rem 0;">Game Not Found</h2>
                <p style="color:#a09080;">The game you're looking for doesn't exist or has been removed.</p>
                <a href="play.php" class="btn-play" style="display:inline-block;margin-top:1.5rem;padding:0.8rem 2rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-decoration:none;">
                    <i class="fas fa-chess"></i> Start a New Game
                </a>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== MINI BOARD =====
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // Get game state from PHP (simulated)
        const gameState = <?php echo json_encode($gameDetails ? [
            'board' => $gameDetails['final_position'] ?? [
                ['r','n','b','q','k','b','n','r'],
                ['p','p','p','p','p','p','p','p'],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['P','P','P','P','P','P','P','P'],
                ['R','N','B','Q','K','B','N','R']
            ]
        ] : []); ?>;

        function renderMiniBoard() {
            const boardEl = document.getElementById('miniBoard');
            if (!boardEl) return;
            
            const board = gameState.board || [
                ['r','n','b','q','k','b','n','r'],
                ['p','p','p','p','p','p','p','p'],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['P','P','P','P','P','P','P','P'],
                ['R','N','B','Q','K','B','N','R']
            ];
            
            boardEl.innerHTML = '';
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    
                    const piece = board[row]?.[col] || '';
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    boardEl.appendChild(square);
                }
            }
        }

        // ===== INIT =====
        document.addEventListener('DOMContentLoaded', function() {
            renderMiniBoard();
        });
    </script>
</body>
</html>
<?php
/**
 * Helper function to get game details
 * In a real implementation, this would fetch from database
 */
function getGameDetails($id) {
    // Simulated game data for demo purposes
    $games = [
        1 => [
            'player_name' => 'Guest Player',
            'player_rating' => '1500',
            'opponent' => 'GM Alpha',
            'opponent_rating' => '2200',
            'result' => 'win',
            'date' => 'Dec 20, 2025',
            'time_control' => 'Classical (30+0)',
            'total_moves' => '45',
            'opening' => 'Italian Game',
            'moves' => ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'd3', 'Nf6', 'Bg5', 'h6', 'Bh4', 'g5', 'Bg3', 'd5', 'exd5', 'Nxd5', 'Nxe5', 'Nxe5', 'Bxd5', 'Qxd5', 'c3', 'O-O', 'O-O', 'Be6', 'Re1', 'Rad8', 'Qa4', 'Bf5', 'Nbd2', 'Qc6', 'Qxc6', 'Bxc6', 'Nf3', 'Rd7', 'b4', 'Bf6', 'Bb3', 'Bd8', 'd4', 'c6', 'dxc6', 'bxc6', 'Rad1', 'Rfd8', 'Rxd7'],
            'accuracy' => '92',
            'captures' => '8',
            'checks' => '4',
            'blunders' => '0',
            'best_move' => 'Nxe5!',
            'final_position' => [
                ['r','n','b','q','k','b','n','r'],
                ['p','p','p','p','p','p','p','p'],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['P','P','P','P','P','P','P','P'],
                ['R','N','B','Q','K','B','N','R']
            ],
            'similar_games' => [
                ['id' => 2, 'opponent' => 'IM Beta', 'date' => 'Dec 18, 2025', 'result' => 'loss'],
                ['id' => 3, 'opponent' => 'CM Gamma', 'date' => 'Dec 16, 2025', 'result' => 'draw'],
                ['id' => 4, 'opponent' => 'FM Delta', 'date' => 'Dec 14, 2025', 'result' => 'win']
            ]
        ],
        2 => [
            'player_name' => 'Guest Player',
            'player_rating' => '1500',
            'opponent' => 'IM Beta',
            'opponent_rating' => '2100',
            'result' => 'loss',
            'date' => 'Dec 18, 2025',
            'time_control' => 'Blitz (5+3)',
            'total_moves' => '28',
            'opening' => 'Sicilian Defense',
            'moves' => ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'a6', 'Be3', 'e5', 'Nb3', 'Be6', 'f3', 'Be7', 'Qd2', 'Nbd7', 'O-O-O', 'b5', 'g4', 'b4', 'Na4', 'd5', 'exd5', 'Nxd5', 'Bxd5', 'Bxd5'],
            'accuracy' => '78',
            'captures' => '6',
            'checks' => '2',
            'blunders' => '2',
            'best_move' => 'd5!',
            'final_position' => [
                ['r','n','b','q','k','b','n','r'],
                ['p','p','p','p','p','p','p','p'],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['P','P','P','P','P','P','P','P'],
                ['R','N','B','Q','K','B','N','R']
            ],
            'similar_games' => [
                ['id' => 1, 'opponent' => 'GM Alpha', 'date' => 'Dec 20, 2025', 'result' => 'win'],
                ['id' => 3, 'opponent' => 'CM Gamma', 'date' => 'Dec 16, 2025', 'result' => 'draw']
            ]
        ],
        3 => [
            'player_name' => 'Guest Player',
            'player_rating' => '1500',
            'opponent' => 'CM Gamma',
            'opponent_rating' => '1900',
            'result' => 'draw',
            'date' => 'Dec 16, 2025',
            'time_control' => 'Rapid (15+10)',
            'total_moves' => '62',
            'opening' => 'Ruy Lopez',
            'moves' => ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6', 'O-O', 'Be7', 'Re1', 'b5', 'Bb3', 'O-O', 'c3', 'd6', 'd4', 'Bg4', 'dxe5', 'Nxe5', 'Nxe5', 'Bxe5', 'Qd3', 'Bxf3', 'gxf3', 'Qd7', 'f4', 'Bh2+', 'Kh1', 'Rad8', 'Qc2', 'Bf5', 'Qc1', 'c5', 'Be3', 'Qc7', 'Bc2', 'Bd7', 'Nd2', 'Qb6', 'b3', 'c4', 'b4', 'a5', 'a3', 'axb4', 'axb4', 'Bc6', 'Bd3', 'Ra8', 'Qb1', 'Qc7'],
            'accuracy' => '85',
            'captures' => '10',
            'checks' => '6',
            'blunders' => '1',
            'best_move' => 'Bc6!',
            'final_position' => [
                ['r','n','b','q','k','b','n','r'],
                ['p','p','p','p','p','p','p','p'],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['','','','','','','',''],
                ['P','P','P','P','P','P','P','P'],
                ['R','N','B','Q','K','B','N','R']
            ],
            'similar_games' => [
                ['id' => 1, 'opponent' => 'GM Alpha', 'date' => 'Dec 20, 2025', 'result' => 'win'],
                ['id' => 2, 'opponent' => 'IM Beta', 'date' => 'Dec 18, 2025', 'result' => 'loss']
            ]
        ]
    ];
    
    return $games[$id] ?? null;
}
?>