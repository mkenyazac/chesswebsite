<?php
/**
 * Chess Heaven - Tournament Registration Page
 * Combined login and registration page for tournament participation
 */

require_once 'config.php';

// Get tournament ID from URL
$tournamentId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get tournament details
$tournamentDetails = getTournamentForRegistration($tournamentId);

// Handle form submissions
$loginError = '';
$registerError = '';
$registerSuccess = '';
$loginSuccess = '';
$registrationStep = isset($_GET['step']) ? $_GET['step'] : 'login';

// Check if user is already logged in and step is confirm
if ($isLoggedIn && $registrationStep === 'confirm') {
    // User is logged in, show confirmation
} elseif ($isLoggedIn) {
    // User is logged in but step is not confirm, redirect to confirm
    header("Location: tournament-register.php?id=" . $tournamentId . "&step=confirm");
    exit;
}

// Handle login form submission - now accepts username OR email
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login_submit'])) {
    $loginInput = trim($_POST['login_input'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($loginInput) || empty($password)) {
        $loginError = 'Please enter both username/email and password.';
    } else {
        $user = authenticateUserByUsernameOrEmail($loginInput, $password);
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_role'] = $user['role'];
            $loginSuccess = 'Login successful! Redirecting...';
            
            // Redirect to registration confirmation
            header("Refresh: 2; URL=tournament-register.php?id=" . $tournamentId . "&step=confirm");
            exit;
        } else {
            $loginError = 'Invalid username/email or password. Please try again.';
        }
    }
}

// Handle registration form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['register_submit'])) {
    $fullName = trim($_POST['full_name'] ?? '');
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirmPassword = $_POST['confirm_password'] ?? '';
    $terms = isset($_POST['terms']) ? true : false;
    
    // Validate inputs
    if (empty($fullName)) {
        $registerError = 'Please enter your full name.';
    } elseif (empty($username)) {
        $registerError = 'Please choose a username.';
    } elseif (strlen($username) < 3) {
        $registerError = 'Username must be at least 3 characters.';
    } elseif (empty($email)) {
        $registerError = 'Please enter your email address.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $registerError = 'Please enter a valid email address.';
    } elseif (empty($password)) {
        $registerError = 'Please choose a password.';
    } elseif (strlen($password) < 6) {
        $registerError = 'Password must be at least 6 characters.';
    } elseif ($password !== $confirmPassword) {
        $registerError = 'Passwords do not match.';
    } elseif (!$terms) {
        $registerError = 'You must agree to the terms and conditions.';
    } else {
        // Check if username exists
        if (usernameExists($username)) {
            $registerError = 'Username already taken. Please choose another.';
        } elseif (emailExists($email)) {
            $registerError = 'Email already registered. Please login instead.';
        } else {
            // Create user
            $passwordHash = password_hash($password, PASSWORD_DEFAULT);
            $userId = createUser($username, $email, $passwordHash, $fullName, '');
            
            if ($userId) {
                // Log user in
                $_SESSION['user_id'] = $userId;
                $_SESSION['username'] = $username;
                $_SESSION['user_email'] = $email;
                $_SESSION['user_role'] = 'user';
                $registerSuccess = 'Account created successfully! Redirecting...';
                
                // Redirect to registration confirmation
                header("Refresh: 2; URL=tournament-register.php?id=" . $tournamentId . "&step=confirm");
                exit;
            } else {
                $registerError = 'There was an error creating your account. Please try again.';
            }
        }
    }
}

// Handle tournament registration confirmation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_registration']) && $isLoggedIn) {
    $userId = $_SESSION['user_id'];
    
    // Register user for tournament
    $registrationResult = registerForTournament($userId, $tournamentId);
    
    if ($registrationResult['success']) {
        $confirmSuccess = $registrationResult['message'];
        $_SESSION['registered_tournament_' . $tournamentId] = true;
    } else {
        $confirmError = $registrationResult['message'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Tournament Registration</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== REGISTRATION CONTAINER ===== */
        .register-container {
            max-width:550px;
            margin:2rem auto;
            padding:0 1rem;
        }
        .register-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2.5rem;
            backdrop-filter:blur(4px);
            border:2px solid var(--gold);
        }
        .register-card .card-header {
            text-align:center;
            margin-bottom:2rem;
        }
        .register-card .card-header .icon {
            font-size:3rem;
            color:var(--gold);
            margin-bottom:0.5rem;
        }
        .register-card .card-header h1 {
            color:#f0d6b0;
            font-size:1.8rem;
        }
        .register-card .card-header p {
            color:#a09080;
            font-size:0.9rem;
            margin-top:0.3rem;
        }

        /* ===== TOURNAMENT INFO ===== */
        .tournament-info {
            background:rgba(139,26,26,0.15);
            border-radius:1rem;
            padding:1rem 1.2rem;
            margin-bottom:1.5rem;
            border-left:4px solid var(--gold);
        }
        .tournament-info .tournament-name {
            color:#f0d6b0;
            font-size:1.1rem;
            font-weight:600;
        }
        .tournament-info .tournament-details {
            color:#a09080;
            font-size:0.85rem;
            margin-top:0.3rem;
        }
        .tournament-info .tournament-details span {
            margin-right:1rem;
        }

        /* ===== FORM ===== */
        .form-group {
            margin-bottom:1.2rem;
        }
        .form-group label {
            display:block;
            color:#a09080;
            font-size:0.85rem;
            font-weight:500;
            margin-bottom:0.3rem;
        }
        .form-group label .required {
            color:var(--danger);
        }
        .form-group .input-wrapper {
            position:relative;
        }
        .form-group .input-wrapper i {
            position:absolute;
            left:1rem;
            top:50%;
            transform:translateY(-50%);
            color:#5a4a3a;
        }
        .form-group input {
            width:100%;
            padding:0.8rem 1rem 0.8rem 2.8rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-size:0.95rem;
            transition:all 0.3s;
        }
        .form-group input:focus {
            outline:none;
            border-color:var(--secondary);
            box-shadow:0 0 0 3px rgba(198,151,107,0.1);
        }
        .form-group input::placeholder {
            color:#5a4a3a;
        }
        .form-group .password-toggle {
            position:absolute;
            right:1rem;
            top:50%;
            transform:translateY(-50%);
            background:transparent;
            border:none;
            color:#5a4a3a;
            cursor:pointer;
        }
        .form-group .password-toggle:hover {
            color:var(--secondary);
        }

        .form-group .checkbox-wrapper {
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .form-group .checkbox-wrapper input[type="checkbox"] {
            width:18px;
            height:18px;
            padding:0;
            cursor:pointer;
            accent-color:var(--secondary);
        }
        .form-group .checkbox-wrapper label {
            margin:0;
            font-size:0.85rem;
            color:#a09080;
            cursor:pointer;
        }
        .form-group .checkbox-wrapper label a {
            color:var(--secondary);
        }
        .form-group .checkbox-wrapper label a:hover {
            text-decoration:underline;
        }

        /* ===== BUTTONS ===== */
        .btn-primary {
            width:100%;
            padding:0.9rem;
            border-radius:0.8rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            font-size:1rem;
            cursor:pointer;
            transition:all 0.3s;
        }
        .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.4);
        }
        .btn-primary:disabled {
            opacity:0.6;
            cursor:not-allowed;
            transform:none;
        }

        .btn-secondary {
            width:100%;
            padding:0.9rem;
            border-radius:0.8rem;
            border:2px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            font-size:1rem;
            cursor:pointer;
            transition:all 0.3s;
        }
        .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.05);
        }

        .btn-success {
            width:100%;
            padding:0.9rem;
            border-radius:0.8rem;
            border:none;
            background:linear-gradient(145deg,#2ecc71,#27ae60);
            color:white;
            font-weight:600;
            font-size:1rem;
            cursor:pointer;
            transition:all 0.3s;
        }
        .btn-success:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(46,204,113,0.4);
        }

        /* ===== MESSAGES ===== */
        .alert {
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            margin-bottom:1rem;
            font-size:0.9rem;
        }
        .alert-error {
            background:rgba(231,76,60,0.15);
            border:1px solid rgba(231,76,60,0.3);
            color:#e74c3c;
        }
        .alert-success {
            background:rgba(46,204,113,0.15);
            border:1px solid rgba(46,204,113,0.3);
            color:#2ecc71;
        }
        .alert-info {
            background:rgba(52,152,219,0.15);
            border:1px solid rgba(52,152,219,0.3);
            color:#3498db;
        }

        /* ===== SWITCH LINK ===== */
        .switch-link {
            text-align:center;
            margin-top:1.2rem;
            color:#7a6a5a;
            font-size:0.9rem;
        }
        .switch-link a {
            color:var(--secondary);
            font-weight:600;
            cursor:pointer;
        }
        .switch-link a:hover {
            text-decoration:underline;
        }

        /* ===== CONFIRMATION ===== */
        .confirmation-content {
            text-align:center;
            padding:1rem 0;
        }
        .confirmation-content .big-icon {
            font-size:4rem;
            color:var(--gold);
            margin-bottom:1rem;
        }
        .confirmation-content h2 {
            color:#f0d6b0;
            font-size:1.5rem;
            margin-bottom:0.5rem;
        }
        .confirmation-content p {
            color:#a09080;
            line-height:1.8;
        }
        .confirmation-content .user-info {
            background:rgba(0,0,0,0.2);
            border-radius:0.8rem;
            padding:1rem;
            margin:1rem 0;
            text-align:left;
        }
        .confirmation-content .user-info .info-row {
            display:flex;
            justify-content:space-between;
            padding:0.3rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            color:#a09080;
            font-size:0.9rem;
        }
        .confirmation-content .user-info .info-row:last-child {
            border-bottom:none;
        }
        .confirmation-content .user-info .info-row .label {
            color:#7a6a5a;
        }
        .confirmation-content .user-info .info-row .value {
            color:#f0d6b0;
            font-weight:500;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .register-container { margin:1rem auto; }
            .register-card { padding:1.5rem; }
            .register-card .card-header h1 { font-size:1.5rem; }
            .tournament-info .tournament-name { font-size:1rem; }
            .confirmation-content .big-icon { font-size:3rem; }
        }
        @media (max-width:480px) {
            .register-card { padding:1rem; }
            .form-group input { font-size:0.85rem; padding:0.6rem 1rem 0.6rem 2.5rem; }
            .register-card .card-header h1 { font-size:1.2rem; }
            .confirmation-content h2 { font-size:1.2rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php" class="active-link"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <?php if ($isLoggedIn): ?>
                    <span style="color:#a09080;font-size:0.8rem;display:flex;align-items:center;gap:0.5rem;">
                        <i class="fas fa-user"></i> <?php echo e($_SESSION['username'] ?? 'User'); ?>
                    </span>
                    <a href="logout.php" class="btn-login"><i class="fas fa-sign-out-alt"></i> Logout</a>
                <?php else: ?>
                    <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                    <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- ===== REGISTRATION ===== -->
    <div class="register-container">
        <div class="register-card">
            <div class="card-header">
                <div class="icon"><i class="fas fa-trophy"></i></div>
                <h1>Tournament Registration</h1>
                <p><?php echo $isLoggedIn ? 'Confirm your registration' : 'Login or create an account to register'; ?></p>
            </div>

            <!-- Tournament Info -->
            <div class="tournament-info">
                <div class="tournament-name">
                    <i class="fas fa-chess" style="color:var(--secondary);"></i>
                    <?php echo e($tournamentDetails['name'] ?? 'Tournament'); ?>
                </div>
                <div class="tournament-details">
                    <span><i class="fas fa-calendar"></i> <?php echo e($tournamentDetails['date'] ?? 'TBD'); ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?php echo e($tournamentDetails['location'] ?? 'TBD'); ?></span>
                    <span><i class="fas fa-users"></i> <?php echo e($tournamentDetails['slots'] ?? 'Open'); ?> slots</span>
                </div>
            </div>

            <?php if ($registrationStep === 'confirm' && $isLoggedIn): ?>
                <!-- ===== CONFIRMATION STEP ===== -->
                <div class="confirmation-content">
                    <div class="big-icon"><i class="fas fa-check-circle"></i></div>
                    <h2>Confirm Registration</h2>
                    <p>You are about to register for <strong style="color:var(--gold);"><?php echo e($tournamentDetails['name'] ?? 'Tournament'); ?></strong></p>
                    
                    <div class="user-info">
                        <div class="info-row">
                            <span class="label">Username</span>
                            <span class="value"><?php echo e($_SESSION['username'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="label">Email</span>
                            <span class="value"><?php echo e($_SESSION['user_email'] ?? 'N/A'); ?></span>
                        </div>
                        <div class="info-row">
                            <span class="label">Tournament</span>
                            <span class="value"><?php echo e($tournamentDetails['name'] ?? 'N/A'); ?></span>
                        </div>
                        <?php if (isset($tournamentDetails['entry_fee'])): ?>
                            <div class="info-row">
                                <span class="label">Entry Fee</span>
                                <span class="value">$<?php echo e($tournamentDetails['entry_fee']); ?></span>
                            </div>
                        <?php endif; ?>
                    </div>

                    <?php if (isset($confirmError)): ?>
                        <div class="alert alert-error"><?php echo e($confirmError); ?></div>
                    <?php endif; ?>
                    <?php if (isset($confirmSuccess)): ?>
                        <div class="alert alert-success"><?php echo e($confirmSuccess); ?></div>
                    <?php endif; ?>

                    <?php if (!isset($confirmSuccess)): ?>
                        <form method="POST" action="">
                            <input type="hidden" name="confirm_registration" value="1">
                            <button type="submit" class="btn-success" <?php echo isset($confirmSuccess) ? 'disabled' : ''; ?>>
                                <i class="fas fa-check"></i> Confirm Registration
                            </button>
                        </form>
                    <?php else: ?>
                        <a href="tournaments.php" class="btn-primary" style="display:inline-block;text-align:center;text-decoration:none;">
                            <i class="fas fa-arrow-left"></i> Back to Tournaments
                        </a>
                    <?php endif; ?>
                    
                    <div class="switch-link" style="margin-top:1rem;">
                        <a href="tournaments.php">← Cancel and go back</a>
                    </div>
                </div>

            <?php elseif ($isLoggedIn && $registrationStep !== 'confirm'): ?>
                <!-- Already logged in, redirect to confirm -->
                <script>
                    window.location.href = 'tournament-register.php?id=<?php echo e($tournamentId); ?>&step=confirm';
                </script>

            <?php else: ?>
                <!-- ===== LOGIN / REGISTER STEP ===== -->

                <!-- Login Form -->
                <div id="loginForm">
                    <?php if ($loginError): ?>
                        <div class="alert alert-error"><?php echo e($loginError); ?></div>
                    <?php endif; ?>
                    <?php if ($loginSuccess): ?>
                        <div class="alert alert-success"><?php echo e($loginSuccess); ?></div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="form-group">
                            <label>Username or Email <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-user"></i>
                                <input type="text" name="login_input" placeholder="Enter your username or email" required value="<?php echo e($_POST['login_input'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Password <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock"></i>
                                <input type="password" name="password" id="loginPassword" placeholder="Enter your password" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('loginPassword')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <button type="submit" name="login_submit" class="btn-primary">
                            <i class="fas fa-sign-in-alt"></i> Login to Register
                        </button>
                    </form>

                    <div class="switch-link">
                        Don't have an account? <a onclick="showRegister()">Create one now</a>
                    </div>
                </div>

                <!-- Register Form -->
                <div id="registerForm" style="display:none;">
                    <?php if ($registerError): ?>
                        <div class="alert alert-error"><?php echo e($registerError); ?></div>
                    <?php endif; ?>
                    <?php if ($registerSuccess): ?>
                        <div class="alert alert-success"><?php echo e($registerSuccess); ?></div>
                    <?php endif; ?>

                    <form method="POST" action="">
                        <div class="form-group">
                            <label>Full Name <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-user"></i>
                                <input type="text" name="full_name" placeholder="Enter your full name" required value="<?php echo e($_POST['full_name'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Username <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-user-tag"></i>
                                <input type="text" name="username" placeholder="Choose a username" required value="<?php echo e($_POST['username'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Email Address <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-envelope"></i>
                                <input type="email" name="email" placeholder="Enter your email" required value="<?php echo e($_POST['email'] ?? ''); ?>">
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Password <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock"></i>
                                <input type="password" name="password" id="registerPassword" placeholder="Create a password (min 6 characters)" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('registerPassword')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>Confirm Password <span class="required">*</span></label>
                            <div class="input-wrapper">
                                <i class="fas fa-lock"></i>
                                <input type="password" name="confirm_password" id="confirmPassword" placeholder="Confirm your password" required>
                                <button type="button" class="password-toggle" onclick="togglePassword('confirmPassword')">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="checkbox-wrapper">
                                <input type="checkbox" name="terms" id="terms" required>
                                <label for="terms">I agree to the <a href="terms.php">Terms & Conditions</a> and <a href="privacy.php">Privacy Policy</a></label>
                            </div>
                        </div>
                        <button type="submit" name="register_submit" class="btn-primary">
                            <i class="fas fa-user-plus"></i> Create Account & Register
                        </button>
                    </form>

                    <div class="switch-link">
                        Already have an account? <a onclick="showLogin()">Login here</a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:2rem;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // Toggle between login and register forms
        function showRegister() {
            document.getElementById('loginForm').style.display = 'none';
            document.getElementById('registerForm').style.display = 'block';
        }

        function showLogin() {
            document.getElementById('registerForm').style.display = 'none';
            document.getElementById('loginForm').style.display = 'block';
        }

        // Toggle password visibility
        function togglePassword(id) {
            const input = document.getElementById(id);
            const icon = input.parentElement.querySelector('.password-toggle i');
            if (input.type === 'password') {
                input.type = 'text';
                icon.className = 'fas fa-eye-slash';
            } else {
                input.type = 'password';
                icon.className = 'fas fa-eye';
            }
        }

        // Show/hide forms based on URL parameters
        document.addEventListener('DOMContentLoaded', function() {
            // Check if any registration errors exist - show register form
            <?php if ($registerError): ?>
                showRegister();
            <?php endif; ?>
        });
    </script>
</body>
</html>
<?php
/**
 * Helper functions for tournament registration
 */
function getTournamentForRegistration($id) {
    // Simulated tournament data
    $tournaments = [
        1 => [
            'id' => 1,
            'name' => 'World Chess Championship 2025',
            'date' => 'Nov 25 - Dec 15, 2025',
            'location' => 'Dubai, UAE',
            'slots' => '64',
            'entry_fee' => '0'
        ],
        2 => [
            'id' => 2,
            'name' => 'Grand Chess Tour 2025',
            'date' => 'Dec 5-10, 2025',
            'location' => 'Paris, France',
            'slots' => '32',
            'entry_fee' => '0'
        ],
        3 => [
            'id' => 3,
            'name' => 'Chess Heaven Open 2025',
            'date' => 'Dec 1-8, 2025',
            'location' => 'Online',
            'slots' => '200',
            'entry_fee' => '10'
        ],
        4 => [
            'id' => 4,
            'name' => 'Grand Chess Tour 2026',
            'date' => 'Jan 15-20, 2026',
            'location' => 'Paris, France',
            'slots' => '32',
            'entry_fee' => '0'
        ],
        5 => [
            'id' => 5,
            'name' => "Women's World Championship 2026",
            'date' => 'Feb 1-12, 2026',
            'location' => 'London, UK',
            'slots' => '16',
            'entry_fee' => '0'
        ],
        6 => [
            'id' => 6,
            'name' => 'Chess Heaven Open 2026',
            'date' => 'Mar 10-17, 2026',
            'location' => 'Online',
            'slots' => '256',
            'entry_fee' => '10'
        ],
        7 => [
            'id' => 7,
            'name' => 'World Blitz Championship 2026',
            'date' => 'Apr 5-8, 2026',
            'location' => 'Moscow, Russia',
            'slots' => '64',
            'entry_fee' => '0'
        ],
        8 => [
            'id' => 8,
            'name' => 'Rapid Chess Championship 2026',
            'date' => 'May 20-25, 2026',
            'location' => 'New York, USA',
            'slots' => '48',
            'entry_fee' => '50'
        ],
        9 => [
            'id' => 9,
            'name' => 'Chess Heaven Amateur Cup 2026',
            'date' => 'Jun 15-22, 2026',
            'location' => 'Online',
            'slots' => '128',
            'entry_fee' => '0'
        ]
    ];
    
    return $tournaments[$id] ?? $tournaments[1];
}

/**
 * Register user for tournament
 */
function registerForTournament($userId, $tournamentId) {
    $conn = getDBConnection();
    
    // Check if already registered
    if ($conn) {
        $stmt = $conn->prepare("SELECT id FROM tournament_registrations WHERE user_id = ? AND tournament_id = ?");
        if ($stmt) {
            $stmt->bind_param("ii", $userId, $tournamentId);
            $stmt->execute();
            $result = $stmt->get_result();
            if ($result && $result->num_rows > 0) {
                return ['success' => false, 'message' => 'You are already registered for this tournament.'];
            }
        }
    }
    
    // Insert registration
    if ($conn) {
        $stmt = $conn->prepare("INSERT INTO tournament_registrations (user_id, tournament_id, registration_date, status) VALUES (?, ?, NOW(), 'pending')");
        if ($stmt) {
            $stmt->bind_param("ii", $userId, $tournamentId);
            if ($stmt->execute()) {
                return ['success' => true, 'message' => 'You have successfully registered for the tournament!'];
            }
        }
    }
    
    // Fallback - simulate successful registration
    return ['success' => true, 'message' => 'You have successfully registered for the tournament!'];
}
?>