<?php
/**
 * Chess Heaven - About Page
 * Complete about page with mission, vision, team, and impact information
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get about data
$missionStatement = getMissionStatement();
$visionStatement = getVisionStatement();
$coreValues = getCoreValues();
$teamMembers = getTeamMembers(8);
$impactStats = getImpactStats();
$timeline = getTimeline();
$partners = getPartners();
$testimonials = getTestimonials(4);
$faqItems = getFAQItems(4);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · About Us</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(280px,1fr));
            gap:1.5rem;
        }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
            position:relative;
            overflow:hidden;
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }

        /* ===== HERO ===== */
        .about-hero {
            text-align:center;
            padding:3rem 2rem;
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem;
            border:1px solid var(--border-color);
            margin:2rem;
        }
        .about-hero h1 {
            font-size:2.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:1rem;
        }
        .about-hero p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
        }

        /* ===== MISSION & VISION ===== */
        .mission-vision-grid {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:2rem;
        }
        .mission-box, .vision-box {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
            text-align:center;
            transition:all 0.3s;
        }
        .mission-box:hover, .vision-box:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-3px);
        }
        .mission-box i, .vision-box i {
            font-size:3rem;
            color:var(--secondary);
            margin-bottom:1rem;
        }
        .mission-box h3, .vision-box h3 {
            color:#f0d6b0;
            font-size:1.5rem;
            margin-bottom:0.5rem;
        }
        .mission-box p, .vision-box p {
            color:#a09080;
            line-height:1.8;
        }

        /* ===== CORE VALUES ===== */
        .values-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
            gap:1.5rem;
        }
        .value-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            text-align:center;
            transition:all 0.3s;
        }
        .value-item:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--gold);
            transform:translateY(-3px);
        }
        .value-item i {
            font-size:2.5rem;
            color:var(--gold);
            margin-bottom:0.5rem;
        }
        .value-item h4 {
            color:#f0d6b0;
            font-size:1rem;
        }
        .value-item p {
            color:#a09080;
            font-size:0.85rem;
            margin-top:0.3rem;
        }

        /* ===== TEAM ===== */
        .team-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            text-align:center;
            transition:all 0.3s;
        }
        .team-card:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-5px);
        }
        .team-card .avatar {
            width:80px;
            height:80px;
            border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex;
            align-items:center;
            justify-content:center;
            margin:0 auto 0.8rem;
            font-size:2rem;
            color:var(--secondary);
            border:2px solid var(--border-color);
        }
        .team-card h3 {
            color:#f0d6b0;
            font-size:1rem;
        }
        .team-card .role {
            color:var(--secondary);
            font-size:0.85rem;
        }
        .team-card p {
            color:#a09080;
            font-size:0.8rem;
            margin-top:0.5rem;
        }
        .team-card .social-links {
            display:flex;
            justify-content:center;
            gap:0.8rem;
            margin-top:0.8rem;
        }
        .team-card .social-links a {
            color:#7a6a5a;
            transition:0.3s;
        }
        .team-card .social-links a:hover {
            color:var(--secondary);
        }

        /* ===== TIMELINE ===== */
        .timeline {
            position:relative;
            padding-left:2rem;
        }
        .timeline::before {
            content:'';
            position:absolute;
            left:0.5rem;
            top:0;
            bottom:0;
            width:2px;
            background:var(--border-color);
        }
        .timeline-item {
            position:relative;
            padding:1rem 1rem 1rem 2rem;
            border-left:2px solid var(--secondary);
            margin-bottom:1.5rem;
            background:var(--card-bg);
            border-radius:0 1rem 1rem 0;
            transition:all 0.3s;
        }
        .timeline-item:hover {
            background:rgba(139,26,26,0.12);
        }
        .timeline-item::before {
            content:'';
            position:absolute;
            left:-8px;
            top:1.5rem;
            width:14px;
            height:14px;
            border-radius:50%;
            background:var(--secondary);
            border:2px solid var(--dark);
        }
        .timeline-item .year {
            color:var(--gold);
            font-weight:700;
            font-size:1.1rem;
        }
        .timeline-item h4 {
            color:#f0d6b0;
            font-size:1rem;
            margin:0.3rem 0;
        }
        .timeline-item p {
            color:#a09080;
            font-size:0.85rem;
        }

        /* ===== PARTNERS ===== */
        .partners-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
            gap:1.5rem;
            align-items:center;
        }
        .partner-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            text-align:center;
            transition:all 0.3s;
        }
        .partner-item:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-3px);
        }
        .partner-item i {
            font-size:3rem;
            color:var(--secondary);
            opacity:0.5;
        }
        .partner-item h4 {
            color:#f0d6b0;
            font-size:0.9rem;
            margin-top:0.5rem;
        }

        /* ===== IMPACT STATS ===== */
        .impact-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
            gap:1.5rem;
        }
        .impact-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            text-align:center;
            transition:all 0.3s;
        }
        .impact-item:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--gold);
            transform:translateY(-3px);
        }
        .impact-item .number {
            font-size:2.5rem;
            font-weight:700;
            color:var(--gold);
        }
        .impact-item .label {
            color:#a09080;
            font-size:0.85rem;
            margin-top:0.3rem;
        }
        .impact-item i {
            font-size:2rem;
            color:var(--secondary);
            margin-bottom:0.5rem;
            display:block;
        }

        /* ===== FAQ ===== */
        .faq-item {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            margin-bottom:0.8rem;
            cursor:pointer;
            transition:all 0.3s;
        }
        .faq-item:hover { border-color:var(--secondary); }
        .faq-item .faq-question {
            display:flex;
            justify-content:space-between;
            align-items:center;
            color:#f0d6b0;
            font-weight:600;
        }
        .faq-item .faq-answer {
            color:#a09080;
            margin-top:0.8rem;
            display:none;
            line-height:1.6;
        }
        .faq-item.active .faq-answer { display:block; }
        .faq-item .faq-toggle { color:var(--secondary); transition:0.3s; }
        .faq-item.active .faq-toggle { transform:rotate(180deg); }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .mission-vision-grid {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .about-hero { margin:1rem; padding:2rem 1rem; }
            .about-hero h1 { font-size:2rem; flex-direction:column; }
            .values-grid { grid-template-columns:repeat(2,1fr); }
            .impact-grid { grid-template-columns:repeat(2,1fr); }
            .partners-grid { grid-template-columns:repeat(2,1fr); }
            .card-grid { grid-template-columns:1fr; }
        }
        @media (max-width:480px) {
            .section-header h2 { font-size:1.3rem; }
            .about-hero h1 { font-size:1.5rem; }
            .values-grid { grid-template-columns:1fr; }
            .impact-grid { grid-template-columns:1fr; }
            .partners-grid { grid-template-columns:1fr; }
            .mission-box h3, .vision-box h3 { font-size:1.2rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php" class="active-link"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <div class="about-hero">
        <h1>
            <i class="fas fa-info-circle"></i>
            About Chess Heaven
            <i class="fas fa-chess"></i>
        </h1>
        <p>Empowering communities through the royal game — free lessons, mentorship & tournaments. Our mission is to make chess accessible to everyone.</p>
    </div>

    <!-- ===== MISSION & VISION ===== -->
    <section class="section" style="padding-top:0;">
        <div class="mission-vision-grid">
            <div class="mission-box">
                <i class="fas fa-bullseye"></i>
                <h3>Our Mission</h3>
                <p><?php echo e($missionStatement ?? 'To empower individuals and communities through chess education, mentorship, and competitive opportunities. We believe that chess builds critical thinking, patience, and strategic skills that benefit all areas of life.'); ?></p>
            </div>
            <div class="vision-box">
                <i class="fas fa-eye"></i>
                <h3>Our Vision</h3>
                <p><?php echo e($visionStatement ?? 'A world where chess is accessible to everyone, regardless of age, background, or economic status. We envision a global community connected through the love of chess, where everyone can learn, grow, and compete.'); ?></p>
            </div>
        </div>
    </section>

    <!-- ===== CORE VALUES ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-heart"></i> Our Core Values</h2>
        </div>
        <div class="values-grid">
            <?php if (!empty($coreValues)): ?>
                <?php foreach ($coreValues as $value): ?>
                    <div class="value-item">
                        <i class="fas fa-<?php echo e($value['icon'] ?? 'star'); ?>"></i>
                        <h4><?php echo e($value['name']); ?></h4>
                        <p><?php echo e($value['description']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="value-item">
                    <i class="fas fa-hand-holding-heart"></i>
                    <h4>Community First</h4>
                    <p>We prioritize building a supportive and inclusive community.</p>
                </div>
                <div class="value-item">
                    <i class="fas fa-graduation-cap"></i>
                    <h4>Education</h4>
                    <p>We believe in the power of education to transform lives.</p>
                </div>
                <div class="value-item">
                    <i class="fas fa-trophy"></i>
                    <h4>Excellence</h4>
                    <p>We strive for excellence in everything we do.</p>
                </div>
                <div class="value-item">
                    <i class="fas fa-users"></i>
                    <h4>Inclusivity</h4>
                    <p>We welcome everyone regardless of background or skill level.</p>
                </div>
                <div class="value-item">
                    <i class="fas fa-lightbulb"></i>
                    <h4>Innovation</h4>
                    <p>We embrace innovation to make chess more accessible.</p>
                </div>
                <div class="value-item">
                    <i class="fas fa-handshake"></i>
                    <h4>Integrity</h4>
                    <p>We operate with honesty, transparency, and integrity.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== IMPACT STATS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-chart-line"></i> Our Impact</h2>
        </div>
        <div class="impact-grid">
            <?php if (!empty($impactStats)): ?>
                <?php foreach ($impactStats as $stat): ?>
                    <div class="impact-item">
                        <i class="fas fa-<?php echo e($stat['icon'] ?? 'star'); ?>"></i>
                        <div class="number"><?php echo e($stat['number']); ?></div>
                        <div class="label"><?php echo e($stat['label']); ?></div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="impact-item">
                    <i class="fas fa-users"></i>
                    <div class="number">12,000+</div>
                    <div class="label">Students Taught</div>
                </div>
                <div class="impact-item">
                    <i class="fas fa-user-tie"></i>
                    <div class="number">340+</div>
                    <div class="label">Volunteer Coaches</div>
                </div>
                <div class="impact-item">
                    <i class="fas fa-school"></i>
                    <div class="number">87+</div>
                    <div class="label">Partner Schools</div>
                </div>
                <div class="impact-item">
                    <i class="fas fa-dollar-sign"></i>
                    <div class="number">$2.1M</div>
                    <div class="label">Community Funds Raised</div>
                </div>
                <div class="impact-item">
                    <i class="fas fa-trophy"></i>
                    <div class="number">50+</div>
                    <div class="label">Tournaments Hosted</div>
                </div>
                <div class="impact-item">
                    <i class="fas fa-globe"></i>
                    <div class="number">30+</div>
                    <div class="label">Countries Reached</div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== TEAM ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-users"></i> Meet Our Team</h2>
            <a href="team.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($teamMembers)): ?>
                <?php foreach ($teamMembers as $member): ?>
                    <div class="team-card">
                        <div class="avatar"><?php echo e(strtoupper(substr($member['name'], 0, 2))); ?></div>
                        <h3><?php echo e($member['name']); ?></h3>
                        <div class="role"><?php echo e($member['role']); ?></div>
                        <p><?php echo e($member['bio']); ?></p>
                        <div class="social-links">
                            <?php if (!empty($member['twitter'])): ?>
                                <a href="<?php echo e($member['twitter']); ?>"><i class="fab fa-twitter"></i></a>
                            <?php endif; ?>
                            <?php if (!empty($member['linkedin'])): ?>
                                <a href="<?php echo e($member['linkedin']); ?>"><i class="fab fa-linkedin"></i></a>
                            <?php endif; ?>
                            <?php if (!empty($member['email'])): ?>
                                <a href="mailto:<?php echo e($member['email']); ?>"><i class="fas fa-envelope"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="team-card">
                    <div class="avatar">JD</div>
                    <h3>John Doe</h3>
                    <div class="role">Founder & CEO</div>
                    <p>Former national chess champion with 20+ years of teaching experience.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="team-card">
                    <div class="avatar">JS</div>
                    <h3>Jane Smith</h3>
                    <div class="role">Director of Education</div>
                    <p>Chess educator and curriculum developer with 15 years of experience.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="team-card">
                    <div class="avatar">MC</div>
                    <h3>Maria Chen</h3>
                    <div class="role">Head Coach</div>
                    <p>FIDE Master and former national champion with a passion for teaching.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="team-card">
                    <div class="avatar">AR</div>
                    <h3>Alex Rivera</h3>
                    <div class="role">Community Outreach</div>
                    <p>Passionate about bringing chess to underserved communities.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="team-card">
                    <div class="avatar">SK</div>
                    <h3>Sarah Kim</h3>
                    <div class="role">Tournament Director</div>
                    <p>Organizes chess tournaments and events with precision and care.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="team-card">
                    <div class="avatar">MW</div>
                    <h3>Michael Williams</h3>
                    <div class="role">Technology Lead</div>
                    <p>Passionate about using technology to make chess more accessible.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="team-card">
                    <div class="avatar">LP</div>
                    <h3>Lisa Patel</h3>
                    <div class="role">Content Creator</div>
                    <p>Creates engaging chess content for learners of all levels.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                <div class="team-card">
                    <div class="avatar">TO</div>
                    <h3>Thomas Okafor</h3>
                    <div class="role">Mentorship Coordinator</div>
                    <p>Connects beginners with experienced players for mentorship.</p>
                    <div class="social-links">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-linkedin"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== TIMELINE ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-clock"></i> Our Journey</h2>
        </div>
        <div class="timeline">
            <?php if (!empty($timeline)): ?>
                <?php foreach ($timeline as $item): ?>
                    <div class="timeline-item">
                        <div class="year"><?php echo e($item['year']); ?></div>
                        <h4><?php echo e($item['title']); ?></h4>
                        <p><?php echo e($item['description']); ?></p>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="timeline-item">
                    <div class="year">2015</div>
                    <h4>Foundation</h4>
                    <p>Chess Heaven was founded with a mission to make chess accessible to everyone.</p>
                </div>
                <div class="timeline-item">
                    <div class="year">2017</div>
                    <h4>First Community Program</h4>
                    <p>Launched our first community chess program in local schools.</p>
                </div>
                <div class="timeline-item">
                    <div class="year">2019</div>
                    <h4>Online Platform Launch</h4>
                    <p>Launched our online platform to reach students globally.</p>
                </div>
                <div class="timeline-item">
                    <div class="year">2021</div>
                    <h4>Expansion to 10 Countries</h4>
                    <p>Expanded our programs to 10 countries worldwide.</p>
                </div>
                <div class="timeline-item">
                    <div class="year">2023</div>
                    <h4>10,000 Students Milestone</h4>
                    <p>Reached the milestone of 10,000 students taught.</p>
                </div>
                <div class="timeline-item">
                    <div class="year">2025</div>
                    <h4>Global Community</h4>
                    <p>Built a global community of chess enthusiasts and educators.</p>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== PARTNERS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-handshake"></i> Our Partners</h2>
        </div>
        <div class="partners-grid">
            <?php if (!empty($partners)): ?>
                <?php foreach ($partners as $partner): ?>
                    <div class="partner-item">
                        <i class="fas fa-<?php echo e($partner['icon'] ?? 'building'); ?>"></i>
                        <h4><?php echo e($partner['name']); ?></h4>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="partner-item">
                    <i class="fas fa-university"></i>
                    <h4>Chess Federation</h4>
                </div>
                <div class="partner-item">
                    <i class="fas fa-school"></i>
                    <h4>Local Schools</h4>
                </div>
                <div class="partner-item">
                    <i class="fas fa-building"></i>
                    <h4>Corporate Sponsors</h4>
                </div>
                <div class="partner-item">
                    <i class="fas fa-hand-holding-heart"></i>
                    <h4>Charity Partners</h4>
                </div>
                <div class="partner-item">
                    <i class="fas fa-globe"></i>
                    <h4>International Chess Organizations</h4>
                </div>
                <div class="partner-item">
                    <i class="fas fa-users"></i>
                    <h4>Community Groups</h4>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== TESTIMONIALS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-quote-left"></i> What People Say</h2>
            <a href="testimonials.php" class="view-all">All Testimonials <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($testimonials)): ?>
                <?php foreach ($testimonials as $testimonial): ?>
                    <div class="card">
                        <i class="fas fa-quote-right" style="color:var(--gold);"></i>
                        <p style="font-style:italic;">"<?php echo e($testimonial['quote']); ?>"</p>
                        <div style="margin-top:0.8rem;">
                            <div style="color:#f0d6b0;font-weight:600;"><?php echo e($testimonial['author']); ?></div>
                            <div style="color:#7a6a5a;font-size:0.85rem;"><?php echo e($testimonial['title'] ?? ''); ?></div>
                            <div style="color:var(--gold);margin-top:0.3rem;">
                                <?php for ($i = 1; $i <= 5; $i++): ?>
                                    <i class="fas fa-star<?php echo $i <= ($testimonial['rating'] ?? 5) ? '' : '-o'; ?>" style="font-size:0.8rem;"></i>
                                <?php endfor; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="card">
                    <i class="fas fa-quote-right" style="color:var(--gold);"></i>
                    <p style="font-style:italic;">"Chess Heaven changed my life — from a beginner to a national champion."</p>
                    <div style="margin-top:0.8rem;">
                        <div style="color:#f0d6b0;font-weight:600;">Maria Santos</div>
                        <div style="color:#7a6a5a;font-size:0.85rem;">2026 National Junior Champion</div>
                        <div style="color:var(--gold);margin-top:0.3rem;">
                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <i class="fas fa-quote-right" style="color:var(--gold);"></i>
                    <p style="font-style:italic;">"The mentorship program helped me improve my chess skills dramatically."</p>
                    <div style="margin-top:0.8rem;">
                        <div style="color:#f0d6b0;font-weight:600;">James Rodriguez</div>
                        <div style="color:#7a6a5a;font-size:0.85rem;">Chess Heaven Member</div>
                        <div style="color:var(--gold);margin-top:0.3rem;">
                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <i class="fas fa-quote-right" style="color:var(--gold);"></i>
                    <p style="font-style:italic;">"Chess Heaven provides an incredible platform for learning and growth."</p>
                    <div style="margin-top:0.8rem;">
                        <div style="color:#f0d6b0;font-weight:600;">Sarah Chen</div>
                        <div style="color:#7a6a5a;font-size:0.85rem;">Parent of a Chess Heaven Student</div>
                        <div style="color:var(--gold);margin-top:0.3rem;">
                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                        </div>
                    </div>
                </div>
                <div class="card">
                    <i class="fas fa-quote-right" style="color:var(--gold);"></i>
                    <p style="font-style:italic;">"The community is amazing and the tournaments are professionally organized."</p>
                    <div style="margin-top:0.8rem;">
                        <div style="color:#f0d6b0;font-weight:600;">David Kim</div>
                        <div style="color:#7a6a5a;font-size:0.85rem;">Tournament Participant</div>
                        <div style="color:var(--gold);margin-top:0.3rem;">
                            <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== FAQ ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-question-circle"></i> Frequently Asked Questions</h2>
            <a href="faq.php" class="view-all">All FAQs <i class="fas fa-arrow-right"></i></a>
        </div>
        <?php if (!empty($faqItems)): ?>
            <?php foreach ($faqItems as $index => $faq): ?>
                <div class="faq-item <?php echo $index === 0 ? 'active' : ''; ?>" onclick="toggleFAQ(this)">
                    <div class="faq-question">
                        <span><?php echo e($faq['question']); ?></span>
                        <i class="fas fa-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer"><?php echo e($faq['answer']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="faq-item active" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>What is Chess Heaven?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">Chess Heaven is a non-profit organization dedicated to making chess education accessible to everyone. We offer free lessons, mentorship, and tournaments.</div>
            </div>
            <div class="faq-item" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>Is Chess Heaven really free?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">Yes! All our programs and resources are completely free. We are funded by donations and sponsorships.</div>
            </div>
            <div class="faq-item" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>How can I get involved?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">You can volunteer as a coach, donate to support our programs, participate in tournaments, or simply spread the word about Chess Heaven.</div>
            </div>
            <div class="faq-item" onclick="toggleFAQ(this)">
                <div class="faq-question">
                    <span>Who can join Chess Heaven?</span>
                    <i class="fas fa-chevron-down faq-toggle"></i>
                </div>
                <div class="faq-answer">Anyone! Chess Heaven is open to players of all ages and skill levels. Whether you're a complete beginner or a seasoned player, you're welcome here.</div>
            </div>
        <?php endif; ?>
    </section>

    <!-- ===== JOIN US ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));border-radius:1.5rem;padding:2.5rem;border:2px solid var(--gold);text-align:center;">
            <i class="fas fa-handshake" style="font-size:3rem;color:var(--gold);"></i>
            <h2 style="color:#f0d6b0;margin:0.5rem 0;">Join Our Community</h2>
            <p style="color:#a09080;max-width:600px;margin:0 auto 1.5rem;">
                Whether you want to learn, teach, or compete, there's a place for you at Chess Heaven.
            </p>
            <div style="display:flex;gap:1rem;justify-content:center;flex-wrap:wrap;">
                <a href="register.php" class="btn-register" style="padding:0.8rem 2rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;transition:all 0.3s;text-decoration:none;">
                    <i class="fas fa-user-plus"></i> Sign Up Now
                </a>
                <a href="contact.php" class="btn-watch" style="padding:0.8rem 2rem;border-radius:2rem;border:2px solid var(--secondary);background:transparent;color:var(--secondary);font-weight:600;cursor:pointer;transition:all 0.3s;text-decoration:none;">
                    <i class="fas fa-envelope"></i> Contact Us
                </a>
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // FAQ toggle
        function toggleFAQ(element) {
            element.classList.toggle('active');
        }
    </script>
</body>
</html>