<?php
/**
 * Chess Heaven - Simple Configuration File
 */

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'chessdatabase');

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/**
 * Get database connection
 */
function getDBConnection() {
    static $conn = null;
    
    if ($conn === null) {
        $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
        
        if ($conn->connect_error) {
            error_log("Database connection failed: " . $conn->connect_error);
            return false;
        }
        
        $conn->set_charset("utf8mb4");
    }
    
    return $conn;
}

/**
 * Escape HTML output
 */
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Get setting from database
 */
function getSetting($key, $default = null) {
    $conn = getDBConnection();
    if (!$conn) return $default;
    
    $stmt = $conn->prepare("SELECT setting_value FROM settings WHERE setting_key = ?");
    if (!$stmt) return $default;
    
    $stmt->bind_param("s", $key);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row['setting_value'];
    }
    return $default;
}

/**
 * Get user by ID
 */
function getUserById($userId) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("SELECT id, username, email, role, created_at FROM users WHERE id = ?");
    if (!$stmt) return false;
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->fetch_assoc();
}

/**
 * Get user statistics
 */
function getUserStats($userId) {
    $conn = getDBConnection();
    if (!$conn) return null;
    
    $stmt = $conn->prepare("SELECT rating, games_played, games_won, games_drawn, games_lost FROM user_stats WHERE user_id = ?");
    if (!$stmt) {
        return ['rating' => 1200, 'games_played' => 0, 'games_won' => 0, 'games_drawn' => 0, 'games_lost' => 0];
    }
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row;
    }
    
    return ['rating' => 1200, 'games_played' => 0, 'games_won' => 0, 'games_drawn' => 0, 'games_lost' => 0];
}

/**
 * Get game statistics for the current user
 */
function getGameStats() {
    if (isset($_SESSION['user_id'])) {
        return getUserStats($_SESSION['user_id']);
    }
    
    if (!isset($_SESSION['guest_stats'])) {
        $_SESSION['guest_stats'] = [
            'total' => 0,
            'wins' => 0,
            'losses' => 0,
            'draws' => 0
        ];
    }
    
    return $_SESSION['guest_stats'];
}

/**
 * Get recent games for the current user
 */
function getRecentGames($limit = 10) {
    $conn = getDBConnection();
    
    if (isset($_SESSION['user_id'])) {
        if (!$conn) {
            return getDefaultRecentGames();
        }
        
        try {
            $columns = [];
            $colResult = $conn->query("SHOW COLUMNS FROM game_history");
            if ($colResult) {
                while ($col = $colResult->fetch_assoc()) {
                    $columns[] = $col['Field'];
                }
            }
            
            $selectFields = ['id'];
            
            if (in_array('opponent', $columns)) {
                $selectFields[] = 'opponent';
            } else {
                $selectFields[] = "'vs Computer' as opponent";
            }
            
            if (in_array('description', $columns)) {
                $selectFields[] = 'description';
            } else {
                $selectFields[] = "'Game' as description";
            }
            
            if (in_array('result', $columns)) {
                $selectFields[] = 'result';
            } else {
                $selectFields[] = "'draw' as result";
            }
            
            if (in_array('date', $columns)) {
                $selectFields[] = 'date';
            } else {
                $selectFields[] = 'NOW() as date';
            }
            
            $selectClause = implode(', ', $selectFields);
            
            $sql = "SELECT $selectClause FROM game_history WHERE user_id = ? ORDER BY date DESC LIMIT ?";
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                return getDefaultRecentGames();
            }
            
            $stmt->bind_param("ii", $_SESSION['user_id'], $limit);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $games = [];
                while ($row = $result->fetch_assoc()) {
                    if (!isset($row['opponent'])) $row['opponent'] = 'vs Computer';
                    if (!isset($row['description'])) $row['description'] = 'Game';
                    if (!isset($row['result'])) $row['result'] = 'draw';
                    if (!isset($row['date'])) $row['date'] = date('Y-m-d H:i:s');
                    $games[] = $row;
                }
                return $games;
            }
        } catch (Exception $e) {
            // Fall through to default
        }
    }
    
    return getDefaultRecentGames();
}

/**
 * Get default recent games
 */
function getDefaultRecentGames() {
    return [
        ['id' => 1, 'opponent' => 'GM Alpha', 'description' => 'Classical game · 45 moves', 'result' => 'win', 'date' => date('Y-m-d H:i:s', strtotime('-2 days'))],
        ['id' => 2, 'opponent' => 'IM Beta', 'description' => 'Blitz game · 28 moves', 'result' => 'loss', 'date' => date('Y-m-d H:i:s', strtotime('-4 days'))],
        ['id' => 3, 'opponent' => 'CM Gamma', 'description' => 'Rapid game · 62 moves', 'result' => 'draw', 'date' => date('Y-m-d H:i:s', strtotime('-6 days'))],
        ['id' => 4, 'opponent' => 'FM Delta', 'description' => 'Classical game · 33 moves', 'result' => 'win', 'date' => date('Y-m-d H:i:s', strtotime('-8 days'))]
    ];
}

/**
 * Get popular openings
 */
function getPopularOpenings($limit = 6) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultPopularOpenings();
    }
    
    try {
        $columns = [];
        $colResult = $conn->query("SHOW COLUMNS FROM popular_openings");
        if ($colResult) {
            while ($col = $colResult->fetch_assoc()) {
                $columns[] = $col['Field'];
            }
        }
        
        $selectFields = ['id'];
        
        if (in_array('name', $columns)) {
            $selectFields[] = 'name';
        } else {
            $selectFields[] = "'Opening' as name";
        }
        
        if (in_array('moves', $columns)) {
            $selectFields[] = 'moves';
        } else {
            $selectFields[] = "'1.e4' as moves";
        }
        
        if (in_array('category', $columns)) {
            $selectFields[] = 'category';
        } else {
            $selectFields[] = "'Open Game' as category";
        }
        
        if (in_array('popularity', $columns)) {
            $selectFields[] = 'popularity';
        } else {
            $selectFields[] = '80 as popularity';
        }
        
        if (in_array('icon', $columns)) {
            $selectFields[] = 'icon';
        } else {
            $selectFields[] = "'pawn' as icon";
        }
        
        $selectClause = implode(', ', $selectFields);
        
        $sql = "SELECT $selectClause FROM popular_openings WHERE is_active = 1 ORDER BY popularity DESC LIMIT ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return getDefaultPopularOpenings();
        }
        
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $openings = [];
            while ($row = $result->fetch_assoc()) {
                if (!isset($row['name'])) $row['name'] = 'Opening';
                if (!isset($row['moves'])) $row['moves'] = '1.e4';
                if (!isset($row['category'])) $row['category'] = 'Open Game';
                if (!isset($row['popularity'])) $row['popularity'] = 80;
                if (!isset($row['icon'])) $row['icon'] = 'pawn';
                $openings[] = $row;
            }
            return $openings;
        }
    } catch (Exception $e) {
        // Fall through to default
    }
    
    return getDefaultPopularOpenings();
}

/**
 * Get default popular openings
 */
function getDefaultPopularOpenings() {
    return [
        ['id' => 1, 'name' => 'Italian Game', 'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bc4', 'category' => 'Open Game', 'popularity' => 92, 'icon' => 'king'],
        ['id' => 2, 'name' => 'Ruy Lopez', 'moves' => '1.e4 e5 2.Nf3 Nc6 3.Bb5', 'category' => 'Open Game', 'popularity' => 88, 'icon' => 'queen'],
        ['id' => 3, 'name' => 'Sicilian Defense', 'moves' => '1.e4 c5', 'category' => 'Semi-Open', 'popularity' => 85, 'icon' => 'knight'],
        ['id' => 4, 'name' => 'French Defense', 'moves' => '1.e4 e6', 'category' => 'Semi-Open', 'popularity' => 78, 'icon' => 'pawn'],
        ['id' => 5, 'name' => 'Caro-Kann', 'moves' => '1.e4 c6', 'category' => 'Semi-Open', 'popularity' => 76, 'icon' => 'rook'],
        ['id' => 6, 'name' => "Queen's Gambit", 'moves' => '1.d4 d5 2.c4', 'category' => 'Closed Game', 'popularity' => 82, 'icon' => 'bishop']
    ];
}

/**
 * Get features from database
 */
function getFeatures() {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultFeatures();
    }
    
    $result = $conn->query("SELECT icon, title, description FROM features WHERE is_active = 1 ORDER BY display_order LIMIT 4");
    
    if (!$result || $result->num_rows === 0) {
        return getDefaultFeatures();
    }
    
    $features = [];
    while ($row = $result->fetch_assoc()) {
        $features[] = $row;
    }
    return $features;
}

/**
 * Get default features
 */
function getDefaultFeatures() {
    return [
        ['icon' => 'fa-chess-board', 'title' => 'Free Chess Lessons', 'description' => 'Learn from grandmasters — every Saturday at 10 AM GMT'],
        ['icon' => 'fa-hand-holding-heart', 'title' => 'Community Outreach', 'description' => 'Bringing chess to underserved schools and youth clubs'],
        ['icon' => 'fa-people-arrows', 'title' => 'Mentorship Program', 'description' => 'Pairing beginners with experienced players for guidance'],
        ['icon' => 'fa-trophy', 'title' => 'Annual Charity Cup', 'description' => 'Our flagship tournament that funds chess education']
    ];
}

/**
 * Get testimonials from database
 */
function getTestimonials($limit = 1) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultTestimonials();
    }
    
    $stmt = $conn->prepare("SELECT quote, author, title, rating FROM testimonials WHERE is_active = 1 ORDER BY RAND() LIMIT ?");
    if (!$stmt) {
        return getDefaultTestimonials();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultTestimonials();
    }
    
    $testimonials = [];
    while ($row = $result->fetch_assoc()) {
        $testimonials[] = $row;
    }
    return $testimonials;
}

/**
 * Get default testimonials
 */
function getDefaultTestimonials() {
    return [
        ['quote' => 'Chess Heaven changed my life — from a beginner to a national champion.', 'author' => 'Maria Santos', 'title' => '2026 National Junior Champion', 'rating' => 5]
    ];
}

/**
 * Get statistics from database
 */
function getStats() {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultStats();
    }
    
    $result = $conn->query("SELECT students_taught, volunteer_coaches, partner_schools, community_funds FROM stats LIMIT 1");
    
    if (!$result || $result->num_rows === 0) {
        return getDefaultStats();
    }
    
    return $result->fetch_assoc();
}

/**
 * Get default stats
 */
function getDefaultStats() {
    return [
        'students_taught' => 12000,
        'volunteer_coaches' => 340,
        'partner_schools' => 87,
        'community_funds' => 2100000
    ];
}

/**
 * Get announcements from database
 */
function getAnnouncements($limit = 3) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultAnnouncements();
    }
    
    $stmt = $conn->prepare("SELECT title, content, created_at, link FROM announcements WHERE is_active = 1 ORDER BY created_at DESC LIMIT ?");
    if (!$stmt) {
        return getDefaultAnnouncements();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultAnnouncements();
    }
    
    $announcements = [];
    while ($row = $result->fetch_assoc()) {
        $announcements[] = $row;
    }
    return $announcements;
}

/**
 * Get default announcements
 */
function getDefaultAnnouncements() {
    return [
        ['title' => 'Welcome to Chess Heaven!', 'content' => 'We are excited to launch our new community platform. Join us for free chess lessons and tournaments.', 'created_at' => date('Y-m-d H:i:s'), 'link' => '#'],
        ['title' => 'Chess Tournament Coming Soon', 'content' => 'Our annual charity tournament will be held next month. Register now to participate.', 'created_at' => date('Y-m-d H:i:s', strtotime('-1 day')), 'link' => '#'],
        ['title' => 'New Lesson Videos Available', 'content' => 'We have added new video lessons for beginners. Check them out in the Learn section.', 'created_at' => date('Y-m-d H:i:s', strtotime('-3 days')), 'link' => '#']
    ];
}

/**
 * Get daily puzzle
 */
function getDailyPuzzle() {
    $conn = getDBConnection();
    
    if (!$conn) {
        return [
            'title' => 'Mate in 2',
            'difficulty' => 'medium',
            'description' => 'Find the winning move. White to play.',
            'solution' => '1. Qxf7+!'
        ];
    }
    
    try {
        $today = date('Y-m-d');
        
        $stmt = $conn->prepare("SELECT title, difficulty, description, solution FROM puzzles WHERE is_active = 1 AND (puzzle_date = ? OR puzzle_date IS NULL) ORDER BY puzzle_date DESC, id DESC LIMIT 1");
        
        if (!$stmt) {
            return [
                'title' => 'Mate in 2',
                'difficulty' => 'medium',
                'description' => 'Find the winning move. White to play.',
                'solution' => '1. Qxf7+!'
            ];
        }
        
        $stmt->bind_param("s", $today);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($row = $result->fetch_assoc()) {
            return $row;
        }
    } catch (Exception $e) {
        // Database error, return default
    }
    
    return [
        'title' => 'Mate in 2',
        'difficulty' => 'medium',
        'description' => 'Find the winning move. White to play.',
        'solution' => '1. Qxf7+! Rxf7 2. Rxf7+ Kxf7 3. Bxf7'
    ];
}

/**
 * Get default puzzle
 */
function getDefaultPuzzle() {
    return [
        'title' => 'Mate in 2',
        'difficulty' => 'medium',
        'description' => 'Find the winning move. White to play.',
        'solution' => '1. Qxf7+!',
        'fen_position' => 'rnbqkbnr/pppp1ppp/8/4p3/4P3/8/PPPP1PPP/RNBQKBNR w KQkq - 0 1'
    ];
}

/**
 * Get featured games
 */
function getFeaturedGames($limit = 4) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultFeaturedGames();
    }
    
    $stmt = $conn->prepare("SELECT id, title, description, players, year FROM featured_games WHERE is_active = 1 ORDER BY year DESC LIMIT ?");
    if (!$stmt) {
        return getDefaultFeaturedGames();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultFeaturedGames();
    }
    
    $games = [];
    while ($row = $result->fetch_assoc()) {
        $games[] = $row;
    }
    return $games;
}

/**
 * Get default featured games
 */
function getDefaultFeaturedGames() {
    return [
        ['id' => 1, 'title' => 'Immortal Game', 'description' => 'Anderssen vs Kieseritzky (1851) - One of the most famous chess games ever played.', 'players' => 'Anderssen vs Kieseritzky', 'year' => 1851],
        ['id' => 2, 'title' => 'Opera Game', 'description' => 'Morphy vs Duke of Brunswick & Count Isouard (1858) - A masterpiece of development.', 'players' => 'Morphy vs Duke', 'year' => 1858],
        ['id' => 3, 'title' => 'Game of the Century', 'description' => 'Fischer vs Byrne (1956) - 13-year-old Fischer\'s brilliant queen sacrifice.', 'players' => 'Fischer vs Byrne', 'year' => 1956],
        ['id' => 4, 'title' => 'Kasparov\'s Immortal', 'description' => 'Kasparov vs Topalov (1999) - A stunning attacking masterpiece.', 'players' => 'Kasparov vs Topalov', 'year' => 1999]
    ];
}

/**
 * Get live tournaments
 */
function getLiveTournaments($limit = 3) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultTournaments();
    }
    
    try {
        $columns = [];
        $colResult = $conn->query("SHOW COLUMNS FROM tournaments");
        if ($colResult) {
            while ($col = $colResult->fetch_assoc()) {
                $columns[] = $col['Field'];
            }
        }
        
        $selectFields = ['id', 'name', 'description', 'status'];
        
        if (in_array('location', $columns)) {
            $selectFields[] = 'location';
        }
        if (in_array('players', $columns)) {
            $selectFields[] = 'players';
        }
        if (in_array('start_date', $columns)) {
            $selectFields[] = 'start_date';
        }
        
        $selectClause = implode(', ', $selectFields);
        
        if (in_array('status', $columns)) {
            $sql = "SELECT $selectClause FROM tournaments WHERE is_active = 1 AND status IN ('live', 'upcoming', 'open') ORDER BY FIELD(status, 'live', 'upcoming', 'open')";
            if (in_array('start_date', $columns)) {
                $sql .= ", start_date";
            }
            $sql .= " LIMIT ?";
            
            $stmt = $conn->prepare($sql);
            if (!$stmt) {
                return getDefaultTournaments();
            }
            
            $stmt->bind_param("i", $limit);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result && $result->num_rows > 0) {
                $tournaments = [];
                while ($row = $result->fetch_assoc()) {
                    if (!isset($row['location'])) {
                        $row['location'] = 'Online';
                    }
                    if (!isset($row['players'])) {
                        $row['players'] = 0;
                    }
                    if (!isset($row['status'])) {
                        $row['status'] = 'upcoming';
                    }
                    $tournaments[] = $row;
                }
                return $tournaments;
            }
        }
    } catch (Exception $e) {
        // Fall through to default
    }
    
    return getDefaultTournaments();
}

/**
 * Get default tournaments
 */
function getDefaultTournaments() {
    return [
        ['id' => 1, 'name' => 'World Chess Championship', 'description' => 'Watch the world\'s best players compete for the ultimate title.', 'location' => 'Dubai', 'players' => 64, 'status' => 'live'],
        ['id' => 2, 'name' => 'Grand Chess Tour 2026', 'description' => 'Elite tournament featuring top 10 players in the world.', 'location' => 'Paris', 'players' => 32, 'status' => 'upcoming'],
        ['id' => 3, 'name' => 'Chess Heaven Open', 'description' => 'Annual charity tournament open to all players.', 'location' => 'Online', 'players' => 200, 'status' => 'open']
    ];
}

/**
 * Get leaderboard
 */
function getLeaderboard($limit = 5) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultLeaderboard();
    }
    
    $stmt = $conn->prepare("SELECT name, rating, wins, streak FROM leaderboard WHERE is_active = 1 ORDER BY rating DESC LIMIT ?");
    if (!$stmt) {
        return getDefaultLeaderboard();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultLeaderboard();
    }
    
    $leaderboard = [];
    while ($row = $result->fetch_assoc()) {
        $leaderboard[] = $row;
    }
    return $leaderboard;
}

/**
 * Get default leaderboard
 */
function getDefaultLeaderboard() {
    return [
        ['name' => 'Magnus Carlsen', 'rating' => 2847, 'wins' => 127, 'streak' => 15],
        ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'wins' => 98, 'streak' => 8],
        ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'wins' => 112, 'streak' => 12],
        ['name' => 'Fabiano Caruana', 'rating' => 2782, 'wins' => 95, 'streak' => 6],
        ['name' => 'Levon Aronian', 'rating' => 2775, 'wins' => 103, 'streak' => 9]
    ];
}

/**
 * Get articles
 */
function getArticles($limit = 4) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultArticles();
    }
    
    $stmt = $conn->prepare("SELECT id, title, excerpt, author, date, category FROM articles WHERE is_active = 1 ORDER BY date DESC LIMIT ?");
    if (!$stmt) {
        return getDefaultArticles();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultArticles();
    }
    
    $articles = [];
    while ($row = $result->fetch_assoc()) {
        $articles[] = $row;
    }
    return $articles;
}

/**
 * Get default articles
 */
function getDefaultArticles() {
    return [
        ['id' => 1, 'title' => 'Mastering the Queen\'s Gambit', 'excerpt' => 'Deep dive into the classical Queen\'s Gambit opening and its variations.', 'author' => 'GM John Smith', 'date' => '2025-12-10', 'category' => 'strategy'],
        ['id' => 2, 'title' => '10 Tips to Improve Your Chess', 'excerpt' => 'Practical advice to take your chess game to the next level.', 'author' => 'IM Sarah Lee', 'date' => '2025-11-28', 'category' => 'tips'],
        ['id' => 3, 'title' => 'History of Chess: From India to the World', 'excerpt' => 'Explore the fascinating journey of chess through centuries.', 'author' => 'Dr. James Patel', 'date' => '2025-11-05', 'category' => 'history'],
        ['id' => 4, 'title' => 'Chess Psychology: Mind Games', 'excerpt' => 'Understanding the psychological aspects of competitive chess.', 'author' => 'FM David Chen', 'date' => '2025-10-20', 'category' => 'psychology']
    ];
}

/**
 * Get player spotlights
 */
function getPlayerSpotlights($limit = 3) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultPlayerSpotlights();
    }
    
    $stmt = $conn->prepare("SELECT id, name, bio, title, rating FROM player_spotlights WHERE is_active = 1 ORDER BY rating DESC LIMIT ?");
    if (!$stmt) {
        return getDefaultPlayerSpotlights();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultPlayerSpotlights();
    }
    
    $players = [];
    while ($row = $result->fetch_assoc()) {
        $players[] = $row;
    }
    return $players;
}

/**
 * Get default player spotlights
 */
function getDefaultPlayerSpotlights() {
    return [
        ['id' => 1, 'name' => 'Magnus Carlsen', 'bio' => 'World Chess Champion 2013-2025. Highest peak rating of 2882.', 'title' => 'GM', 'rating' => 2847],
        ['id' => 2, 'name' => 'Garry Kasparov', 'bio' => 'World Chess Champion 1985-2000. Revolutionary in chess theory.', 'title' => 'GM', 'rating' => 2851],
        ['id' => 3, 'name' => 'Judit Polgár', 'bio' => 'Strongest female chess player in history. Beat Kasparov at age 15.', 'title' => 'GM', 'rating' => 2735]
    ];
}

/**
 * Get opening of the day
 */
function getOpeningOfDay() {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultOpening();
    }
    
    $today = date('Y-m-d');
    $stmt = $conn->prepare("SELECT name, description, moves FROM openings WHERE is_active = 1 AND (opening_date = ? OR opening_date IS NULL) ORDER BY opening_date DESC, id DESC LIMIT 1");
    if (!$stmt) {
        return getDefaultOpening();
    }
    
    $stmt->bind_param("s", $today);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        return $row;
    }
    
    return getDefaultOpening();
}

/**
 * Get default opening
 */
function getDefaultOpening() {
    return [
        'name' => "Queen's Gambit",
        'description' => '1.d4 d5 2.c4 — One of the most respected openings in chess. White offers a pawn to gain central control.',
        'moves' => '1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Bg5 Nbd7'
    ];
}

/**
 * Get chess quote
 */
function getChessQuote() {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultQuote();
    }
    
    $result = $conn->query("SELECT quote, author FROM chess_quotes WHERE is_active = 1 ORDER BY RAND() LIMIT 1");
    
    if (!$result || $result->num_rows === 0) {
        return getDefaultQuote();
    }
    
    return $result->fetch_assoc();
}

/**
 * Get default quote
 */
function getDefaultQuote() {
    return [
        'quote' => 'Chess is the struggle against error.',
        'author' => 'Wilhelm Steinitz'
    ];
}

/**
 * Get FAQ items
 */
function getFAQItems($limit = 6) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultFAQ();
    }
    
    $stmt = $conn->prepare("SELECT question, answer FROM faq WHERE is_active = 1 ORDER BY display_order LIMIT ?");
    if (!$stmt) {
        return getDefaultFAQ();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultFAQ();
    }
    
    $faq = [];
    while ($row = $result->fetch_assoc()) {
        $faq[] = $row;
    }
    return $faq;
}

/**
 * Get default FAQ
 */
function getDefaultFAQ() {
    return [
        ['question' => 'How do I play chess on Chess Heaven?', 'answer' => 'You can play as a guest immediately or sign up for a free account to access all features. Go to the Play section and start playing against the computer or other players.'],
        ['question' => 'Is Chess Heaven free to use?', 'answer' => 'Yes! Chess Heaven is completely free for all users. We are a non-profit organization dedicated to promoting chess education.'],
        ['question' => 'What is the Daily Puzzle?', 'answer' => 'Every day we feature a new chess puzzle of varying difficulty. Test your tactical skills and improve your pattern recognition.'],
        ['question' => 'How can I improve my chess skills?', 'answer' => 'Use our Learn section with lessons from beginner to advanced. Practice with puzzles, study openings, and analyze featured games. Regular practice is key!'],
        ['question' => 'Do I need to create an account?', 'answer' => 'No, you can play as a guest and access many features. However, creating a free account allows you to save your progress, track your rating, and participate in tournaments.'],
        ['question' => 'What are the tournaments on Chess Heaven?', 'answer' => 'We host regular tournaments for players of all levels. Check the Tournaments section for upcoming events, or watch live games in progress.']
    ];
}

/**
 * Get recent comments
 */
function getRecentComments($limit = 5) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultComments();
    }
    
    $stmt = $conn->prepare("SELECT author, text, rating, helpful, date FROM comments WHERE is_active = 1 ORDER BY date DESC LIMIT ?");
    if (!$stmt) {
        return getDefaultComments();
    }
    
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return getDefaultComments();
    }
    
    $comments = [];
    while ($row = $result->fetch_assoc()) {
        $comments[] = $row;
    }
    return $comments;
}

/**
 * Get default comments
 */
function getDefaultComments() {
    return [
        ['author' => 'Mike R.', 'text' => '"Chess Heaven is an incredible resource for players of all levels. The puzzles are challenging and the lessons are well-structured."', 'rating' => 5, 'helpful' => 24, 'date' => date('Y-m-d H:i:s', strtotime('-1 day'))],
        ['author' => 'Sarah K.', 'text' => '"I\'ve been using Chess Heaven for 6 months and my rating has improved by 300 points. The community is amazing!"', 'rating' => 5, 'helpful' => 18, 'date' => date('Y-m-d H:i:s', strtotime('-4 days'))],
        ['author' => 'James P.', 'text' => '"The live tournaments feature is fantastic! I\'ve participated in several and the organization is top-notch."', 'rating' => 4, 'helpful' => 12, 'date' => date('Y-m-d H:i:s', strtotime('-8 days'))]
    ];
}

/**
 * Get upcoming events - FIXED VERSION
 */
function getUpcomingEvents($limit = 4) {
    $conn = getDBConnection();
    
    // If no database connection, return default events
    if (!$conn) {
        return getDefaultEvents();
    }
    
    try {
        // First, check if the events table exists
        $tableCheck = $conn->query("SHOW TABLES LIKE 'events'");
        if ($tableCheck && $tableCheck->num_rows === 0) {
            // Table doesn't exist, return default events
            return getDefaultEvents();
        }
        
        // Check what columns exist in the events table
        $columns = [];
        $colResult = $conn->query("SHOW COLUMNS FROM events");
        if ($colResult) {
            while ($col = $colResult->fetch_assoc()) {
                $columns[] = $col['Field'];
            }
        }
        
        // Build select fields based on existing columns
        $selectFields = [];
        
        if (in_array('id', $columns)) {
            $selectFields[] = 'id';
        }
        if (in_array('title', $columns)) {
            $selectFields[] = 'title';
        } else {
            $selectFields[] = "'Event' as title";
        }
        if (in_array('description', $columns)) {
            $selectFields[] = 'description';
        } else {
            $selectFields[] = "'Description' as description";
        }
        if (in_array('date', $columns)) {
            $selectFields[] = 'date';
        } else {
            $selectFields[] = 'NOW() as date';
        }
        if (in_array('location', $columns)) {
            $selectFields[] = 'location';
        } else {
            $selectFields[] = "'Location' as location";
        }
        
        $selectClause = implode(', ', $selectFields);
        
        // Prepare and execute query
        $sql = "SELECT $selectClause FROM events WHERE is_active = 1";
        
        // Only add date filter if the column exists
        if (in_array('date', $columns)) {
            $sql .= " AND date >= CURDATE() ORDER BY date ASC LIMIT ?";
        } else {
            $sql .= " ORDER BY id ASC LIMIT ?";
        }
        
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return getDefaultEvents();
        }
        
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $events = [];
            while ($row = $result->fetch_assoc()) {
                // Ensure all required keys exist
                if (!isset($row['id'])) $row['id'] = uniqid();
                if (!isset($row['title'])) $row['title'] = 'Event';
                if (!isset($row['description'])) $row['description'] = 'Description';
                if (!isset($row['date'])) $row['date'] = date('Y-m-d');
                if (!isset($row['location'])) $row['location'] = 'Location';
                $events[] = $row;
            }
            return $events;
        }
    } catch (Exception $e) {
        // Database error, return default events
        error_log("Error in getUpcomingEvents: " . $e->getMessage());
    }
    
    return getDefaultEvents();
}

/**
 * Get default events
 */
function getDefaultEvents() {
    return [
        ['id' => 1, 'title' => 'Chess Workshop for Beginners', 'description' => 'Learn the basics of chess in this free workshop.', 'date' => date('Y-m-d', strtotime('+2 days')), 'location' => 'Community Center'],
        ['id' => 2, 'title' => 'Monthly Chess Tournament', 'description' => 'Competitive tournament open to all skill levels.', 'date' => date('Y-m-d', strtotime('+5 days')), 'location' => 'Online'],
        ['id' => 3, 'title' => 'Chess in Schools Program', 'description' => 'Bringing chess education to local schools.', 'date' => date('Y-m-d', strtotime('+10 days')), 'location' => 'Various Schools'],
        ['id' => 4, 'title' => 'Grandmaster Exhibition', 'description' => 'Watch a GM play simultaneous exhibition matches.', 'date' => date('Y-m-d', strtotime('+15 days')), 'location' => 'Chess Hall']
    ];
}

/**
 * Get lessons from database
 */
function getLessons($limit = 12) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultLessons();
    }
    
    try {
        $columns = [];
        $colResult = $conn->query("SHOW COLUMNS FROM lessons");
        if ($colResult) {
            while ($col = $colResult->fetch_assoc()) {
                $columns[] = $col['Field'];
            }
        }
        
        $selectFields = ['id'];
        
        if (in_array('title', $columns)) $selectFields[] = 'title';
        else $selectFields[] = "'Lesson' as title";
        
        if (in_array('description', $columns)) $selectFields[] = 'description';
        else $selectFields[] = "'Description' as description";
        
        if (in_array('level', $columns)) $selectFields[] = 'level';
        else $selectFields[] = "'beginner' as level";
        
        if (in_array('category', $columns)) $selectFields[] = 'category';
        else $selectFields[] = "'all' as category";
        
        if (in_array('icon', $columns)) $selectFields[] = 'icon';
        else $selectFields[] = "'book' as icon";
        
        if (in_array('duration', $columns)) $selectFields[] = 'duration';
        else $selectFields[] = "'30 min' as duration";
        
        if (in_array('lessons_count', $columns)) $selectFields[] = 'lessons_count';
        else $selectFields[] = '5 as lessons_count';
        
        $selectClause = implode(', ', $selectFields);
        
        $sql = "SELECT $selectClause FROM lessons WHERE is_active = 1 ORDER BY id LIMIT ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return getDefaultLessons();
        }
        
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $lessons = [];
            while ($row = $result->fetch_assoc()) {
                if (!isset($row['title'])) $row['title'] = 'Lesson';
                if (!isset($row['description'])) $row['description'] = 'Description';
                if (!isset($row['level'])) $row['level'] = 'beginner';
                if (!isset($row['category'])) $row['category'] = 'all';
                if (!isset($row['icon'])) $row['icon'] = 'book';
                if (!isset($row['duration'])) $row['duration'] = '30 min';
                if (!isset($row['lessons_count'])) $row['lessons_count'] = 5;
                $lessons[] = $row;
            }
            return $lessons;
        }
    } catch (Exception $e) {
        // Fall through to default
    }
    
    return getDefaultLessons();
}

/**
 * Get default lessons
 */
function getDefaultLessons() {
    return [
        ['id' => 1, 'title' => 'Chess Rules Explained', 'description' => 'Complete guide to chess rules, piece movements, and special moves.', 'level' => 'beginner', 'category' => 'beginner', 'icon' => 'chess-king', 'duration' => '30 min', 'lessons_count' => 8],
        ['id' => 2, 'title' => 'Chess for Beginners', 'description' => 'Start your chess journey with this comprehensive beginner course.', 'level' => 'beginner', 'category' => 'beginner', 'icon' => 'child', 'duration' => '45 min', 'lessons_count' => 12],
        ['id' => 3, 'title' => 'Opening Principles', 'description' => 'Master the fundamental principles of chess openings.', 'level' => 'intermediate', 'category' => 'openings', 'icon' => 'chess-queen', 'duration' => '60 min', 'lessons_count' => 10],
        ['id' => 4, 'title' => 'Middlegame Strategies', 'description' => 'Develop winning strategies for the middlegame.', 'level' => 'intermediate', 'category' => 'middlegame', 'icon' => 'chess-knight', 'duration' => '50 min', 'lessons_count' => 8],
        ['id' => 5, 'title' => 'Endgame Techniques', 'description' => 'Essential endgame skills and checkmate patterns.', 'level' => 'advanced', 'category' => 'endgame', 'icon' => 'chess-rook', 'duration' => '40 min', 'lessons_count' => 6],
        ['id' => 6, 'title' => 'Tactical Patterns', 'description' => 'Recognize and execute tactical patterns like forks, pins, and skewers.', 'level' => 'intermediate', 'category' => 'tactics', 'icon' => 'bolt', 'duration' => '55 min', 'lessons_count' => 9],
        ['id' => 7, 'title' => 'Strategic Planning', 'description' => 'Learn long-term strategic planning and positional play.', 'level' => 'advanced', 'category' => 'strategy', 'icon' => 'brain', 'duration' => '45 min', 'lessons_count' => 7],
        ['id' => 8, 'title' => 'Chess Psychology', 'description' => 'Master the mental aspects of competitive chess.', 'level' => 'advanced', 'category' => 'strategy', 'icon' => 'user-circle', 'duration' => '35 min', 'lessons_count' => 5]
    ];
}

/**
 * Get lesson categories
 */
function getLessonCategories() {
    return [
        ['name' => 'Beginner', 'slug' => 'beginner'],
        ['name' => 'Intermediate', 'slug' => 'intermediate'],
        ['name' => 'Advanced', 'slug' => 'advanced'],
        ['name' => 'Openings', 'slug' => 'openings'],
        ['name' => 'Middlegame', 'slug' => 'middlegame'],
        ['name' => 'Endgame', 'slug' => 'endgame'],
        ['name' => 'Strategy', 'slug' => 'strategy'],
        ['name' => 'Tactics', 'slug' => 'tactics']
    ];
}

/**
 * Get featured lesson
 */
function getFeaturedLesson() {
    return [
        'id' => 1,
        'title' => 'Chess Basics: The Ultimate Beginner\'s Guide',
        'description' => 'Learn the fundamental rules, piece movements, and basic strategies to start your chess journey.',
        'duration' => '45 min',
        'level' => 'Beginner',
        'rating' => '4.8',
        'reviews' => '256'
    ];
}

/**
 * Get learning paths
 */
function getLearningPaths() {
    return [
        [
            'name' => 'Beginner to Intermediate',
            'description' => 'Master the fundamentals and build a solid foundation.',
            'icon' => 'road',
            'progress' => 40,
            'completed' => 4,
            'total' => 10,
            'lessons' => [
                ['name' => 'Lesson 1: Chess Basics', 'completed' => true],
                ['name' => 'Lesson 2: Piece Movement', 'completed' => true],
                ['name' => 'Lesson 3: Opening Principles', 'completed' => false],
                ['name' => 'Lesson 4: Basic Tactics', 'completed' => false]
            ]
        ],
        [
            'name' => 'Intermediate to Advanced',
            'description' => 'Deepen your understanding and master complex strategies.',
            'icon' => 'trophy',
            'progress' => 25,
            'completed' => 2,
            'total' => 8,
            'lessons' => [
                ['name' => 'Lesson 1: Advanced Tactics', 'completed' => true],
                ['name' => 'Lesson 2: Positional Play', 'completed' => false],
                ['name' => 'Lesson 3: Endgame Mastery', 'completed' => false]
            ]
        ],
        [
            'name' => 'Opening Repertoire',
            'description' => 'Build a complete opening repertoire for White and Black.',
            'icon' => 'chess',
            'progress' => 15,
            'completed' => 1,
            'total' => 8,
            'lessons' => [
                ['name' => 'Lesson 1: Italian Game', 'completed' => true],
                ['name' => 'Lesson 2: Ruy Lopez', 'completed' => false],
                ['name' => 'Lesson 3: Sicilian Defense', 'completed' => false]
            ]
        ]
    ];
}

/**
 * Get video tutorials
 */
function getVideoTutorials($limit = 6) {
    return [
        ['title' => 'Understanding Pawn Structure', 'description' => 'Learn the importance of pawn structures in chess.', 'duration' => '15 min', 'instructor' => 'GM Magnus', 'views' => '2.4k', 'icon' => 'chess-king'],
        ['title' => 'Queen Sacrifice Patterns', 'description' => 'Recognize when to sacrifice your queen for victory.', 'duration' => '20 min', 'instructor' => 'GM Kasparov', 'views' => '1.8k', 'icon' => 'chess-queen'],
        ['title' => 'Knight Fork Mastery', 'description' => 'Master the powerful knight fork tactic.', 'duration' => '12 min', 'instructor' => 'IM Sarah', 'views' => '1.5k', 'icon' => 'chess-knight'],
        ['title' => 'Rook Endgame Fundamentals', 'description' => 'Essential rook endgame techniques every player must know.', 'duration' => '25 min', 'instructor' => 'GM Carlsen', 'views' => '3.1k', 'icon' => 'chess-rook'],
        ['title' => 'Bishop Pair Advantage', 'description' => 'Learn to utilize the bishop pair for maximum effect.', 'duration' => '18 min', 'instructor' => 'GM Polgar', 'views' => '1.9k', 'icon' => 'chess-bishop'],
        ['title' => 'Pawn Promotion Techniques', 'description' => 'Master the art of promoting pawns to victory.', 'duration' => '14 min', 'instructor' => 'IM Lee', 'views' => '1.3k', 'icon' => 'chess-pawn']
    ];
}

/**
 * Get recommended books
 */
function getRecommendedBooks($limit = 4) {
    return [
        ['title' => 'Bobby Fischer Teaches Chess', 'description' => 'Classic book by the legendary chess champion.', 'author' => 'Bobby Fischer', 'pages' => 352, 'rating' => 4.8, 'icon' => 'book'],
        ['title' => 'My Great Predecessors', 'description' => "Kasparov's masterful analysis of chess legends.", 'author' => 'Garry Kasparov', 'pages' => 480, 'rating' => 4.9, 'icon' => 'book'],
        ['title' => 'The Art of Attack in Chess', 'description' => 'Master the art of attacking play.', 'author' => 'Vladimir Vukovic', 'pages' => 288, 'rating' => 4.7, 'icon' => 'book'],
        ['title' => 'Endgame Strategy', 'description' => 'Essential endgame knowledge for every player.', 'author' => 'Mikhail Shereshevsky', 'pages' => 256, 'rating' => 4.6, 'icon' => 'book']
    ];
}

/**
 * Get practice exercises
 */
function getPracticeExercises($limit = 6) {
    return [
        ['id' => 1, 'title' => 'Fork Practice', 'description' => 'Practice identifying and executing forks.', 'level' => 'beginner', 'icon' => 'chess-knight'],
        ['id' => 2, 'title' => 'Pin Exercises', 'description' => 'Master the art of pins and use them effectively.', 'level' => 'intermediate', 'icon' => 'chess-queen'],
        ['id' => 3, 'title' => 'Skewer Training', 'description' => 'Learn to skewer enemy pieces for material gain.', 'level' => 'intermediate', 'icon' => 'chess-rook'],
        ['id' => 4, 'title' => 'Checkmate Patterns', 'description' => 'Recognize and execute checkmate patterns.', 'level' => 'advanced', 'icon' => 'chess-king'],
        ['id' => 5, 'title' => 'Pawn Endgames', 'description' => 'Practice essential pawn endgame positions.', 'level' => 'intermediate', 'icon' => 'chess-pawn'],
        ['id' => 6, 'title' => 'Queen vs Rook Endgame', 'description' => 'Master the queen vs rook endgame.', 'level' => 'advanced', 'icon' => 'chess-queen']
    ];
}

/**
 * Get user achievements
 */
function getUserAchievements() {
    return [
        ['name' => 'First Lesson', 'description' => 'Complete your first lesson', 'icon' => 'medal', 'unlocked' => true],
        ['name' => 'Tactics Master', 'description' => 'Solve 50 tactical puzzles', 'icon' => 'medal', 'unlocked' => true],
        ['name' => 'Opening Expert', 'description' => 'Master 5 openings', 'icon' => 'medal', 'unlocked' => false],
        ['name' => 'Endgame Specialist', 'description' => 'Complete all endgame lessons', 'icon' => 'medal', 'unlocked' => false],
        ['name' => 'Learning Streak', 'description' => 'Learn 7 days in a row', 'icon' => 'medal', 'unlocked' => true],
        ['name' => 'Grandmaster in Training', 'description' => 'Complete all lessons', 'icon' => 'medal', 'unlocked' => false]
    ];
}

/**
 * Get learning progress for current user
 */
function getLearningProgress() {
    return [
        'total_lessons' => 12,
        'completed_lessons' => 5,
        'total_exercises' => 50,
        'completed_exercises' => 23,
        'streak_days' => 4,
        'total_hours' => 18.5
    ];
}

/**
 * Get puzzle categories
 */
function getPuzzleCategories() {
    return [
        ['name' => 'Checkmate', 'slug' => 'mate'],
        ['name' => 'Forks', 'slug' => 'fork'],
        ['name' => 'Pins', 'slug' => 'pin'],
        ['name' => 'Skewers', 'slug' => 'skewer'],
        ['name' => 'Sacrifices', 'slug' => 'sacrifice'],
        ['name' => 'Endgame', 'slug' => 'endgame'],
        ['name' => 'Opening Traps', 'slug' => 'opening']
    ];
}

/**
 * Get tactical puzzles
 */
function getTacticalPuzzles($limit = 12) {
    return [
        ['id' => 1, 'title' => 'Checkmate in 1', 'description' => 'Find the immediate checkmate. White to play.', 'difficulty' => 'easy', 'category' => 'mate', 'icon' => 'chess-king', 'solved_percent' => 78, 'solved' => false],
        ['id' => 2, 'title' => 'Royal Fork', 'description' => 'Use a knight fork to win the queen.', 'difficulty' => 'medium', 'category' => 'fork', 'icon' => 'chess-knight', 'solved_percent' => 55, 'solved' => false],
        ['id' => 3, 'title' => 'Pin to Win', 'description' => 'Exploit a pin to win material.', 'difficulty' => 'medium', 'category' => 'pin', 'icon' => 'chess-queen', 'solved_percent' => 48, 'solved' => false],
        ['id' => 4, 'title' => 'Skewer Tactic', 'description' => 'Use a skewer to win the queen.', 'difficulty' => 'medium', 'category' => 'skewer', 'icon' => 'chess-rook', 'solved_percent' => 52, 'solved' => false],
        ['id' => 5, 'title' => 'Queen Sacrifice', 'description' => 'Sacrifice your queen for a winning attack.', 'difficulty' => 'hard', 'category' => 'sacrifice', 'icon' => 'fire', 'solved_percent' => 32, 'solved' => false],
        ['id' => 6, 'title' => 'Endgame Position', 'description' => 'Convert the winning endgame.', 'difficulty' => 'hard', 'category' => 'endgame', 'icon' => 'chess-pawn', 'solved_percent' => 28, 'solved' => false],
        ['id' => 7, 'title' => 'Mate in 2', 'description' => 'Find the forced mate in 2 moves.', 'difficulty' => 'medium', 'category' => 'mate', 'icon' => 'chess-queen', 'solved_percent' => 62, 'solved' => false],
        ['id' => 8, 'title' => 'Discovered Attack', 'description' => 'Unleash a devastating discovered attack.', 'difficulty' => 'hard', 'category' => 'sacrifice', 'icon' => 'bolt', 'solved_percent' => 35, 'solved' => false],
        ['id' => 9, 'title' => 'Opening Trap', 'description' => 'Win material with an opening trap.', 'difficulty' => 'easy', 'category' => 'opening', 'icon' => 'chess-knight', 'solved_percent' => 72, 'solved' => false],
        ['id' => 10, 'title' => 'Zwischenzug', 'description' => 'Find the intermediate move that wins.', 'difficulty' => 'expert', 'category' => 'sacrifice', 'icon' => 'brain', 'solved_percent' => 18, 'solved' => false],
        ['id' => 11, 'title' => 'King and Pawn Endgame', 'description' => 'Win the key king and pawn endgame.', 'difficulty' => 'medium', 'category' => 'endgame', 'icon' => 'chess-king', 'solved_percent' => 44, 'solved' => false],
        ['id' => 12, 'title' => 'Mate in 3', 'description' => 'Find the beautiful mate in 3 moves.', 'difficulty' => 'hard', 'category' => 'mate', 'icon' => 'chess-king', 'solved_percent' => 25, 'solved' => false]
    ];
}

/**
 * Get puzzle statistics for the current user
 */
function getPuzzleStats() {
    return [
        'total' => 150,
        'solved' => 42,
        'streak' => 7,
        'rating' => 1850
    ];
}

/**
 * Get puzzle leaderboard
 */
function getPuzzleLeaderboard($limit = 5) {
    return [
        ['name' => 'TacticalMaster', 'rating' => 2450, 'solved' => 342, 'streak' => 15, 'accuracy' => 92],
        ['name' => 'PuzzleKing', 'rating' => 2380, 'solved' => 298, 'streak' => 12, 'accuracy' => 88],
        ['name' => 'ChessTactician', 'rating' => 2315, 'solved' => 276, 'streak' => 8, 'accuracy' => 85],
        ['name' => 'StrategyPro', 'rating' => 2250, 'solved' => 245, 'streak' => 6, 'accuracy' => 82],
        ['name' => 'TacticalGenius', 'rating' => 2190, 'solved' => 212, 'streak' => 4, 'accuracy' => 79]
    ];
}

/**
 * Get featured puzzles
 */
function getFeaturedPuzzles($limit = 4) {
    return [
        ['id' => 1, 'title' => 'Immortal Puzzle', 'description' => 'Find the famous move from the Immortal Game.', 'difficulty' => 'medium', 'icon' => 'star', 'author' => 'Anderssen', 'solved_percent' => 72],
        ['id' => 2, 'title' => "Queen's Sacrifice", 'description' => 'The brilliant queen sacrifice that won the game.', 'difficulty' => 'hard', 'icon' => 'star', 'author' => 'Fischer', 'solved_percent' => 34],
        ['id' => 3, 'title' => 'Beautiful Mate', 'description' => 'A stunning checkmate pattern.', 'difficulty' => 'easy', 'icon' => 'star', 'author' => 'Morphy', 'solved_percent' => 81],
        ['id' => 4, 'title' => "Kasparov's Masterpiece", 'description' => 'Find the winning combination from Kasparov\'s immortal.', 'difficulty' => 'expert', 'icon' => 'star', 'author' => 'Kasparov', 'solved_percent' => 22]
    ];
}

/**
 * Get puzzle themes
 */
function getPuzzleThemes() {
    return [
        ['id' => 1, 'name' => 'Checkmate', 'description' => 'Practice checkmate patterns', 'icon' => 'chess-king', 'count' => 24],
        ['id' => 2, 'name' => 'Forks', 'description' => 'Master the fork tactic', 'icon' => 'chess-knight', 'count' => 18],
        ['id' => 3, 'name' => 'Pins', 'description' => 'Practice pinning pieces', 'icon' => 'chess-queen', 'count' => 15],
        ['id' => 4, 'name' => 'Skewers', 'description' => 'Master the skewer tactic', 'icon' => 'chess-rook', 'count' => 12],
        ['id' => 5, 'name' => 'Sacrifices', 'description' => 'Learn when to sacrifice', 'icon' => 'fire', 'count' => 20],
        ['id' => 6, 'name' => 'Endgame', 'description' => 'Endgame position puzzles', 'icon' => 'chess-pawn', 'count' => 16]
    ];
}

/**
 * Get featured news
 */
function getFeaturedNews() {
    return [
        'id' => 1,
        'title' => 'World Chess Championship 2025: Carlsen to Face Nepomniachtchi',
        'excerpt' => 'The World Chess Championship match has been officially announced. Magnus Carlsen will defend his title against Ian Nepomniachtchi in a 14-game match starting November 2025.',
        'date' => 'Nov 25, 2025',
        'author' => 'Chess Heaven Staff',
        'category' => 'Tournament',
        'comments' => 42
    ];
}

/**
 * Get news categories
 */
function getNewsCategories() {
    return [
        ['name' => 'Tournaments', 'slug' => 'tournament'],
        ['name' => 'Achievements', 'slug' => 'achievement'],
        ['name' => 'Interviews', 'slug' => 'interview'],
        ['name' => 'Analysis', 'slug' => 'analysis'],
        ['name' => 'Updates', 'slug' => 'update'],
        ['name' => 'Community', 'slug' => 'community']
    ];
}

/**
 * Get newsletter statistics
 */
function getNewsletterStats() {
    return '2,500';
}

/**
 * Get trending topics
 */
function getTrendingTopics() {
    return [
        ['name' => 'WorldChampionship', 'slug' => 'worldchampionship', 'count' => 156],
        ['name' => 'Carlsen', 'slug' => 'carlsen', 'count' => 142],
        ['name' => 'GrandChess', 'slug' => 'grandchess', 'count' => 98],
        ['name' => 'Grandmaster', 'slug' => 'gm', 'count' => 87],
        ['name' => 'OpeningTheory', 'slug' => 'opening', 'count' => 76],
        ['name' => 'WomenInChess', 'slug' => 'womenchess', 'count' => 65]
    ];
}

/**
 * Get tournament news
 */
function getTournamentNews($limit = 4) {
    return [
        ['id' => 1, 'title' => 'World Chess Championship 2025', 'date' => '2025-11-25', 'live' => true],
        ['id' => 2, 'title' => 'Grand Chess Tour 2026', 'date' => '2026-01-15', 'live' => false],
        ['id' => 3, 'title' => "Women's World Championship", 'date' => '2026-02-01', 'live' => false],
        ['id' => 4, 'title' => 'Chess Heaven Open 2025', 'date' => '2025-12-30', 'live' => false]
    ];
}

/**
 * Get video news
 */
function getVideoNews($limit = 3) {
    return [
        ['title' => "Carlsen's Best Games Compilation", 'duration' => '15 min', 'views' => '2.4k', 'icon' => 'chess-king'],
        ['title' => 'World Championship Press Conference', 'duration' => '22 min', 'views' => '1.8k', 'icon' => 'chess-queen'],
        ['title' => "Opening Analysis: Queen's Gambit", 'duration' => '18 min', 'views' => '1.2k', 'icon' => 'chess-knight']
    ];
}

/**
 * Get chess news
 */
function getChessNews($limit = 12) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultChessNews();
    }
    
    try {
        $columns = [];
        $colResult = $conn->query("SHOW COLUMNS FROM chess_news");
        if ($colResult) {
            while ($col = $colResult->fetch_assoc()) {
                $columns[] = $col['Field'];
            }
        }
        
        $selectFields = ['id', 'title', 'excerpt', 'date'];
        
        if (in_array('category', $columns)) {
            $selectFields[] = 'category';
        } else {
            $selectFields[] = "'update' as category";
        }
        
        if (in_array('comments', $columns)) {
            $selectFields[] = 'comments';
        } else {
            $selectFields[] = '0 as comments';
        }
        
        if (in_array('views', $columns)) {
            $selectFields[] = 'views';
        } else {
            $selectFields[] = '0 as views';
        }
        
        $selectClause = implode(', ', $selectFields);
        
        $sql = "SELECT $selectClause FROM chess_news WHERE is_active = 1 ORDER BY date DESC LIMIT ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return getDefaultChessNews();
        }
        
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $news = [];
            while ($row = $result->fetch_assoc()) {
                if (!isset($row['category'])) $row['category'] = 'update';
                if (!isset($row['comments'])) $row['comments'] = 0;
                if (!isset($row['views'])) $row['views'] = 0;
                
                $badgeMap = [
                    'tournament' => 'tournament',
                    'achievement' => 'achievement',
                    'interview' => 'interview',
                    'analysis' => 'analysis',
                    'update' => 'update',
                    'community' => 'update'
                ];
                $iconMap = [
                    'tournament' => 'trophy',
                    'achievement' => 'medal',
                    'interview' => 'microphone',
                    'analysis' => 'chess-board',
                    'update' => 'chess-king',
                    'community' => 'users'
                ];
                $row['badge'] = $badgeMap[$row['category']] ?? 'update';
                $row['icon'] = $iconMap[$row['category']] ?? 'newspaper';
                $news[] = $row;
            }
            return $news;
        }
    } catch (Exception $e) {
        // Fall through to default
    }
    
    return getDefaultChessNews();
}

/**
 * Get default chess news
 */
function getDefaultChessNews() {
    return [
        ['id' => 1, 'title' => 'Grand Chess Tour 2026 Announced', 'excerpt' => 'The Grand Chess Tour returns with stops in Paris, Dubai, and New York.', 'date' => '2025-12-20', 'category' => 'tournament', 'badge' => 'tournament', 'icon' => 'trophy', 'comments' => 28, 'views' => 1200],
        ['id' => 2, 'title' => 'New Grandmaster Title Earned', 'excerpt' => '18-year-old prodigy becomes the youngest GM in history.', 'date' => '2025-12-18', 'category' => 'achievement', 'badge' => 'achievement', 'icon' => 'medal', 'comments' => 45, 'views' => 2400],
        ['id' => 3, 'title' => 'Exclusive: Interview with Magnus Carlsen', 'excerpt' => 'World champion talks about his preparation for the upcoming match.', 'date' => '2025-12-15', 'category' => 'interview', 'badge' => 'interview', 'icon' => 'microphone', 'comments' => 67, 'views' => 3800],
        ['id' => 4, 'title' => 'Game Analysis: Carlsen vs Caruana', 'excerpt' => 'Deep analysis of the decisive game from the recent tournament.', 'date' => '2025-12-12', 'category' => 'analysis', 'badge' => 'analysis', 'icon' => 'chess-board', 'comments' => 34, 'views' => 1800],
        ['id' => 5, 'title' => 'Chess Heaven Platform Update', 'excerpt' => 'New features and improvements to your favorite chess platform.', 'date' => '2025-12-10', 'category' => 'update', 'badge' => 'update', 'icon' => 'chess-king', 'comments' => 19, 'views' => 856],
        ['id' => 6, 'title' => 'Community Tournament a Success', 'excerpt' => 'Over 200 players participated in the annual charity tournament.', 'date' => '2025-12-08', 'category' => 'community', 'badge' => 'update', 'icon' => 'users', 'comments' => 52, 'views' => 1500],
        ['id' => 7, 'title' => "Women's World Championship Qualifiers", 'excerpt' => 'The qualifiers for the Women\'s World Championship have concluded.', 'date' => '2025-12-05', 'category' => 'tournament', 'badge' => 'tournament', 'icon' => 'trophy', 'comments' => 23, 'views' => 967],
        ['id' => 8, 'title' => 'Chess Heaven Hits 100,000 Users', 'excerpt' => 'Our community has reached a milestone of 100,000 registered users.', 'date' => '2025-12-03', 'category' => 'achievement', 'badge' => 'achievement', 'icon' => 'medal', 'comments' => 31, 'views' => 1100]
    ];
}

/**
 * Get upcoming tournaments
 */
function getUpcomingTournaments($limit = 6) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultUpcomingTournaments();
    }
    
    try {
        $columns = [];
        $colResult = $conn->query("SHOW COLUMNS FROM tournaments");
        if ($colResult) {
            while ($col = $colResult->fetch_assoc()) {
                $columns[] = $col['Field'];
            }
        }
        
        $selectFields = ['id', 'name', 'description', 'date'];
        
        if (in_array('location', $columns)) $selectFields[] = 'location';
        else $selectFields[] = "'Online' as location";
        
        if (in_array('status', $columns)) $selectFields[] = 'status';
        else $selectFields[] = "'upcoming' as status";
        
        if (in_array('category', $columns)) $selectFields[] = 'category';
        else $selectFields[] = "'upcoming' as category";
        
        if (in_array('icon', $columns)) $selectFields[] = 'icon';
        else $selectFields[] = "'calendar-plus' as icon";
        
        if (in_array('slots', $columns)) $selectFields[] = 'slots';
        else $selectFields[] = "'Open' as slots";
        
        $selectClause = implode(', ', $selectFields);
        
        $sql = "SELECT $selectClause FROM tournaments WHERE is_active = 1 AND (status = 'upcoming' OR status = 'open') ORDER BY date ASC LIMIT ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return getDefaultUpcomingTournaments();
        }
        
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $tournaments = [];
            while ($row = $result->fetch_assoc()) {
                if (!isset($row['location'])) $row['location'] = 'Online';
                if (!isset($row['status'])) $row['status'] = 'upcoming';
                if (!isset($row['category'])) $row['category'] = 'upcoming';
                if (!isset($row['icon'])) $row['icon'] = 'calendar-plus';
                if (!isset($row['slots'])) $row['slots'] = 'Open';
                $tournaments[] = $row;
            }
            return $tournaments;
        }
    } catch (Exception $e) {
        // Fall through to default
    }
    
    return getDefaultUpcomingTournaments();
}

/**
 * Get default upcoming tournaments
 */
function getDefaultUpcomingTournaments() {
    return [
        ['id' => 4, 'name' => 'Grand Chess Tour 2026', 'description' => 'Elite tournament featuring top 10 players in the world.', 'date' => '2026-01-15', 'location' => 'Paris', 'status' => 'upcoming', 'category' => 'upcoming', 'icon' => 'calendar-plus', 'slots' => '32 slots'],
        ['id' => 5, 'name' => "Women's World Championship", 'description' => 'The premier event for women\'s chess.', 'date' => '2026-02-01', 'location' => 'London', 'status' => 'upcoming', 'category' => 'upcoming', 'icon' => 'calendar-plus', 'slots' => '16 slots'],
        ['id' => 6, 'name' => 'Chess Heaven Open 2026', 'description' => 'Annual charity tournament open to all players.', 'date' => '2026-03-10', 'location' => 'Online', 'status' => 'open', 'category' => 'upcoming', 'icon' => 'calendar-plus', 'slots' => '256 slots'],
        ['id' => 7, 'name' => 'World Blitz Championship', 'description' => 'Fast-paced blitz chess at the highest level.', 'date' => '2026-04-05', 'location' => 'Moscow', 'status' => 'upcoming', 'category' => 'upcoming', 'icon' => 'calendar-plus', 'slots' => '64 slots'],
        ['id' => 8, 'name' => 'Rapid Chess Championship', 'description' => 'Rapid chess tournament with a $100,000 prize pool.', 'date' => '2026-05-20', 'location' => 'New York', 'status' => 'upcoming', 'category' => 'upcoming', 'icon' => 'calendar-plus', 'slots' => '48 slots'],
        ['id' => 9, 'name' => 'Chess Heaven Amateur Cup', 'description' => 'Free tournament for amateur players under 2000 ELO.', 'date' => '2026-06-15', 'location' => 'Online', 'status' => 'open', 'category' => 'upcoming', 'icon' => 'calendar-plus', 'slots' => '128 slots']
    ];
}

/**
 * Get past tournaments
 */
function getPastTournaments($limit = 4) {
    $conn = getDBConnection();
    if (!$conn) {
        return getDefaultPastTournaments();
    }
    
    try {
        $columns = [];
        $colResult = $conn->query("SHOW COLUMNS FROM tournaments");
        if ($colResult) {
            while ($col = $colResult->fetch_assoc()) {
                $columns[] = $col['Field'];
            }
        }
        
        $selectFields = ['id', 'name'];
        
        if (in_array('description', $columns)) $selectFields[] = 'description';
        else $selectFields[] = "'Finished tournament' as description";
        
        if (in_array('date', $columns)) $selectFields[] = 'date';
        else $selectFields[] = 'NOW() as date';
        
        if (in_array('category', $columns)) $selectFields[] = 'category';
        else $selectFields[] = "'finished' as category";
        
        if (in_array('icon', $columns)) $selectFields[] = 'icon';
        else $selectFields[] = "'history' as icon";
        
        if (in_array('winner', $columns)) $selectFields[] = 'winner';
        else $selectFields[] = "'TBD' as winner";
        
        if (in_array('prize', $columns)) $selectFields[] = 'prize';
        else $selectFields[] = '0 as prize';
        
        $selectClause = implode(', ', $selectFields);
        
        $sql = "SELECT $selectClause FROM tournaments WHERE is_active = 1 AND status = 'finished' ORDER BY date DESC LIMIT ?";
        $stmt = $conn->prepare($sql);
        if (!$stmt) {
            return getDefaultPastTournaments();
        }
        
        $stmt->bind_param("i", $limit);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result && $result->num_rows > 0) {
            $tournaments = [];
            while ($row = $result->fetch_assoc()) {
                if (!isset($row['description'])) $row['description'] = 'Finished tournament';
                if (!isset($row['category'])) $row['category'] = 'finished';
                if (!isset($row['icon'])) $row['icon'] = 'history';
                if (!isset($row['winner'])) $row['winner'] = 'TBD';
                if (!isset($row['prize'])) $row['prize'] = 0;
                $tournaments[] = $row;
            }
            return $tournaments;
        }
    } catch (Exception $e) {
        // Fall through to default
    }
    
    return getDefaultPastTournaments();
}

/**
 * Get default past tournaments
 */
function getDefaultPastTournaments() {
    return [
        ['id' => 1, 'name' => 'World Chess Championship 2024', 'description' => 'The world\'s best players compete for the ultimate title.', 'date' => '2024-12-15', 'category' => 'finished', 'icon' => 'history', 'winner' => 'Magnus Carlsen', 'prize' => '2,000,000'],
        ['id' => 2, 'name' => 'Grand Chess Tour 2025', 'description' => 'Elite tournament featuring top 10 players in the world.', 'date' => '2025-11-30', 'category' => 'finished', 'icon' => 'history', 'winner' => 'Fabiano Caruana', 'prize' => '500,000'],
        ['id' => 3, 'name' => 'Chess Heaven Open 2025', 'description' => 'Annual charity tournament open to all players.', 'date' => '2025-12-01', 'category' => 'finished', 'icon' => 'history', 'winner' => 'GM Hikaru Nakamura', 'prize' => '50,000'],
        ['id' => 4, 'name' => 'World Rapid Championship', 'description' => 'Rapid chess tournament with a $150,000 prize pool.', 'date' => '2025-10-20', 'category' => 'finished', 'icon' => 'history', 'winner' => 'GM Ian Nepomniachtchi', 'prize' => '150,000']
    ];
}

/**
 * Get tournament categories
 */
function getTournamentCategories() {
    return [
        ['name' => 'Live', 'slug' => 'live'],
        ['name' => 'Upcoming', 'slug' => 'upcoming'],
        ['name' => 'Finished', 'slug' => 'finished'],
        ['name' => 'Online', 'slug' => 'online'],
        ['name' => 'Over-the-Board', 'slug' => 'otb'],
        ['name' => 'Blitz', 'slug' => 'blitz'],
        ['name' => 'Rapid', 'slug' => 'rapid'],
        ['name' => 'Classical', 'slug' => 'classical']
    ];
}

/**
 * Get featured tournament
 */
function getFeaturedTournament() {
    return [
        'id' => 1,
        'name' => 'World Chess Championship 2025',
        'description' => 'The most prestigious chess tournament in the world. Watch the world\'s best players compete for the ultimate title and a $2,000,000 prize pool.',
        'date' => 'Nov 25 - Dec 15, 2025',
        'location' => 'Dubai, UAE',
        'players' => '64',
        'prize' => '2,000,000'
    ];
}

/**
 * Get tournament stats
 */
function getTournamentStats() {
    return [
        'total' => 24,
        'live' => 3,
        'players' => 1250,
        'prize_pool' => 50000
    ];
}

/**
 * Get prize pools
 */
function getPrizePools() {
    return [
        ['amount' => '2,000,000', 'label' => 'World Championship', 'icon' => 'trophy'],
        ['amount' => '500,000', 'label' => 'Grand Chess Tour', 'icon' => 'medal'],
        ['amount' => '150,000', 'label' => 'Rapid Championship', 'icon' => 'star'],
        ['amount' => '100,000', 'label' => "Women's Championship", 'icon' => 'chess-queen'],
        ['amount' => '50,000', 'label' => 'Chess Heaven Open', 'icon' => 'gem'],
        ['amount' => '25,000', 'label' => 'Amateur Cup', 'icon' => 'award']
    ];
}

/**
 * Get tournament leaderboard
 */
function getTournamentLeaderboard($limit = 5) {
    return [
        ['name' => 'Magnus Carlsen', 'tournaments' => 12, 'wins' => 8, 'prize' => '3,450,000', 'rating' => 2847],
        ['name' => 'Ian Nepomniachtchi', 'tournaments' => 10, 'wins' => 5, 'prize' => '2,100,000', 'rating' => 2795],
        ['name' => 'Hikaru Nakamura', 'tournaments' => 14, 'wins' => 6, 'prize' => '1,800,000', 'rating' => 2788],
        ['name' => 'Fabiano Caruana', 'tournaments' => 11, 'wins' => 4, 'prize' => '1,200,000', 'rating' => 2782],
        ['name' => 'Levon Aronian', 'tournaments' => 9, 'wins' => 3, 'prize' => '950,000', 'rating' => 2775]
    ];
}

/**
 * Get recent tournament results
 */
function getRecentTournamentResults($limit = 5) {
    return [
        ['tournament' => 'World Chess Championship 2024', 'winner' => 'Magnus Carlsen', 'description' => 'Carlsen defends his title in a thrilling 12-game match.', 'date' => '2024-12-15', 'prize' => '2,000,000', 'icon' => 'chess-king'],
        ['tournament' => 'Grand Chess Tour 2025', 'winner' => 'Fabiano Caruana', 'description' => 'Caruana wins the tour with a dominant performance.', 'date' => '2025-11-30', 'prize' => '500,000', 'icon' => 'chess-queen'],
        ['tournament' => 'Chess Heaven Open 2025', 'winner' => 'GM Hikaru Nakamura', 'description' => 'Nakamura wins the charity tournament with a perfect score.', 'date' => '2025-12-01', 'prize' => '50,000', 'icon' => 'chess-knight'],
        ['tournament' => 'World Rapid Championship 2025', 'winner' => 'GM Ian Nepomniachtchi', 'description' => 'Nepomniachtchi wins the rapid chess championship.', 'date' => '2025-10-20', 'prize' => '150,000', 'icon' => 'chess-rook'],
        ['tournament' => 'Chess Heaven Amateur Cup', 'winner' => 'IM Alex Rodriguez', 'description' => 'Rodriguez wins the amateur tournament with an undefeated record.', 'date' => '2025-11-15', 'prize' => '10,000', 'icon' => 'chess-pawn']
    ];
}

/**
 * Get mission statement
 */
function getMissionStatement() {
    return 'To empower individuals and communities through chess education, mentorship, and competitive opportunities. We believe that chess builds critical thinking, patience, and strategic skills that benefit all areas of life.';
}

/**
 * Get vision statement
 */
function getVisionStatement() {
    return 'A world where chess is accessible to everyone, regardless of age, background, or economic status. We envision a global community connected through the love of chess, where everyone can learn, grow, and compete.';
}

/**
 * Get core values
 */
function getCoreValues() {
    return [
        ['name' => 'Community First', 'description' => 'We prioritize building a supportive and inclusive community.', 'icon' => 'hand-holding-heart'],
        ['name' => 'Education', 'description' => 'We believe in the power of education to transform lives.', 'icon' => 'graduation-cap'],
        ['name' => 'Excellence', 'description' => 'We strive for excellence in everything we do.', 'icon' => 'trophy'],
        ['name' => 'Inclusivity', 'description' => 'We welcome everyone regardless of background or skill level.', 'icon' => 'users'],
        ['name' => 'Innovation', 'description' => 'We embrace innovation to make chess more accessible.', 'icon' => 'lightbulb'],
        ['name' => 'Integrity', 'description' => 'We operate with honesty, transparency, and integrity.', 'icon' => 'handshake']
    ];
}

/**
 * Get team members
 */
function getTeamMembers($limit = 8) {
    return [
        ['name' => 'John Doe', 'role' => 'Founder & CEO', 'bio' => 'Former national chess champion with 20+ years of teaching experience.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'john@chessheaven.org'],
        ['name' => 'Jane Smith', 'role' => 'Director of Education', 'bio' => 'Chess educator and curriculum developer with 15 years of experience.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'jane@chessheaven.org'],
        ['name' => 'Maria Chen', 'role' => 'Head Coach', 'bio' => 'FIDE Master and former national champion with a passion for teaching.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'maria@chessheaven.org'],
        ['name' => 'Alex Rivera', 'role' => 'Community Outreach', 'bio' => 'Passionate about bringing chess to underserved communities.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'alex@chessheaven.org'],
        ['name' => 'Sarah Kim', 'role' => 'Tournament Director', 'bio' => 'Organizes chess tournaments and events with precision and care.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'sarah@chessheaven.org'],
        ['name' => 'Michael Williams', 'role' => 'Technology Lead', 'bio' => 'Passionate about using technology to make chess more accessible.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'michael@chessheaven.org'],
        ['name' => 'Lisa Patel', 'role' => 'Content Creator', 'bio' => 'Creates engaging chess content for learners of all levels.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'lisa@chessheaven.org'],
        ['name' => 'Thomas Okafor', 'role' => 'Mentorship Coordinator', 'bio' => 'Connects beginners with experienced players for mentorship.', 'twitter' => '#', 'linkedin' => '#', 'email' => 'thomas@chessheaven.org']
    ];
}

/**
 * Get impact statistics
 */
function getImpactStats() {
    return [
        ['number' => '12,000+', 'label' => 'Students Taught', 'icon' => 'users'],
        ['number' => '340+', 'label' => 'Volunteer Coaches', 'icon' => 'user-tie'],
        ['number' => '87+', 'label' => 'Partner Schools', 'icon' => 'school'],
        ['number' => '$2.1M', 'label' => 'Community Funds Raised', 'icon' => 'dollar-sign'],
        ['number' => '50+', 'label' => 'Tournaments Hosted', 'icon' => 'trophy'],
        ['number' => '30+', 'label' => 'Countries Reached', 'icon' => 'globe']
    ];
}

/**
 * Get timeline
 */
function getTimeline() {
    return [
        ['year' => '2015', 'title' => 'Foundation', 'description' => 'Chess Heaven was founded with a mission to make chess accessible to everyone.'],
        ['year' => '2017', 'title' => 'First Community Program', 'description' => 'Launched our first community chess program in local schools.'],
        ['year' => '2019', 'title' => 'Online Platform Launch', 'description' => 'Launched our online platform to reach students globally.'],
        ['year' => '2021', 'title' => 'Expansion to 10 Countries', 'description' => 'Expanded our programs to 10 countries worldwide.'],
        ['year' => '2023', 'title' => '10,000 Students Milestone', 'description' => 'Reached the milestone of 10,000 students taught.'],
        ['year' => '2025', 'title' => 'Global Community', 'description' => 'Built a global community of chess enthusiasts and educators.']
    ];
}

/**
 * Get partners
 */
function getPartners() {
    return [
        ['name' => 'Chess Federation', 'icon' => 'university'],
        ['name' => 'Local Schools', 'icon' => 'school'],
        ['name' => 'Corporate Sponsors', 'icon' => 'building'],
        ['name' => 'Charity Partners', 'icon' => 'hand-holding-heart'],
        ['name' => 'International Chess Organizations', 'icon' => 'globe'],
        ['name' => 'Community Groups', 'icon' => 'users']
    ];
}

/**
 * Get contact information
 */
function getContactInfo() {
    return [
        'address' => '123 Chess Lane, New York, NY 10001, USA',
        'email' => 'contact@chessheaven.org',
        'phone' => '+1 (555) 123-4567'
    ];
}

/**
 * Get support hours
 */
function getSupportHours() {
    return [
        ['day' => 'Monday - Friday', 'hours' => '9:00 AM - 6:00 PM EST'],
        ['day' => 'Saturday', 'hours' => '10:00 AM - 4:00 PM EST'],
        ['day' => 'Sunday', 'hours' => 'Closed']
    ];
}

/**
 * Get social links
 */
function getSocialLinks() {
    return [
        ['name' => 'Twitter', 'icon' => 'twitter', 'url' => '#'],
        ['name' => 'YouTube', 'icon' => 'youtube', 'url' => '#'],
        ['name' => 'Discord', 'icon' => 'discord', 'url' => '#'],
        ['name' => 'Instagram', 'icon' => 'instagram', 'url' => '#'],
        ['name' => 'Facebook', 'icon' => 'facebook', 'url' => '#'],
        ['name' => 'TikTok', 'icon' => 'tiktok', 'url' => '#']
    ];
}

/**
 * Authenticate user
 */
function authenticateUser($email, $password) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("SELECT id, username, email, password, role FROM users WHERE email = ? AND is_active = 1");
    if (!$stmt) return false;
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            return $row;
        }
    }
    
    return false;
}

/**
 * Save remember me token
 */
function saveRememberToken($userId, $token) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $expires = date('Y-m-d H:i:s', time() + (86400 * 30));
    $stmt = $conn->prepare("INSERT INTO remember_tokens (user_id, token, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE token = ?, expires_at = ?");
    if (!$stmt) return false;
    
    $stmt->bind_param("issss", $userId, $token, $expires, $token, $expires);
    return $stmt->execute();
}

/**
 * Send password reset email
 */
function sendPasswordReset($email) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND is_active = 1");
    if (!$stmt) return false;
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows === 0) {
        return false;
    }
    
    $user = $result->fetch_assoc();
    
    $token = bin2hex(random_bytes(32));
    $expires = date('Y-m-d H:i:s', time() + 3600);
    
    $stmt = $conn->prepare("INSERT INTO password_resets (user_id, token, expires_at) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE token = ?, expires_at = ?");
    if (!$stmt) return false;
    
    $stmt->bind_param("issss", $user['id'], $token, $expires, $token, $expires);
    if (!$stmt->execute()) {
        return false;
    }
    
    return true;
}

/**
 * Get login features
 */
function getLoginFeatures() {
    return [
        ['icon' => 'chess-board', 'title' => 'Free Chess Lessons', 'description' => 'Access all lessons and tutorials'],
        ['icon' => 'trophy', 'title' => 'Tournaments', 'description' => 'Join live tournaments and compete'],
        ['icon' => 'puzzle-piece', 'title' => 'Daily Puzzles', 'description' => 'Solve puzzles and improve tactics'],
        ['icon' => 'users', 'title' => 'Community', 'description' => 'Connect with other chess players']
    ];
}

/**
 * Check if username exists
 */
function usernameExists($username) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE username = ?");
    if (!$stmt) return false;
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

/**
 * Check if email exists
 */
function emailExists($email) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
    if (!$stmt) return false;
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    
    return $result->num_rows > 0;
}

/**
 * Create a new user
 */
function createUser($username, $email, $passwordHash, $firstName = '', $lastName = '') {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $conn->begin_transaction();
    
    try {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, first_name, last_name, role, created_at) VALUES (?, ?, ?, ?, ?, 'user', NOW())");
        if (!$stmt) {
            $conn->rollback();
            return false;
        }
        
        $stmt->bind_param("sssss", $username, $email, $passwordHash, $firstName, $lastName);
        if (!$stmt->execute()) {
            $conn->rollback();
            return false;
        }
        
        $userId = $conn->insert_id;
        
        $stmt = $conn->prepare("INSERT INTO user_stats (user_id, rating, games_played, games_won, games_drawn, games_lost) VALUES (?, 1200, 0, 0, 0, 0)");
        if (!$stmt) {
            $conn->rollback();
            return false;
        }
        
        $stmt->bind_param("i", $userId);
        if (!$stmt->execute()) {
            $conn->rollback();
            return false;
        }
        
        $conn->commit();
        return $userId;
        
    } catch (Exception $e) {
        $conn->rollback();
        return false;
    }
}

/**
 * Get registration benefits
 */
function getRegistrationBenefits() {
    return [
        ['icon' => 'chess-board', 'title' => 'Free Lessons', 'description' => 'Access all chess lessons and tutorials'],
        ['icon' => 'trophy', 'title' => 'Tournaments', 'description' => 'Join live tournaments and compete'],
        ['icon' => 'puzzle-piece', 'title' => 'Daily Puzzles', 'description' => 'Solve puzzles and improve tactics'],
        ['icon' => 'users', 'title' => 'Community', 'description' => 'Connect with other chess players']
    ];
}

/**
 * Get member data by user ID
 */
function getMemberData($userId) {
    $conn = getDBConnection();
    if (!$conn) return null;
    
    $stmt = $conn->prepare("SELECT * FROM members WHERE user_id = ?");
    if (!$stmt) return null;
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Get coach data by user ID
 */
function getCoachData($userId) {
    $conn = getDBConnection();
    if (!$conn) return null;
    
    $stmt = $conn->prepare("SELECT * FROM coaches WHERE user_id = ?");
    if (!$stmt) return null;
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Get admin data by user ID
 */
function getAdminData($userId) {
    $conn = getDBConnection();
    if (!$conn) return null;
    
    $stmt = $conn->prepare("SELECT * FROM admins WHERE user_id = ?");
    if (!$stmt) return null;
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Get user by username
 */
function getUserByUsername($username) {
    $conn = getDBConnection();
    if (!$conn) return null;
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    if (!$stmt) return null;
    
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Get user by email
 */
function getUserByEmail($email) {
    $conn = getDBConnection();
    if (!$conn) return null;
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    if (!$stmt) return null;
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    return $result->fetch_assoc();
}

/**
 * Update last login timestamp
 */
function updateLastLogin($userId) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
    if (!$stmt) return false;
    
    $stmt->bind_param("i", $userId);
    return $stmt->execute();
}

/**
 * Get user by ID (enhanced version with role data)
 */
function getUserByIdEnhanced($userId) {
    $conn = getDBConnection();
    if (!$conn) return null;
    
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    if (!$stmt) return null;
    
    $stmt->bind_param("i", $userId);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    
    if (!$user) return null;
    
    // Get role-specific data
    switch ($user['role']) {
        case 'admin':
            $roleData = getAdminData($userId);
            break;
        case 'coach':
            $roleData = getCoachData($userId);
            break;
        case 'member':
        default:
            $roleData = getMemberData($userId);
            break;
    }
    
    if ($roleData) {
        $user = array_merge($user, $roleData);
    }
    
    return $user;
}

/**
 * Track anonymous user activity
 */
function trackHistoryView($page, $itemType = 'game', $itemTitle = '', $duration = 0) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    if (!isset($_SESSION['history_session_id'])) {
        $_SESSION['history_session_id'] = bin2hex(random_bytes(32));
    }
    $sessionId = $_SESSION['history_session_id'];
    
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';
    $referrer = $_SERVER['HTTP_REFERER'] ?? '';
    
    $stmt = $conn->prepare("INSERT INTO chess_history_views (session_id, ip_address, user_agent, viewed_page, viewed_item, item_type, view_duration, referrer) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssssis", $sessionId, $ipAddress, $userAgent, $page, $itemTitle, $itemType, $duration, $referrer);
    return $stmt->execute();
}

/**
 * Track user interaction
 */
function trackHistoryInteraction($interactionType, $itemType, $itemId = null, $itemTitle = '', $details = '') {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    if (!isset($_SESSION['history_session_id'])) {
        $_SESSION['history_session_id'] = bin2hex(random_bytes(32));
    }
    $sessionId = $_SESSION['history_session_id'];
    
    $ipAddress = $_SERVER['REMOTE_ADDR'] ?? '';
    
    $stmt = $conn->prepare("INSERT INTO chess_history_interactions (session_id, ip_address, interaction_type, item_type, item_id, item_title, details) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssiss", $sessionId, $ipAddress, $interactionType, $itemType, $itemId, $itemTitle, $details);
    return $stmt->execute();
}

/**
 * Get anonymous history views for admin
 */
function getHistoryViews($limit = 50, $filter = '') {
    $conn = getDBConnection();
    if (!$conn) return [];
    
    $sql = "SELECT * FROM chess_history_views";
    if ($filter) {
        $sql .= " WHERE item_type = ? OR viewed_page LIKE ?";
    }
    $sql .= " ORDER BY created_at DESC LIMIT ?";
    
    $stmt = $conn->prepare($sql);
    if ($filter) {
        $filterParam = "%$filter%";
        $stmt->bind_param("ssi", $filter, $filterParam, $limit);
    } else {
        $stmt->bind_param("i", $limit);
    }
    $stmt->execute();
    $result = $stmt->get_result();
    
    $views = [];
    while ($row = $result->fetch_assoc()) {
        $views[] = $row;
    }
    return $views;
}

/**
 * Get anonymous history interactions for admin
 */
function getHistoryInteractions($limit = 50) {
    $conn = getDBConnection();
    if (!$conn) return [];
    
    $stmt = $conn->prepare("SELECT * FROM chess_history_interactions ORDER BY created_at DESC LIMIT ?");
    $stmt->bind_param("i", $limit);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $interactions = [];
    while ($row = $result->fetch_assoc()) {
        $interactions[] = $row;
    }
    return $interactions;
}

/**
 * Get anonymous history statistics
 */
function getHistoryStats() {
    $conn = getDBConnection();
    if (!$conn) return [];
    
    $stats = [];
    
    $result = $conn->query("SELECT COUNT(*) as total FROM chess_history_views");
    $stats['total_views'] = $result->fetch_assoc()['total'] ?? 0;
    
    $result = $conn->query("SELECT COUNT(DISTINCT session_id) as unique_visitors FROM chess_history_views");
    $stats['unique_visitors'] = $result->fetch_assoc()['unique_visitors'] ?? 0;
    
    $result = $conn->query("SELECT item_type, COUNT(*) as count FROM chess_history_views GROUP BY item_type ORDER BY count DESC");
    $stats['views_by_type'] = [];
    while ($row = $result->fetch_assoc()) {
        $stats['views_by_type'][] = $row;
    }
    
    $result = $conn->query("SELECT COUNT(*) as today FROM chess_history_views WHERE DATE(created_at) = CURDATE()");
    $stats['today_views'] = $result->fetch_assoc()['today'] ?? 0;
    
    $result = $conn->query("SELECT COUNT(*) as total FROM chess_history_interactions");
    $stats['total_interactions'] = $result->fetch_assoc()['total'] ?? 0;
    
    return $stats;
}

/**
 * Clear old history data
 */
function clearOldHistory($days = 30) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    $stmt = $conn->prepare("DELETE FROM chess_history_views WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
    $stmt->bind_param("i", $days);
    $stmt->execute();
    
    $stmt = $conn->prepare("DELETE FROM chess_history_interactions WHERE created_at < DATE_SUB(NOW(), INTERVAL ? DAY)");
    $stmt->bind_param("i", $days);
    return $stmt->execute();
}
/**
 * Authenticate user by username OR email
 * @param string $loginInput Username or email
 * @param string $password Password
 * @return array|false User data or false on failure
 */
function authenticateUserByUsernameOrEmail($loginInput, $password) {
    $conn = getDBConnection();
    if (!$conn) return false;
    
    // Check if input looks like an email
    $isEmail = filter_var($loginInput, FILTER_VALIDATE_EMAIL);
    
    if ($isEmail) {
        $stmt = $conn->prepare("SELECT id, username, email, password, role FROM users WHERE email = ? AND is_active = 1");
    } else {
        $stmt = $conn->prepare("SELECT id, username, email, password, role FROM users WHERE username = ? AND is_active = 1");
    }
    
    if (!$stmt) return false;
    
    $stmt->bind_param("s", $loginInput);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            return $row;
        }
    }
    
    return false;
}

// End of config.php
?>