<?php
/**
 * Chess Heaven - Openings Page
 * Comprehensive chess openings database with search and filtering
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get search parameters
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$category = isset($_GET['category']) ? trim($_GET['category']) : 'all';
$difficulty = isset($_GET['difficulty']) ? trim($_GET['difficulty']) : 'all';

// Get all openings
$openings = getAllOpenings($search, $category, $difficulty);
$categories = getOpeningCategories();
$difficulties = ['Beginner', 'Intermediate', 'Advanced'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Chess Openings</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== HERO ===== */
        .hero-section {
            text-align:center;
            padding:2rem 2rem 1rem;
        }
        .hero-section h1 {
            font-size:2.8rem;
            color:#f0d6b0;
            display:flex;
            align-items:center;
            justify-content:center;
            gap:1rem;
            flex-wrap:wrap;
        }
        .hero-section h1 i { color:var(--secondary); }
        .hero-section p {
            color:#a09080;
            max-width:600px;
            margin:0.5rem auto;
            font-size:1.1rem;
        }

        /* ===== SEARCH & FILTERS ===== */
        .filter-section {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:1.5rem;
            margin-bottom:2rem;
        }
        .filter-form {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            align-items:center;
            justify-content:center;
        }
        .filter-form .search-box {
            flex:1;
            min-width:200px;
            display:flex;
            align-items:center;
            background:rgba(0,0,0,0.2);
            border-radius:2rem;
            padding:0 1rem;
            border:1px solid var(--border-color);
            transition:0.3s;
        }
        .filter-form .search-box:focus-within {
            border-color:var(--secondary);
        }
        .filter-form .search-box input {
            background:transparent;
            border:none;
            padding:0.7rem 0.5rem;
            color:#f0e0d0;
            font-size:0.9rem;
            width:100%;
            outline:none;
        }
        .filter-form .search-box input::placeholder {
            color:#5a4a3a;
        }
        .filter-form .search-box i {
            color:#5a4a3a;
        }
        .filter-form select {
            padding:0.7rem 1.5rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            background:rgba(0,0,0,0.2);
            color:#f0e0d0;
            font-size:0.9rem;
            cursor:pointer;
            outline:none;
            min-width:150px;
        }
        .filter-form select option {
            background:#1a0a0a;
            color:#f0e0d0;
        }
        .filter-form .btn-filter {
            padding:0.7rem 2rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:0.3s;
            font-size:0.9rem;
        }
        .filter-form .btn-filter:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.4);
        }
        .filter-form .btn-reset {
            padding:0.7rem 1.5rem;
            border-radius:2rem;
            border:1px solid rgba(255,255,255,0.1);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:0.3s;
            font-size:0.9rem;
        }
        .filter-form .btn-reset:hover {
            background:rgba(255,255,255,0.05);
            color:#f0d6b0;
        }
        .filter-stats {
            text-align:center;
            color:#7a6a5a;
            font-size:0.9rem;
            margin-top:1rem;
        }
        .filter-stats strong {
            color:#f0d6b0;
        }

        /* ===== OPENINGS GRID ===== */
        .openings-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(300px,1fr));
            gap:1.5rem;
        }
        .opening-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
            transition:all 0.3s;
            cursor:pointer;
            position:relative;
            overflow:hidden;
        }
        .opening-card:hover {
            background:rgba(139,26,26,0.12);
            border-color:var(--secondary);
            transform:translateY(-5px);
            box-shadow:0 10px 30px rgba(0,0,0,0.3);
        }
        .opening-card .card-icon {
            font-size:2.5rem;
            color:var(--secondary);
            margin-bottom:0.8rem;
            display:block;
        }
        .opening-card h3 {
            color:#f0d6b0;
            font-size:1.2rem;
            margin-bottom:0.3rem;
        }
        .opening-card .eco {
            color:#5a4a3a;
            font-size:0.75rem;
            font-family:monospace;
            display:inline-block;
            background:rgba(255,255,255,0.05);
            padding:0.1rem 0.5rem;
            border-radius:0.3rem;
            margin-bottom:0.5rem;
        }
        .opening-card .moves-preview {
            color:#a09080;
            font-size:0.85rem;
            font-family:monospace;
            padding:0.5rem;
            background:rgba(0,0,0,0.2);
            border-radius:0.5rem;
            margin:0.5rem 0;
        }
        .opening-card .card-meta {
            display:flex;
            gap:1rem;
            flex-wrap:wrap;
            margin-top:0.8rem;
            padding-top:0.8rem;
            border-top:1px solid rgba(255,255,255,0.05);
        }
        .opening-card .card-meta .tag {
            font-size:0.7rem;
            padding:0.2rem 0.7rem;
            border-radius:2rem;
            background:rgba(198,151,107,0.1);
            color:var(--secondary);
            border:1px solid rgba(198,151,107,0.2);
        }
        .opening-card .card-meta .tag.difficulty-beginner { background:rgba(46,204,113,0.1); color:#2ecc71; border-color:rgba(46,204,113,0.2); }
        .opening-card .card-meta .tag.difficulty-intermediate { background:rgba(241,196,15,0.1); color:#f1c40f; border-color:rgba(241,196,15,0.2); }
        .opening-card .card-meta .tag.difficulty-advanced { background:rgba(231,76,60,0.1); color:#e74c3c; border-color:rgba(231,76,60,0.2); }
        .opening-card .card-meta .stats {
            margin-left:auto;
            color:#5a4a3a;
            font-size:0.75rem;
            display:flex;
            align-items:center;
            gap:0.3rem;
        }
        .opening-card .card-meta .stats i { color:var(--secondary); }
        .opening-card .popularity-bar {
            height:3px;
            background:rgba(255,255,255,0.05);
            border-radius:2px;
            margin-top:0.8rem;
            overflow:hidden;
        }
        .opening-card .popularity-bar .fill {
            height:100%;
            background:linear-gradient(90deg,var(--secondary),var(--gold));
            border-radius:2px;
            transition:width 1s ease;
        }

        /* ===== EMPTY STATE ===== */
        .empty-state {
            text-align:center;
            padding:4rem 2rem;
            grid-column:1/-1;
        }
        .empty-state i {
            font-size:4rem;
            color:var(--secondary);
            margin-bottom:1rem;
            opacity:0.5;
        }
        .empty-state h3 {
            color:#f0d6b0;
            font-size:1.5rem;
            margin-bottom:0.5rem;
        }
        .empty-state p {
            color:#7a6a5a;
            max-width:400px;
            margin:0 auto;
        }

        /* ===== FEATURED OPENING ===== */
        .featured-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.5));
            border-radius:1.5rem;
            padding:2rem;
            border:1px solid var(--border-color);
            margin-bottom:2rem;
        }
        .featured-content {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:2rem;
            align-items:center;
        }
        .featured-content .featured-text h3 {
            color:#f0d6b0;
            font-size:1.5rem;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .featured-content .featured-text h3 i { color:var(--secondary); }
        .featured-content .featured-text p {
            color:#a09080;
            line-height:1.6;
            margin:0.5rem 0;
        }
        .featured-content .featured-text .btn-learn {
            display:inline-block;
            padding:0.7rem 2rem;
            border-radius:2rem;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            transition:0.3s;
            margin-top:0.5rem;
        }
        .featured-content .featured-text .btn-learn:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 20px rgba(139,26,26,0.4);
        }
        .featured-content .featured-stats {
            display:grid;
            grid-template-columns:1fr 1fr 1fr;
            gap:1rem;
            text-align:center;
        }
        .featured-content .featured-stats .stat-item {
            background:rgba(0,0,0,0.2);
            padding:1rem;
            border-radius:0.8rem;
        }
        .featured-content .featured-stats .stat-item .number {
            font-size:1.8rem;
            font-weight:700;
            color:var(--secondary);
        }
        .featured-content .featured-stats .stat-item .label {
            color:#7a6a5a;
            font-size:0.75rem;
            text-transform:uppercase;
            letter-spacing:1px;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .featured-content {
                grid-template-columns:1fr;
                text-align:center;
            }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .hero-section h1 { font-size:2rem; }
            .filter-form {
                flex-direction:column;
            }
            .filter-form .search-box {
                width:100%;
            }
            .filter-form select {
                width:100%;
            }
            .openings-grid {
                grid-template-columns:1fr;
            }
            .featured-content .featured-stats {
                grid-template-columns:1fr;
            }
        }
        @media (max-width:480px) {
            .hero-section h1 { font-size:1.5rem; }
            .opening-card .card-meta {
                flex-direction:column;
                align-items:flex-start;
            }
            .opening-card .card-meta .stats {
                margin-left:0;
            }
        }

        /* ===== SCROLLBAR ===== */
        ::-webkit-scrollbar { width:6px; }
        ::-webkit-scrollbar-track { background:transparent; }
        ::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:3px; }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="openings.php" class="active-link"><i class="fas fa-book-open"></i> Openings</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== HERO ===== -->
    <section class="section hero-section">
        <h1>
            <i class="fas fa-chess"></i>
            Chess Openings
            <i class="fas fa-chess"></i>
        </h1>
        <p>
            <i class="fas fa-info-circle"></i>
            Explore the most popular chess openings and variations. Learn the theory, key concepts, and master your opening repertoire.
        </p>
    </section>

    <!-- ===== FEATURED OPENING ===== -->
    <?php 
        $featuredOpening = getFeaturedOpening();
        if ($featuredOpening): 
    ?>
    <section class="section" style="padding-top:0;">
        <div class="featured-section">
            <div class="featured-content">
                <div class="featured-text">
                    <h3>
                        <i class="fas fa-star" style="color:var(--gold);"></i>
                        Featured Opening
                    </h3>
                    <h2 style="color:#f0d6b0;font-size:1.8rem;margin:0.3rem 0;">
                        <?php echo e($featuredOpening['name']); ?>
                    </h2>
                    <span class="eco" style="color:#5a4a3a;font-family:monospace;font-size:0.85rem;">
                        <?php echo e($featuredOpening['eco'] ?? 'ECO: —'); ?>
                    </span>
                    <p><?php echo e($featuredOpening['description']); ?></p>
                    <a href="opening.php?id=<?php echo e($featuredOpening['id']); ?>" class="btn-learn">
                        <i class="fas fa-graduation-cap"></i> Learn More
                    </a>
                </div>
                <div class="featured-stats">
                    <div class="stat-item">
                        <div class="number"><?php echo e($featuredOpening['popularity']); ?>%</div>
                        <div class="label">Popularity</div>
                    </div>
                    <div class="stat-item">
                        <div class="number"><?php echo e($featuredOpening['win_rate'] ?? '52'); ?>%</div>
                        <div class="label">Win Rate</div>
                    </div>
                    <div class="stat-item">
                        <div class="number"><?php echo e(number_format($featuredOpening['games_played'] ?? 0)); ?></div>
                        <div class="label">Games</div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>

    <!-- ===== FILTERS ===== -->
    <section class="section" style="padding-top:0;">
        <div class="filter-section">
            <form method="GET" action="openings.php" class="filter-form" id="filterForm">
                <div class="search-box">
                    <i class="fas fa-search"></i>
                    <input type="text" name="search" placeholder="Search openings..." value="<?php echo e(htmlspecialchars($search)); ?>" />
                </div>
                <select name="category">
                    <option value="all" <?php echo $category === 'all' ? 'selected' : ''; ?>>All Categories</option>
                    <?php foreach ($categories as $cat): ?>
                        <option value="<?php echo e($cat); ?>" <?php echo $category === $cat ? 'selected' : ''; ?>>
                            <?php echo e($cat); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <select name="difficulty">
                    <option value="all" <?php echo $difficulty === 'all' ? 'selected' : ''; ?>>All Levels</option>
                    <?php foreach ($difficulties as $diff): ?>
                        <option value="<?php echo e($diff); ?>" <?php echo $difficulty === $diff ? 'selected' : ''; ?>>
                            <?php echo e($diff); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button type="submit" class="btn-filter">
                    <i class="fas fa-filter"></i> Filter
                </button>
                <?php if ($search || $category !== 'all' || $difficulty !== 'all'): ?>
                    <a href="openings.php" class="btn-reset">
                        <i class="fas fa-times"></i> Clear
                    </a>
                <?php endif; ?>
            </form>
            <div class="filter-stats">
                <i class="fas fa-chess-pawn"></i>
                Found <strong><?php echo e(count($openings)); ?></strong> opening<?php echo count($openings) !== 1 ? 's' : ''; ?>
                <?php if ($search): ?>
                    matching "<strong><?php echo e(htmlspecialchars($search)); ?></strong>"
                <?php endif; ?>
            </div>
        </div>

        <!-- ===== OPENINGS GRID ===== -->
        <div class="openings-grid">
            <?php if (!empty($openings)): ?>
                <?php foreach ($openings as $opening): ?>
                    <a href="opening.php?id=<?php echo e($opening['id']); ?>" class="opening-card">
                        <span class="card-icon">
                            <i class="fas fa-chess-<?php echo $opening['icon'] ?? 'pawn'; ?>"></i>
                        </span>
                        <h3><?php echo e($opening['name']); ?></h3>
                        <?php if (isset($opening['eco'])): ?>
                            <span class="eco"><?php echo e($opening['eco']); ?></span>
                        <?php endif; ?>
                        <?php if (!empty($opening['moves_preview']) || !empty($opening['moves'])): ?>
                            <div class="moves-preview">
                                <?php echo e(is_array($opening['moves']) ? implode(' ', array_slice($opening['moves'], 0, 6)) : $opening['moves_preview']); ?>
                                <?php if (count($opening['moves']) > 6): ?>
                                    ...
                                <?php endif; ?>
                            </div>
                        <?php endif; ?>
                        <div class="card-meta">
                            <span class="tag"><?php echo e($opening['category']); ?></span>
                            <span class="tag difficulty-<?php echo strtolower($opening['difficulty'] ?? 'beginner'); ?>">
                                <?php echo e($opening['difficulty'] ?? 'Beginner'); ?>
                            </span>
                            <span class="stats">
                                <i class="fas fa-star"></i>
                                <?php echo e($opening['popularity']); ?>%
                            </span>
                        </div>
                        <?php if (isset($opening['popularity'])): ?>
                            <div class="popularity-bar">
                                <div class="fill" style="width:<?php echo e($opening['popularity']); ?>%;"></div>
                            </div>
                        <?php endif; ?>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="empty-state">
                    <i class="fas fa-book-open"></i>
                    <h3>No Openings Found</h3>
                    <p>Try adjusting your search or filters to find the openings you're looking for.</p>
                    <a href="openings.php" class="btn-play" style="display:inline-block;margin-top:1.5rem;padding:0.8rem 2rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-decoration:none;">
                        <i class="fas fa-redo"></i> Reset Filters
                    </a>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== QUICK TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(250px,1fr));gap:1.5rem;">
            <div style="background:var(--card-bg);border-radius:1.2rem;padding:1.5rem;border:1px solid var(--border-color);text-align:center;">
                <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--gold);"></i>
                <h4 style="color:#f0d6b0;margin:0.5rem 0;">Master the Basics</h4>
                <p style="color:#a09080;font-size:0.9rem;">Start with classical openings like the Italian Game and Ruy Lopez to build a solid foundation.</p>
            </div>
            <div style="background:var(--card-bg);border-radius:1.2rem;padding:1.5rem;border:1px solid var(--border-color);text-align:center;">
                <i class="fas fa-chess-board" style="font-size:2rem;color:var(--secondary);"></i>
                <h4 style="color:#f0d6b0;margin:0.5rem 0;">Study Variations</h4>
                <p style="color:#a09080;font-size:0.9rem;">Each opening has multiple variations. Learn the main lines first, then explore sidelines.</p>
            </div>
            <div style="background:var(--card-bg);border-radius:1.2rem;padding:1.5rem;border:1px solid var(--border-color);text-align:center;">
                <i class="fas fa-trophy" style="font-size:2rem;color:var(--gold);"></i>
                <h4 style="color:#f0d6b0;margin:0.5rem 0;">Practice Regularly</h4>
                <p style="color:#a09080;font-size:0.9rem;">Play games using your chosen openings to gain practical experience and confidence.</p>
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== POPULARITY BAR ANIMATION =====
        document.addEventListener('DOMContentLoaded', function() {
            const bars = document.querySelectorAll('.popularity-bar .fill');
            bars.forEach(bar => {
                const width = bar.style.width;
                bar.style.width = '0%';
                setTimeout(() => {
                    bar.style.width = width;
                }, 100);
            });
        });
    </script>
</body>
</html>
<?php
/**
 * Helper functions for openings page
 */
function getAllOpenings($search = '', $category = 'all', $difficulty = 'all') {
    // Simulated opening data
    $allOpenings = [
        [
            'id' => 1,
            'name' => 'Italian Game',
            'eco' => 'C50',
            'category' => 'Open Game',
            'popularity' => 92,
            'difficulty' => 'Beginner',
            'games_played' => 1250000,
            'win_rate' => 52,
            'icon' => 'king',
            'moves' => ['e4', 'e5', 'Nf3', 'Nc6', 'Bc4', 'Bc5', 'd3', 'Nf6', 'Bg5', 'h6', 'Bh4', 'g5', 'Bg3', 'd5', 'exd5', 'Nxd5'],
            'description' => 'The Italian Game is one of the oldest recorded chess openings, dating back to the 16th century.'
        ],
        [
            'id' => 2,
            'name' => 'Ruy Lopez',
            'eco' => 'C60-C99',
            'category' => 'Open Game',
            'popularity' => 88,
            'difficulty' => 'Intermediate',
            'games_played' => 980000,
            'win_rate' => 50,
            'icon' => 'queen',
            'moves' => ['e4', 'e5', 'Nf3', 'Nc6', 'Bb5', 'a6', 'Ba4', 'Nf6', 'O-O', 'Be7', 'Re1', 'b5', 'Bb3', 'O-O', 'c3', 'd6'],
            'description' => 'The Ruy Lopez, also known as the Spanish Opening, is one of the most respected openings in chess.'
        ],
        [
            'id' => 3,
            'name' => 'Sicilian Defense',
            'eco' => 'B20-B99',
            'category' => 'Semi-Open',
            'popularity' => 85,
            'difficulty' => 'Advanced',
            'games_played' => 2100000,
            'win_rate' => 51,
            'icon' => 'knight',
            'moves' => ['e4', 'c5', 'Nf3', 'd6', 'd4', 'cxd4', 'Nxd4', 'Nf6', 'Nc3', 'a6', 'Be3', 'e5', 'Nb3', 'Be6', 'f3', 'Be7'],
            'description' => 'The Sicilian Defense is the most popular and dynamic response to 1.e4.'
        ],
        [
            'id' => 4,
            'name' => 'French Defense',
            'eco' => 'C00-C19',
            'category' => 'Semi-Open',
            'popularity' => 78,
            'difficulty' => 'Intermediate',
            'games_played' => 890000,
            'win_rate' => 48,
            'icon' => 'pawn',
            'moves' => ['e4', 'e6', 'd4', 'd5', 'Nc3', 'Nf6', 'Bg5', 'Be7', 'e5', 'Nfd7', 'Bxe7', 'Qxe7', 'f4', 'c5', 'Nf3', 'Nc6'],
            'description' => 'The French Defense is a solid and reliable opening for Black.'
        ],
        [
            'id' => 5,
            'name' => 'Caro-Kann Defense',
            'eco' => 'B10-B19',
            'category' => 'Semi-Open',
            'popularity' => 76,
            'difficulty' => 'Intermediate',
            'games_played' => 720000,
            'win_rate' => 49,
            'icon' => 'rook',
            'moves' => ['e4', 'c6', 'd4', 'd5', 'Nc3', 'dxe4', 'Nxe4', 'Bf5', 'Ng3', 'Bg6', 'Nf3', 'e6', 'Bd3', 'Bxd3', 'Qxd3', 'Nf6'],
            'description' => 'The Caro-Kann Defense is a solid and reliable opening for Black.'
        ],
        [
            'id' => 6,
            'name' => "Queen's Gambit",
            'eco' => 'D10-D69',
            'category' => 'Closed Game',
            'popularity' => 82,
            'difficulty' => 'Intermediate',
            'games_played' => 1100000,
            'win_rate' => 51,
            'icon' => 'bishop',
            'moves' => ['d4', 'd5', 'c4', 'e6', 'Nc3', 'Nf6', 'Bg5', 'Be7', 'e3', 'Nbd7', 'Nf3', 'O-O', 'Rc1', 'c6', 'Bd3', 'dxc4'],
            'description' => "The Queen's Gambit is one of the most respected and popular openings in chess."
        ],
        [
            'id' => 7,
            'name' => 'King\'s Indian Defense',
            'eco' => 'E60-E99',
            'category' => 'Closed Game',
            'popularity' => 74,
            'difficulty' => 'Advanced',
            'games_played' => 650000,
            'win_rate' => 47,
            'icon' => 'king',
            'moves' => ['d4', 'Nf6', 'c4', 'g6', 'Nc3', 'Bg7', 'e4', 'd6', 'Nf3', 'O-O', 'Be2', 'e5', 'O-O', 'Nc6', 'd5', 'Ne7'],
            'description' => 'The King\'s Indian Defense is a hypermodern opening known for its aggressive and dynamic play.'
        ],
        [
            'id' => 8,
            'name' => 'London System',
            'eco' => 'A40-A48',
            'category' => 'Closed Game',
            'popularity' => 70,
            'difficulty' => 'Beginner',
            'games_played' => 580000,
            'win_rate' => 53,
            'icon' => 'bishop',
            'moves' => ['d4', 'd5', 'Bf4', 'Nf6', 'e3', 'e6', 'Nf3', 'c5', 'c3', 'Nc6', 'Nbd2', 'Bd6', 'Bg3', 'O-O', 'Bd3', 'b6'],
            'description' => 'The London System is a solid and reliable opening system for White.'
        ],
        [
            'id' => 9,
            'name' => 'English Opening',
            'eco' => 'A10-A39',
            'category' => 'Closed Game',
            'popularity' => 68,
            'difficulty' => 'Intermediate',
            'games_played' => 520000,
            'win_rate' => 50,
            'icon' => 'knight',
            'moves' => ['c4', 'e5', 'Nc3', 'Nf6', 'Nf3', 'Nc6', 'e3', 'Bb4', 'Qc2', 'O-O', 'a3', 'Bxc3', 'Qxc3', 'd6', 'b4', 'Bg4'],
            'description' => 'The English Opening is a flexible and positional opening named after the English Grandmaster Howard Staunton.'
        ],
        [
            'id' => 10,
            'name' => 'Pirc Defense',
            'eco' => 'B07-B09',
            'category' => 'Semi-Open',
            'popularity' => 62,
            'difficulty' => 'Advanced',
            'games_played' => 430000,
            'win_rate' => 46,
            'icon' => 'pawn',
            'moves' => ['e4', 'd6', 'd4', 'Nf6', 'Nc3', 'g6', 'Be3', 'Bg7', 'Qd2', 'O-O', 'f3', 'e5', 'Nge2', 'exd4', 'Nxd4', 'Nc6'],
            'description' => 'The Pirc Defense is a hypermodern opening that allows White to build a large center.'
        ]
    ];

    // Apply filters
    $filtered = array_filter($allOpenings, function($opening) use ($search, $category, $difficulty) {
        // Search filter
        if ($search !== '') {
            $searchLower = strtolower($search);
            $nameMatch = stripos($opening['name'], $searchLower) !== false;
            $descMatch = isset($opening['description']) && stripos($opening['description'], $searchLower) !== false;
            if (!$nameMatch && !$descMatch) {
                return false;
            }
        }
        
        // Category filter
        if ($category !== 'all' && $opening['category'] !== $category) {
            return false;
        }
        
        // Difficulty filter
        if ($difficulty !== 'all' && ($opening['difficulty'] ?? 'Beginner') !== $difficulty) {
            return false;
        }
        
        return true;
    });

    // Sort by popularity
    usort($filtered, function($a, $b) {
        return ($b['popularity'] ?? 0) - ($a['popularity'] ?? 0);
    });

    return array_values($filtered);
}

function getOpeningCategories() {
    return [
        'Open Game',
        'Semi-Open',
        'Closed Game',
        'Flank Opening',
        'Hypermodern'
    ];
}

function getFeaturedOpening() {
    $openings = getAllOpenings();
    return $openings[0] ?? null;
}
?>