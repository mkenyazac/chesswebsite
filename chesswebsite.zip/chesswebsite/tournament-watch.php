<?php
/**
 * Chess Heaven - Tournament Watch Page
 * Live tournament viewing with interactive board, player info, and real-time updates
 */

require_once 'config.php';

// Get tournament ID from URL
$tournamentId = isset($_GET['id']) ? (int)$_GET['id'] : 1;

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get tournament details
$tournamentDetails = getTournamentDetails($tournamentId);
$liveGames = getLiveGames($tournamentId);
$tournamentStandings = getTournamentStandings($tournamentId, 8);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · <?php echo e($tournamentDetails ? $tournamentDetails['name'] : 'Tournament'); ?> (Live)</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.5rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== TOURNAMENT HEADER ===== */
        .tournament-header {
            background:linear-gradient(145deg,rgba(139,26,26,0.2),rgba(10,5,5,0.6));
            border-radius:2rem;
            padding:2rem;
            border:2px solid var(--gold);
            margin-bottom:2rem;
        }
        .tournament-header .header-top {
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:1rem;
        }
        .tournament-header h1 {
            color:#f0d6b0;
            font-size:2rem;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .tournament-header .live-badge {
            padding:0.3rem 1.2rem;
            border-radius:2rem;
            background:rgba(231,76,60,0.3);
            color:#e74c3c;
            font-weight:700;
            font-size:0.85rem;
            animation:pulse-badge 2s infinite;
        }
        @keyframes pulse-badge {
            0%, 100% { opacity:1; }
            50% { opacity:0.5; }
        }
        .tournament-header .header-meta {
            display:flex;
            gap:1.5rem;
            flex-wrap:wrap;
            margin-top:0.5rem;
            color:#a09080;
            font-size:0.9rem;
        }
        .tournament-header .header-meta span {
            display:flex;
            align-items:center;
            gap:0.4rem;
        }
        .tournament-header .header-meta span i { color:var(--secondary); }

        /* ===== GAME LAYOUT ===== */
        .game-layout {
            display:grid;
            grid-template-columns:1.2fr 1fr;
            gap:2rem;
        }
        .game-main {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:1.5rem;
        }
        .game-main .game-title {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:0.8rem;
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .game-main .game-title .players {
            display:flex;
            align-items:center;
            gap:1rem;
        }
        .game-main .game-title .players .player {
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .game-main .game-title .players .player .avatar {
            width:30px;
            height:30px;
            border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:0.8rem;
            color:var(--secondary);
        }
        .game-main .game-title .players .vs {
            color:#7a6a5a;
            font-weight:700;
            font-size:0.8rem;
        }
        .game-main .game-title .move-counter {
            color:#7a6a5a;
            font-size:0.75rem;
        }

        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:550px;
            aspect-ratio:1;
            margin:0 auto;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
            transition:transform 0.3s ease;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.8rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
            position:relative;
        }
        .chess-board .square.light { background:var(--light-square); }
        .chess-board .square.dark { background:var(--dark-square); }
        .chess-board .square.highlight {
            background:rgba(255,255,0,0.4) !important;
            box-shadow:inset 0 0 20px rgba(255,255,0,0.3);
        }
        .chess-board .square.last-move {
            background:rgba(255,255,100,0.3) !important;
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
            pointer-events:none;
            z-index:1;
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }
        .chess-board .square .coords {
            position:absolute;
            font-size:0.55rem;
            color:rgba(0,0,0,0.3);
            pointer-events:none;
            font-weight:600;
        }
        .chess-board .square .coords.file { bottom:2px; right:4px; }
        .chess-board .square .coords.rank { top:2px; left:4px; }
        .chess-board .square.dark .coords { color:rgba(255,255,255,0.3); }

        .board-controls {
            display:flex;
            gap:0.6rem;
            flex-wrap:wrap;
            justify-content:center;
            margin-top:0.8rem;
            width:100%;
        }
        .board-controls button {
            padding:0.4rem 0.9rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.75rem;
            display:inline-flex;
            align-items:center;
            gap:0.4rem;
        }
        .btn-nav {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-nav:hover { background:rgba(198,151,107,0.25); }
        .btn-nav:disabled {
            opacity:0.3;
            cursor:not-allowed;
        }
        .btn-reset-board {
            background:rgba(255,255,255,0.05);
            color:#a09080;
            border:1px solid rgba(255,255,255,0.1) !important;
        }
        .btn-reset-board:hover { background:rgba(255,255,255,0.1); }
        .btn-flip-board {
            background:rgba(46,204,113,0.15);
            color:#2ecc71;
            border:1px solid #2ecc71 !important;
        }
        .btn-flip-board:hover { background:rgba(46,204,113,0.25); }

        /* ===== SIDEBAR ===== */
        .game-sidebar {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .sidebar-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
        }
        .sidebar-card h3 {
            color:#f0d6b0;
            font-size:1rem;
            margin-bottom:0.8rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .sidebar-card h3 i { color:var(--secondary); }
        .sidebar-card .stat-row {
            display:flex;
            justify-content:space-between;
            padding:0.4rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            color:#a09080;
            font-size:0.85rem;
        }
        .sidebar-card .stat-row:last-child { border-bottom:none; }
        .sidebar-card .stat-row span:last-child { color:#f0d6b0; font-weight:500; }

        .move-history {
            max-height:200px;
            overflow-y:auto;
            padding:0.5rem;
            background:rgba(0,0,0,0.2);
            border-radius:0.5rem;
            font-size:0.8rem;
            font-family:monospace;
        }
        .move-history::-webkit-scrollbar { width:4px; }
        .move-history::-webkit-scrollbar-track { background:transparent; }
        .move-history::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }
        .move-history .move-row {
            display:flex;
            gap:0.5rem;
            padding:0.1rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
        }
        .move-history .move-row .move-number { color:#5a4a3a; min-width:25px; }
        .move-history .move-row .move-white { color:#f0d6b0; }
        .move-history .move-row .move-black { color:#a09080; }

        /* ===== STANDINGS ===== */
        .standings-table {
            width:100%;
            border-collapse:collapse;
            font-size:0.85rem;
        }
        .standings-table th {
            color:#7a6a5a;
            border-bottom:1px solid var(--border-color);
            padding:0.5rem;
            text-align:left;
        }
        .standings-table td {
            padding:0.5rem;
            border-bottom:1px solid rgba(255,255,255,0.03);
        }
        .standings-table tr:last-child td { border-bottom:none; }
        .standings-table .rank {
            font-weight:700;
            color:#5a4a3a;
        }
        .standings-table .rank-1 { color:var(--gold); }
        .standings-table .rank-2 { color:#c0c0c0; }
        .standings-table .rank-3 { color:#cd7f32; }

        /* ===== CHAT ===== */
        .chat-container {
            max-height:200px;
            overflow-y:auto;
            padding:0.5rem;
            background:rgba(0,0,0,0.2);
            border-radius:0.5rem;
        }
        .chat-container::-webkit-scrollbar { width:4px; }
        .chat-container::-webkit-scrollbar-track { background:transparent; }
        .chat-container::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }
        .chat-message {
            padding:0.3rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            font-size:0.8rem;
        }
        .chat-message .chat-author {
            color:var(--secondary);
            font-weight:600;
        }
        .chat-message .chat-text {
            color:#a09080;
        }
        .chat-input {
            display:flex;
            gap:0.5rem;
            margin-top:0.5rem;
        }
        .chat-input input {
            flex:1;
            padding:0.5rem 0.8rem;
            border-radius:2rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0e0d0;
            font-size:0.8rem;
        }
        .chat-input input:focus {
            outline:none;
            border-color:var(--secondary);
        }
        .chat-input button {
            padding:0.5rem 1rem;
            border-radius:2rem;
            border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.8rem;
        }
        .chat-input button:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .game-layout {
                grid-template-columns:1fr;
            }
            .chess-board { max-width:400px; }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:1rem; }
            .tournament-header { padding:1.5rem; }
            .tournament-header h1 { font-size:1.5rem; }
            .game-main { padding:1rem; }
            .chess-board .square .piece { font-size:2rem; }
            .chess-board { max-width:100%; }
            .board-controls button { padding:0.3rem 0.7rem; font-size:0.7rem; }
        }
        @media (max-width:480px) {
            .tournament-header h1 { font-size:1.2rem; }
            .chess-board .square .piece { font-size:1.5rem; }
            .game-main .game-title .players { flex-wrap:wrap; }
            .standings-table { font-size:0.75rem; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php" class="active-link"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <?php if ($tournamentDetails): ?>
        <!-- ===== TOURNAMENT HEADER ===== -->
        <section class="section" style="padding-top:2rem;">
            <div class="tournament-header">
                <div class="header-top">
                    <h1>
                        <i class="fas fa-trophy" style="color:var(--gold);"></i>
                        <?php echo e($tournamentDetails['name']); ?>
                    </h1>
                    <span class="live-badge">● LIVE</span>
                </div>
                <div class="header-meta">
                    <span><i class="fas fa-calendar"></i> <?php echo e($tournamentDetails['date']); ?></span>
                    <span><i class="fas fa-map-marker-alt"></i> <?php echo e($tournamentDetails['location']); ?></span>
                    <span><i class="fas fa-users"></i> <?php echo e($tournamentDetails['players']); ?> players</span>
                    <span><i class="fas fa-trophy"></i> $<?php echo e($tournamentDetails['prize']); ?></span>
                    <span><i class="fas fa-clock"></i> Round <?php echo e($tournamentDetails['round'] ?? 7); ?></span>
                    <span><i class="fas fa-eye"></i> <?php echo e(number_format($tournamentDetails['viewers'] ?? 1247)); ?> watching</span>
                </div>
                <div style="margin-top:0.5rem;display:flex;gap:0.8rem;flex-wrap:wrap;">
                    <a href="tournament-register.php?id=<?php echo e($tournamentId); ?>" class="btn-register" style="display:inline-block;padding:0.5rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;transition:all 0.3s;">
                        <i class="fas fa-user-plus"></i> Register
                    </a>
                    <a href="tournaments.php" class="btn-watch" style="display:inline-block;padding:0.5rem 1.5rem;border-radius:2rem;border:2px solid var(--secondary);background:transparent;color:var(--secondary);font-weight:600;cursor:pointer;transition:all 0.3s;">
                        <i class="fas fa-arrow-left"></i> Back to Tournaments
                    </a>
                </div>
            </div>
        </section>

        <!-- ===== GAME LAYOUT ===== -->
        <section class="section" style="padding-top:0;">
            <div class="game-layout">
                <!-- Main Game -->
                <div class="game-main">
                    <div class="game-title">
                        <div class="players">
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span id="whitePlayerName"><?php echo e($tournamentDetails['white_player'] ?? 'GM White'); ?></span>
                                <span style="color:#a09080;font-size:0.8rem;" id="whiteRating">(<?php echo e($tournamentDetails['white_rating'] ?? '2847'); ?>)</span>
                            </div>
                            <span class="vs">VS</span>
                            <div class="player">
                                <div class="avatar"><i class="fas fa-user"></i></div>
                                <span id="blackPlayerName"><?php echo e($tournamentDetails['black_player'] ?? 'GM Black'); ?></span>
                                <span style="color:#a09080;font-size:0.8rem;" id="blackRating">(<?php echo e($tournamentDetails['black_rating'] ?? '2795'); ?>)</span>
                            </div>
                        </div>
                        <span class="move-counter" id="moveCounter">Move 0</span>
                    </div>

                    <div class="chess-board" id="chessBoard"></div>

                    <div class="board-controls">
                        <button class="btn-nav" id="prevBtn" onclick="prevMove()">
                            <i class="fas fa-chevron-left"></i> Prev
                        </button>
                        <button class="btn-nav" id="nextBtn" onclick="nextMove()">
                            Next <i class="fas fa-chevron-right"></i>
                        </button>
                        <button class="btn-reset-board" onclick="resetBoard()">
                            <i class="fas fa-redo"></i> Reset
                        </button>
                        <button class="btn-flip-board" onclick="flipBoard()">
                            <i class="fas fa-sync-alt"></i> Flip
                        </button>
                        <button class="btn-nav" onclick="toggleAutoPlay()" id="autoBtn">
                            <i class="fas fa-play"></i> Auto
                        </button>
                    </div>

                    <div style="margin-top:0.8rem;text-align:center;color:#7a6a5a;font-size:0.75rem;">
                        <i class="fas fa-info-circle"></i> Auto-play updates every 3 seconds (simulated)
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="game-sidebar">
                    <!-- Game Info -->
                    <div class="sidebar-card">
                        <h3><i class="fas fa-info-circle"></i> Game Info</h3>
                        <div class="stat-row">
                            <span>Time Control</span>
                            <span><?php echo e($tournamentDetails['time_control'] ?? '90+30'); ?></span>
                        </div>
                        <div class="stat-row">
                            <span>White Time</span>
                            <span id="whiteTime">01:25:30</span>
                        </div>
                        <div class="stat-row">
                            <span>Black Time</span>
                            <span id="blackTime">01:18:45</span>
                        </div>
                        <div class="stat-row">
                            <span>Evaluation</span>
                            <span id="evaluation">+0.45</span>
                        </div>
                        <div class="stat-row">
                            <span>Status</span>
                            <span style="color:var(--success);">In Progress</span>
                        </div>
                    </div>

                    <!-- Move History -->
                    <div class="sidebar-card">
                        <h3><i class="fas fa-list"></i> Move History</h3>
                        <div class="move-history" id="moveHistory">
                            <div style="color:#5a4a3a;text-align:center;padding:0.5rem;">No moves yet</div>
                        </div>
                    </div>

                    <!-- Live Chat -->
                    <div class="sidebar-card">
                        <h3><i class="fas fa-comments"></i> Live Chat</h3>
                        <div class="chat-container" id="chatContainer">
                            <div class="chat-message">
                                <span class="chat-author">System:</span>
                                <span class="chat-text">Welcome to the live stream!</span>
                            </div>
                            <div class="chat-message">
                                <span class="chat-author">GM_ Fan:</span>
                                <span class="chat-text">Great game so far!</span>
                            </div>
                            <div class="chat-message">
                                <span class="chat-author">ChessLover:</span>
                                <span class="chat-text">White is pushing for a win.</span>
                            </div>
                        </div>
                        <div class="chat-input">
                            <input type="text" placeholder="Type a message..." id="chatInput" onkeypress="if(event.key==='Enter') sendChat()">
                            <button onclick="sendChat()"><i class="fas fa-paper-plane"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- ===== STANDINGS ===== -->
        <section class="section" style="padding-top:0;">
            <div class="section-header">
                <h2><i class="fas fa-list-ol"></i> Tournament Standings</h2>
                <a href="standings.php?id=<?php echo e($tournamentId); ?>" class="view-all">Full Standings <i class="fas fa-arrow-right"></i></a>
            </div>
            <div style="background:var(--card-bg);border:1px solid var(--border-color);border-radius:1.2rem;padding:1rem;overflow-x:auto;">
                <table class="standings-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Player</th>
                            <th style="text-align:center;">Rating</th>
                            <th style="text-align:center;">Points</th>
                            <th style="text-align:center;">Wins</th>
                            <th style="text-align:center;">Draws</th>
                            <th style="text-align:center;">Losses</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($tournamentStandings)): ?>
                            <?php foreach ($tournamentStandings as $index => $player): ?>
                                <tr>
                                    <td class="rank rank-<?php echo $index + 1 <= 3 ? $index + 1 : ''; ?>"><?php echo e($index + 1); ?></td>
                                    <td style="color:#f0d6b0;"><?php echo e($player['name']); ?></td>
                                    <td style="text-align:center;color:#a09080;"><?php echo e($player['rating']); ?></td>
                                    <td style="text-align:center;color:var(--gold);font-weight:600;"><?php echo e($player['points']); ?></td>
                                    <td style="text-align:center;color:var(--success);"><?php echo e($player['wins']); ?></td>
                                    <td style="text-align:center;color:var(--warning);"><?php echo e($player['draws']); ?></td>
                                    <td style="text-align:center;color:var(--danger);"><?php echo e($player['losses']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr><td class="rank rank-1">1</td><td style="color:#f0d6b0;">Magnus Carlsen</td><td style="text-align:center;color:#a09080;">2847</td><td style="text-align:center;color:var(--gold);font-weight:600;">6.5</td><td style="text-align:center;color:var(--success);">5</td><td style="text-align:center;color:var(--warning);">3</td><td style="text-align:center;color:var(--danger);">1</td></tr>
                            <tr><td class="rank rank-2">2</td><td style="color:#f0d6b0;">Ian Nepomniachtchi</td><td style="text-align:center;color:#a09080;">2795</td><td style="text-align:center;color:var(--gold);font-weight:600;">5.5</td><td style="text-align:center;color:var(--success);">4</td><td style="text-align:center;color:var(--warning);">3</td><td style="text-align:center;color:var(--danger);">2</td></tr>
                            <tr><td class="rank rank-3">3</td><td style="color:#f0d6b0;">Hikaru Nakamura</td><td style="text-align:center;color:#a09080;">2788</td><td style="text-align:center;color:var(--gold);font-weight:600;">5.0</td><td style="text-align:center;color:var(--success);">3</td><td style="text-align:center;color:var(--warning);">4</td><td style="text-align:center;color:var(--danger);">2</td></tr>
                            <tr><td>4</td><td style="color:#f0d6b0;">Fabiano Caruana</td><td style="text-align:center;color:#a09080;">2782</td><td style="text-align:center;color:var(--gold);font-weight:600;">4.5</td><td style="text-align:center;color:var(--success);">3</td><td style="text-align:center;color:var(--warning);">3</td><td style="text-align:center;color:var(--danger);">3</td></tr>
                            <tr><td>5</td><td style="color:#f0d6b0;">Levon Aronian</td><td style="text-align:center;color:#a09080;">2775</td><td style="text-align:center;color:var(--gold);font-weight:600;">4.0</td><td style="text-align:center;color:var(--success);">2</td><td style="text-align:center;color:var(--warning);">4</td><td style="text-align:center;color:var(--danger);">3</td></tr>
                            <tr><td>6</td><td style="color:#f0d6b0;">Wesley So</td><td style="text-align:center;color:#a09080;">2760</td><td style="text-align:center;color:var(--gold);font-weight:600;">4.0</td><td style="text-align:center;color:var(--success);">2</td><td style="text-align:center;color:var(--warning);">4</td><td style="text-align:center;color:var(--danger);">3</td></tr>
                            <tr><td>7</td><td style="color:#f0d6b0;">Anish Giri</td><td style="text-align:center;color:#a09080;">2745</td><td style="text-align:center;color:var(--gold);font-weight:600;">3.5</td><td style="text-align:center;color:var(--success);">2</td><td style="text-align:center;color:var(--warning);">3</td><td style="text-align:center;color:var(--danger);">4</td></tr>
                            <tr><td>8</td><td style="color:#f0d6b0;">Alireza Firouzja</td><td style="text-align:center;color:#a09080;">2730</td><td style="text-align:center;color:var(--gold);font-weight:600;">3.0</td><td style="text-align:center;color:var(--success);">1</td><td style="text-align:center;color:var(--warning);">4</td><td style="text-align:center;color:var(--danger);">4</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

    <?php else: ?>
        <section class="section" style="padding-top:3rem;">
            <div style="text-align:center;padding:4rem 2rem;">
                <i class="fas fa-exclamation-triangle" style="font-size:4rem;color:var(--secondary);"></i>
                <h2 style="color:#f0d6b0;margin:1rem 0;">Tournament Not Found</h2>
                <p style="color:#a09080;">The tournament you're looking for doesn't exist or has ended.</p>
                <a href="tournaments.php" class="btn-register" style="display:inline-block;margin-top:1.5rem;padding:0.8rem 2rem;border-radius:2rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;text-decoration:none;">
                    <i class="fas fa-arrow-left"></i> Back to Tournaments
                </a>
            </div>
        </section>
    <?php endif; ?>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:2rem;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== PIECE SYMBOLS =====
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // ===== BOARD STATE =====
        const INITIAL_BOARD = [
            ['r','n','b','q','k','b','n','r'],
            ['p','p','p','p','p','p','p','p'],
            ['','','','','','','',''],
            ['','','','','','','',''],
            ['','','','','','','',''],
            ['','','','','','','',''],
            ['P','P','P','P','P','P','P','P'],
            ['R','N','B','Q','K','B','N','R']
        ];

        let board = JSON.parse(JSON.stringify(INITIAL_BOARD));
        let moveHistory = [];
        let currentMoveIndex = 0;
        let isFlipped = false;
        let autoPlayInterval = null;
        let isAutoPlaying = false;
        let lastMove = null;

        // ===== SIMULATED MOVES =====
        const SIMULATED_MOVES = [
            { from: 'e2', to: 'e4' },
            { from: 'e7', to: 'e5' },
            { from: 'g1', to: 'f3' },
            { from: 'b8', to: 'c6' },
            { from: 'f1', to: 'c4' },
            { from: 'g8', to: 'f6' },
            { from: 'd2', to: 'd3' },
            { from: 'f8', to: 'c5' },
            { from: 'c1', to: 'g5' },
            { from: 'd7', to: 'd6' },
            { from: 'b1', to: 'c3' },
            { from: 'c8', to: 'e6' },
            { from: 'd1', to: 'e2' },
            { from: 'a7', to: 'a6' },
            { from: 'e1', to: 'g1' },
            { from: 'e8', to: 'g8' }
        ];

        const FILES = 'abcdefgh';

        // ===== RENDER BOARD =====
        function renderBoard() {
            const boardEl = document.getElementById('chessBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            const boardState = moveHistory[currentMoveIndex]?.board || board;
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isFlipped ? 7 - row : row;
                    const actualCol = isFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    
                    const piece = boardState[actualRow]?.[actualCol] || '';
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    // Coordinates
                    if (col === 0) {
                        const rank = document.createElement('span');
                        rank.className = 'coords rank';
                        rank.textContent = 8 - actualRow;
                        square.appendChild(rank);
                    }
                    if (row === 7) {
                        const file = document.createElement('span');
                        file.className = 'coords file';
                        file.textContent = FILES[actualCol];
                        square.appendChild(file);
                    }
                    
                    // Highlight last move
                    if (lastMove && currentMoveIndex > 0) {
                        const lastMoveData = moveHistory[currentMoveIndex - 1];
                        if (lastMoveData) {
                            const fromRow = 8 - parseInt(lastMoveData.from[1]);
                            const fromCol = FILES.indexOf(lastMoveData.from[0]);
                            const toRow = 8 - parseInt(lastMoveData.to[1]);
                            const toCol = FILES.indexOf(lastMoveData.to[0]);
                            if ((actualRow === fromRow && actualCol === fromCol) ||
                                (actualRow === toRow && actualCol === toCol)) {
                                square.classList.add('last-move');
                            }
                        }
                    }
                    
                    boardEl.appendChild(square);
                }
            }
            
            updateUI();
        }

        function updateUI() {
            document.getElementById('moveCounter').textContent = `Move ${currentMoveIndex}`;
            document.getElementById('prevBtn').disabled = currentMoveIndex === 0;
            document.getElementById('nextBtn').disabled = currentMoveIndex >= moveHistory.length;
            
            // Update move history
            const historyEl = document.getElementById('moveHistory');
            if (moveHistory.length === 0) {
                historyEl.innerHTML = '<div style="color:#5a4a3a;text-align:center;padding:0.5rem;">No moves yet</div>';
            } else {
                let html = '';
                for (let i = 0; i < moveHistory.length; i += 2) {
                    const moveNum = Math.floor(i / 2) + 1;
                    const whiteMove = moveHistory[i] ? moveHistory[i].notation : '';
                    const blackMove = moveHistory[i + 1] ? moveHistory[i + 1].notation : '';
                    html += `<div class="move-row">
                        <span class="move-number">${moveNum}.</span>
                        <span class="move-white">${whiteMove}</span>
                        <span class="move-black">${blackMove}</span>
                    </div>`;
                }
                historyEl.innerHTML = html;
                historyEl.scrollTop = historyEl.scrollHeight;
            }
            
            // Update time (simulated)
            updateTime();
        }

        // ===== TIME UPDATE =====
        function updateTime() {
            const whiteTime = document.getElementById('whiteTime');
            const blackTime = document.getElementById('blackTime');
            if (whiteTime && blackTime) {
                // Simulate time decreasing
                const baseTime = 5400; // 90 minutes in seconds
                const elapsed = currentMoveIndex * 30; // 30 seconds per move
                const whiteRemaining = Math.max(0, baseTime - elapsed + 300);
                const blackRemaining = Math.max(0, baseTime - elapsed);
                
                whiteTime.textContent = formatTime(whiteRemaining);
                blackTime.textContent = formatTime(blackRemaining);
            }
        }

        function formatTime(seconds) {
            const hrs = Math.floor(seconds / 3600);
            const mins = Math.floor((seconds % 3600) / 60);
            const secs = Math.floor(seconds % 60);
            return `${String(hrs).padStart(2, '0')}:${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
        }

        // ===== APPLY MOVE =====
        function applyMove(index) {
            // Reset to initial board
            board = JSON.parse(JSON.stringify(INITIAL_BOARD));
            lastMove = null;
            
            // Apply moves up to index
            for (let i = 0; i < index && i < moveHistory.length; i++) {
                const move = moveHistory[i];
                const fromRow = 8 - parseInt(move.from[1]);
                const fromCol = FILES.indexOf(move.from[0]);
                const toRow = 8 - parseInt(move.to[1]);
                const toCol = FILES.indexOf(move.to[0]);
                
                if (fromRow >= 0 && fromRow < 8 && fromCol >= 0 && fromCol < 8 &&
                    toRow >= 0 && toRow < 8 && toCol >= 0 && toCol < 8) {
                    board[toRow][toCol] = board[fromRow][fromCol];
                    board[fromRow][fromCol] = '';
                    lastMove = move;
                }
            }
        }

        // ===== NAVIGATION =====
        function goToMove(index) {
            currentMoveIndex = Math.max(0, Math.min(index, moveHistory.length));
            applyMove(currentMoveIndex);
            renderBoard();
        }

        function nextMove() {
            if (currentMoveIndex < moveHistory.length) {
                goToMove(currentMoveIndex + 1);
            }
        }

        function prevMove() {
            if (currentMoveIndex > 0) {
                goToMove(currentMoveIndex - 1);
            }
        }

        function resetBoard() {
            goToMove(0);
            if (isAutoPlaying) {
                clearTimeout(autoPlayInterval);
                isAutoPlaying = false;
                document.getElementById('autoBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
            }
        }

        function flipBoard() {
            isFlipped = !isFlipped;
            renderBoard();
        }

        function toggleAutoPlay() {
            isAutoPlaying = !isAutoPlaying;
            const btn = document.getElementById('autoBtn');
            if (isAutoPlaying) {
                btn.innerHTML = '<i class="fas fa-pause"></i> Pause';
                if (currentMoveIndex < moveHistory.length) {
                    autoPlayInterval = setTimeout(() => {
                        if (currentMoveIndex < moveHistory.length) {
                            nextMove();
                            if (isAutoPlaying) {
                                autoPlayInterval = setTimeout(() => {
                                    if (currentMoveIndex < moveHistory.length) {
                                        nextMove();
                                        if (isAutoPlaying) {
                                            autoPlayInterval = setTimeout(() => {
                                                if (currentMoveIndex < moveHistory.length) {
                                                    nextMove();
                                                    if (isAutoPlaying) {
                                                        autoPlayInterval = setTimeout(() => {
                                                            if (currentMoveIndex < moveHistory.length) {
                                                                nextMove();
                                                            } else {
                                                                isAutoPlaying = false;
                                                                document.getElementById('autoBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
                                                            }
                                                        }, 3000);
                                                    }
                                                } else {
                                                    isAutoPlaying = false;
                                                    document.getElementById('autoBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
                                                }
                                            }, 3000);
                                        }
                                    } else {
                                        isAutoPlaying = false;
                                        document.getElementById('autoBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
                                    }
                                }, 3000);
                            }
                        } else {
                            isAutoPlaying = false;
                            document.getElementById('autoBtn').innerHTML = '<i class="fas fa-play"></i> Auto';
                        }
                    }, 3000);
                }
            } else {
                btn.innerHTML = '<i class="fas fa-play"></i> Auto';
                clearTimeout(autoPlayInterval);
            }
        }

        // ===== GENERATE MOVES =====
        function generateMoves() {
            // Generate random moves from SIMULATED_MOVES
            const numMoves = Math.floor(Math.random() * 10) + 8;
            const selectedMoves = [];
            const usedIndices = new Set();
            
            for (let i = 0; i < Math.min(numMoves, SIMULATED_MOVES.length); i++) {
                let randomIndex;
                do {
                    randomIndex = Math.floor(Math.random() * SIMULATED_MOVES.length);
                } while (usedIndices.has(randomIndex) && usedIndices.size < SIMULATED_MOVES.length);
                usedIndices.add(randomIndex);
                selectedMoves.push(SIMULATED_MOVES[randomIndex]);
            }
            
            // Sort by original order
            selectedMoves.sort((a, b) => {
                const idxA = SIMULATED_MOVES.indexOf(a);
                const idxB = SIMULATED_MOVES.indexOf(b);
                return idxA - idxB;
            });
            
            // Add notation
            return selectedMoves.map((move, index) => {
                const fromPiece = getPieceAt(move.from);
                const toPiece = getPieceAt(move.to);
                const pieceSymbol = fromPiece ? fromPiece.toUpperCase() : '';
                const pieceName = pieceSymbol === 'P' ? '' : pieceSymbol;
                const captureSymbol = toPiece ? 'x' : '';
                const notation = `${pieceName}${captureSymbol}${move.to}`;
                return { ...move, notation };
            });
        }

        function getPieceAt(square) {
            const row = 8 - parseInt(square[1]);
            const col = FILES.indexOf(square[0]);
            if (row >= 0 && row < 8 && col >= 0 && col < 8) {
                return board[row][col] || '';
            }
            return '';
        }

        // ===== CHAT =====
        function sendChat() {
            const input = document.getElementById('chatInput');
            const message = input.value.trim();
            if (!message) return;
            
            const container = document.getElementById('chatContainer');
            const msgDiv = document.createElement('div');
            msgDiv.className = 'chat-message';
            msgDiv.innerHTML = `
                <span class="chat-author">You:</span>
                <span class="chat-text">${message}</span>
            `;
            container.appendChild(msgDiv);
            container.scrollTop = container.scrollHeight;
            input.value = '';
        }

        // ===== KEYBOARD SHORTCUTS =====
        document.addEventListener('keydown', function(e) {
            if (document.activeElement?.tagName === 'INPUT') return;
            
            if (e.key === 'ArrowRight' || e.key === 'ArrowDown') {
                e.preventDefault();
                nextMove();
            } else if (e.key === 'ArrowLeft' || e.key === 'ArrowUp') {
                e.preventDefault();
                prevMove();
            } else if (e.key === 'r' || e.key === 'R') {
                resetBoard();
            } else if (e.key === 'f' || e.key === 'F') {
                if (!e.ctrlKey && !e.metaKey) {
                    e.preventDefault();
                    flipBoard();
                }
            } else if (e.key === ' ') {
                e.preventDefault();
                toggleAutoPlay();
            }
        });

        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // ===== NAVBAR SCROLL =====
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== INIT =====
        document.addEventListener('DOMContentLoaded', function() {
            // Generate moves
            moveHistory = generateMoves();
            currentMoveIndex = 0;
            applyMove(0);
            renderBoard();
            
            // Make functions globally accessible
            window.nextMove = nextMove;
            window.prevMove = prevMove;
            window.resetBoard = resetBoard;
            window.flipBoard = flipBoard;
            window.toggleAutoPlay = toggleAutoPlay;
            window.sendChat = sendChat;
        });
    </script>
</body>
</html>
<?php
/**
 * Helper functions for tournament watch page
 */
function getTournamentDetails($id) {
    // Simulated tournament data
    $tournaments = [
        1 => [
            'id' => 1,
            'name' => 'World Chess Championship 2025',
            'date' => 'Nov 25 - Dec 15, 2025',
            'location' => 'Dubai, UAE',
            'players' => '64',
            'prize' => '2,000,000',
            'round' => 7,
            'viewers' => 1247,
            'time_control' => '90+30',
            'white_player' => 'GM Magnus Carlsen',
            'white_rating' => '2847',
            'black_player' => 'GM Ian Nepomniachtchi',
            'black_rating' => '2795'
        ],
        2 => [
            'id' => 2,
            'name' => 'Grand Chess Tour - Paris 2025',
            'date' => 'Dec 5-10, 2025',
            'location' => 'Paris, France',
            'players' => '32',
            'prize' => '500,000',
            'round' => 4,
            'viewers' => 856,
            'time_control' => '120+30',
            'white_player' => 'GM Hikaru Nakamura',
            'white_rating' => '2788',
            'black_player' => 'GM Fabiano Caruana',
            'black_rating' => '2782'
        ],
        3 => [
            'id' => 3,
            'name' => 'Chess Heaven Open 2025',
            'date' => 'Dec 1-8, 2025',
            'location' => 'Online',
            'players' => '200',
            'prize' => '50,000',
            'round' => 3,
            'viewers' => 432,
            'time_control' => '60+15',
            'white_player' => 'IM Sarah Lee',
            'white_rating' => '2450',
            'black_player' => 'FM David Chen',
            'black_rating' => '2380'
        ]
    ];
    
    return $tournaments[$id] ?? $tournaments[1];
}

function getLiveGames($tournamentId) {
    // Simulated live games
    return [
        [
            'board' => 1,
            'white' => 'GM Magnus Carlsen',
            'white_rating' => '2847',
            'black' => 'GM Ian Nepomniachtchi',
            'black_rating' => '2795',
            'moves' => 35,
            'status' => 'In Progress'
        ],
        [
            'board' => 2,
            'white' => 'GM Hikaru Nakamura',
            'white_rating' => '2788',
            'black' => 'GM Fabiano Caruana',
            'black_rating' => '2782',
            'moves' => 28,
            'status' => 'In Progress'
        ]
    ];
}

function getTournamentStandings($tournamentId, $limit = 8) {
    // Simulated standings
    return [
        ['name' => 'Magnus Carlsen', 'rating' => 2847, 'points' => 6.5, 'wins' => 5, 'draws' => 3, 'losses' => 1],
        ['name' => 'Ian Nepomniachtchi', 'rating' => 2795, 'points' => 5.5, 'wins' => 4, 'draws' => 3, 'losses' => 2],
        ['name' => 'Hikaru Nakamura', 'rating' => 2788, 'points' => 5.0, 'wins' => 3, 'draws' => 4, 'losses' => 2],
        ['name' => 'Fabiano Caruana', 'rating' => 2782, 'points' => 4.5, 'wins' => 3, 'draws' => 3, 'losses' => 3],
        ['name' => 'Levon Aronian', 'rating' => 2775, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 3],
        ['name' => 'Wesley So', 'rating' => 2760, 'points' => 4.0, 'wins' => 2, 'draws' => 4, 'losses' => 3],
        ['name' => 'Anish Giri', 'rating' => 2745, 'points' => 3.5, 'wins' => 2, 'draws' => 3, 'losses' => 4],
        ['name' => 'Alireza Firouzja', 'rating' => 2730, 'points' => 3.0, 'wins' => 1, 'draws' => 4, 'losses' => 4]
    ];
}
?>