<?php
/**
 * Chess Heaven - Logout Page with Confirmation
 * Shows a logout confirmation before redirecting
 */

// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once 'config.php';

// Get site settings
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');

// Check if user is logged in
$isLoggedIn = isset($_SESSION['user_id']);
$username = $_SESSION['username'] ?? 'User';
$displayName = $_SESSION['display_name'] ?? $username;

// Handle logout action
$logoutSuccess = false;
if (isset($_GET['confirm']) && $_GET['confirm'] === 'yes') {
    // Clear remember me cookie
    if (isset($_COOKIE['remember_token'])) {
        setcookie('remember_token', '', time() - 3600, '/');
    }
    
    // Clear chess heaven username cookie
    if (isset($_COOKIE['chessheaven_username'])) {
        setcookie('chessheaven_username', '', time() - 3600, '/');
    }
    
    // Clear all session variables
    $_SESSION = array();
    
    // Delete session cookie
    if (ini_get("session.use_cookies")) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            time() - 42000,
            $params["path"],
            $params["domain"],
            $params["secure"],
            $params["httponly"]
        );
    }
    
    // Destroy the session
    session_destroy();
    
    $logoutSuccess = true;
    
    // Redirect after 3 seconds
    header('Refresh: 3; url=login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Logout</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
            --border-color: rgba(139,26,26,0.25);
            --card-bg: rgba(255,255,255,0.03);
        }

        body {
            min-height: 100vh;
            background: radial-gradient(circle at 30% 20%, #3a1a1a, #0a0505);
            color: #f0e0d0;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 2rem;
        }

        .logout-container {
            max-width: 480px;
            width: 100%;
            background: rgba(10, 5, 5, 0.8);
            backdrop-filter: blur(16px);
            -webkit-backdrop-filter: blur(16px);
            border-radius: 2rem;
            padding: 2.5rem;
            border: 1px solid rgba(201, 168, 124, 0.12);
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.6);
            text-align: center;
            animation: fadeInUp 0.6s ease-out;
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        .logout-icon {
            font-size: 4rem;
            color: var(--danger);
            background: rgba(231, 76, 60, 0.15);
            width: 100px;
            height: 100px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem auto;
            border: 2px solid rgba(231, 76, 60, 0.2);
        }

        .logout-container h1 {
            font-size: 2rem;
            font-weight: 700;
            color: #f0d6b0;
            margin-bottom: 0.5rem;
        }

        .logout-container p {
            color: #a09080;
            font-size: 1rem;
            margin-bottom: 0.3rem;
        }

        .logout-container .username-display {
            color: var(--secondary);
            font-weight: 600;
            font-size: 1.1rem;
        }

        .logout-container .sub-message {
            color: #5a4a3a;
            font-size: 0.85rem;
            margin-top: 0.5rem;
        }

        .logout-buttons {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
            justify-content: center;
        }

        .btn {
            padding: 0.8rem 2rem;
            border-radius: 2rem;
            border: none;
            font-weight: 600;
            font-size: 1rem;
            transition: all 0.3s ease;
            cursor: pointer;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .btn-danger {
            background: linear-gradient(145deg, var(--danger), #c0392b);
            color: white;
            box-shadow: 0 4px 15px rgba(231, 76, 60, 0.3);
        }

        .btn-danger:hover {
            transform: translateY(-3px);
            box-shadow: 0 8px 25px rgba(231, 76, 60, 0.5);
        }

        .btn-secondary {
            border: 1px solid var(--border-color);
            background: rgba(255, 255, 255, 0.05);
            color: #d4c0b0;
        }

        .btn-secondary:hover {
            border-color: var(--secondary);
            color: #f0d6b0;
            background: rgba(255, 255, 255, 0.08);
            transform: translateY(-3px);
        }

        .btn-success {
            background: linear-gradient(145deg, var(--success), #27ae60);
            color: white;
            box-shadow: 0 4px 15px rgba(46, 204, 113, 0.3);
            cursor: default;
        }

        .spinner {
            display: inline-block;
            animation: spin 1s linear infinite;
            margin-right: 0.5rem;
        }

        .success-message {
            padding: 1.5rem;
            background: rgba(46, 204, 113, 0.1);
            border: 1px solid rgba(46, 204, 113, 0.2);
            border-radius: 1rem;
            color: var(--success);
            margin-bottom: 1rem;
        }

        .success-message i {
            font-size: 3rem;
            display: block;
            margin-bottom: 0.5rem;
        }

        .success-message h2 {
            color: var(--success);
            font-size: 1.3rem;
        }

        .success-message p {
            color: #a09080;
            font-size: 0.9rem;
            margin-top: 0.3rem;
        }

        .redirect-timer {
            color: #5a4a3a;
            font-size: 0.85rem;
            margin-top: 1rem;
        }

        .redirect-timer strong {
            color: var(--secondary);
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width: 480px) {
            .logout-container {
                padding: 1.5rem;
            }

            .logout-icon {
                width: 80px;
                height: 80px;
                font-size: 3rem;
            }

            .logout-container h1 {
                font-size: 1.5rem;
            }

            .logout-buttons {
                flex-direction: column;
            }

            .btn {
                justify-content: center;
            }
        }
    </style>
</head>
<body>
    <div class="logout-container">
        <?php if ($logoutSuccess): ?>
            <!-- Logout Success -->
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <h2>Logged Out Successfully</h2>
                <p>You have been securely logged out of your account.</p>
            </div>
            <p style="color:#a09080;">
                <i class="fas fa-spinner spinner"></i> Redirecting to login page...
            </p>
            <div class="redirect-timer">
                You will be redirected in <strong id="timer">3</strong> seconds.
            </div>
            <div style="margin-top:1.5rem;">
                <a href="login.php" class="btn btn-secondary">
                    <i class="fas fa-sign-in-alt"></i> Go to Login Now
                </a>
            </div>

            <script>
                let seconds = 3;
                const timerElement = document.getElementById('timer');
                const interval = setInterval(() => {
                    seconds--;
                    if (timerElement) {
                        timerElement.textContent = seconds;
                    }
                    if (seconds <= 0) {
                        clearInterval(interval);
                        window.location.href = 'login.php';
                    }
                }, 1000);
            </script>

        <?php elseif ($isLoggedIn): ?>
            <!-- Logout Confirmation -->
            <div class="logout-icon">
                <i class="fas fa-sign-out-alt"></i>
            </div>
            <h1>Logout</h1>
            <p>Are you sure you want to logout?</p>
            <div class="username-display">
                <i class="fas fa-user"></i> <?php echo e($displayName); ?>
            </div>
            <p class="sub-message">
                <i class="fas fa-info-circle"></i> You will need to login again to access your account.
            </p>

            <div class="logout-buttons">
                <a href="?confirm=yes" class="btn btn-danger">
                    <i class="fas fa-sign-out-alt"></i> Yes, Logout
                </a>
                <a href="userdashboard.php" class="btn btn-secondary">
                    <i class="fas fa-arrow-left"></i> Cancel
                </a>
            </div>

        <?php else: ?>
            <!-- Not Logged In -->
            <div class="logout-icon" style="border-color: rgba(201,168,124,0.2);">
                <i class="fas fa-exclamation-circle" style="color: var(--warning);"></i>
            </div>
            <h1>Already Logged Out</h1>
            <p>You are not currently logged in.</p>
            <p class="sub-message">No action needed. You can safely return to the homepage.</p>

            <div class="logout-buttons">
                <a href="index.php" class="btn btn-secondary">
                    <i class="fas fa-home"></i> Return Home
                </a>
                <a href="login.php" class="btn btn-danger">
                    <i class="fas fa-sign-in-alt"></i> Login
                </a>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>