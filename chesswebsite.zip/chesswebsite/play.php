<?php
/**
 * Chess Heaven - Play Page
 * Complete gameplay hub with guest play, computer opponent, and game history
 * Full chess board implementation - no login required
 */

require_once 'config.php';

// Get site data
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']); // Fixed: added missing closing parenthesis

// Get game statistics and history
$gameStats = getGameStats();
$recentGames = getRecentGames(10);
$topPlayers = getLeaderboard(5);
$openings = getPopularOpenings(6);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Play Chess</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --light-square: #f0d9b5;
            --dark-square: #b58863;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:1.5rem; }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }

        /* ===== CHESS BOARD ===== */
        .game-board-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.12),rgba(10,5,5,0.5));
            border-radius:2rem; padding:2rem; border:1px solid var(--border-color);
        }
        .game-container {
            display:grid; grid-template-columns:1fr 1.5fr; gap:2rem;
            align-items:start;
        }
        .board-wrapper {
            background:rgba(0,0,0,0.4); border-radius:1.5rem; padding:1.5rem;
            border:2px solid var(--border-color);
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:center;
            position:relative;
        }
        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:550px;
            aspect-ratio:1;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
            transition:transform 0.3s ease;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.8rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
            position:relative;
        }
        .chess-board .square.light { background:var(--light-square); }
        .chess-board .square.dark { background:var(--dark-square); }
        .chess-board .square.selected {
            background:rgba(255,255,0,0.4) !important;
            box-shadow:inset 0 0 20px rgba(255,255,0,0.3);
        }
        .chess-board .square.legal-move::after {
            content:'';
            position:absolute;
            width:30%;
            height:30%;
            background:rgba(0,0,0,0.2);
            border-radius:50%;
            pointer-events:none;
        }
        .chess-board .square.legal-capture {
            box-shadow:inset 0 0 0 4px rgba(0,0,0,0.3);
            border-radius:50%;
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
            pointer-events:none;
            z-index:1;
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }
        .chess-board .square.last-move {
            background:rgba(255,255,100,0.3) !important;
        }
        .chess-board .square.in-check {
            background:rgba(255,0,0,0.3) !important;
        }
        .chess-board .square .coords {
            position:absolute;
            font-size:0.55rem;
            color:rgba(0,0,0,0.3);
            pointer-events:none;
            font-weight:600;
        }
        .chess-board .square .coords.file { bottom:2px; right:4px; }
        .chess-board .square .coords.rank { top:2px; left:4px; }
        .chess-board .square.dark .coords { color:rgba(255,255,255,0.3); }

        .game-status {
            margin-top:0.8rem;
            padding:0.5rem 1rem;
            background:rgba(0,0,0,0.3);
            border-radius:2rem;
            color:#d4c0b0;
            font-size:0.85rem;
            width:100%;
            text-align:center;
        }
        .game-controls {
            display:flex;
            gap:0.6rem;
            flex-wrap:wrap;
            justify-content:center;
            margin-top:0.8rem;
            width:100%;
        }
        .game-controls button {
            padding:0.5rem 1rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.75rem;
            display:inline-flex;
            align-items:center;
            gap:0.4rem;
        }
        .btn-play {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .btn-play:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .btn-restart {
            background:rgba(198,151,107,0.15);
            color:var(--secondary);
            border:1px solid var(--secondary) !important;
        }
        .btn-restart:hover { background:rgba(198,151,107,0.25); }
        .btn-undo {
            background:rgba(255,255,255,0.05);
            color:#a09080;
            border:1px solid rgba(255,255,255,0.1) !important;
        }
        .btn-undo:hover { background:rgba(255,255,255,0.1); }
        .btn-flip {
            background:rgba(46,204,113,0.15);
            color:#2ecc71;
            border:1px solid #2ecc71 !important;
        }
        .btn-flip:hover { background:rgba(46,204,113,0.25); }
        .btn-ai {
            background:rgba(52,152,219,0.15);
            color:#3498db;
            border:1px solid #3498db !important;
        }
        .btn-ai:hover { background:rgba(52,152,219,0.25); }

        /* ===== SIDEBAR ===== */
        .game-sidebar {
            display:flex;
            flex-direction:column;
            gap:1.5rem;
        }
        .game-info-panel {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1.2rem;
            padding:1.5rem;
        }
        .game-info-panel h3 {
            color:#f0d6b0;
            font-size:1rem;
            margin-bottom:0.8rem;
            display:flex;
            align-items:center;
            gap:0.5rem;
        }
        .game-info-panel h3 i { color:var(--secondary); }
        .game-info-panel .info-row {
            display:flex;
            justify-content:space-between;
            padding:0.4rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
            color:#a09080;
            font-size:0.85rem;
        }
        .game-info-panel .info-row:last-child { border-bottom:none; }
        .game-info-panel .info-row span:last-child { color:#f0d6b0; font-weight:500; }
        .move-history-box {
            max-height:150px;
            overflow-y:auto;
            padding:0.5rem;
            background:rgba(0,0,0,0.2);
            border-radius:0.5rem;
            font-size:0.8rem;
            color:#a09080;
            font-family:monospace;
        }
        .move-history-box .move-row {
            display:flex;
            gap:0.5rem;
            padding:0.1rem 0;
            border-bottom:1px solid rgba(255,255,255,0.03);
        }
        .move-history-box .move-row .move-number { color:#5a4a3a; min-width:25px; }
        .move-history-box .move-row .move-white { color:#f0d6b0; }
        .move-history-box .move-row .move-black { color:#a09080; }

        /* ===== DIFFICULTY ===== */
        .difficulty-selector {
            display:flex;
            gap:0.6rem;
            justify-content:center;
            flex-wrap:wrap;
            margin:0.5rem 0;
        }
        .difficulty-btn {
            padding:0.4rem 1.2rem;
            border-radius:2rem;
            border:2px solid var(--border-color);
            background:transparent;
            color:#a09080;
            font-weight:600;
            cursor:pointer;
            transition:all 0.3s;
            font-size:0.8rem;
        }
        .difficulty-btn:hover,
        .difficulty-btn.active {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }
        .difficulty-btn .icon { margin-right:0.3rem; }

        /* ===== LEADERBOARD ===== */
        .leaderboard-table {
            background:var(--card-bg); border-radius:1.5rem;
            padding:1.5rem; border:1px solid var(--border-color);
            overflow-x:auto;
        }
        .leaderboard-table table { width:100%; border-collapse:collapse; }
        .leaderboard-table th {
            color:#7a6a5a; border-bottom:1px solid var(--border-color);
            padding:0.8rem; text-align:left;
        }
        .leaderboard-table td { padding:0.8rem; border-bottom:1px solid rgba(255,255,255,0.03); }
        .leaderboard-table tr:last-child td { border-bottom:none; }
        .rank-gold { color:var(--gold); font-weight:700; }
        .rank-silver { color:#c0c0c0; font-weight:700; }
        .rank-bronze { color:#cd7f32; font-weight:700; }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .game-container { grid-template-columns:1fr; }
            .board-wrapper { max-width:600px; margin:0 auto; }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .section { padding:2rem 1rem; }
            .game-board-section { padding:1rem; }
            .board-wrapper { padding:0.8rem; }
            .chess-board .square .piece { font-size:2rem; }
            .chess-board { max-width:100%; }
            .game-controls button { padding:0.3rem 0.7rem; font-size:0.7rem; }
            .difficulty-btn { padding:0.3rem 0.8rem; font-size:0.7rem; }
        }
        @media (max-width:480px) {
            .section-header h2 { font-size:1.3rem; }
            .card-grid { grid-template-columns:1fr; }
            .chess-board .square .piece { font-size:1.5rem; }
            .game-info-panel { padding:1rem; }
        }
        
        /* ===== SCROLLBAR ===== */
        .move-history-box::-webkit-scrollbar { width:4px; }
        .move-history-box::-webkit-scrollbar-track { background:transparent; }
        .move-history-box::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php"><i class="fas fa-home"></i> Home</a>
                <a href="play.php" class="active-link"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== PLAY HERO ===== -->
    <section class="section" style="padding-top:2rem;text-align:center;">
        <h1 style="font-size:2.5rem;color:#f0d6b0;display:flex;align-items:center;justify-content:center;gap:1rem;flex-wrap:wrap;">
            <i class="fas fa-chess" style="color:var(--secondary);"></i>
            Play Chess
            <i class="fas fa-chess" style="color:var(--secondary);"></i>
        </h1>
        <p style="color:#a09080;max-width:600px;margin:0.5rem auto;">
            <i class="fas fa-info-circle"></i> Play against the computer or challenge other players. No account required for guest play.
        </p>
    </section>

    <!-- ===== GAME BOARD ===== -->
    <section class="section" style="padding-top:0;">
        <div class="game-board-section">
            <div class="game-container">
                <!-- Board -->
                <div class="board-wrapper">
                    <div class="chess-board" id="chessBoard"></div>
                    <div class="game-status" id="gameStatus">⚫ Your turn · White to move</div>
                    <div class="game-controls">
                        <button class="btn-play" onclick="startNewGame()"><i class="fas fa-play"></i> New</button>
                        <button class="btn-restart" onclick="restartGame()"><i class="fas fa-redo"></i> Restart</button>
                        <button class="btn-undo" onclick="undoMove()"><i class="fas fa-undo"></i> Undo</button>
                        <button class="btn-flip" onclick="flipBoard()"><i class="fas fa-sync-alt"></i> Flip</button>
                        <button class="btn-ai" onclick="makeAIMove()"><i class="fas fa-robot"></i> AI Move</button>
                    </div>
                </div>

                <!-- Sidebar -->
                <div class="game-sidebar">
                    <div class="game-info-panel">
                        <h3><i class="fas fa-sliders-h"></i> Difficulty</h3>
                        <div class="difficulty-selector">
                            <button class="difficulty-btn active" data-diff="easy" onclick="selectDifficulty(this)"><span class="icon">♟</span> Easy</button>
                            <button class="difficulty-btn" data-diff="medium" onclick="selectDifficulty(this)"><span class="icon">♞</span> Medium</button>
                            <button class="difficulty-btn" data-diff="hard" onclick="selectDifficulty(this)"><span class="icon">♛</span> Hard</button>
                        </div>
                    </div>

                    <div class="game-info-panel">
                        <h3><i class="fas fa-info-circle"></i> Game Info</h3>
                        <div class="info-row"><span>Mode</span><span>Guest · vs Computer</span></div>
                        <div class="info-row"><span>Your Color</span><span id="playerColor">White</span></div>
                        <div class="info-row"><span>Moves</span><span id="moveCount">0</span></div>
                        <div class="info-row"><span>Status</span><span id="gameState">In Progress</span></div>
                        <div class="info-row"><span>Capture</span><span id="captureInfo">-</span></div>
                    </div>

                    <div class="game-info-panel">
                        <h3><i class="fas fa-list"></i> Move History</h3>
                        <div class="move-history-box" id="moveHistoryBox">
                            <div style="color:#5a4a3a;text-align:center;padding:0.5rem;">No moves yet</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== RECENT GAMES ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-clock"></i> Recent Games</h2>
            <a href="history.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($recentGames)): ?>
                <?php foreach ($recentGames as $game): ?>
                    <a href="game-detail.php?id=<?php echo e($game['id']); ?>" class="card">
                        <i class="fas fa-chess-<?php echo $game['result'] === 'win' ? 'king' : ($game['result'] === 'loss' ? 'queen' : 'knight'); ?>"></i>
                        <h3><?php echo e($game['opponent']); ?></h3>
                        <p><?php echo e($game['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($game['date']))); ?></span>
                            <span style="color:<?php echo $game['result'] === 'win' ? '#2ecc71' : ($game['result'] === 'loss' ? '#e74c3c' : '#f1c40f'); ?>;">
                                <?php echo e(ucfirst($game['result'])); ?>
                            </span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="card"><i class="fas fa-chess-king"></i><h3>vs GM Alpha</h3><p>Classical game · 45 moves</p><div class="meta"><span><i class="fas fa-calendar"></i> Dec 20, 2025</span><span style="color:#2ecc71;">Win</span></div></div>
                <div class="card"><i class="fas fa-chess-queen"></i><h3>vs IM Beta</h3><p>Blitz game · 28 moves</p><div class="meta"><span><i class="fas fa-calendar"></i> Dec 18, 2025</span><span style="color:#e74c3c;">Loss</span></div></div>
                <div class="card"><i class="fas fa-chess-knight"></i><h3>vs CM Gamma</h3><p>Rapid game · 62 moves</p><div class="meta"><span><i class="fas fa-calendar"></i> Dec 16, 2025</span><span style="color:#f1c40f;">Draw</span></div></div>
                <div class="card"><i class="fas fa-chess-rook"></i><h3>vs FM Delta</h3><p>Classical game · 33 moves</p><div class="meta"><span><i class="fas fa-calendar"></i> Dec 14, 2025</span><span style="color:#2ecc71;">Win</span></div></div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== POPULAR OPENINGS ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-book-open"></i> Popular Openings</h2>
            <a href="openings.php" class="view-all">Explore All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($openings)): ?>
                <?php foreach ($openings as $opening): ?>
                    <a href="opening.php?id=<?php echo e($opening['id']); ?>" class="card">
                        <i class="fas fa-chess-<?php echo $opening['icon'] ?? 'pawn'; ?>"></i>
                        <h3><?php echo e($opening['name']); ?></h3>
                        <p><?php echo e($opening['moves']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-tag"></i> <?php echo e($opening['category']); ?></span>
                            <span><i class="fas fa-star"></i> <?php echo e($opening['popularity']); ?>%</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="opening-italian.php" class="card"><i class="fas fa-chess-king"></i><h3>Italian Game</h3><p>1.e4 e5 2.Nf3 Nc6 3.Bc4</p><div class="meta"><span><i class="fas fa-tag"></i> Open Game</span><span><i class="fas fa-star"></i> 92%</span></div></a>
                <a href="opening-spanish.php" class="card"><i class="fas fa-chess-queen"></i><h3>Ruy Lopez</h3><p>1.e4 e5 2.Nf3 Nc6 3.Bb5</p><div class="meta"><span><i class="fas fa-tag"></i> Open Game</span><span><i class="fas fa-star"></i> 88%</span></div></a>
                <a href="opening-sicilian.php" class="card"><i class="fas fa-chess-knight"></i><h3>Sicilian Defense</h3><p>1.e4 c5</p><div class="meta"><span><i class="fas fa-tag"></i> Semi-Open</span><span><i class="fas fa-star"></i> 85%</span></div></a>
                <a href="opening-french.php" class="card"><i class="fas fa-chess-pawn"></i><h3>French Defense</h3><p>1.e4 e6</p><div class="meta"><span><i class="fas fa-tag"></i> Semi-Open</span><span><i class="fas fa-star"></i> 78%</span></div></a>
                <a href="opening-caro.php" class="card"><i class="fas fa-chess-rook"></i><h3>Caro-Kann</h3><p>1.e4 c6</p><div class="meta"><span><i class="fas fa-tag"></i> Semi-Open</span><span><i class="fas fa-star"></i> 76%</span></div></a>
                <a href="opening-queens.php" class="card"><i class="fas fa-chess-bishop"></i><h3>Queen's Gambit</h3><p>1.d4 d5 2.c4</p><div class="meta"><span><i class="fas fa-tag"></i> Closed Game</span><span><i class="fas fa-star"></i> 82%</span></div></a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LEADERBOARD ===== -->
    <section class="section">
        <div class="section-header">
            <h2><i class="fas fa-trophy"></i> Top Players</h2>
            <a href="rankings.php" class="view-all">Full Rankings <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="leaderboard-table">
            <table>
                <thead>
                    <tr>
                        <th style="text-align:left;">#</th>
                        <th style="text-align:left;">Player</th>
                        <th style="text-align:center;">Rating</th>
                        <th style="text-align:center;">Wins</th>
                        <th style="text-align:center;">Streak</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($topPlayers)): ?>
                        <?php foreach ($topPlayers as $index => $player): ?>
                            <tr>
                                <td class="<?php echo $index < 3 ? 'rank-' . ['gold','silver','bronze'][$index] : ''; ?>"><?php echo e($index + 1); ?></td>
                                <td style="color:#f0d6b0;"><?php echo e($player['name']); ?></td>
                                <td style="text-align:center;color:var(--secondary);font-weight:600;"><?php echo e($player['rating']); ?></td>
                                <td style="text-align:center;color:#a09080;"><?php echo e($player['wins']); ?></td>
                                <td style="text-align:center;color:#2ecc71;"><?php echo e($player['streak']); ?>🔥</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td class="rank-gold">1</td><td style="color:#f0d6b0;">Magnus Carlsen</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2847</td><td style="text-align:center;color:#a09080;">127</td><td style="text-align:center;color:#2ecc71;">15🔥</td></tr>
                        <tr><td class="rank-silver">2</td><td style="color:#f0d6b0;">Ian Nepomniachtchi</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2795</td><td style="text-align:center;color:#a09080;">98</td><td style="text-align:center;color:#f1c40f;">8🔥</td></tr>
                        <tr><td class="rank-bronze">3</td><td style="color:#f0d6b0;">Hikaru Nakamura</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2788</td><td style="text-align:center;color:#a09080;">112</td><td style="text-align:center;color:#2ecc71;">12🔥</td></tr>
                        <tr><td>4</td><td style="color:#f0d6b0;">Fabiano Caruana</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2772</td><td style="text-align:center;color:#a09080;">94</td><td style="text-align:center;color:#a09080;">5🔥</td></tr>
                        <tr><td>5</td><td style="color:#f0d6b0;">Levon Aronian</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2755</td><td style="text-align:center;color:#a09080;">87</td><td style="text-align:center;color:#a09080;">3🔥</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- ===== TIPS ===== -->
    <section class="section" style="padding:1rem 2rem 3rem;">
        <div style="background:var(--card-bg);border-radius:1.5rem;padding:2rem;border:1px solid var(--border-color);text-align:center;">
            <i class="fas fa-lightbulb" style="font-size:2rem;color:var(--secondary);"></i>
            <h3 style="color:#f0d6b0;margin:0.5rem 0;">Pro Tip</h3>
            <p style="color:#a09080;max-width:600px;margin:0 auto;">
                <i class="fas fa-chess-pawn"></i> Control the center, develop your pieces, and protect your king.
                <br>
                <span style="color:var(--secondary);font-size:0.85rem;">"The opening is a fight for the center."</span>
            </p>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer" style="margin-top:0;padding:3rem 2rem 2rem;border-top:1px solid var(--border-color);display:grid;grid-template-columns:2fr 1fr 1fr 1fr;gap:2rem;max-width:1400px;margin-left:auto;margin-right:auto;">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" style="padding:0.6rem 1rem;border-radius:2rem;border:1px solid var(--border-color);background:rgba(255,255,255,0.05);color:#f0e0d0;width:100%;margin-bottom:0.5rem;" />
            <button onclick="alert('Thank you for subscribing!')" style="padding:0.6rem 1.5rem;border-radius:2rem;border:none;background:linear-gradient(145deg,var(--primary),var(--primary-dark));color:white;font-weight:600;cursor:pointer;width:100%;">Subscribe</button>
        </div>
        <div class="footer-bottom" style="grid-column:1/-1;text-align:center;padding-top:2rem;border-top:1px solid var(--border-color);color:#5a4a3a;font-size:0.85rem;">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== MOBILE MENU =====
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // ===== CHESS ENGINE =====
        // Piece symbols
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // Initial board
        const INITIAL_BOARD = [
            ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
            ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
            ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R']
        ];

        // State
        let board = JSON.parse(JSON.stringify(INITIAL_BOARD));
        let currentTurn = 'white';
        let selectedSquare = null;
        let moveHistory = [];
        let moveCount = 0;
        let isFlipped = false;
        let gameOver = false;
        let difficulty = 'medium';
        let playerColor = 'white';
        let isAIMoving = false;
        let lastMove = null;
        let capturedPieces = [];

        const FILES = 'abcdefgh';

        // ===== RENDER BOARD =====
        function renderBoard() {
            const boardEl = document.getElementById('chessBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isFlipped ? 7 - row : row;
                    const actualCol = isFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    square.dataset.row = actualRow;
                    square.dataset.col = actualCol;
                    
                    // Coordinates
                    if (col === 0) {
                        const rank = document.createElement('span');
                        rank.className = 'coords rank';
                        rank.textContent = 8 - actualRow;
                        square.appendChild(rank);
                    }
                    if (row === 7) {
                        const file = document.createElement('span');
                        file.className = 'coords file';
                        file.textContent = FILES[actualCol];
                        square.appendChild(file);
                    }
                    
                    const piece = board[actualRow][actualCol];
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    // Highlight last move
                    if (lastMove) {
                        if ((actualRow === lastMove.fromRow && actualCol === lastMove.fromCol) ||
                            (actualRow === lastMove.toRow && actualCol === lastMove.toCol)) {
                            square.classList.add('last-move');
                        }
                    }
                    
                    // Highlight selected square
                    if (selectedSquare && selectedSquare.row === actualRow && selectedSquare.col === actualCol) {
                        square.classList.add('selected');
                    }
                    
                    // Show legal moves
                    if (selectedSquare && !gameOver) {
                        const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                        for (const move of legalMoves) {
                            if (move.row === actualRow && move.col === actualCol) {
                                if (board[actualRow][actualCol]) {
                                    square.classList.add('legal-capture');
                                } else {
                                    square.classList.add('legal-move');
                                }
                            }
                        }
                    }
                    
                    // Check for king in check
                    if (piece && (piece === 'K' || piece === 'k') && isInCheck(actualRow, actualCol)) {
                        square.classList.add('in-check');
                    }
                    
                    square.addEventListener('click', () => onSquareClick(actualRow, actualCol));
                    boardEl.appendChild(square);
                }
            }
            
            updateTurnIndicator();
            updateMoveHistory();
        }

        // ===== UPDATE UI =====
        function updateTurnIndicator() {
            const indicator = document.getElementById('gameStatus');
            const state = document.getElementById('gameState');
            if (!indicator) return;
            
            if (gameOver) {
                if (state) state.textContent = 'Game Over';
                return;
            }
            
            if (isAIMoving) {
                indicator.innerHTML = '🤖 Computer is thinking...';
                return;
            }
            
            const colorName = currentTurn === 'white' ? 'White' : 'Black';
            const colorIcon = currentTurn === 'white' ? '⚪' : '⚫';
            const isPlayerTurn = currentTurn === playerColor;
            indicator.innerHTML = `${colorIcon} ${isPlayerTurn ? 'Your turn' : 'Computer thinking'} · ${colorName} to move`;
            if (state) state.textContent = 'In Progress';
        }

        function updateMoveHistory() {
            const box = document.getElementById('moveHistoryBox');
            if (!box) return;
            
            if (moveHistory.length === 0) {
                box.innerHTML = '<div style="color:#5a4a3a;text-align:center;padding:0.5rem;">No moves yet</div>';
                return;
            }
            
            let html = '';
            for (let i = 0; i < moveHistory.length; i += 2) {
                const moveNum = Math.floor(i / 2) + 1;
                const whiteMove = moveHistory[i] ? moveHistory[i].notation : '';
                const blackMove = moveHistory[i + 1] ? moveHistory[i + 1].notation : '';
                html += `<div class="move-row">
                    <span class="move-number">${moveNum}.</span>
                    <span class="move-white">${whiteMove}</span>
                    <span class="move-black">${blackMove}</span>
                </div>`;
            }
            box.innerHTML = html;
            box.scrollTop = box.scrollHeight;
        }

        // ===== MOVE GENERATION =====
        function getLegalMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const direction = isWhite ? -1 : 1;
                    if (row + direction >= 0 && row + direction < 8 && !board[row + direction][col]) {
                        moves.push({row: row + direction, col: col});
                        const startRow = isWhite ? 6 : 1;
                        if (row === startRow && !board[row + 2 * direction][col]) {
                            moves.push({row: row + 2 * direction, col: col});
                        }
                    }
                    for (const dcol of [-1, 1]) {
                        const newCol = col + dcol;
                        if (newCol >= 0 && newCol < 8 && row + direction >= 0 && row + direction < 8) {
                            const target = board[row + direction][newCol];
                            if (target && (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: row + direction, col: newCol});
                            }
                        }
                    }
                    break;
                case 'n':
                    const knightMoves = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
                    for (const [dr, dc] of knightMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
                case 'b':
                case 'r':
                case 'q':
                    const dirs = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                               piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                               [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of dirs) {
                        for (let i = 1; i < 8; i++) {
                            const newRow = row + dr * i, newCol = col + dc * i;
                            if (newRow < 0 || newRow >= 8 || newCol < 0 || newCol >= 8) break;
                            const target = board[newRow][newCol];
                            if (target) {
                                if (isWhite ? target === target.toLowerCase() : target === target.toUpperCase()) {
                                    moves.push({row: newRow, col: newCol});
                                }
                                break;
                            }
                            moves.push({row: newRow, col: newCol});
                        }
                    }
                    break;
                case 'k':
                    const kingMoves = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of kingMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
            }
            
            return moves.filter(move => !wouldBeInCheck(row, col, move.row, move.col));
        }

        function wouldBeInCheck(fromRow, fromCol, toRow, toCol) {
            const piece = board[fromRow][fromCol];
            const isWhite = piece === piece.toUpperCase();
            
            const captured = board[toRow][toCol];
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            let kingRow, kingCol;
            const kingPiece = isWhite ? 'K' : 'k';
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    if (board[r][c] === kingPiece) {
                        kingRow = r; kingCol = c;
                        break;
                    }
                }
                if (kingRow !== undefined) break;
            }
            
            let inCheck = false;
            if (kingRow !== undefined) {
                const opponent = isWhite ? 'black' : 'white';
                for (let r = 0; r < 8; r++) {
                    for (let c = 0; c < 8; c++) {
                        const p = board[r][c];
                        if (p && (opponent === 'white' ? p === p.toUpperCase() : p === p.toLowerCase())) {
                            const attacks = getRawMoves(r, c);
                            for (const attack of attacks) {
                                if (attack.row === kingRow && attack.col === kingCol) {
                                    inCheck = true;
                                    break;
                                }
                            }
                        }
                        if (inCheck) break;
                    }
                    if (inCheck) break;
                }
            }
            
            board[fromRow][fromCol] = piece;
            board[toRow][toCol] = captured;
            
            return inCheck;
        }

        function getRawMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const dir = isWhite ? -1 : 1;
                    if (row + dir >= 0 && row + dir < 8 && !board[row + dir][col]) {
                        moves.push({row: row + dir, col: col});
                    }
                    for (const dc of [-1, 1]) {
                        const nc = col + dc;
                        if (nc >= 0 && nc < 8 && row + dir >= 0 && row + dir < 8) {
                            if (board[row + dir][nc]) moves.push({row: row + dir, col: nc});
                        }
                    }
                    break;
                case 'n':
                    const nm = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
                    for (const [dr, dc] of nm) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
                case 'b':
                case 'r':
                case 'q':
                    const dirs = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                               piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                               [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of dirs) {
                        for (let i = 1; i < 8; i++) {
                            const nr = row + dr * i, nc = col + dc * i;
                            if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
                            moves.push({row: nr, col: nc});
                            if (board[nr][nc]) break;
                        }
                    }
                    break;
                case 'k':
                    const km = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of km) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
            }
            return moves;
        }

        function isInCheck(row, col) {
            const piece = board[row][col];
            if (!piece || (piece !== 'K' && piece !== 'k')) return false;
            const isWhite = piece === 'K';
            const opponent = isWhite ? 'black' : 'white';
            
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const p = board[r][c];
                    if (p && (opponent === 'white' ? p === p.toUpperCase() : p === p.toLowerCase())) {
                        const attacks = getRawMoves(r, c);
                        for (const attack of attacks) {
                            if (attack.row === row && attack.col === col) {
                                return true;
                            }
                        }
                    }
                }
            }
            return false;
        }

        function hasAnyLegalMoves(color) {
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((color === 'white' && isWhite) || (color === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            if (moves.length > 0) return true;
                        }
                    }
                }
            }
            return false;
        }

        // ===== GAME LOGIC =====
        function onSquareClick(row, col) {
            if (gameOver || isAIMoving || currentTurn !== playerColor) return;
            
            const piece = board[row][col];
            const isWhiteTurn = currentTurn === 'white';
            const isWhitePiece = piece && piece === piece.toUpperCase();
            
            if (selectedSquare) {
                const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                const isLegal = legalMoves.some(m => m.row === row && m.col === col);
                
                if (isLegal) {
                    makeMove(selectedSquare.row, selectedSquare.col, row, col);
                    selectedSquare = null;
                    renderBoard();
                    
                    // AI turn
                    if (!gameOver && currentTurn !== playerColor) {
                        setTimeout(() => makeAIMove(), 300);
                    }
                    return;
                }
                
                if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                    selectedSquare = {row, col};
                    renderBoard();
                    return;
                }
                
                selectedSquare = null;
                renderBoard();
                return;
            }
            
            if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                selectedSquare = {row, col};
                renderBoard();
            }
        }

        function makeMove(fromRow, fromCol, toRow, toCol, recordMove = true) {
            const piece = board[fromRow][fromCol];
            const captured = board[toRow][toCol];
            
            // Store move for undo
            if (recordMove) {
                const notation = getMoveNotation(fromRow, fromCol, toRow, toCol, piece, captured);
                moveHistory.push({
                    fromRow, fromCol, toRow, toCol,
                    piece, captured,
                    previousBoard: JSON.parse(JSON.stringify(board)),
                    notation: notation
                });
            }
            
            // Execute move
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            // Track captured pieces
            if (captured) {
                capturedPieces.push(captured);
                document.getElementById('captureInfo').textContent = capturedPieces.map(p => PIECES[p]).join(' ');
            }
            
            // Pawn promotion
            if (piece.toLowerCase() === 'p' && (toRow === 0 || toRow === 7)) {
                board[toRow][toCol] = piece === 'P' ? 'Q' : 'q';
            }
            
            lastMove = { fromRow, fromCol, toRow, toCol };
            moveCount++;
            document.getElementById('moveCount').textContent = moveCount;
            
            // Switch turn
            currentTurn = currentTurn === 'white' ? 'black' : 'white';
            
            // Check game over
            checkGameOver();
        }

        function getMoveNotation(fromRow, fromCol, toRow, toCol, piece, captured) {
            const pieceSymbol = piece.toUpperCase();
            const pieceName = pieceSymbol === 'P' ? '' : pieceSymbol;
            const captureSymbol = captured ? 'x' : '';
            const fromFile = FILES[fromCol];
            const fromRank = 8 - fromRow;
            const toFile = FILES[toCol];
            const toRank = 8 - toRow;
            
            // Check for check or checkmate (simplified)
            let suffix = '';
            if (isInCheck(toRow, toCol)) {
                suffix = '+';
                // Check if it's checkmate (simplified)
                const hasLegal = hasAnyLegalMoves(currentTurn);
                if (!hasLegal) suffix = '#';
            }
            
            return `${pieceName}${captureSymbol}${toFile}${toRank}${suffix}`;
        }

        function checkGameOver() {
            const hasLegal = hasAnyLegalMoves(currentTurn);
            const statusEl = document.getElementById('gameStatus');
            const stateEl = document.getElementById('gameState');
            
            if (!hasLegal) {
                gameOver = true;
                const isWhite = currentTurn === 'white';
                const winner = isWhite ? 'Black' : 'White';
                const isCheck = false; // Simplified
                for (let r = 0; r < 8; r++) {
                    for (let c = 0; c < 8; c++) {
                        const p = board[r][c];
                        if (p && (p === 'K' || p === 'k')) {
                            if (isInCheck(r, c)) {
                                statusEl.innerHTML = `🏆 ${winner} wins! (Checkmate)`;
                                stateEl.textContent = `${winner} Won`;
                                return;
                            }
                        }
                    }
                }
                statusEl.innerHTML = '🤝 Stalemate!';
                stateEl.textContent = 'Draw';
                return;
            }
            
            // Check for insufficient material (simplified)
            let pieces = [];
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    if (board[r][c]) pieces.push(board[r][c]);
                }
            }
            if (pieces.length === 2) {
                gameOver = true;
                statusEl.innerHTML = '🤝 Draw (Insufficient material)';
                stateEl.textContent = 'Draw';
                return;
            }
            
            // Check for threefold repetition (simplified)
            // Not implemented in this version
            
            updateTurnIndicator();
        }

        // ===== AI =====
        function makeAIMove() {
            if (isAIMoving || gameOver) return;
            
            const aiColor = playerColor === 'white' ? 'black' : 'white';
            if (currentTurn !== aiColor) return;
            
            isAIMoving = true;
            document.getElementById('gameStatus').innerHTML = '🤖 Computer is thinking...';
            
            // Get all legal moves for AI
            const allMoves = [];
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((aiColor === 'white' && isWhite) || (aiColor === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            for (const move of moves) {
                                allMoves.push({fromRow: r, fromCol: c, toRow: move.row, toCol: move.col});
                            }
                        }
                    }
                }
            }
            
            if (allMoves.length === 0) {
                isAIMoving = false;
                checkGameOver();
                renderBoard();
                return;
            }
            
            // Score moves
            const scoredMoves = allMoves.map(move => {
                let score = 0;
                const target = board[move.toRow][move.toCol];
                
                // Capture piece value
                if (target) {
                    const pieceValues = {'p': 1, 'n': 3, 'b': 3, 'r': 5, 'q': 9, 'k': 100};
                    const val = pieceValues[target.toLowerCase()] || 0;
                    score += val * 10;
                }
                
                // Center control
                const centerDist = Math.abs(move.toRow - 3.5) + Math.abs(move.toCol - 3.5);
                score += (7 - centerDist) * 2;
                
                // Piece values for moving pieces
                const piece = board[move.fromRow][move.fromCol];
                const pieceValues = {'p': 1, 'n': 3, 'b': 3, 'r': 5, 'q': 9, 'k': 100};
                const val = pieceValues[piece.toLowerCase()] || 0;
                score += val * 0.5;
                
                // Random factor for variety
                if (difficulty === 'easy') score += Math.random() * 10;
                else if (difficulty === 'medium') score += Math.random() * 5;
                else if (difficulty === 'hard') score += Math.random() * 2;
                
                return {move, score};
            });
            
            scoredMoves.sort((a, b) => b.score - a.score);
            
            // Select move based on difficulty
            let selectedMove;
            if (difficulty === 'easy') {
                const topN = Math.min(5, Math.floor(scoredMoves.length * 0.3) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else if (difficulty === 'medium') {
                const topN = Math.min(3, Math.floor(scoredMoves.length * 0.15) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else {
                selectedMove = scoredMoves[0].move;
            }
            
            // Make the move
            setTimeout(() => {
                makeMove(selectedMove.fromRow, selectedMove.fromCol, selectedMove.toRow, selectedMove.toCol);
                isAIMoving = false;
                renderBoard();
                
                // Check if game is over
                if (gameOver) {
                    document.getElementById('gameStatus').innerHTML = '🏆 Game Over!';
                } else {
                    document.getElementById('gameStatus').innerHTML = '⚫ Your turn · ' + (currentTurn === 'white' ? 'White' : 'Black') + ' to move';
                }
            }, 400);
        }

        // ===== GAME CONTROLS =====
        function startNewGame() {
            board = JSON.parse(JSON.stringify(INITIAL_BOARD));
            currentTurn = 'white';
            moveHistory = [];
            moveCount = 0;
            gameOver = false;
            selectedSquare = null;
            isAIMoving = false;
            lastMove = null;
            capturedPieces = [];
            
            document.getElementById('moveCount').textContent = '0';
            document.getElementById('gameState').textContent = 'In Progress';
            document.getElementById('captureInfo').textContent = '-';
            document.getElementById('gameStatus').innerHTML = '⚫ Your turn · White to move';
            document.getElementById('playerColor').textContent = playerColor.charAt(0).toUpperCase() + playerColor.slice(1);
            
            // If player is black, AI goes first
            if (playerColor === 'black') {
                setTimeout(() => makeAIMove(), 500);
            }
            
            renderBoard();
        }

        function restartGame() {
            if (confirm('Restart the current game?')) {
                startNewGame();
            }
        }

        function undoMove() {
            if (moveHistory.length === 0 || isAIMoving) {
                alert('No moves to undo or AI is thinking.');
                return;
            }
            
            // If it's AI's turn and we undo, we need to undo both moves
            const aiColor = playerColor === 'white' ? 'black' : 'white';
            let movesToUndo = 1;
            if (moveHistory.length > 0 && moveHistory[moveHistory.length - 1].previousBoard) {
                // Check if the last move was AI's
                const lastMoveColor = moveHistory.length % 2 === 0 ? playerColor : aiColor;
                if (lastMoveColor !== playerColor) {
                    movesToUndo = 2;
                }
            }
            
            for (let i = 0; i < movesToUndo && moveHistory.length > 0; i++) {
                const last = moveHistory.pop();
                board = last.previousBoard;
                currentTurn = currentTurn === 'white' ? 'black' : 'white';
                moveCount--;
                if (last.captured) {
                    capturedPieces.pop();
                }
            }
            
            lastMove = moveHistory.length > 0 ? {
                fromRow: moveHistory[moveHistory.length - 1].fromRow,
                fromCol: moveHistory[moveHistory.length - 1].fromCol,
                toRow: moveHistory[moveHistory.length - 1].toRow,
                toCol: moveHistory[moveHistory.length - 1].toCol
            } : null;
            
            gameOver = false;
            selectedSquare = null;
            document.getElementById('moveCount').textContent = moveCount;
            document.getElementById('gameState').textContent = 'In Progress';
            document.getElementById('captureInfo').textContent = capturedPieces.map(p => PIECES[p]).join(' ') || '-';
            document.getElementById('gameStatus').innerHTML = '↩ Undo · ' + (currentTurn === 'white' ? 'White' : 'Black') + ' to move';
            
            renderBoard();
        }

        function flipBoard() {
            isFlipped = !isFlipped;
            renderBoard();
        }

        function selectDifficulty(btn) {
            document.querySelectorAll('.difficulty-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            difficulty = btn.dataset.diff;
            document.getElementById('gameStatus').innerHTML = `⚫ Difficulty set to ${btn.textContent.trim()} · New game to apply`;
        }

        // ===== INITIALIZATION =====
        document.addEventListener('DOMContentLoaded', function() {
            // Randomize player color
            playerColor = Math.random() < 0.5 ? 'white' : 'black';
            document.getElementById('playerColor').textContent = playerColor.charAt(0).toUpperCase() + playerColor.slice(1);
            
            startNewGame();
        });
    </script>
</body>
</html>