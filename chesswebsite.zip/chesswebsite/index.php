<?php
/**
 * Chess Heaven - Home Page
 * Public-facing landing page with complete features including anonymous history tracking
 */

require_once 'config.php';

// Track anonymous history viewing
$currentPage = basename($_SERVER['PHP_SELF']);
$viewedItem = '';
$itemType = '';

// Detect what type of content is being viewed
if (isset($_GET['id']) && isset($_GET['type'])) {
    $itemType = $_GET['type'];
    $viewedItem = $_GET['id'];
} elseif (strpos($_SERVER['REQUEST_URI'], 'game.php') !== false) {
    $itemType = 'game';
    $viewedItem = 'Featured Game';
} elseif (strpos($_SERVER['REQUEST_URI'], 'puzzle') !== false) {
    $itemType = 'puzzle';
    $viewedItem = 'Daily Puzzle';
} elseif (strpos($_SERVER['REQUEST_URI'], 'tournament') !== false) {
    $itemType = 'tournament';
    $viewedItem = 'Tournament';
} elseif (strpos($_SERVER['REQUEST_URI'], 'opening') !== false) {
    $itemType = 'opening';
    $viewedItem = 'Opening';
} elseif (strpos($_SERVER['REQUEST_URI'], 'learn') !== false) {
    $itemType = 'lesson';
    $viewedItem = 'Lesson';
} elseif (strpos($_SERVER['REQUEST_URI'], 'news') !== false) {
    $itemType = 'news';
    $viewedItem = 'News Article';
} elseif (strpos($_SERVER['REQUEST_URI'], 'player') !== false) {
    $itemType = 'player';
    $viewedItem = 'Player Profile';
} else {
    $itemType = 'page';
    $viewedItem = 'Homepage';
}

// Track the view
trackHistoryView($currentPage, $itemType, $viewedItem, 0);

// Get all content from database
$site_title = getSetting('site_title', '♚ Chess Heaven');
$site_subtitle = getSetting('site_subtitle', 'NGO · COMMUNITY · EDUCATION');
$tagline = getSetting('tagline', 'Empowering communities through the royal game — free lessons, mentorship & tournaments');
$currentYear = date('Y');
$isLoggedIn = isset($_SESSION['user_id']);

// Get all data
$dailyPuzzle = getDailyPuzzle();
$featuredGames = getFeaturedGames(4);
$chessNews = getChessNews(5);
$liveTournaments = getLiveTournaments(3);
$leaderboard = getLeaderboard(5);
$articles = getArticles(4);
$testimonials = getTestimonials(3);
$playerSpotlights = getPlayerSpotlights(3);
$openingOfDay = getOpeningOfDay();
$chessQuote = getChessQuote();
$faqItems = getFAQItems(6);
$recentComments = getRecentComments(5);
$upcomingEvents = getUpcomingEvents(4);
$features = getFeatures();
$stats = getStats();
$announcements = getAnnouncements(3);

// Get history stats
$historyStats = getHistoryStats();

// Get popular history items
$historyPopularItems = [
    ['title' => 'Immortal Game', 'type' => 'game', 'year' => 1851, 'description' => 'Anderssen vs Kieseritzky', 'icon' => 'chess-king'],
    ['title' => 'Opera Game', 'type' => 'game', 'year' => 1858, 'description' => 'Morphy vs Duke', 'icon' => 'chess-queen'],
    ['title' => 'Game of the Century', 'type' => 'game', 'year' => 1956, 'description' => 'Fischer vs Byrne', 'icon' => 'chess-knight'],
    ['title' => "Kasparov's Immortal", 'type' => 'game', 'year' => 1999, 'description' => 'Kasparov vs Topalov', 'icon' => 'chess-rook'],
    ['title' => "Queen's Gambit", 'type' => 'opening', 'year' => 1850, 'description' => 'Classical Opening', 'icon' => 'chess-pawn'],
    ['title' => 'Sicilian Defense', 'type' => 'opening', 'year' => 1600, 'description' => 'Popular Defense', 'icon' => 'chess-bishop'],
];

// Define navigation sections for floating nav
$navSections = [
    ['id' => 'hero', 'icon' => 'fa-home', 'label' => 'Home'],
    ['id' => 'puzzle', 'icon' => 'fa-puzzle-piece', 'label' => 'Puzzle'],
    ['id' => 'play', 'icon' => 'fa-chess', 'label' => 'Play'],
    ['id' => 'games', 'icon' => 'fa-history', 'label' => 'Games'],
    ['id' => 'learn', 'icon' => 'fa-graduation-cap', 'label' => 'Learn'],
    ['id' => 'openings', 'icon' => 'fa-book', 'label' => 'Openings'],
    ['id' => 'news', 'icon' => 'fa-newspaper', 'label' => 'News'],
    ['id' => 'tournaments', 'icon' => 'fa-trophy', 'label' => 'Tournaments'],
    ['id' => 'players', 'icon' => 'fa-star', 'label' => 'Players'],
    ['id' => 'opening-day', 'icon' => 'fa-chess-king', 'label' => 'Opening'],
    ['id' => 'quote', 'icon' => 'fa-quote-left', 'label' => 'Quote'],
    ['id' => 'leaderboard', 'icon' => 'fa-list-ol', 'label' => 'Rankings'],
    ['id' => 'articles', 'icon' => 'fa-blog', 'label' => 'Blog'],
    ['id' => 'comments', 'icon' => 'fa-comments', 'label' => 'Comments'],
    ['id' => 'history', 'icon' => 'fa-history', 'label' => 'History'],
    ['id' => 'faq', 'icon' => 'fa-question-circle', 'label' => 'FAQ'],
    ['id' => 'contact', 'icon' => 'fa-envelope', 'label' => 'Contact'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Home</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
        }
        body { min-height:100vh; background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505); color:#f0e0d0; padding-top:var(--nav-height); scroll-behavior:smooth; }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
        }
        .navbar-container {
            max-width:1400px; margin:0 auto;
            display:flex; align-items:center; justify-content:space-between; gap:1rem;
        }
        .navbar-logo { display:flex; align-items:center; gap:0.8rem; }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .nav-links { display:flex; flex-wrap:wrap; align-items:center; gap:0.2rem 0.8rem; }
        .nav-links a {
            color:#d4c0b0; font-weight:500; font-size:0.82rem;
            padding:0.4rem 0.6rem; border-radius:0.5rem; transition:0.25s;
            display:inline-flex; align-items:center; gap:0.4rem;
        }
        .nav-links a:hover { color:#f0d6b0; background:rgba(139,26,26,0.2); }
        .nav-links .active-link { color:#f0d6b0; background:rgba(139,26,26,0.15); }
        .auth-buttons { display:flex; gap:0.5rem; }
        .auth-buttons .btn-login {
            padding:0.5rem 1.2rem; border-radius:2rem;
            border:1px solid var(--secondary); background:transparent;
            color:var(--secondary); font-weight:600; font-size:0.8rem;
            transition:all 0.3s;
        }
        .auth-buttons .btn-login:hover { background:rgba(201,168,124,0.1); transform:translateY(-2px); }
        .auth-buttons .btn-signup {
            padding:0.5rem 1.2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; font-size:0.8rem;
            transition:all 0.3s; box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .auth-buttons .btn-signup:hover { transform:translateY(-2px); box-shadow:0 6px 25px rgba(139,26,26,0.5); }
        .menu-toggle { display:none; flex-direction:column; gap:4px; background:transparent; border:none; cursor:pointer; padding:0.5rem; }
        .menu-toggle span { display:block; width:28px; height:2.5px; background:#f0d6b0; border-radius:2px; transition:all 0.3s; }
        .menu-toggle.active span:nth-child(1) { transform:rotate(45deg) translate(5px,5px); }
        .menu-toggle.active span:nth-child(2) { opacity:0; }
        .menu-toggle.active span:nth-child(3) { transform:rotate(-45deg) translate(5px,-5px); }

        /* ===== FLOATING NAVIGATION TOOLBAR ===== */
        .floating-nav {
            position: fixed;
            right: 20px;
            top: 50%;
            transform: translateY(-50%);
            z-index: 9998;
            display: flex;
            flex-direction: column;
            gap: 6px;
            background: rgba(10, 5, 5, 0.85);
            backdrop-filter: blur(12px);
            padding: 10px 8px;
            border-radius: 16px;
            border: 1px solid var(--border-color);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.6);
            transition: all 0.3s ease;
        }
        .floating-nav .nav-dot {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.12);
            border: 2px solid rgba(255, 255, 255, 0.08);
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .floating-nav .nav-dot:hover {
            background: var(--secondary);
            border-color: var(--secondary);
            transform: scale(1.3);
        }
        .floating-nav .nav-dot.active {
            background: var(--secondary);
            border-color: var(--secondary);
            box-shadow: 0 0 20px rgba(198, 151, 107, 0.3);
        }
        .floating-nav .nav-dot .tooltip {
            position: absolute;
            right: calc(100% + 12px);
            top: 50%;
            transform: translateY(-50%);
            background: rgba(10, 5, 5, 0.95);
            backdrop-filter: blur(8px);
            color: #f0d6b0;
            padding: 4px 12px;
            border-radius: 6px;
            font-size: 0.65rem;
            font-weight: 500;
            white-space: nowrap;
            opacity: 0;
            pointer-events: none;
            transition: all 0.3s ease;
            border: 1px solid var(--border-color);
        }
        .floating-nav .nav-dot:hover .tooltip {
            opacity: 1;
            transform: translateY(-50%) translateX(-4px);
        }
        .floating-nav .nav-dot .tooltip i {
            margin-right: 4px;
            color: var(--secondary);
        }
        .floating-nav .nav-divider {
            width: 20px;
            height: 1px;
            background: var(--border-color);
            margin: 2px 0;
        }
        .floating-nav .nav-dot .dot-icon {
            font-size: 0.5rem;
            color: rgba(255,255,255,0.3);
            transition: all 0.3s ease;
        }
        .floating-nav .nav-dot:hover .dot-icon,
        .floating-nav .nav-dot.active .dot-icon {
            color: var(--secondary);
        }
        .floating-nav-toggle {
            display: none;
            position: fixed;
            right: 20px;
            bottom: 80px;
            z-index: 9997;
            background: rgba(139, 26, 26, 0.8);
            backdrop-filter: blur(8px);
            border: 1px solid var(--border-color);
            border-radius: 50%;
            width: 44px;
            height: 44px;
            color: white;
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
        }
        .floating-nav-toggle:hover {
            transform: scale(1.1);
            background: var(--primary);
        }

        /* ===== SECTIONS ===== */
        .section { padding:3rem 2rem; max-width:1400px; margin:0 auto; scroll-margin-top:80px; }
        .section-header {
            display:flex; align-items:center; justify-content:space-between;
            margin-bottom:1.5rem; flex-wrap:wrap; gap:1rem;
        }
        .section-header h2 {
            font-size:1.8rem; color:#f0d6b0;
            display:flex; align-items:center; gap:0.8rem;
        }
        .section-header h2 i { color:var(--secondary); }
        .section-header .view-all {
            color:var(--secondary); font-weight:500;
            transition:0.3s; display:flex; align-items:center; gap:0.5rem;
        }
        .section-header .view-all:hover { color:#f0d6b0; transform:translateX(5px); }

        /* ===== CARDS ===== */
        .card-grid { display:grid; grid-template-columns:repeat(auto-fit,minmax(260px,1fr)); gap:1.5rem; }
        .card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1.2rem; padding:1.5rem; transition:all 0.3s;
            backdrop-filter:blur(4px);
        }
        .card:hover { background:rgba(139,26,26,0.12); border-color:var(--secondary); transform:translateY(-5px); }
        .card i { font-size:2rem; color:var(--secondary); margin-bottom:0.8rem; }
        .card h3 { color:#f0d6b0; font-size:1rem; margin-bottom:0.5rem; }
        .card p { color:#a09080; font-size:0.85rem; line-height:1.6; }
        .card .meta { color:var(--secondary); font-size:0.75rem; margin-top:0.8rem; display:flex; gap:0.8rem; flex-wrap:wrap; }

        /* ===== HERO ===== */
        .hero-section {
            min-height:calc(100vh - var(--nav-height));
            display:flex; align-items:center; justify-content:center;
            padding:2rem; position:relative; text-align:center;
            scroll-margin-top:70px;
        }
        .floating-pieces { position:absolute; width:100%; height:100%; pointer-events:none; overflow:hidden; z-index:1; }
        .floating-piece {
            position:absolute; font-size:2.5rem; opacity:0.07;
            animation:floatPiece 20s infinite linear;
        }
        @keyframes floatPiece {
            0% { transform:translateY(0) rotate(0deg); }
            50% { transform:translateY(-30px) rotate(180deg); }
            100% { transform:translateY(0) rotate(360deg); }
        }
        .hero-content { max-width:1300px; width:100%; position:relative; z-index:2; animation:fadeInUp 1s ease-out; }
        @keyframes fadeInUp { from { opacity:0; transform:translateY(40px); } to { opacity:1; transform:translateY(0); } }
        .logo-badge {
            display:inline-block; font-size:4rem;
            background:linear-gradient(145deg,var(--primary),var(--secondary));
            padding:1.5rem; border-radius:50%; width:120px; height:120px; line-height:120px;
            color:#1a0a0a; box-shadow:0 20px 60px rgba(139,26,26,0.5);
            margin-bottom:1.5rem; animation:pulse 3s ease-in-out infinite;
        }
        @keyframes pulse { 0%,100% { transform:scale(1); } 50% { transform:scale(1.05); } }
        .main-title {
            font-size:3.5rem; font-weight:800;
            background:linear-gradient(135deg,#f0d6b0,#d4a080,#b8734b);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
            margin-bottom:0.5rem;
        }
        .main-subtitle { font-size:1.1rem; color:#d4b09a; font-weight:300; letter-spacing:6px; margin-bottom:0.5rem; }
        .tagline { font-size:1rem; color:#a08070; max-width:600px; margin:1.5rem auto; line-height:1.8; }
        .hero-buttons { display:flex; gap:1rem; justify-content:center; flex-wrap:wrap; margin-top:2rem; }
        .btn-hero-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.9rem 2.5rem; border-radius:3rem; border:none;
            font-weight:700; color:white; display:inline-flex; align-items:center; gap:0.8rem;
            transition:all 0.3s; box-shadow:0 8px 25px rgba(139,26,26,0.6);
        }
        .btn-hero-primary:hover { transform:translateY(-3px) scale(1.02); }
        .btn-hero-secondary {
            background:transparent; border:2px solid var(--secondary);
            padding:0.9rem 2.5rem; border-radius:3rem;
            font-weight:600; color:var(--secondary); display:inline-flex; align-items:center; gap:0.8rem;
            transition:all 0.3s;
        }
        .btn-hero-secondary:hover { background:rgba(201,168,124,0.1); transform:translateY(-3px); }

        /* ===== PUZZLE ===== */
        .puzzle-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.15),rgba(10,5,5,0.6));
            border-radius:2rem; padding:2rem; border:1px solid var(--border-color);
            scroll-margin-top:80px;
        }
        .puzzle-container { display:grid; grid-template-columns:1fr 1fr; gap:2rem; align-items:center; }
        .puzzle-board {
            background:rgba(0,0,0,0.3); border-radius:1rem; padding:1rem;
            aspect-ratio:1; display:flex; align-items:center; justify-content:center;
            font-size:5rem; color:var(--secondary); border:2px solid var(--border-color);
        }
        .puzzle-info h3 { font-size:1.3rem; color:#f0d6b0; margin-bottom:0.5rem; }
        .difficulty {
            display:inline-block; padding:0.2rem 1rem; border-radius:2rem;
            font-size:0.75rem; font-weight:600; margin:0.5rem 0;
        }
        .difficulty.easy { background:rgba(46,204,113,0.2); color:#2ecc71; }
        .difficulty.medium { background:rgba(241,196,15,0.2); color:#f1c40f; }
        .difficulty.hard { background:rgba(231,76,60,0.2); color:#e74c3c; }
        .puzzle-actions { display:flex; gap:0.8rem; flex-wrap:wrap; margin-top:1rem; }
        .puzzle-actions button {
            padding:0.5rem 1.5rem; border-radius:2rem; border:none;
            font-weight:600; cursor:pointer; transition:all 0.3s;
        }
        .btn-hint { background:rgba(198,151,107,0.2); color:var(--secondary); border:1px solid var(--secondary) !important; }
        .btn-hint:hover { background:rgba(198,151,107,0.3); }
        .btn-solution { background:linear-gradient(145deg,var(--primary),var(--primary-dark)); color:white; }
        .btn-solution:hover { transform:translateY(-2px); }

        /* ===== GUEST PLAY ===== */
        .guest-play-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.08),rgba(10,5,5,0.4));
            border-radius:2rem; padding:2rem; border:1px solid var(--border-color);
            scroll-margin-top:80px;
        }
        .difficulty-selector { display:flex; gap:1rem; justify-content:center; flex-wrap:wrap; margin:1.5rem 0; }
        .difficulty-btn {
            padding:0.5rem 1.8rem; border-radius:2rem;
            border:2px solid var(--border-color); background:transparent;
            color:#a09080; font-weight:600; cursor:pointer; transition:all 0.3s;
        }
        .difficulty-btn:hover, .difficulty-btn.active {
            border-color:var(--secondary); color:#f0d6b0;
            background:rgba(198,151,107,0.1);
        }
        .game-controls { display:flex; gap:1rem; justify-content:center; flex-wrap:wrap; margin-top:1.5rem; }
        .game-controls button {
            padding:0.5rem 1.5rem; border-radius:2rem; border:none;
            font-weight:600; cursor:pointer; transition:all 0.3s;
        }
        .btn-play { background:linear-gradient(145deg,var(--primary),var(--primary-dark)); color:white; padding:0.8rem 2.5rem !important; }
        .btn-play:hover { transform:translateY(-2px); }
        .btn-restart { background:rgba(198,151,107,0.15); color:var(--secondary); border:1px solid var(--secondary) !important; }
        .btn-restart:hover { background:rgba(198,151,107,0.25); }
        .btn-undo { background:rgba(255,255,255,0.05); color:#a09080; border:1px solid rgba(255,255,255,0.1) !important; }

        /* ===== LEADERBOARD TABLE ===== */
        .leaderboard-table {
            background:var(--card-bg); border-radius:1.5rem;
            padding:1.5rem; border:1px solid var(--border-color);
            overflow-x:auto;
        }
        .leaderboard-table table { width:100%; border-collapse:collapse; }
        .leaderboard-table th {
            color:#7a6a5a; border-bottom:1px solid var(--border-color);
            padding:0.8rem; text-align:left;
        }
        .leaderboard-table td { padding:0.8rem; border-bottom:1px solid rgba(255,255,255,0.03); }
        .leaderboard-table tr:last-child td { border-bottom:none; }
        .rank-gold { color:var(--gold); font-weight:700; }
        .rank-silver { color:#c0c0c0; font-weight:700; }
        .rank-bronze { color:#cd7f32; font-weight:700; }

        /* ===== FAQ ===== */
        .faq-item {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:1rem; padding:1.2rem; margin-bottom:0.8rem;
            cursor:pointer; transition:all 0.3s;
        }
        .faq-item:hover { border-color:var(--secondary); }
        .faq-item .faq-question {
            display:flex; justify-content:space-between; align-items:center;
            color:#f0d6b0; font-weight:600;
        }
        .faq-item .faq-answer {
            color:#a09080; margin-top:0.8rem; display:none; line-height:1.6;
        }
        .faq-item.active .faq-answer { display:block; }
        .faq-item .faq-toggle { color:var(--secondary); transition:0.3s; }
        .faq-item.active .faq-toggle { transform:rotate(180deg); }

        /* ===== CONTACT ===== */
        .contact-grid { display:grid; grid-template-columns:1fr 1fr; gap:2rem; }
        .contact-form input, .contact-form textarea {
            width:100%; padding:0.8rem 1rem; border-radius:0.8rem;
            border:1px solid var(--border-color); background:rgba(255,255,255,0.05);
            color:#f0e0d0; font-size:0.9rem; margin-bottom:1rem;
        }
        .contact-form input:focus, .contact-form textarea:focus {
            outline:none; border-color:var(--secondary);
            background:rgba(255,255,255,0.08);
        }
        .contact-form textarea { min-height:100px; resize:vertical; }
        .contact-form .btn-submit {
            padding:0.8rem 2rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; cursor:pointer; transition:all 0.3s;
        }
        .contact-form .btn-submit:hover { transform:translateY(-2px); }
        .contact-info { display:flex; flex-direction:column; gap:1.2rem; }
        .contact-info .info-item { display:flex; align-items:center; gap:1rem; color:#d4c0b0; }
        .contact-info .info-item i { font-size:1.2rem; color:var(--secondary); width:30px; text-align:center; }
        .social-links-big { display:flex; gap:1.5rem; margin-top:1rem; }
        .social-links-big a { color:#7a6a5a; font-size:1.5rem; transition:0.3s; }
        .social-links-big a:hover { color:var(--secondary); transform:translateY(-3px); }

        /* ===== HISTORY SECTION ===== */
        .history-section {
            background:linear-gradient(145deg,rgba(139,26,26,0.08),rgba(10,5,5,0.4));
            border-radius:2rem; padding:2rem; border:1px solid var(--border-color);
            scroll-margin-top:80px;
        }
        .history-stats-grid {
            display:grid; grid-template-columns:repeat(auto-fill,minmax(120px,1fr));
            gap:0.8rem; margin-bottom:1.5rem;
        }
        .history-stat-card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:0.8rem; padding:0.8rem; text-align:center;
        }
        .history-stat-card .stat-value {
            font-size:1.5rem; font-weight:700; color:#f0d6b0;
        }
        .history-stat-card .stat-label {
            font-size:0.7rem; color:#7a6a5a;
        }
        .history-items-grid {
            display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr));
            gap:0.8rem;
        }
        .history-item-card {
            background:var(--card-bg); border:1px solid var(--border-color);
            border-radius:0.8rem; padding:0.8rem; text-align:center;
            transition:all 0.3s; cursor:pointer;
        }
        .history-item-card:hover {
            border-color:var(--secondary); transform:translateY(-2px);
        }
        .history-item-card i {
            font-size:1.5rem; color:var(--secondary); margin-bottom:0.3rem;
        }
        .history-item-card h4 {
            color:#f0d6b0; font-size:0.85rem;
        }
        .history-item-card p {
            color:#7a6a5a; font-size:0.7rem;
        }
        .history-item-card .year-badge {
            display:inline-block; padding:0.1rem 0.5rem; border-radius:1rem;
            background:rgba(139,26,26,0.3); font-size:0.65rem; color:var(--secondary);
            margin-top:0.3rem;
        }

        /* ===== FOOTER ===== */
        .footer {
            margin-top:2rem; padding:3rem 2rem 2rem;
            border-top:1px solid var(--border-color);
            display:grid; grid-template-columns:2fr 1fr 1fr 1fr; gap:2rem;
        }
        .footer h4 { color:#f0d6b0; margin-bottom:1rem; }
        .footer a { color:#7a6a5a; display:block; margin-bottom:0.5rem; transition:0.3s; }
        .footer a:hover { color:var(--secondary); }
        .footer .newsletter input {
            padding:0.6rem 1rem; border-radius:2rem;
            border:1px solid var(--border-color); background:rgba(255,255,255,0.05);
            color:#f0e0d0; width:100%; margin-bottom:0.5rem;
        }
        .footer .newsletter button {
            padding:0.6rem 1.5rem; border-radius:2rem; border:none;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white; font-weight:600; cursor:pointer; width:100%;
        }
        .footer .newsletter button:hover { transform:translateY(-2px); }
        .footer-bottom {
            grid-column:1/-1; text-align:center; padding-top:2rem;
            border-top:1px solid var(--border-color);
            color:#5a4a3a; font-size:0.85rem;
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:1024px) {
            .contact-grid { grid-template-columns:1fr; }
            .footer { grid-template-columns:1fr 1fr; }
        }
        @media (max-width:768px) {
            :root { --nav-height:60px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .menu-toggle { display:flex; }
            .nav-links {
                display:none; position:absolute; top:100%; left:0; right:0;
                flex-direction:column; background:rgba(10,5,5,0.98);
                padding:1rem; border-top:1px solid rgba(201,168,124,0.1);
                gap:0.2rem; max-height:80vh; overflow-y:auto;
            }
            .nav-links.open { display:flex; }
            .nav-links a { padding:0.6rem 0.8rem; font-size:0.9rem; border-bottom:1px solid rgba(139,26,26,0.15); }
            .auth-buttons { display:none; }
            .main-title { font-size:2.5rem; }
            .main-subtitle { font-size:0.9rem; letter-spacing:3px; }
            .logo-badge { width:80px; height:80px; font-size:2.5rem; line-height:80px; }
            .puzzle-container { grid-template-columns:1fr; }
            .puzzle-board { font-size:4rem; max-height:250px; }
            .footer { grid-template-columns:1fr; gap:1.5rem; }
            .section { padding:2rem 1rem; }
            .hero-buttons { flex-direction:column; align-items:center; }
            .btn-hero-primary, .btn-hero-secondary { width:100%; max-width:300px; justify-content:center; }
            .difficulty-selector, .game-controls { flex-direction:column; align-items:center; }
            .difficulty-btn, .game-controls button { width:100%; max-width:200px; text-align:center; }
            .contact-grid { grid-template-columns:1fr; }
            .history-stats-grid { grid-template-columns:repeat(2,1fr); }
            .history-items-grid { grid-template-columns:1fr 1fr; }
            
            /* Floating nav - hide on mobile, show toggle button */
            .floating-nav { display: none; }
            .floating-nav.open { display: flex; position: fixed; right: 10px; top: 50%; transform: translateY(-50%); }
            .floating-nav-toggle { display: flex; align-items: center; justify-content: center; }
        }
        @media (max-width:480px) {
            .main-title { font-size:2rem; }
            .section-header h2 { font-size:1.3rem; }
            .card-grid { grid-template-columns:1fr; }
            .history-items-grid { grid-template-columns:1fr; }
            .floating-nav { padding: 8px 6px; }
            .floating-nav .nav-dot { width: 10px; height: 10px; }
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-container">
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
            <button class="menu-toggle" id="menuToggle">
                <span></span><span></span><span></span>
            </button>
            <div class="nav-links" id="navLinks">
                <a href="index.php" class="active-link"><i class="fas fa-home"></i> Home</a>
                <a href="play.php"><i class="fas fa-chess"></i> Play</a>
                <a href="learn.php"><i class="fas fa-graduation-cap"></i> Learn</a>
                <a href="puzzles.php"><i class="fas fa-puzzle-piece"></i> Puzzles</a>
                <a href="news.php"><i class="fas fa-newspaper"></i> News</a>
                <a href="tournaments.php"><i class="fas fa-trophy"></i> Tournaments</a>
                <a href="about.php"><i class="fas fa-info-circle"></i> About</a>
                <a href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
            </div>
            <div class="auth-buttons">
                <a href="login.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Login</a>
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Sign Up</a>
            </div>
        </div>
    </nav>

    <!-- ===== FLOATING NAVIGATION TOOLBAR ===== -->
    <button class="floating-nav-toggle" id="floatingNavToggle" onclick="toggleFloatingNav()">
        <i class="fas fa-compass"></i>
    </button>
    <nav class="floating-nav" id="floatingNav">
        <?php foreach ($navSections as $section): ?>
            <?php if ($section['id'] === 'hero'): ?>
                <a href="#<?php echo $section['id']; ?>" class="nav-dot active" onclick="closeFloatingNav()" data-section="<?php echo $section['id']; ?>">
                    <i class="fas <?php echo $section['icon']; ?> dot-icon"></i>
                    <span class="tooltip"><i class="fas <?php echo $section['icon']; ?>"></i> <?php echo $section['label']; ?></span>
                </a>
            <?php else: ?>
                <a href="#<?php echo $section['id']; ?>" class="nav-dot" onclick="closeFloatingNav()" data-section="<?php echo $section['id']; ?>">
                    <i class="fas <?php echo $section['icon']; ?> dot-icon"></i>
                    <span class="tooltip"><i class="fas <?php echo $section['icon']; ?>"></i> <?php echo $section['label']; ?></span>
                </a>
            <?php endif; ?>
            <?php if ($section['id'] === 'puzzle' || $section['id'] === 'tournaments' || $section['id'] === 'articles'): ?>
                <div class="nav-divider"></div>
            <?php endif; ?>
        <?php endforeach; ?>
    </nav>

    <!-- ===== HERO ===== -->
    <section class="hero-section" id="hero">
        <div class="floating-pieces">
            <span class="floating-piece" style="top:10%;left:5%;font-size:3rem;">♔</span>
            <span class="floating-piece" style="top:20%;right:8%;animation-delay:3s;">♕</span>
            <span class="floating-piece" style="bottom:30%;left:8%;animation-delay:5s;">♗</span>
            <span class="floating-piece" style="bottom:20%;right:5%;animation-delay:2s;">♘</span>
            <span class="floating-piece" style="top:50%;left:3%;animation-delay:7s;">♖</span>
            <span class="floating-piece" style="top:60%;right:3%;animation-delay:4s;">♙</span>
        </div>
        <div class="hero-content">
            <div class="logo-badge"><i class="fas fa-chess-king"></i></div>
            <h1 class="main-title"><?php echo e($site_title); ?></h1>
            <p class="main-subtitle"><?php echo e($site_subtitle); ?></p>
            <p class="tagline"><i class="fas fa-chess-pawn"></i> <?php echo e($tagline); ?> <i class="fas fa-chess-pawn"></i></p>
            <div class="hero-buttons">
                <a href="play.php" class="btn-hero-primary"><i class="fas fa-chess"></i> Play Now</a>
                <a href="puzzles.php" class="btn-hero-secondary"><i class="fas fa-puzzle-piece"></i> Solve Today's Puzzle</a>
            </div>
        </div>
    </section>

    <!-- ===== DAILY PUZZLE ===== -->
    <section class="section" id="puzzle">
        <div class="puzzle-section">
            <div class="section-header">
                <h2><i class="fas fa-puzzle-piece"></i> Daily Chess Puzzle</h2>
                <a href="puzzles.php" class="view-all">More Puzzles <i class="fas fa-arrow-right"></i></a>
            </div>
            <div class="puzzle-container">
                <div class="puzzle-board"><?php echo e($dailyPuzzle['board'] ?? '♔♕♗♘♖♙'); ?></div>
                <div class="puzzle-info">
                    <h3><?php echo e($dailyPuzzle['title'] ?? 'Mate in 2'); ?></h3>
                    <span class="difficulty <?php echo e($dailyPuzzle['difficulty'] ?? 'medium'); ?>">
                        <?php echo e(ucfirst($dailyPuzzle['difficulty'] ?? 'Medium')); ?>
                    </span>
                    <p style="color:#a09080;margin:0.5rem 0;"><?php echo e($dailyPuzzle['description'] ?? 'Find the winning move. White to play.'); ?></p>
                    <div class="puzzle-actions">
                        <button class="btn-hint" onclick="trackHistoryInteraction('hint', 'puzzle', 0, 'Daily Puzzle', 'Hint requested')"><i class="fas fa-lightbulb"></i> Hint</button>
                        <button class="btn-solution" onclick="trackHistoryInteraction('solution', 'puzzle', 0, 'Daily Puzzle', 'Solution viewed')"><i class="fas fa-eye"></i> Solution</button>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== PLAY AS GUEST ===== -->
    <section class="section" id="play">
        <div class="guest-play-section">
            <div class="section-header">
                <h2><i class="fas fa-user"></i> Play as Guest</h2>
                <a href="play.php" class="view-all">Full Game <i class="fas fa-arrow-right"></i></a>
            </div>
            <p style="text-align:center;color:#a09080;margin-bottom:1rem;">
                <i class="fas fa-info-circle"></i> Play against the computer instantly. No account required.
            </p>
            <div class="difficulty-selector">
                <button class="difficulty-btn active" onclick="selectDifficulty(this)">♟ Easy</button>
                <button class="difficulty-btn" onclick="selectDifficulty(this)">♞ Medium</button>
                <button class="difficulty-btn" onclick="selectDifficulty(this)">♛ Hard</button>
            </div>
            <div style="text-align:center;min-height:150px;background:rgba(0,0,0,0.2);border-radius:1rem;display:flex;align-items:center;justify-content:center;flex-direction:column;padding:2rem;border:2px dashed var(--border-color);">
                <i class="fas fa-chess-board" style="font-size:3rem;color:var(--secondary);opacity:0.3;"></i>
                <p style="color:#7a6a5a;margin-top:0.5rem;">Game Board</p>
            </div>
            <div class="game-controls">
                <button class="btn-play" onclick="trackHistoryInteraction('play', 'game', 0, 'Guest Game', 'Started new game')"><i class="fas fa-play"></i> New Game</button>
                <button class="btn-restart" onclick="trackHistoryInteraction('restart', 'game', 0, 'Guest Game', 'Restarted game')"><i class="fas fa-redo"></i> Restart</button>
                <button class="btn-undo" onclick="trackHistoryInteraction('undo', 'game', 0, 'Guest Game', 'Undo move')"><i class="fas fa-undo"></i> Undo</button>
            </div>
        </div>
    </section>

    <!-- ===== FEATURED GAMES ===== -->
    <section class="section" id="games">
        <div class="section-header">
            <h2><i class="fas fa-history"></i> Featured Games</h2>
            <a href="games.php" class="view-all">View All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($featuredGames)): ?>
                <?php foreach ($featuredGames as $game): ?>
                    <a href="game.php?id=<?php echo e($game['id']); ?>" class="card" onclick="trackHistoryInteraction('view', 'game', <?php echo e($game['id']); ?>, '<?php echo e($game['title']); ?>', 'Featured game viewed')">
                        <i class="fas fa-chess-knight"></i>
                        <h3><?php echo e($game['title']); ?></h3>
                        <p><?php echo e($game['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-user"></i> <?php echo e($game['players']); ?></span>
                            <span><i class="fas fa-calendar"></i> <?php echo e($game['year']); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="game.php?id=1" class="card" onclick="trackHistoryInteraction('view', 'game', 1, 'Immortal Game', 'Featured game viewed')">
                    <i class="fas fa-chess-king"></i>
                    <h3>Immortal Game</h3>
                    <p>Anderssen vs Kieseritzky (1851)</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Anderssen vs Kieseritzky</span><span><i class="fas fa-calendar"></i> 1851</span></div>
                </a>
                <a href="game.php?id=2" class="card" onclick="trackHistoryInteraction('view', 'game', 2, 'Opera Game', 'Featured game viewed')">
                    <i class="fas fa-chess-queen"></i>
                    <h3>Opera Game</h3>
                    <p>Morphy vs Duke (1858)</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Morphy vs Duke</span><span><i class="fas fa-calendar"></i> 1858</span></div>
                </a>
                <a href="game.php?id=3" class="card" onclick="trackHistoryInteraction('view', 'game', 3, 'Game of the Century', 'Featured game viewed')">
                    <i class="fas fa-chess-rook"></i>
                    <h3>Game of the Century</h3>
                    <p>Fischer vs Byrne (1956)</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Fischer vs Byrne</span><span><i class="fas fa-calendar"></i> 1956</span></div>
                </a>
                <a href="game.php?id=4" class="card" onclick="trackHistoryInteraction('view', 'game', 4, 'Kasparov\'s Immortal', 'Featured game viewed')">
                    <i class="fas fa-chess-knight"></i>
                    <h3>Kasparov's Immortal</h3>
                    <p>Kasparov vs Topalov (1999)</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Kasparov vs Topalov</span><span><i class="fas fa-calendar"></i> 1999</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LEARN CHESS ===== -->
    <section class="section" id="learn">
        <div class="section-header">
            <h2><i class="fas fa-graduation-cap"></i> Learn Chess</h2>
            <a href="learn.php" class="view-all">All Lessons <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <a href="learn-rules.php" class="card" onclick="trackHistoryInteraction('view', 'lesson', 0, 'Chess Rules', 'Lesson viewed')">
                <i class="fas fa-book-open"></i>
                <h3>Chess Rules</h3>
                <p>Learn the basic rules of chess.</p>
            </a>
            <a href="learn-beginners.php" class="card" onclick="trackHistoryInteraction('view', 'lesson', 0, 'Beginner Lessons', 'Lesson viewed')">
                <i class="fas fa-child"></i>
                <h3>Beginner Lessons</h3>
                <p>Start your chess journey here.</p>
            </a>
            <a href="learn-openings.php" class="card" onclick="trackHistoryInteraction('view', 'lesson', 0, 'Opening Principles', 'Lesson viewed')">
                <i class="fas fa-chess-king"></i>
                <h3>Opening Principles</h3>
                <p>Master opening fundamentals.</p>
            </a>
            <a href="learn-middlegame.php" class="card" onclick="trackHistoryInteraction('view', 'lesson', 0, 'Middlegame Strategies', 'Lesson viewed')">
                <i class="fas fa-chess-queen"></i>
                <h3>Middlegame Strategies</h3>
                <p>Develop winning strategies.</p>
            </a>
            <a href="learn-endgame.php" class="card" onclick="trackHistoryInteraction('view', 'lesson', 0, 'Endgame Techniques', 'Lesson viewed')">
                <i class="fas fa-chess-rook"></i>
                <h3>Endgame Techniques</h3>
                <p>Essential endgame skills.</p>
            </a>
            <a href="learn-videos.php" class="card" onclick="trackHistoryInteraction('view', 'lesson', 0, 'Video Tutorials', 'Lesson viewed')">
                <i class="fas fa-video"></i>
                <h3>Video Tutorials</h3>
                <p>Watch professional tutorials.</p>
            </a>
        </div>
    </section>

    <!-- ===== OPENING EXPLORER ===== -->
    <section class="section" id="openings">
        <div class="section-header">
            <h2><i class="fas fa-book"></i> Opening Explorer</h2>
            <a href="openings.php" class="view-all">Explore All <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <a href="opening-italian.php" class="card" onclick="trackHistoryInteraction('view', 'opening', 0, 'Italian Game', 'Opening viewed')">
                <i class="fas fa-chess-king"></i>
                <h3>Italian Game</h3>
                <p>1.e4 e5 2.Nf3 Nc6 3.Bc4</p>
                <div class="meta">♟ Popular · Strategic</div>
            </a>
            <a href="opening-spanish.php" class="card" onclick="trackHistoryInteraction('view', 'opening', 0, 'Spanish Opening', 'Opening viewed')">
                <i class="fas fa-chess-queen"></i>
                <h3>Spanish Opening</h3>
                <p>1.e4 e5 2.Nf3 Nc6 3.Bb5</p>
                <div class="meta">♟ Classical · Positional</div>
            </a>
            <a href="opening-sicilian.php" class="card" onclick="trackHistoryInteraction('view', 'opening', 0, 'Sicilian Defense', 'Opening viewed')">
                <i class="fas fa-chess-knight"></i>
                <h3>Sicilian Defense</h3>
                <p>1.e4 c5</p>
                <div class="meta">♟ Sharp · Tactical</div>
            </a>
            <a href="opening-french.php" class="card" onclick="trackHistoryInteraction('view', 'opening', 0, 'French Defense', 'Opening viewed')">
                <i class="fas fa-chess-pawn"></i>
                <h3>French Defense</h3>
                <p>1.e4 e6</p>
                <div class="meta">♟ Solid · Defensive</div>
            </a>
        </div>
    </section>

    <!-- ===== CHESS NEWS ===== -->
    <section class="section" id="news">
        <div class="section-header">
            <h2><i class="fas fa-newspaper"></i> Chess News</h2>
            <a href="news.php" class="view-all">All News <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($chessNews)): ?>
                <?php foreach ($chessNews as $news): ?>
                    <a href="news-detail.php?id=<?php echo e($news['id']); ?>" class="card" onclick="trackHistoryInteraction('view', 'news', <?php echo e($news['id']); ?>, '<?php echo e($news['title']); ?>', 'News article viewed')">
                        <i class="fas fa-newspaper"></i>
                        <h3><?php echo e($news['title']); ?></h3>
                        <p><?php echo e($news['excerpt']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($news['date']))); ?></span>
                            <span><i class="fas fa-tag"></i> <?php echo e($news['category']); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="news-detail.php?id=1" class="card" onclick="trackHistoryInteraction('view', 'news', 1, 'World Chess Championship 2025', 'News viewed')">
                    <i class="fas fa-trophy"></i>
                    <h3>World Chess Championship 2025</h3>
                    <p>Carlsen vs Nepomniachtchi</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Nov 25, 2025</span><span><i class="fas fa-tag"></i> Tournament</span></div>
                </a>
                <a href="news-detail.php?id=2" class="card" onclick="trackHistoryInteraction('view', 'news', 2, 'New Grandmaster Title', 'News viewed')">
                    <i class="fas fa-medal"></i>
                    <h3>New Grandmaster Title</h3>
                    <p>18-year-old earns GM title</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Oct 15, 2025</span><span><i class="fas fa-tag"></i> Achievement</span></div>
                </a>
                <a href="news-detail.php?id=3" class="card" onclick="trackHistoryInteraction('view', 'news', 3, 'New Chess Variant Released', 'News viewed')">
                    <i class="fas fa-chess"></i>
                    <h3>New Chess Variant Released</h3>
                    <p>Chess960 gets a new twist</p>
                    <div class="meta"><span><i class="fas fa-calendar"></i> Sep 28, 2025</span><span><i class="fas fa-tag"></i> Variants</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== LIVE TOURNAMENTS ===== -->
    <section class="section" id="tournaments">
        <div class="section-header">
            <h2><i class="fas fa-trophy"></i> Live Tournaments</h2>
            <a href="tournaments.php" class="view-all">All Tournaments <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($liveTournaments)): ?>
                <?php foreach ($liveTournaments as $tournament): ?>
                    <a href="tournament.php?id=<?php echo e($tournament['id']); ?>" class="card" style="border-color:var(--gold);" onclick="trackHistoryInteraction('view', 'tournament', <?php echo e($tournament['id']); ?>, '<?php echo e($tournament['name']); ?>', 'Tournament viewed')">
                        <i class="fas fa-broadcast-tower"></i>
                        <h3><?php echo e($tournament['name']); ?> <?php if($tournament['status'] === 'live'): ?><span style="color:#2ecc71;font-size:0.7rem;">LIVE</span><?php endif; ?></h3>
                        <p><?php echo e($tournament['description']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-map-marker-alt"></i> <?php echo e($tournament['location']); ?></span>
                            <span><i class="fas fa-users"></i> <?php echo e($tournament['players']); ?> players</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="tournament.php?id=1" class="card" style="border-color:var(--gold);" onclick="trackHistoryInteraction('view', 'tournament', 1, 'World Chess Championship', 'Tournament viewed')">
                    <i class="fas fa-broadcast-tower"></i>
                    <h3>World Chess Championship <span style="color:#2ecc71;font-size:0.7rem;">LIVE</span></h3>
                    <p>Watch the world's best players compete.</p>
                    <div class="meta"><span><i class="fas fa-map-marker-alt"></i> Dubai</span><span><i class="fas fa-users"></i> 64 players</span></div>
                </a>
                <a href="tournament.php?id=2" class="card" onclick="trackHistoryInteraction('view', 'tournament', 2, 'Grand Chess Tour 2026', 'Tournament viewed')">
                    <i class="fas fa-clock"></i>
                    <h3>Grand Chess Tour 2026</h3>
                    <p>Elite tournament featuring top 10 players.</p>
                    <div class="meta"><span><i class="fas fa-map-marker-alt"></i> Paris</span><span><i class="fas fa-users"></i> 32 players</span></div>
                </a>
                <a href="tournament.php?id=3" class="card" onclick="trackHistoryInteraction('view', 'tournament', 3, 'Chess Heaven Open', 'Tournament viewed')">
                    <i class="fas fa-calendar"></i>
                    <h3>Chess Heaven Open</h3>
                    <p>Annual charity tournament.</p>
                    <div class="meta"><span><i class="fas fa-map-marker-alt"></i> Online</span><span><i class="fas fa-users"></i> 200+ players</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== PLAYER SPOTLIGHT ===== -->
    <section class="section" id="players">
        <div class="section-header">
            <h2><i class="fas fa-star"></i> Player Spotlight</h2>
            <a href="players.php" class="view-all">All Players <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($playerSpotlights)): ?>
                <?php foreach ($playerSpotlights as $player): ?>
                    <a href="player.php?id=<?php echo e($player['id']); ?>" class="card" onclick="trackHistoryInteraction('view', 'player', <?php echo e($player['id']); ?>, '<?php echo e($player['name']); ?>', 'Player profile viewed')">
                        <i class="fas fa-user-circle" style="font-size:3rem;"></i>
                        <h3><?php echo e($player['name']); ?></h3>
                        <p><?php echo e($player['bio']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-crown"></i> <?php echo e($player['title']); ?></span>
                            <span><i class="fas fa-chart-line"></i> <?php echo e($player['rating']); ?> ELO</span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="player.php?id=1" class="card" onclick="trackHistoryInteraction('view', 'player', 1, 'Magnus Carlsen', 'Player profile viewed')">
                    <i class="fas fa-user-circle" style="font-size:3rem;"></i>
                    <h3>Magnus Carlsen</h3>
                    <p>World Chess Champion 2013-2025.</p>
                    <div class="meta"><span><i class="fas fa-crown"></i> GM</span><span><i class="fas fa-chart-line"></i> 2847 ELO</span></div>
                </a>
                <a href="player.php?id=2" class="card" onclick="trackHistoryInteraction('view', 'player', 2, 'Garry Kasparov', 'Player profile viewed')">
                    <i class="fas fa-user-circle" style="font-size:3rem;"></i>
                    <h3>Garry Kasparov</h3>
                    <p>World Chess Champion 1985-2000.</p>
                    <div class="meta"><span><i class="fas fa-crown"></i> GM</span><span><i class="fas fa-chart-line"></i> 2851 ELO</span></div>
                </a>
                <a href="player.php?id=3" class="card" onclick="trackHistoryInteraction('view', 'player', 3, 'Judit Polgár', 'Player profile viewed')">
                    <i class="fas fa-user-circle" style="font-size:3rem;"></i>
                    <h3>Judit Polgár</h3>
                    <p>Strongest female chess player ever.</p>
                    <div class="meta"><span><i class="fas fa-crown"></i> GM</span><span><i class="fas fa-chart-line"></i> 2735 ELO</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== OPENING OF THE DAY ===== -->
    <section class="section" id="opening-day">
        <div class="guest-play-section">
            <div class="section-header">
                <h2><i class="fas fa-chess-king"></i> Opening of the Day</h2>
                <a href="openings.php" class="view-all">Explore <i class="fas fa-arrow-right"></i></a>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:2rem;align-items:center;">
                <div>
                    <h3 style="color:#f0d6b0;font-size:1.3rem;"><?php echo e($openingOfDay['name'] ?? "Queen's Gambit"); ?></h3>
                    <p style="color:#a09080;margin:0.5rem 0;"><?php echo e($openingOfDay['description'] ?? '1.d4 d5 2.c4 — One of the most respected openings.'); ?></p>
                    <div style="color:#d4c0b0;font-family:monospace;background:rgba(0,0,0,0.3);padding:0.8rem;border-radius:0.8rem;margin:0.8rem 0;font-size:0.85rem;">
                        <?php echo e($openingOfDay['moves'] ?? '1. d4 d5 2. c4 e6 3. Nc3 Nf6 4. Bg5 Nbd7'); ?>
                    </div>
                    <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                        <span style="color:#2ecc71;font-size:0.8rem;"><i class="fas fa-check-circle"></i> Pros: Solid position</span>
                        <span style="color:#e74c3c;font-size:0.8rem;"><i class="fas fa-times-circle"></i> Cons: Can be drawish</span>
                    </div>
                    <button onclick="trackHistoryInteraction('view', 'opening', 0, '<?php echo e($openingOfDay['name'] ?? "Queen's Gambit"); ?>', 'Opening of the day viewed')" style="margin-top:0.8rem;padding:0.4rem 1.2rem;border-radius:2rem;border:1px solid var(--secondary);background:transparent;color:var(--secondary);cursor:pointer;transition:0.3s;">
                        <i class="fas fa-bookmark"></i> Save Opening
                    </button>
                </div>
                <div style="background:rgba(0,0,0,0.2);border-radius:1rem;padding:2rem;text-align:center;border:2px dashed var(--border-color);">
                    <i class="fas fa-chess-board" style="font-size:4rem;color:var(--secondary);opacity:0.3;"></i>
                    <p style="color:#7a6a5a;margin-top:0.5rem;">Opening Position</p>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== QUOTE ===== -->
    <section class="section" id="quote" style="text-align:center;padding:2rem;">
        <div style="background:var(--card-bg);border-radius:2rem;padding:2rem;border:1px solid var(--border-color);">
            <i class="fas fa-quote-left" style="color:var(--secondary);font-size:2rem;opacity:0.5;"></i>
            <blockquote style="font-size:1.3rem;color:#f0d6b0;font-style:italic;margin:1rem 0;">
                "<?php echo e($chessQuote['quote'] ?? 'Chess is the struggle against error.'); ?>"
            </blockquote>
            <p style="color:var(--secondary);">— <?php echo e($chessQuote['author'] ?? 'Wilhelm Steinitz'); ?></p>
            <button onclick="trackHistoryInteraction('share', 'quote', 0, 'Chess Quote', 'Shared quote')" style="margin-top:0.8rem;padding:0.3rem 1rem;border-radius:1rem;border:1px solid var(--border-color);background:transparent;color:#7a6a5a;cursor:pointer;transition:0.3s;">
                <i class="fas fa-share-alt"></i> Share Quote
            </button>
        </div>
    </section>

    <!-- ===== LEADERBOARD ===== -->
    <section class="section" id="leaderboard">
        <div class="section-header">
            <h2><i class="fas fa-list-ol"></i> Leaderboards</h2>
            <a href="rankings.php" class="view-all">Full Rankings <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="leaderboard-table">
            <table>
                <thead>
                    <tr>
                        <th style="text-align:left;">#</th>
                        <th style="text-align:left;">Player</th>
                        <th style="text-align:center;">Rating</th>
                        <th style="text-align:center;">Wins</th>
                        <th style="text-align:center;">Streak</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($leaderboard)): ?>
                        <?php foreach ($leaderboard as $index => $player): ?>
                            <tr>
                                <td class="<?php echo $index < 3 ? 'rank-' . ['gold','silver','bronze'][$index] : ''; ?>"><?php echo e($index + 1); ?></td>
                                <td style="color:#f0d6b0;"><?php echo e($player['name']); ?></td>
                                <td style="text-align:center;color:var(--secondary);font-weight:600;"><?php echo e($player['rating']); ?></td>
                                <td style="text-align:center;color:#a09080;"><?php echo e($player['wins']); ?></td>
                                <td style="text-align:center;color:#2ecc71;"><?php echo e($player['streak']); ?>🔥</td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td class="rank-gold">1</td><td style="color:#f0d6b0;">Magnus Carlsen</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2847</td><td style="text-align:center;color:#a09080;">127</td><td style="text-align:center;color:#2ecc71;">15🔥</td></tr>
                        <tr><td class="rank-silver">2</td><td style="color:#f0d6b0;">Ian Nepomniachtchi</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2795</td><td style="text-align:center;color:#a09080;">98</td><td style="text-align:center;color:#f1c40f;">8🔥</td></tr>
                        <tr><td class="rank-bronze">3</td><td style="color:#f0d6b0;">Hikaru Nakamura</td><td style="text-align:center;color:var(--secondary);font-weight:600;">2788</td><td style="text-align:center;color:#a09080;">112</td><td style="text-align:center;color:#2ecc71;">12🔥</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </section>

    <!-- ===== ARTICLES & BLOG ===== -->
    <section class="section" id="articles">
        <div class="section-header">
            <h2><i class="fas fa-blog"></i> Articles & Blog</h2>
            <a href="blog.php" class="view-all">All Articles <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($articles)): ?>
                <?php foreach ($articles as $article): ?>
                    <a href="article.php?id=<?php echo e($article['id']); ?>" class="card" onclick="trackHistoryInteraction('view', 'article', <?php echo e($article['id']); ?>, '<?php echo e($article['title']); ?>', 'Article viewed')">
                        <i class="fas fa-pencil-alt"></i>
                        <h3><?php echo e($article['title']); ?></h3>
                        <p><?php echo e($article['excerpt']); ?></p>
                        <div class="meta">
                            <span><i class="fas fa-user"></i> <?php echo e($article['author']); ?></span>
                            <span><i class="fas fa-calendar"></i> <?php echo e(date('M d, Y', strtotime($article['date']))); ?></span>
                        </div>
                    </a>
                <?php endforeach; ?>
            <?php else: ?>
                <a href="article.php?id=1" class="card" onclick="trackHistoryInteraction('view', 'article', 1, 'Mastering the Queen\'s Gambit', 'Article viewed')">
                    <i class="fas fa-chess-queen"></i>
                    <h3>Mastering the Queen's Gambit</h3>
                    <p>Deep dive into the classical opening.</p>
                    <div class="meta"><span><i class="fas fa-user"></i> GM John Smith</span><span><i class="fas fa-calendar"></i> Dec 10, 2025</span></div>
                </a>
                <a href="article.php?id=2" class="card" onclick="trackHistoryInteraction('view', 'article', 2, '10 Tips to Improve Your Chess', 'Article viewed')">
                    <i class="fas fa-pencil-alt"></i>
                    <h3>10 Tips to Improve Your Chess</h3>
                    <p>Practical advice to level up.</p>
                    <div class="meta"><span><i class="fas fa-user"></i> IM Sarah Lee</span><span><i class="fas fa-calendar"></i> Nov 28, 2025</span></div>
                </a>
                <a href="article.php?id=3" class="card" onclick="trackHistoryInteraction('view', 'article', 3, 'History of Chess', 'Article viewed')">
                    <i class="fas fa-history"></i>
                    <h3>History of Chess</h3>
                    <p>From India to the world.</p>
                    <div class="meta"><span><i class="fas fa-user"></i> Dr. James Patel</span><span><i class="fas fa-calendar"></i> Nov 5, 2025</span></div>
                </a>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== COMMENTS ===== -->
    <section class="section" id="comments">
        <div class="section-header">
            <h2><i class="fas fa-comments"></i> Comments & Reviews</h2>
            <a href="comments.php" class="view-all">All Comments <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="card-grid">
            <?php if (!empty($recentComments)): ?>
                <?php foreach ($recentComments as $comment): ?>
                    <div class="card">
                        <div style="display:flex;align-items:center;gap:0.8rem;margin-bottom:0.8rem;">
                            <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-weight:700;color:white;">
                                <?php echo e(strtoupper(substr($comment['author'], 0, 1))); ?>
                            </div>
                            <div>
                                <div style="color:#f0d6b0;font-weight:600;"><?php echo e($comment['author']); ?></div>
                                <div style="color:#7a6a5a;font-size:0.75rem;"><?php echo e(date('M d, Y', strtotime($comment['date']))); ?></div>
                            </div>
                        </div>
                        <p style="color:#d4c0b0;font-size:0.85rem;"><?php echo e($comment['text']); ?></p>
                        <div style="color:var(--gold);margin-top:0.5rem;">
                            <?php for ($i = 1; $i <= 5; $i++): ?>
                                <i class="fas fa-star<?php echo $i <= ($comment['rating'] ?? 4) ? '' : '-o'; ?>" style="font-size:0.8rem;"></i>
                            <?php endfor; ?>
                        </div>
                        <div class="meta">
                            <button style="background:transparent;border:none;color:#7a6a5a;cursor:pointer;" onclick="trackHistoryInteraction('like', 'comment', 0, 'Comment', 'Liked comment')">
                                <i class="far fa-thumbs-up"></i> Helpful (<?php echo e($comment['helpful'] ?? 0); ?>)
                            </button>
                            <button style="background:transparent;border:none;color:#7a6a5a;cursor:pointer;" onclick="trackHistoryInteraction('share', 'comment', 0, 'Comment', 'Shared comment')">
                                <i class="fas fa-share"></i> Share
                            </button>
                        </div>
                    </div>
                <?php endforeach; ?>
            <?php else: ?>
                <div class="card">
                    <div style="display:flex;align-items:center;gap:0.8rem;margin-bottom:0.8rem;">
                        <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-weight:700;color:white;">M</div>
                        <div><div style="color:#f0d6b0;font-weight:600;">Mike R.</div><div style="color:#7a6a5a;font-size:0.75rem;">Dec 15, 2025</div></div>
                    </div>
                    <p style="color:#d4c0b0;font-size:0.85rem;">"Chess Heaven is an incredible resource for players of all levels."</p>
                    <div style="color:var(--gold);margin-top:0.5rem;"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <div class="meta"><button style="background:transparent;border:none;color:#7a6a5a;cursor:pointer;"><i class="far fa-thumbs-up"></i> Helpful (24)</button></div>
                </div>
                <div class="card">
                    <div style="display:flex;align-items:center;gap:0.8rem;margin-bottom:0.8rem;">
                        <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-weight:700;color:white;">S</div>
                        <div><div style="color:#f0d6b0;font-weight:600;">Sarah K.</div><div style="color:#7a6a5a;font-size:0.75rem;">Dec 12, 2025</div></div>
                    </div>
                    <p style="color:#d4c0b0;font-size:0.85rem;">"I've been using Chess Heaven for 6 months and my rating has improved by 300 points."</p>
                    <div style="color:var(--gold);margin-top:0.5rem;"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></div>
                    <div class="meta"><button style="background:transparent;border:none;color:#7a6a5a;cursor:pointer;"><i class="far fa-thumbs-up"></i> Helpful (18)</button></div>
                </div>
                <div class="card">
                    <div style="display:flex;align-items:center;gap:0.8rem;margin-bottom:0.8rem;">
                        <div style="width:40px;height:40px;border-radius:50%;background:var(--primary);display:flex;align-items:center;justify-content:center;font-weight:700;color:white;">J</div>
                        <div><div style="color:#f0d6b0;font-weight:600;">James P.</div><div style="color:#7a6a5a;font-size:0.75rem;">Dec 8, 2025</div></div>
                    </div>
                    <p style="color:#d4c0b0;font-size:0.85rem;">"The live tournaments feature is fantastic!"</p>
                    <div style="color:var(--gold);margin-top:0.5rem;"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star-o"></i></div>
                    <div class="meta"><button style="background:transparent;border:none;color:#7a6a5a;cursor:pointer;"><i class="far fa-thumbs-up"></i> Helpful (12)</button></div>
                </div>
            <?php endif; ?>
        </div>
    </section>

    <!-- ===== CHESS HISTORY EXPLORER ===== -->
    <section class="section" id="history">
        <div class="section-header">
            <h2><i class="fas fa-history"></i> Chess History Explorer</h2>
            <a href="history.php" class="view-all">Full History <i class="fas fa-arrow-right"></i></a>
        </div>
        <div class="history-section">
            <!-- History Stats -->
            <div class="history-stats-grid">
                <div class="history-stat-card">
                    <div class="stat-value"><?php echo $historyStats['total_views'] ?? 0; ?></div>
                    <div class="stat-label">Total Views</div>
                </div>
                <div class="history-stat-card">
                    <div class="stat-value"><?php echo $historyStats['unique_visitors'] ?? 0; ?></div>
                    <div class="stat-label">Unique Visitors</div>
                </div>
                <div class="history-stat-card">
                    <div class="stat-value"><?php echo $historyStats['today_views'] ?? 0; ?></div>
                    <div class="stat-label">Today's Views</div>
                </div>
                <div class="history-stat-card">
                    <div class="stat-value"><?php echo $historyStats['total_interactions'] ?? 0; ?></div>
                    <div class="stat-label">Interactions</div>
                </div>
            </div>

            <!-- Popular History Items -->
            <h4 style="color:#f0d6b0;margin-bottom:0.8rem;"><i class="fas fa-star" style="color:var(--secondary);"></i> Popular History Items</h4>
            <div class="history-items-grid">
                <?php foreach ($historyPopularItems as $item): ?>
                    <div class="history-item-card" onclick="trackHistoryInteraction('view', '<?php echo e($item['type']); ?>', 0, '<?php echo e($item['title']); ?>', 'Popular history item viewed')">
                        <i class="fas fa-<?php echo e($item['icon'] ?? 'chess-pawn'); ?>"></i>
                        <h4><?php echo e($item['title']); ?></h4>
                        <p><?php echo e($item['description']); ?></p>
                        <span class="year-badge"><?php echo e($item['year']); ?></span>
                    </div>
                <?php endforeach; ?>
            </div>

            <!-- Featured History Item -->
            <div style="margin-top:1.5rem;padding-top:1.5rem;border-top:1px solid var(--border-color);">
                <div style="display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
                    <span style="background:rgba(139,26,26,0.3);padding:0.3rem 0.8rem;border-radius:1rem;font-size:0.75rem;color:var(--secondary);">
                        <i class="fas fa-star"></i> Featured
                    </span>
                    <h4 style="color:#f0d6b0;">The Immortal Game - Anderssen vs Kieseritzky (1851)</h4>
                </div>
                <p style="color:#a09080;margin-top:0.5rem;">One of the most famous chess games ever played. Watch the brilliant queen sacrifice that made history.</p>
                <div style="display:flex;gap:0.8rem;flex-wrap:wrap;margin-top:0.8rem;">
                    <a href="game.php?id=immortal" class="btn" style="display:inline-block;padding:0.5rem 1.5rem;border-radius:2rem;border:1px solid var(--secondary);color:var(--secondary);transition:0.3s;" onclick="trackHistoryInteraction('view', 'game', 0, 'Immortal Game', 'Featured history item viewed')">
                        <i class="fas fa-play"></i> View Game
                    </a>
                    <button onclick="trackHistoryInteraction('bookmark', 'game', 0, 'Immortal Game', 'Bookmarked history item')" style="display:inline-block;padding:0.5rem 1.5rem;border-radius:2rem;border:1px solid var(--border-color);background:transparent;color:#7a6a5a;cursor:pointer;transition:0.3s;">
                        <i class="far fa-bookmark"></i> Save for Later
                    </button>
                    <button onclick="trackHistoryInteraction('share', 'game', 0, 'Immortal Game', 'Shared history item')" style="display:inline-block;padding:0.5rem 1.5rem;border-radius:2rem;border:1px solid var(--border-color);background:transparent;color:#7a6a5a;cursor:pointer;transition:0.3s;">
                        <i class="fas fa-share-alt"></i> Share
                    </button>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== FAQ ===== -->
    <section class="section" id="faq">
        <div class="section-header">
            <h2><i class="fas fa-question-circle"></i> FAQ</h2>
            <a href="faq.php" class="view-all">All FAQs <i class="fas fa-arrow-right"></i></a>
        </div>
        <?php if (!empty($faqItems)): ?>
            <?php foreach ($faqItems as $index => $faq): ?>
                <div class="faq-item <?php echo $index === 0 ? 'active' : ''; ?>" onclick="toggleFAQ(this)">
                    <div class="faq-question">
                        <span><?php echo e($faq['question']); ?></span>
                        <i class="fas fa-chevron-down faq-toggle"></i>
                    </div>
                    <div class="faq-answer"><?php echo e($faq['answer']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <div class="faq-item active" onclick="toggleFAQ(this)"><div class="faq-question"><span>How do I play chess on Chess Heaven?</span><i class="fas fa-chevron-down faq-toggle"></i></div><div class="faq-answer">You can play as a guest immediately or sign up for a free account.</div></div>
            <div class="faq-item" onclick="toggleFAQ(this)"><div class="faq-question"><span>Is Chess Heaven free to use?</span><i class="fas fa-chevron-down faq-toggle"></i></div><div class="faq-answer">Yes! Chess Heaven is completely free for all users.</div></div>
            <div class="faq-item" onclick="toggleFAQ(this)"><div class="faq-question"><span>What is the Daily Puzzle?</span><i class="fas fa-chevron-down faq-toggle"></i></div><div class="faq-answer">Every day we feature a new chess puzzle of varying difficulty.</div></div>
            <div class="faq-item" onclick="toggleFAQ(this)"><div class="faq-question"><span>How can I improve my chess skills?</span><i class="fas fa-chevron-down faq-toggle"></i></div><div class="faq-answer">Use our Learn section with lessons from beginner to advanced.</div></div>
            <div class="faq-item" onclick="toggleFAQ(this)"><div class="faq-question"><span>Do I need to create an account?</span><i class="fas fa-chevron-down faq-toggle"></i></div><div class="faq-answer">No, you can play as a guest. But an account lets you save progress.</div></div>
            <div class="faq-item" onclick="toggleFAQ(this)"><div class="faq-question"><span>What are the tournaments on Chess Heaven?</span><i class="fas fa-chevron-down faq-toggle"></i></div><div class="faq-answer">We host regular tournaments for players of all levels.</div></div>
        <?php endif; ?>
    </section>

    <!-- ===== CONTACT ===== -->
    <section class="section" id="contact">
        <div class="section-header">
            <h2><i class="fas fa-envelope"></i> Contact Us</h2>
        </div>
        <div class="contact-grid">
            <div class="contact-form">
                <input type="text" placeholder="Your Name" />
                <input type="email" placeholder="Your Email" />
                <input type="text" placeholder="Subject" />
                <textarea placeholder="Your Message"></textarea>
                <button class="btn-submit" onclick="trackHistoryInteraction('contact', 'page', 0, 'Contact Form', 'Contact form submitted')"><i class="fas fa-paper-plane"></i> Send Message</button>
            </div>
            <div class="contact-info">
                <div class="info-item"><i class="fas fa-map-marker-alt"></i><span>123 Chess Lane, New York, NY 10001</span></div>
                <div class="info-item"><i class="fas fa-envelope"></i><span>contact@chessheaven.org</span></div>
                <div class="info-item"><i class="fas fa-phone"></i><span>+1 (555) 123-4567</span></div>
                <div class="info-item"><i class="fas fa-clock"></i><span>Mon-Fri: 9:00 AM - 6:00 PM EST</span></div>
                <div>
                    <p style="color:#a09080;margin-bottom:0.5rem;">Follow us:</p>
                    <div class="social-links-big">
                        <a href="#"><i class="fab fa-twitter"></i></a>
                        <a href="#"><i class="fab fa-youtube"></i></a>
                        <a href="#"><i class="fab fa-discord"></i></a>
                        <a href="#"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-facebook"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ===== FOOTER ===== -->
    <footer class="footer">
        <div>
            <h4><i class="fas fa-chess-king" style="color:var(--secondary);"></i> Chess Heaven</h4>
            <p style="color:#7a6a5a;margin:0.5rem 0;">Empowering communities through the royal game — free lessons, mentorship & tournaments.</p>
            <div style="display:flex;gap:1rem;margin-top:1rem;">
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-youtube"></i></a>
                <a href="#"><i class="fab fa-discord"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
            </div>
        </div>
        <div>
            <h4>Quick Links</h4>
            <a href="play.php">Play Chess</a>
            <a href="learn.php">Learn Chess</a>
            <a href="puzzles.php">Puzzles</a>
            <a href="tournaments.php">Tournaments</a>
            <a href="news.php">News</a>
            <a href="history.php">Chess History</a>
        </div>
        <div>
            <h4>Resources</h4>
            <a href="openings.php">Openings</a>
            <a href="rankings.php">Rankings</a>
            <a href="about.php">About Us</a>
            <a href="contact.php">Contact</a>
            <a href="faq.php">FAQ</a>
        </div>
        <div class="newsletter">
            <h4>Newsletter</h4>
            <p style="color:#7a6a5a;font-size:0.9rem;">Subscribe for chess tips and updates.</p>
            <input type="email" placeholder="Your email" />
            <button onclick="trackHistoryInteraction('subscribe', 'page', 0, 'Newsletter', 'Subscribed to newsletter')">Subscribe</button>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo $currentYear; ?> Chess Heaven · Charity NGO · <a href="privacy.php" style="display:inline;">Privacy Policy</a> · <a href="terms.php" style="display:inline;">Terms & Conditions</a></p>
        </div>
    </footer>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // Mobile menu toggle
        const menuToggle = document.getElementById('menuToggle');
        const navLinks = document.getElementById('navLinks');
        menuToggle.addEventListener('click', function() {
            this.classList.toggle('active');
            navLinks.classList.toggle('open');
        });
        document.querySelectorAll('.nav-links a').forEach(link => {
            link.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    menuToggle.classList.remove('active');
                    navLinks.classList.remove('open');
                }
            });
        });

        // Navbar scroll effect
        window.addEventListener('scroll', function() {
            const navbar = document.getElementById('navbar');
            if (window.scrollY > 50) navbar.classList.add('scrolled');
            else navbar.classList.remove('scrolled');
        });

        // Difficulty selector
        function selectDifficulty(btn) {
            document.querySelectorAll('.difficulty-btn').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            trackHistoryInteraction('select', 'game', 0, 'Difficulty: ' + btn.textContent.trim(), 'Selected difficulty');
        }

        // FAQ toggle
        function toggleFAQ(element) {
            element.classList.toggle('active');
            if (element.classList.contains('active')) {
                trackHistoryInteraction('view', 'faq', 0, element.querySelector('.faq-question span').textContent, 'FAQ viewed');
            }
        }

        // Track history interaction (PHP function called via AJAX)
        function trackHistoryInteraction(type, itemType, itemId, itemTitle, details) {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'track_history.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.send('interaction_type=' + encodeURIComponent(type) + 
                     '&item_type=' + encodeURIComponent(itemType) + 
                     '&item_id=' + encodeURIComponent(itemId) + 
                     '&item_title=' + encodeURIComponent(itemTitle) + 
                     '&details=' + encodeURIComponent(details));
        }

        // ===== FLOATING NAVIGATION =====
        // Update active dot based on scroll position
        function updateActiveNav() {
            const sections = document.querySelectorAll('section[id]');
            const navDots = document.querySelectorAll('.nav-dot');
            
            let currentSection = '';
            sections.forEach(section => {
                const sectionTop = section.offsetTop - 100;
                if (window.scrollY >= sectionTop) {
                    currentSection = section.getAttribute('id');
                }
            });
            
            navDots.forEach(dot => {
                dot.classList.remove('active');
                if (dot.getAttribute('data-section') === currentSection) {
                    dot.classList.add('active');
                }
            });
        }

        // Toggle floating nav on mobile
        function toggleFloatingNav() {
            const nav = document.getElementById('floatingNav');
            nav.classList.toggle('open');
        }

        function closeFloatingNav() {
            if (window.innerWidth <= 768) {
                const nav = document.getElementById('floatingNav');
                nav.classList.remove('open');
            }
        }

        // Smooth scroll for nav dots
        document.querySelectorAll('.nav-dot').forEach(dot => {
            dot.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('data-section');
                const targetElement = document.getElementById(targetId);
                if (targetElement) {
                    targetElement.scrollIntoView({ behavior: 'smooth' });
                }
            });
        });

        // Update active dot on scroll
        window.addEventListener('scroll', updateActiveNav);
        window.addEventListener('load', updateActiveNav);

        // Close floating nav on scroll on mobile
        window.addEventListener('scroll', function() {
            if (window.innerWidth <= 768) {
                const nav = document.getElementById('floatingNav');
                if (nav.classList.contains('open')) {
                    nav.classList.remove('open');
                }
            }
        });

        // Close floating nav when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                const nav = document.getElementById('floatingNav');
                const toggle = document.getElementById('floatingNavToggle');
                if (!nav.contains(event.target) && !toggle.contains(event.target)) {
                    nav.classList.remove('open');
                }
            }
        });

        console.log('✅ Chess Heaven loaded successfully!');
        console.log('📊 History tracking is active.');
        console.log('🧭 Floating navigation toolbar is ready.');
    </script>
</body>
</html>