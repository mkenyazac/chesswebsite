<?php
/**
 * Chess Heaven - Administrator Dashboard
 * Complete administrator dashboard with all management features
 * Enhanced: Admin can play chess, request games, and oversee matches
 */

require_once 'config.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header('Location: login.php');
    exit;
}

// Redirect non-admins
if ($_SESSION['role'] === 'coach') {
    header('Location: coachdashboard.php');
    exit;
} elseif ($_SESSION['role'] === 'member') {
    header('Location: userdashboard.php');
    exit;
}

// Get user data
$userId = $_SESSION['user_id'];
$username = $_SESSION['username'] ?? 'Admin';
$displayName = $_SESSION['display_name'] ?? $username;
$email = $_SESSION['email'] ?? '';
$adminLevel = $_SESSION['admin_level'] ?? 'super';
$department = $_SESSION['department'] ?? 'Management';
$canManageUsers = $_SESSION['can_manage_users'] ?? 1;
$canManageCoaches = $_SESSION['can_manage_coaches'] ?? 1;
$canManageTournaments = $_SESSION['can_manage_tournaments'] ?? 1;
$canViewReports = $_SESSION['can_view_reports'] ?? 1;

// Get admin data from database
$adminData = getAdminData($userId);
if ($adminData) {
    $adminLevel = $adminData['admin_level'] ?? 'super';
    $department = $adminData['department'] ?? 'Management';
    $canManageUsers = $adminData['can_manage_users'] ?? 1;
    $canManageCoaches = $adminData['can_manage_coaches'] ?? 1;
    $canManageTournaments = $adminData['can_manage_tournaments'] ?? 1;
    $canViewReports = $adminData['can_view_reports'] ?? 1;
}

// Get site settings
$site_title = getSetting('site_title', '♚ Chess Heaven');
$currentYear = date('Y');

// Sample statistics
$stats = [
    'total_users' => 1250,
    'total_coaches' => 45,
    'total_admins' => 8,
    'active_users' => 892,
    'total_games' => 3450,
    'total_tournaments' => 24,
    'total_puzzles' => 156,
    'total_articles' => 78,
    'pending_coaches' => 6,
    'pending_comments' => 23,
    'reports' => 4,
];

// Sample recent activities
$recentActivities = [
    ['user' => 'JohnDoe', 'action' => 'Registered as new member', 'time' => '5 minutes ago'],
    ['user' => 'CoachMike', 'action' => 'Created new lesson: Opening Principles', 'time' => '15 minutes ago'],
    ['user' => 'AdminSarah', 'action' => 'Approved coach registration for BobSmith', 'time' => '1 hour ago'],
    ['user' => 'AliceW', 'action' => 'Reported inappropriate comment', 'time' => '2 hours ago'],
    ['user' => 'System', 'action' => 'Daily backup completed successfully', 'time' => '3 hours ago'],
];

// Sample users
$users = [
    ['id' => 1, 'username' => 'JohnDoe', 'email' => 'john@example.com', 'role' => 'member', 'status' => 'active', 'joined' => '2026-01-15'],
    ['id' => 2, 'username' => 'CoachMike', 'email' => 'mike@example.com', 'role' => 'coach', 'status' => 'active', 'joined' => '2025-11-10'],
    ['id' => 3, 'username' => 'AdminSarah', 'email' => 'sarah@example.com', 'role' => 'admin', 'status' => 'active', 'joined' => '2025-08-20'],
    ['id' => 4, 'username' => 'BobSmith', 'email' => 'bob@example.com', 'role' => 'member', 'status' => 'inactive', 'joined' => '2026-03-01'],
    ['id' => 5, 'username' => 'AliceW', 'email' => 'alice@example.com', 'role' => 'member', 'status' => 'active', 'joined' => '2026-02-10'],
];

// Sample coaches
$coaches = [
    ['id' => 1, 'name' => 'Mike Johnson', 'specialization' => 'Openings', 'students' => 12, 'rating' => 2250, 'status' => 'approved'],
    ['id' => 2, 'name' => 'Sarah Lee', 'specialization' => 'Endgames', 'students' => 8, 'rating' => 2180, 'status' => 'approved'],
    ['id' => 3, 'name' => 'Bob Smith', 'specialization' => 'Tactics', 'students' => 0, 'rating' => 1900, 'status' => 'pending'],
    ['id' => 4, 'name' => 'David Chen', 'specialization' => 'Strategy', 'students' => 15, 'rating' => 2300, 'status' => 'approved'],
];

// Sample tournaments
$tournaments = [
    ['id' => 1, 'name' => 'World Chess Championship', 'date' => '2026-08-15', 'players' => 64, 'status' => 'upcoming'],
    ['id' => 2, 'name' => 'Grand Chess Tour', 'date' => '2026-07-20', 'players' => 32, 'status' => 'open'],
    ['id' => 3, 'name' => 'Chess Heaven Open', 'date' => '2026-07-10', 'players' => 128, 'status' => 'completed'],
];

// Sample comments
$comments = [
    ['id' => 1, 'author' => 'JohnDoe', 'content' => 'Great lesson! Really helpful.', 'type' => 'lesson', 'status' => 'approved', 'date' => '2026-07-01'],
    ['id' => 2, 'author' => 'AliceW', 'content' => 'This puzzle is too easy.', 'type' => 'puzzle', 'status' => 'pending', 'date' => '2026-07-02'],
    ['id' => 3, 'author' => 'BobSmith', 'content' => 'When is the next tournament?', 'type' => 'tournament', 'status' => 'approved', 'date' => '2026-07-03'],
    ['id' => 4, 'author' => 'SpamUser', 'content' => 'Buy chess products here!', 'type' => 'comment', 'status' => 'reported', 'date' => '2026-07-03'],
];

// Sample online users for chess challenges
$onlineUsers = [
    ['id' => 1, 'username' => 'JohnDoe', 'role' => 'member', 'status' => 'online', 'rating' => 1450],
    ['id' => 2, 'username' => 'CoachMike', 'role' => 'coach', 'status' => 'online', 'rating' => 2250],
    ['id' => 3, 'username' => 'AdminSarah', 'role' => 'admin', 'status' => 'online', 'rating' => 2100],
    ['id' => 5, 'username' => 'AliceW', 'role' => 'member', 'status' => 'online', 'rating' => 1320],
    ['id' => 7, 'username' => 'GrandMasterX', 'role' => 'member', 'status' => 'online', 'rating' => 2450],
];

// Sample active games (for oversight)
$activeGames = [
    ['id' => 101, 'white' => 'JohnDoe', 'black' => 'CoachMike', 'status' => 'in_progress', 'move' => 12, 'time' => '15:23'],
    ['id' => 102, 'white' => 'AliceW', 'black' => 'BobSmith', 'status' => 'in_progress', 'move' => 8, 'time' => '08:45'],
    ['id' => 103, 'white' => 'AdminSarah', 'black' => 'GrandMasterX', 'status' => 'in_progress', 'move' => 24, 'time' => '22:10'],
];

// Determine active tab
$activeTab = isset($_GET['tab']) ? $_GET['tab'] : 'dashboard';

// Handle POST requests
$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle profile update
    if (isset($_POST['update_profile'])) {
        $displayName = trim($_POST['display_name'] ?? '');
        $department = trim($_POST['department'] ?? '');
        $adminLevel = $_POST['admin_level'] ?? 'super';
        
        $conn = getDBConnection();
        if ($conn) {
            $stmt = $conn->prepare("UPDATE users SET display_name = ? WHERE id = ?");
            $stmt->bind_param("si", $displayName, $userId);
            $stmt->execute();
            
            $stmt = $conn->prepare("UPDATE admins SET department = ?, admin_level = ? WHERE user_id = ?");
            $stmt->bind_param("ssi", $department, $adminLevel, $userId);
            $stmt->execute();
            
            $_SESSION['display_name'] = $displayName;
            $_SESSION['department'] = $department;
            $_SESSION['admin_level'] = $adminLevel;
            
            $message = 'Profile updated successfully!';
            $messageType = 'success';
        }
    }
    
    // Handle password change
    if (isset($_POST['change_password'])) {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';
        
        if (strlen($newPassword) < 6) {
            $message = 'Password must be at least 6 characters long.';
            $messageType = 'error';
        } elseif ($newPassword !== $confirmPassword) {
            $message = 'Passwords do not match.';
            $messageType = 'error';
        } else {
            $conn = getDBConnection();
            if ($conn) {
                $stmt = $conn->prepare("SELECT password FROM users WHERE id = ?");
                $stmt->bind_param("i", $userId);
                $stmt->execute();
                $result = $stmt->get_result();
                $user = $result->fetch_assoc();
                
                if (password_verify($currentPassword, $user['password'])) {
                    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
                    $stmt->bind_param("si", $hashedPassword, $userId);
                    $stmt->execute();
                    
                    $message = 'Password changed successfully!';
                    $messageType = 'success';
                } else {
                    $message = 'Current password is incorrect.';
                    $messageType = 'error';
                }
            }
        }
    }
    
    // Handle user status toggle
    if (isset($_POST['toggle_user_status'])) {
        $targetUserId = intval($_POST['user_id'] ?? 0);
        $newStatus = intval($_POST['new_status'] ?? 0);
        $conn = getDBConnection();
        if ($conn && $targetUserId > 0) {
            $stmt = $conn->prepare("UPDATE users SET is_active = ? WHERE id = ?");
            $stmt->bind_param("ii", $newStatus, $targetUserId);
            $stmt->execute();
            $message = 'User status updated successfully!';
            $messageType = 'success';
        }
    }
    
    // Handle coach approval
    if (isset($_POST['approve_coach'])) {
        $coachId = intval($_POST['coach_id'] ?? 0);
        $conn = getDBConnection();
        if ($conn && $coachId > 0) {
            $stmt = $conn->prepare("UPDATE coaches SET status = 'approved' WHERE id = ?");
            $stmt->bind_param("i", $coachId);
            $stmt->execute();
            $message = 'Coach approved successfully!';
            $messageType = 'success';
        }
    }
    
    // Handle chess game request
    if (isset($_POST['request_game'])) {
        $opponentId = intval($_POST['opponent_id'] ?? 0);
        $color = $_POST['color'] ?? 'random';
        $timeControl = $_POST['time_control'] ?? '30';
        
        if ($opponentId > 0) {
            // Find opponent name
            $opponentName = '';
            foreach ($onlineUsers as $u) {
                if ($u['id'] == $opponentId) {
                    $opponentName = $u['username'];
                    break;
                }
            }
            if (!$opponentName) {
                foreach ($users as $u) {
                    if ($u['id'] == $opponentId) {
                        $opponentName = $u['username'];
                        break;
                    }
                }
            }
            $message = "Game request sent to {$opponentName}!";
            $messageType = 'success';
            
            // Add to activities
            $recentActivities[] = [
                'user' => $displayName,
                'action' => "Requested a chess game with {$opponentName} ({$timeControl} min)",
                'time' => 'Just now'
            ];
        } else {
            $message = "Please select an opponent.";
            $messageType = 'error';
        }
    }
    
    // Handle game oversight (view game)
    if (isset($_POST['oversee_game'])) {
        $gameId = intval($_POST['game_id'] ?? 0);
        if ($gameId > 0) {
            $message = "Now overseeing game #{$gameId}. You can view moves in real-time.";
            $messageType = 'info';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo e($site_title); ?> · Admin Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet" />
    <style>
        /* ===== RESET & BASE ===== */
        * { margin:0; padding:0; box-sizing:border-box; font-family:'Inter',sans-serif; }
        :root {
            --primary: #8B1A1A;
            --primary-dark: #5C0E0E;
            --secondary: #C6976B;
            --gold: #D4A373;
            --dark: #1e1a1a;
            --darker: #0a0505;
            --gray: #9a8a7a;
            --white: #ffffff;
            --nav-height: 70px;
            --card-bg: rgba(255,255,255,0.03);
            --border-color: rgba(139,26,26,0.25);
            --sidebar-width: 260px;
            --success: #2ecc71;
            --warning: #f1c40f;
            --danger: #e74c3c;
            --info: #3498db;
            /* Chess board colors */
            --light-square: #f0d9b5;
            --dark-square: #b58863;
        }
        body {
            min-height:100vh;
            background:radial-gradient(circle at 30%20%, #3a1a1a, #0a0505);
            color:#f0e0d0;
            padding-top:var(--nav-height);
            display:flex;
            flex-direction:column;
        }
        a { text-decoration:none; color:inherit; }
        
        /* ===== NAVBAR ===== */
        .navbar-fixed {
            position:fixed; top:0; left:0; right:0; z-index:9999;
            background:rgba(10,5,5,0.95); backdrop-filter:blur(16px);
            border-bottom:1px solid rgba(201,168,124,0.12);
            padding:0.5rem 2rem; transition:all 0.3s;
            display:flex; align-items:center; justify-content:space-between;
        }
        .navbar-fixed.scrolled {
            background:rgba(10,5,5,0.98);
            box-shadow:0 4px 30px rgba(0,0,0,0.5);
        }
        .navbar-left { display:flex; align-items:center; gap:1rem; }
        .navbar-logo {
            display:flex; align-items:center; gap:0.8rem;
            text-decoration:none;
        }
        .navbar-logo .logo-icon {
            font-size:1.8rem; color:var(--secondary);
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            padding:0.4rem; border-radius:50%; width:44px; height:44px;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-logo .logo-text {
            font-size:1.3rem; font-weight:700;
            background:linear-gradient(135deg,#f0d6b0,#d4a080);
            -webkit-background-clip:text; -webkit-text-fill-color:transparent;
        }
        .navbar-right { display:flex; align-items:center; gap:1rem; }
        .navbar-right .admin-badge {
            background:rgba(139,26,26,0.3);
            border:1px solid var(--secondary);
            padding:0.2rem 0.8rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
            color:var(--secondary);
        }
        .navbar-right .notification-btn {
            position:relative;
            background:rgba(255,255,255,0.05);
            border:1px solid var(--border-color);
            border-radius:50%;
            width:40px; height:40px;
            display:flex; align-items:center; justify-content:center;
            color:#d4c0b0; transition:0.3s;
            cursor:pointer;
        }
        .navbar-right .notification-btn:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        .navbar-right .notification-btn .badge {
            position:absolute; top:-5px; right:-5px;
            background:var(--danger); color:white;
            border-radius:50%; width:20px; height:20px;
            font-size:0.7rem; font-weight:700;
            display:flex; align-items:center; justify-content:center;
        }
        .navbar-right .user-menu {
            display:flex; align-items:center; gap:0.5rem;
            cursor:pointer; padding:0.3rem 0.8rem;
            border-radius:2rem; transition:0.3s;
            border:1px solid transparent;
        }
        .navbar-right .user-menu:hover {
            border-color:var(--border-color);
            background:rgba(255,255,255,0.05);
        }
        .navbar-right .user-avatar {
            width:36px; height:36px; border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex; align-items:center; justify-content:center;
            font-weight:700; color:white; font-size:1rem;
        }
        .navbar-right .user-name {
            color:#f0d6b0; font-weight:600; font-size:0.9rem;
        }
        .navbar-right .user-name span {
            color:#7a6a5a; font-weight:400; font-size:0.75rem;
        }

        /* ===== DASHBOARD LAYOUT ===== */
        .dashboard-container {
            display:flex;
            flex:1;
        }

        /* ===== SIDEBAR ===== */
        .sidebar {
            width:var(--sidebar-width);
            background:rgba(10,5,5,0.8);
            backdrop-filter:blur(16px);
            border-right:1px solid var(--border-color);
            padding:1.5rem 0;
            position:fixed;
            top:var(--nav-height);
            bottom:0;
            left:0;
            overflow-y:auto;
            transition:transform 0.3s ease;
            z-index:1000;
        }
        .sidebar::-webkit-scrollbar { width:4px; }
        .sidebar::-webkit-scrollbar-track { background:transparent; }
        .sidebar::-webkit-scrollbar-thumb { background:var(--secondary); border-radius:2px; }

        .sidebar .sidebar-section {
            padding:0 1rem 1rem;
            border-bottom:1px solid rgba(255,255,255,0.05);
            margin-bottom:1rem;
        }
        .sidebar .sidebar-section:last-child { border-bottom:none; }

        .sidebar .section-title {
            font-size:0.7rem;
            text-transform:uppercase;
            letter-spacing:1px;
            color:#5a4a3a;
            font-weight:600;
            padding:0 0.5rem;
            margin-bottom:0.5rem;
        }

        .sidebar .sidebar-item {
            display:flex;
            align-items:center;
            gap:0.8rem;
            padding:0.6rem 1rem;
            border-radius:0.5rem;
            color:#a09080;
            transition:all 0.3s;
            cursor:pointer;
            text-decoration:none;
            margin-bottom:0.2rem;
            position:relative;
        }
        .sidebar .sidebar-item:hover {
            color:#f0d6b0;
            background:rgba(139,26,26,0.2);
        }
        .sidebar .sidebar-item.active {
            color:#f0d6b0;
            background:rgba(139,26,26,0.3);
            border-left:3px solid var(--secondary);
        }
        .sidebar .sidebar-item i {
            width:20px;
            text-align:center;
            font-size:1rem;
            color:var(--secondary);
        }
        .sidebar .sidebar-item .item-badge {
            margin-left:auto;
            background:var(--danger);
            color:white;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .sidebar .sidebar-item .item-badge.warning {
            background:var(--warning);
        }
        .sidebar .sidebar-item .item-badge.success {
            background:var(--success);
        }

        /* ===== MAIN CONTENT ===== */
        .main-content {
            margin-left:var(--sidebar-width);
            flex:1;
            padding:2rem;
            min-height:calc(100vh - var(--nav-height));
        }

        /* ===== PAGE HEADER ===== */
        .page-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:2rem;
            flex-wrap:wrap;
            gap:1rem;
        }
        .page-header h1 {
            font-size:1.8rem;
            font-weight:700;
            color:#f0d6b0;
        }
        .page-header h1 i {
            color:var(--secondary);
            margin-right:0.5rem;
        }
        .page-header .header-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
        }
        .page-header .header-actions .btn {
            padding:0.6rem 1.2rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            font-size:0.85rem;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .page-header .header-actions .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .page-header .header-actions .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 6px 25px rgba(139,26,26,0.5);
        }
        .page-header .header-actions .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .page-header .header-actions .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
        }
        .page-header .header-actions .btn-success {
            background:rgba(46,204,113,0.2);
            color:var(--success);
            border:1px solid rgba(46,204,113,0.3);
        }
        .page-header .header-actions .btn-success:hover {
            background:rgba(46,204,113,0.3);
        }

        /* ===== STATS GRID ===== */
        .stats-grid {
            display:grid;
            grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
            gap:1rem;
            margin-bottom:2rem;
        }
        .stat-card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.2rem;
            transition:all 0.3s;
        }
        .stat-card:hover {
            border-color:rgba(201,168,124,0.3);
            transform:translateY(-3px);
        }
        .stat-card .stat-icon {
            font-size:1.8rem;
            color:var(--secondary);
            margin-bottom:0.3rem;
        }
        .stat-card .stat-value {
            font-size:1.8rem;
            font-weight:700;
            color:#f0d6b0;
        }
        .stat-card .stat-label {
            font-size:0.8rem;
            color:#7a6a5a;
        }
        .stat-card .stat-change {
            display:inline-block;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
            margin-top:0.3rem;
        }
        .stat-card .stat-change.positive {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .stat-card .stat-change.negative {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
        }
        .stat-card .stat-change.warning {
            background:rgba(241,196,15,0.2);
            color:var(--warning);
        }

        /* ===== WELCOME CARD ===== */
        .welcome-card {
            background:linear-gradient(145deg, rgba(139,26,26,0.3), rgba(10,5,5,0.5));
            border:1px solid var(--border-color);
            border-radius:1.5rem;
            padding:2rem;
            margin-bottom:2rem;
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:1rem;
        }
        .welcome-card .welcome-text h2 {
            font-size:1.5rem;
            color:#f0d6b0;
        }
        .welcome-card .welcome-text p {
            color:#a09080;
            margin-top:0.3rem;
        }
        .welcome-card .welcome-text .admin-badge-large {
            display:inline-block;
            background:rgba(201,168,124,0.15);
            padding:0.2rem 1rem;
            border-radius:1rem;
            border:1px solid rgba(201,168,124,0.2);
            font-weight:600;
            color:var(--secondary);
            margin-top:0.5rem;
        }
        .welcome-card .welcome-text .admin-badge-large i {
            margin-right:0.3rem;
        }
        .welcome-card .welcome-actions {
            display:flex;
            gap:0.8rem;
            flex-wrap:wrap;
        }
        .welcome-card .welcome-actions .btn {
            padding:0.7rem 1.5rem;
            border-radius:2rem;
            border:none;
            font-weight:600;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .welcome-card .welcome-actions .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
            box-shadow:0 4px 15px rgba(139,26,26,0.3);
        }
        .welcome-card .welcome-actions .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 6px 25px rgba(139,26,26,0.5);
        }
        .welcome-card .welcome-actions .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .welcome-card .welcome-actions .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
            transform:translateY(-2px);
        }
        .welcome-card .welcome-actions .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .welcome-card .welcome-actions .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }

        /* ===== CONTENT GRID ===== */
        .content-grid {
            display:grid;
            grid-template-columns:2fr 1fr;
            gap:1.5rem;
            margin-bottom:2rem;
        }
        @media (max-width:992px) {
            .content-grid { grid-template-columns:1fr; }
        }

        /* ===== CARDS ===== */
        .card {
            background:var(--card-bg);
            border:1px solid var(--border-color);
            border-radius:1rem;
            padding:1.5rem;
            transition:all 0.3s;
        }
        .card:hover {
            border-color:rgba(201,168,124,0.2);
        }
        .card .card-header {
            display:flex;
            justify-content:space-between;
            align-items:center;
            margin-bottom:1rem;
        }
        .card .card-header h3 {
            color:#f0d6b0;
            font-size:1.1rem;
        }
        .card .card-header .card-action {
            color:var(--secondary);
            font-size:0.85rem;
            transition:0.3s;
            cursor:pointer;
        }
        .card .card-header .card-action:hover {
            color:#f0d6b0;
        }
        .card .card-body { color:#d4c0b0; }

        /* ===== ACTIVITY ITEM ===== */
        .activity-item {
            display:flex;
            gap:0.8rem;
            padding:0.6rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .activity-item:last-child { border-bottom:none; }
        .activity-item .activity-icon {
            width:32px; height:32px; border-radius:50%;
            background:rgba(139,26,26,0.3);
            display:flex; align-items:center; justify-content:center;
            color:var(--secondary);
            flex-shrink:0;
        }
        .activity-item .activity-content {
            flex:1;
        }
        .activity-item .activity-content .activity-text {
            font-size:0.9rem;
            color:#d4c0b0;
        }
        .activity-item .activity-content .activity-text strong {
            color:#f0d6b0;
        }
        .activity-item .activity-content .activity-time {
            font-size:0.75rem;
            color:#5a4a3a;
        }

        /* ===== USER ITEM ===== */
        .user-item {
            display:flex;
            justify-content:space-between;
            align-items:center;
            padding:0.5rem 0;
            border-bottom:1px solid rgba(255,255,255,0.05);
        }
        .user-item:last-child { border-bottom:none; }
        .user-item .user-info {
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .user-item .user-avatar-sm {
            width:32px; height:32px; border-radius:50%;
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            display:flex; align-items:center; justify-content:center;
            font-weight:700; color:white; font-size:0.8rem;
        }
        .user-item .user-status {
            font-size:0.7rem;
            padding:0.1rem 0.5rem;
            border-radius:1rem;
        }
        .user-item .user-status.active {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .user-item .user-status.inactive {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
        }
        .user-item .user-status.pending {
            background:rgba(241,196,15,0.2);
            color:var(--warning);
        }
        .user-item .user-status.online {
            background:rgba(46,204,113,0.3);
            color:var(--success);
        }
        .user-item .user-status.offline {
            background:rgba(90,74,58,0.3);
            color:#5a4a3a;
        }
        .user-item .user-actions {
            display:flex;
            gap:0.3rem;
        }
        .user-item .user-actions .btn {
            padding:0.2rem 0.6rem;
            font-size:0.75rem;
            border-radius:0.5rem;
            border:1px solid var(--border-color);
            background:transparent;
            color:#7a6a5a;
            cursor:pointer;
            transition:0.3s;
        }
        .user-item .user-actions .btn:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        .user-item .user-actions .btn-danger:hover {
            border-color:var(--danger);
            color:var(--danger);
        }
        .user-item .user-actions .btn-chess:hover {
            border-color:var(--gold);
            color:var(--gold);
        }

        /* ===== TAB CONTENT ===== */
        .tab-content {
            display:none;
            animation:fadeIn 0.3s ease;
        }
        .tab-content.active {
            display:block;
        }
        @keyframes fadeIn {
            from { opacity:0; transform:translateY(10px); }
            to { opacity:1; transform:translateY(0); }
        }

        /* ===== FORMS ===== */
        .form-group {
            margin-bottom:1.2rem;
        }
        .form-group label {
            display:block;
            color:#d4c0b0;
            font-weight:500;
            margin-bottom:0.3rem;
            font-size:0.9rem;
        }
        .form-group .form-control {
            width:100%;
            padding:0.7rem 1rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0d6b0;
            font-size:0.95rem;
            transition:all 0.3s;
        }
        .form-group .form-control:focus {
            outline:none;
            border-color:var(--secondary);
            background:rgba(255,255,255,0.08);
        }
        .form-group .form-control::placeholder {
            color:#5a4a3a;
        }
        .form-group textarea.form-control {
            min-height:100px;
            resize:vertical;
        }
        .form-group .form-hint {
            font-size:0.75rem;
            color:#5a4a3a;
            margin-top:0.3rem;
        }
        .form-group select.form-control {
            appearance:none;
            cursor:pointer;
        }
        .form-group select.form-control option {
            background:#1a0a0a;
            color:#f0d6b0;
        }

        /* ===== BUTTONS ===== */
        .btn {
            padding:0.6rem 1.2rem;
            border-radius:0.8rem;
            border:none;
            font-weight:600;
            font-size:0.85rem;
            transition:all 0.3s;
            cursor:pointer;
            display:inline-flex;
            align-items:center;
            gap:0.5rem;
        }
        .btn-primary {
            background:linear-gradient(145deg,var(--primary),var(--primary-dark));
            color:white;
        }
        .btn-primary:hover {
            transform:translateY(-2px);
            box-shadow:0 4px 15px rgba(139,26,26,0.4);
        }
        .btn-secondary {
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .btn-secondary:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
            background:rgba(255,255,255,0.08);
        }
        .btn-success {
            background:rgba(46,204,113,0.2);
            color:var(--success);
            border:1px solid rgba(46,204,113,0.3);
        }
        .btn-success:hover {
            background:rgba(46,204,113,0.3);
        }
        .btn-danger {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
            border:1px solid rgba(231,76,60,0.3);
        }
        .btn-danger:hover {
            background:rgba(231,76,60,0.3);
        }
        .btn-warning {
            background:rgba(241,196,15,0.2);
            color:var(--warning);
            border:1px solid rgba(241,196,15,0.3);
        }
        .btn-warning:hover {
            background:rgba(241,196,15,0.3);
        }
        .btn-chess {
            background:rgba(201,168,124,0.2);
            color:var(--gold);
            border:1px solid rgba(201,168,124,0.3);
        }
        .btn-chess:hover {
            background:rgba(201,168,124,0.3);
            transform:translateY(-2px);
        }

        /* ===== MESSAGES ===== */
        .message {
            padding:0.8rem 1rem;
            border-radius:0.8rem;
            margin-bottom:1.5rem;
            display:flex;
            align-items:center;
            gap:0.8rem;
        }
        .message-success {
            background:rgba(46,204,113,0.15);
            border:1px solid rgba(46,204,113,0.2);
            color:var(--success);
        }
        .message-error {
            background:rgba(231,76,60,0.15);
            border:1px solid rgba(231,76,60,0.2);
            color:var(--danger);
        }
        .message-info {
            background:rgba(52,152,219,0.15);
            border:1px solid rgba(52,152,219,0.2);
            color:var(--info);
        }

        /* ===== TABLE ===== */
        .table {
            width:100%;
            border-collapse:collapse;
        }
        .table th {
            text-align:left;
            padding:0.6rem 0.8rem;
            color:#5a4a3a;
            font-weight:600;
            font-size:0.8rem;
            text-transform:uppercase;
            letter-spacing:0.5px;
            border-bottom:1px solid var(--border-color);
        }
        .table td {
            padding:0.6rem 0.8rem;
            border-bottom:1px solid rgba(255,255,255,0.05);
            color:#d4c0b0;
        }
        .table tr:hover td {
            background:rgba(255,255,255,0.02);
        }
        .table .status-badge {
            padding:0.1rem 0.5rem;
            border-radius:1rem;
            font-size:0.7rem;
            font-weight:600;
        }
        .table .status-badge.approved {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }
        .table .status-badge.pending {
            background:rgba(241,196,15,0.2);
            color:var(--warning);
        }
        .table .status-badge.reported {
            background:rgba(231,76,60,0.2);
            color:var(--danger);
        }
        .table .status-badge.completed {
            background:rgba(52,152,219,0.2);
            color:var(--info);
        }
        .table .status-badge.in_progress {
            background:rgba(46,204,113,0.2);
            color:var(--success);
        }

        /* ===== CHESS BOARD ===== */
        .chess-board-container {
            display:flex;
            justify-content:center;
            padding:0.5rem;
        }
        .chess-board {
            display:grid;
            grid-template-columns:repeat(8, 1fr);
            grid-template-rows:repeat(8, 1fr);
            width:100%;
            max-width:500px;
            aspect-ratio:1;
            border:3px solid var(--secondary);
            border-radius:4px;
            overflow:hidden;
        }
        .chess-board .square {
            display:flex;
            align-items:center;
            justify-content:center;
            font-size:2.5rem;
            cursor:pointer;
            transition:all 0.15s;
            aspect-ratio:1;
            user-select:none;
        }
        .chess-board .square.light {
            background:var(--light-square);
        }
        .chess-board .square.dark {
            background:var(--dark-square);
        }
        .chess-board .square.selected {
            background:rgba(255,255,0,0.4) !important;
        }
        .chess-board .square.legal-move {
            position:relative;
        }
        .chess-board .square.legal-move::after {
            content:'';
            position:absolute;
            width:30%;
            height:30%;
            background:rgba(0,0,0,0.15);
            border-radius:50%;
        }
        .chess-board .square.legal-capture {
            position:relative;
        }
        .chess-board .square.legal-capture::after {
            content:'';
            position:absolute;
            width:100%;
            height:100%;
            border:6px solid rgba(0,0,0,0.15);
            border-radius:50%;
            box-sizing:border-box;
        }
        .chess-board .square .piece {
            font-size:2.8rem;
            line-height:1;
            text-shadow:0 1px 3px rgba(0,0,0,0.3);
        }
        .chess-board .square .piece.white-piece {
            color:#fff;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.5));
        }
        .chess-board .square .piece.black-piece {
            color:#1a1a1a;
            filter:drop-shadow(0 1px 2px rgba(0,0,0,0.3));
        }

        /* ===== RESPONSIVE ===== */
        @media (max-width:768px) {
            :root { --nav-height:60px; --sidebar-width:0px; }
            .navbar-fixed { padding:0.5rem 1rem; }
            .navbar-left .logo-text { font-size:1rem; }
            .navbar-right .user-name { display:none; }
            
            .sidebar {
                transform:translateX(-100%);
                width:280px;
            }
            .sidebar.open {
                transform:translateX(0);
            }
            .sidebar-overlay {
                display:none;
                position:fixed;
                top:var(--nav-height);
                left:0; right:0; bottom:0;
                background:rgba(0,0,0,0.5);
                z-index:999;
            }
            .sidebar-overlay.active {
                display:block;
            }
            
            .main-content {
                margin-left:0;
                padding:1rem;
            }
            .welcome-card {
                flex-direction:column;
                text-align:center;
            }
            .welcome-card .welcome-actions {
                justify-content:center;
            }
            .stats-grid {
                grid-template-columns:repeat(2,1fr);
            }
            .content-grid {
                grid-template-columns:1fr;
            }
            .page-header {
                flex-direction:column;
                align-items:flex-start;
            }
            .page-header .header-actions {
                width:100%;
            }
            .page-header .header-actions .btn {
                flex:1;
                justify-content:center;
            }
            .chess-board .square .piece {
                font-size:2rem;
            }
        }
        @media (max-width:480px) {
            .stats-grid {
                grid-template-columns:1fr;
            }
            .user-item {
                flex-direction:column;
                align-items:flex-start;
                gap:0.3rem;
            }
            .user-item .user-actions {
                width:100%;
                justify-content:flex-start;
            }
            .chess-board .square .piece {
                font-size:1.5rem;
            }
        }

        /* ===== MOBILE SIDEBAR TOGGLE ===== */
        .sidebar-toggle {
            display:none;
            background:rgba(255,255,255,0.05);
            border:1px solid var(--border-color);
            border-radius:0.5rem;
            color:#d4c0b0;
            padding:0.5rem 0.8rem;
            cursor:pointer;
            transition:0.3s;
            font-size:1.2rem;
        }
        .sidebar-toggle:hover {
            border-color:var(--secondary);
            color:#f0d6b0;
        }
        @media (max-width:768px) {
            .sidebar-toggle {
                display:block;
            }
        }

        /* ===== SEARCH BAR ===== */
        .search-bar {
            display:flex;
            gap:0.5rem;
            margin-bottom:1rem;
        }
        .search-bar input {
            flex:1;
            padding:0.6rem 1rem;
            border-radius:0.8rem;
            border:1px solid var(--border-color);
            background:rgba(255,255,255,0.05);
            color:#f0d6b0;
            font-size:0.9rem;
        }
        .search-bar input::placeholder {
            color:#5a4a3a;
        }
        .search-bar input:focus {
            outline:none;
            border-color:var(--secondary);
        }
        .search-bar .btn {
            padding:0.6rem 1.2rem;
        }

        /* ===== GAME OVERSIGHT ===== */
        .game-oversight {
            display:grid;
            grid-template-columns:1fr 1fr;
            gap:1rem;
        }
        @media (max-width:768px) {
            .game-oversight {
                grid-template-columns:1fr;
            }
        }

        .game-status-bar {
            display:flex;
            justify-content:space-between;
            padding:0.5rem 0;
            border-bottom:1px solid var(--border-color);
            margin-bottom:0.5rem;
        }
        .game-status-bar .player {
            font-weight:600;
            color:#f0d6b0;
        }
        .game-status-bar .player i {
            margin-right:0.3rem;
        }
        .game-status-bar .move-info {
            color:#7a6a5a;
            font-size:0.85rem;
        }
    </style>
</head>
<body>
    <!-- ===== NAVBAR ===== -->
    <nav class="navbar-fixed" id="navbar">
        <div class="navbar-left">
            <button class="sidebar-toggle" id="sidebarToggle">
                <i class="fas fa-bars"></i>
            </button>
            <a href="index.php" class="navbar-logo">
                <span class="logo-icon"><i class="fas fa-chess-king"></i></span>
                <span class="logo-text">Chess Heaven</span>
            </a>
        </div>
        <div class="navbar-right">
            <span class="admin-badge">
                <i class="fas fa-crown"></i> <?php echo ucfirst($adminLevel); ?> Admin
            </span>
            <div class="notification-btn" onclick="switchTab('notifications')">
                <i class="fas fa-bell"></i>
                <?php if ($stats['pending_comments'] + $stats['pending_coaches'] > 0): ?>
                    <span class="badge"><?php echo $stats['pending_comments'] + $stats['pending_coaches']; ?></span>
                <?php endif; ?>
            </div>
            <div class="user-menu" onclick="switchTab('profile')">
                <div class="user-avatar"><?php echo strtoupper(substr($displayName, 0, 1)); ?></div>
                <span class="user-name"><?php echo e($displayName); ?> <span>· Admin</span></span>
            </div>
            <a href="logout.php" class="btn" style="border:1px solid var(--border-color);background:transparent;color:#7a6a5a;padding:0.4rem 0.8rem;border-radius:0.5rem;font-size:0.8rem;">
                <i class="fas fa-sign-out-alt"></i>
            </a>
        </div>
    </nav>

    <!-- ===== SIDEBAR OVERLAY (mobile) ===== -->
    <div class="sidebar-overlay" id="sidebarOverlay"></div>

    <!-- ===== SIDEBAR ===== -->
    <nav class="sidebar" id="sidebar">
        <div class="sidebar-section">
            <div class="section-title">Main</div>
            <a class="sidebar-item <?php echo $activeTab === 'dashboard' ? 'active' : ''; ?>" href="?tab=dashboard">
                <i class="fas fa-th-large"></i> Dashboard
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'profile' ? 'active' : ''; ?>" href="?tab=profile">
                <i class="fas fa-user"></i> My Profile
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Management</div>
            <a class="sidebar-item <?php echo $activeTab === 'users' ? 'active' : ''; ?>" href="?tab=users">
                <i class="fas fa-users"></i> User Management
                <span class="item-badge"><?php echo $stats['total_users']; ?></span>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'coaches' ? 'active' : ''; ?>" href="?tab=coaches">
                <i class="fas fa-chalkboard-teacher"></i> Coach Management
                <?php if ($stats['pending_coaches'] > 0): ?>
                    <span class="item-badge warning"><?php echo $stats['pending_coaches']; ?></span>
                <?php endif; ?>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'admins' ? 'active' : ''; ?>" href="?tab=admins">
                <i class="fas fa-user-shield"></i> Administrator Management
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Content</div>
            <a class="sidebar-item <?php echo $activeTab === 'content' ? 'active' : ''; ?>" href="?tab=content">
                <i class="fas fa-newspaper"></i> Content Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'courses' ? 'active' : ''; ?>" href="?tab=courses">
                <i class="fas fa-graduation-cap"></i> Course Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'puzzles' ? 'active' : ''; ?>" href="?tab=puzzles">
                <i class="fas fa-puzzle-piece"></i> Puzzle Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'tournaments' ? 'active' : ''; ?>" href="?tab=tournaments">
                <i class="fas fa-trophy"></i> Tournament Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'games' ? 'active' : ''; ?>" href="?tab=games">
                <i class="fas fa-chess"></i> Game Management
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Moderation</div>
            <a class="sidebar-item <?php echo $activeTab === 'comments' ? 'active' : ''; ?>" href="?tab=comments">
                <i class="fas fa-comment"></i> Comments & Reviews
                <?php if ($stats['pending_comments'] > 0): ?>
                    <span class="item-badge"><?php echo $stats['pending_comments']; ?></span>
                <?php endif; ?>
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'reports' ? 'active' : ''; ?>" href="?tab=reports">
                <i class="fas fa-flag"></i> Reports & Analytics
                <?php if ($stats['reports'] > 0): ?>
                    <span class="item-badge warning"><?php echo $stats['reports']; ?></span>
                <?php endif; ?>
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Communication</div>
            <a class="sidebar-item <?php echo $activeTab === 'notifications' ? 'active' : ''; ?>" href="?tab=notifications">
                <i class="fas fa-bell"></i> Notifications & Announcements
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'messages' ? 'active' : ''; ?>" href="?tab=messages">
                <i class="fas fa-envelope"></i> Messaging Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'feedback' ? 'active' : ''; ?>" href="?tab=feedback">
                <i class="fas fa-star"></i> Feedback Management
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Chess Play</div>
            <a class="sidebar-item <?php echo $activeTab === 'play' ? 'active' : ''; ?>" href="?tab=play">
                <i class="fas fa-chess-king"></i> Play Chess
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'oversee' ? 'active' : ''; ?>" href="?tab=oversee">
                <i class="fas fa-eye"></i> Oversee Games
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'challenge' ? 'active' : ''; ?>" href="?tab=challenge">
                <i class="fas fa-handshake"></i> Challenge Players
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">System</div>
            <a class="sidebar-item <?php echo $activeTab === 'files' ? 'active' : ''; ?>" href="?tab=files">
                <i class="fas fa-folder"></i> File Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'settings' ? 'active' : ''; ?>" href="?tab=settings">
                <i class="fas fa-cog"></i> System Settings
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'security' ? 'active' : ''; ?>" href="?tab=security">
                <i class="fas fa-shield-alt"></i> Security Management
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'database' ? 'active' : ''; ?>" href="?tab=database">
                <i class="fas fa-database"></i> Database & Backup
            </a>
            <a class="sidebar-item <?php echo $activeTab === 'audit' ? 'active' : ''; ?>" href="?tab=audit">
                <i class="fas fa-clipboard-list"></i> Audit Logs
            </a>
        </div>
        
        <div class="sidebar-section">
            <div class="section-title">Support</div>
            <a class="sidebar-item <?php echo $activeTab === 'help' ? 'active' : ''; ?>" href="?tab=help">
                <i class="fas fa-question-circle"></i> Help & Support
            </a>
        </div>
        
        <div class="sidebar-section" style="border-bottom:none;padding-top:0.5rem;">
            <a class="sidebar-item" href="logout.php" style="color:var(--danger);">
                <i class="fas fa-sign-out-alt"></i> Logout
            </a>
        </div>
    </nav>

    <!-- ===== MAIN CONTENT ===== -->
    <main class="main-content">
        <!-- ====== DASHBOARD TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'dashboard' ? 'active' : ''; ?>" id="tab-dashboard">
            <div class="page-header">
                <h1><i class="fas fa-th-large"></i> Administrator Dashboard</h1>
                <div class="header-actions">
                    <a href="?tab=users" class="btn btn-primary"><i class="fas fa-user-plus"></i> Add User</a>
                    <a href="?tab=content" class="btn btn-secondary"><i class="fas fa-plus"></i> New Content</a>
                    <a href="?tab=play" class="btn btn-chess"><i class="fas fa-chess-king"></i> Play Chess</a>
                </div>
            </div>

            <!-- Welcome Card -->
            <div class="welcome-card">
                <div class="welcome-text">
                    <h2>Welcome back, Admin <?php echo e($displayName); ?>! 👑</h2>
                    <p>Here's your system overview and management summary.</p>
                    <div class="admin-badge-large">
                        <i class="fas fa-crown"></i> <?php echo ucfirst($adminLevel); ?> Administrator · <?php echo e($department); ?> Department
                    </div>
                </div>
                <div class="welcome-actions">
                    <a href="?tab=users" class="btn btn-primary"><i class="fas fa-users"></i> Manage Users</a>
                    <a href="?tab=play" class="btn btn-chess"><i class="fas fa-chess-king"></i> Play Chess</a>
                    <a href="?tab=settings" class="btn btn-secondary"><i class="fas fa-cog"></i> Settings</a>
                </div>
            </div>

            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-value"><?php echo $stats['total_users']; ?></div>
                    <div class="stat-label">Total Users</div>
                    <span class="stat-change positive"><i class="fas fa-arrow-up"></i> <?php echo $stats['active_users']; ?> active</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-chalkboard-teacher"></i></div>
                    <div class="stat-value"><?php echo $stats['total_coaches']; ?></div>
                    <div class="stat-label">Total Coaches</div>
                    <?php if ($stats['pending_coaches'] > 0): ?>
                        <span class="stat-change warning"><i class="fas fa-clock"></i> <?php echo $stats['pending_coaches']; ?> pending</span>
                    <?php else: ?>
                        <span class="stat-change positive">All approved</span>
                    <?php endif; ?>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-user-shield"></i></div>
                    <div class="stat-value"><?php echo $stats['total_admins']; ?></div>
                    <div class="stat-label">Administrators</div>
                    <span class="stat-change">Active</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-chess"></i></div>
                    <div class="stat-value"><?php echo $stats['total_games']; ?></div>
                    <div class="stat-label">Total Games</div>
                    <span class="stat-change positive">+<?php echo rand(10, 50); ?> this week</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-trophy"></i></div>
                    <div class="stat-value"><?php echo $stats['total_tournaments']; ?></div>
                    <div class="stat-label">Tournaments</div>
                    <span class="stat-change positive"><?php echo rand(1, 3); ?> active</span>
                </div>
                <div class="stat-card">
                    <div class="stat-icon"><i class="fas fa-puzzle-piece"></i></div>
                    <div class="stat-value"><?php echo $stats['total_puzzles']; ?></div>
                    <div class="stat-label">Total Puzzles</div>
                    <span class="stat-change"><?php echo rand(5, 15); ?> new</span>
                </div>
            </div>

            <!-- Content Grid -->
            <div class="content-grid">
                <!-- Recent Activities -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-clock"></i> Recent Activities</h3>
                        <a href="?tab=audit" class="card-action">View All <i class="fas fa-arrow-right"></i></a>
                    </div>
                    <div class="card-body">
                        <?php foreach ($recentActivities as $activity): ?>
                            <div class="activity-item">
                                <div class="activity-icon">
                                    <i class="fas <?php echo strpos($activity['action'], 'Registered') !== false ? 'fa-user-plus' : (strpos($activity['action'], 'Created') !== false ? 'fa-plus' : (strpos($activity['action'], 'Approved') !== false ? 'fa-check' : (strpos($activity['action'], 'Reported') !== false ? 'fa-flag' : 'fa-info'))); ?>"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-text">
                                        <strong><?php echo e($activity['user']); ?></strong> <?php echo e($activity['action']); ?>
                                    </div>
                                    <div class="activity-time"><i class="fas fa-clock"></i> <?php echo e($activity['time']); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Quick Stats -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chart-bar"></i> Quick Stats</h3>
                    </div>
                    <div class="card-body">
                        <div style="display:grid;grid-template-columns:1fr 1fr;gap:0.8rem;">
                            <div style="background:rgba(255,255,255,0.03);padding:0.8rem;border-radius:0.8rem;text-align:center;">
                                <div style="font-size:1.5rem;font-weight:700;color:var(--secondary);"><?php echo $stats['total_articles']; ?></div>
                                <div style="font-size:0.8rem;color:#5a4a3a;">Articles</div>
                            </div>
                            <div style="background:rgba(255,255,255,0.03);padding:0.8rem;border-radius:0.8rem;text-align:center;">
                                <div style="font-size:1.5rem;font-weight:700;color:var(--secondary);"><?php echo $stats['pending_comments']; ?></div>
                                <div style="font-size:0.8rem;color:#5a4a3a;">Pending Comments</div>
                            </div>
                            <div style="background:rgba(255,255,255,0.03);padding:0.8rem;border-radius:0.8rem;text-align:center;">
                                <div style="font-size:1.5rem;font-weight:700;color:var(--secondary);"><?php echo $stats['pending_coaches']; ?></div>
                                <div style="font-size:0.8rem;color:#5a4a3a;">Pending Coaches</div>
                            </div>
                            <div style="background:rgba(255,255,255,0.03);padding:0.8rem;border-radius:0.8rem;text-align:center;">
                                <div style="font-size:1.5rem;font-weight:700;color:var(--secondary);"><?php echo $stats['reports']; ?></div>
                                <div style="font-size:0.8rem;color:#5a4a3a;">Active Reports</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== PROFILE TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'profile' ? 'active' : ''; ?>" id="tab-profile">
            <div class="page-header">
                <h1><i class="fas fa-user"></i> My Profile</h1>
                <div class="header-actions">
                    <button class="btn btn-primary" onclick="document.getElementById('profileForm').submit();">
                        <i class="fas fa-save"></i> Save Changes
                    </button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'profile'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid" style="grid-template-columns:1fr 2fr;">
                <div class="card" style="text-align:center;">
                    <div class="user-avatar" style="width:120px;height:120px;border-radius:50%;margin:0 auto 1rem;font-size:3rem;background:linear-gradient(145deg,var(--primary),var(--primary-dark));display:flex;align-items:center;justify-content:center;color:white;">
                        <?php echo strtoupper(substr($displayName, 0, 1)); ?>
                    </div>
                    <h3 style="color:#f0d6b0;"><?php echo e($displayName); ?></h3>
                    <p style="color:#7a6a5a;">@<?php echo e($username); ?></p>
                    <p style="color:var(--secondary);">
                        <i class="fas fa-crown"></i> <?php echo ucfirst($adminLevel); ?> Administrator
                    </p>
                    <p style="color:#5a4a3a;font-size:0.85rem;">
                        <i class="fas fa-building"></i> <?php echo e($department); ?> Department
                    </p>
                    <button class="btn btn-secondary" style="margin-top:0.8rem;width:100%;">
                        <i class="fas fa-camera"></i> Change Photo
                    </button>
                </div>

                <div class="card">
                    <form id="profileForm" method="POST">
                        <input type="hidden" name="update_profile" value="1">
                        <div class="form-group">
                            <label>Display Name</label>
                            <input type="text" name="display_name" class="form-control" value="<?php echo e($displayName); ?>">
                        </div>
                        <div class="form-group">
                            <label>Email</label>
                            <input type="email" class="form-control" value="<?php echo e($email); ?>" disabled>
                            <div class="form-hint">Email cannot be changed. Contact support for assistance.</div>
                        </div>
                        <div class="form-group">
                            <label>Administrator Level</label>
                            <select name="admin_level" class="form-control">
                                <option value="super" <?php echo $adminLevel === 'super' ? 'selected' : ''; ?>>Super Administrator</option>
                                <option value="moderator" <?php echo $adminLevel === 'moderator' ? 'selected' : ''; ?>>Moderator</option>
                                <option value="support" <?php echo $adminLevel === 'support' ? 'selected' : ''; ?>>Support</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Department</label>
                            <input type="text" name="department" class="form-control" value="<?php echo e($department); ?>" placeholder="e.g., Management, Technical">
                        </div>
                    </form>
                </div>
            </div>

            <!-- Change Password -->
            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-lock"></i> Change Password</h3>
                </div>
                <div class="card-body">
                    <form method="POST" style="max-width:400px;">
                        <input type="hidden" name="change_password" value="1">
                        <div class="form-group">
                            <label>Current Password</label>
                            <input type="password" name="current_password" class="form-control" placeholder="Enter current password" required>
                        </div>
                        <div class="form-group">
                            <label>New Password</label>
                            <input type="password" name="new_password" class="form-control" placeholder="Min 6 characters" required>
                        </div>
                        <div class="form-group">
                            <label>Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-key"></i> Change Password
                        </button>
                    </form>
                </div>
            </div>
        </div>

        <!-- ====== USER MANAGEMENT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'users' ? 'active' : ''; ?>" id="tab-users">
            <div class="page-header">
                <h1><i class="fas fa-users"></i> User Management</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-user-plus"></i> Add User</button>
                    <button class="btn btn-secondary"><i class="fas fa-download"></i> Export</button>
                </div>
            </div>

            <div class="search-bar">
                <input type="text" placeholder="Search users by username, email, or role..." />
                <button class="btn btn-primary"><i class="fas fa-search"></i> Search</button>
                <select class="form-control" style="width:auto;padding:0.6rem 1rem;background:rgba(255,255,255,0.05);border:1px solid var(--border-color);border-radius:0.8rem;color:#d4c0b0;">
                    <option>All Roles</option>
                    <option>Members</option>
                    <option>Coaches</option>
                    <option>Admins</option>
                </select>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> All Users (<?php echo $stats['total_users']; ?>)</h3>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Joined</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                                <tr>
                                    <td><strong style="color:#f0d6b0;"><?php echo e($user['username']); ?></strong></td>
                                    <td><?php echo e($user['email']); ?></td>
                                    <td><span class="status-badge <?php echo $user['role']; ?>"><?php echo ucfirst($user['role']); ?></span></td>
                                    <td><?php echo e($user['joined']); ?></td>
                                    <td><span class="user-status <?php echo $user['status']; ?>"><?php echo ucfirst($user['status']); ?></span></td>
                                    <td>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-key"></i>
                                        </button>
                                        <button class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;" title="Challenge to game">
                                            <i class="fas fa-chess-king"></i>
                                        </button>
                                        <button class="btn btn-danger" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== COACH MANAGEMENT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'coaches' ? 'active' : ''; ?>" id="tab-coaches">
            <div class="page-header">
                <h1><i class="fas fa-chalkboard-teacher"></i> Coach Management</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-user-plus"></i> Add Coach</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> All Coaches</h3>
                    <?php if ($stats['pending_coaches'] > 0): ?>
                        <span class="item-badge warning" style="padding:0.2rem 0.8rem;"><?php echo $stats['pending_coaches']; ?> pending approval</span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Coach</th>
                                <th>Specialization</th>
                                <th>Students</th>
                                <th>Rating</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($coaches as $coach): ?>
                                <tr>
                                    <td><strong style="color:#f0d6b0;"><?php echo e($coach['name']); ?></strong></td>
                                    <td><?php echo e($coach['specialization']); ?></td>
                                    <td><?php echo $coach['students']; ?></td>
                                    <td><?php echo $coach['rating']; ?></td>
                                    <td><span class="user-status <?php echo $coach['status']; ?>"><?php echo ucfirst($coach['status']); ?></span></td>
                                    <td>
                                        <?php if ($coach['status'] === 'pending'): ?>
                                            <button class="btn btn-success" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                                <i class="fas fa-check"></i> Approve
                                            </button>
                                        <?php endif; ?>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;" title="Challenge to game">
                                            <i class="fas fa-chess-king"></i>
                                        </button>
                                        <button class="btn btn-danger" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== TOURNAMENT MANAGEMENT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'tournaments' ? 'active' : ''; ?>" id="tab-tournaments">
            <div class="page-header">
                <h1><i class="fas fa-trophy"></i> Tournament Management</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Create Tournament</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> All Tournaments</h3>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Tournament</th>
                                <th>Date</th>
                                <th>Players</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tournaments as $tournament): ?>
                                <tr>
                                    <td><strong style="color:#f0d6b0;"><?php echo e($tournament['name']); ?></strong></td>
                                    <td><?php echo e($tournament['date']); ?></td>
                                    <td><?php echo $tournament['players']; ?></td>
                                    <td><span class="status-badge <?php echo $tournament['status']; ?>"><?php echo ucfirst($tournament['status']); ?></span></td>
                                    <td>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button class="btn btn-secondary" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-users"></i>
                                        </button>
                                        <button class="btn btn-danger" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== COMMENTS & REVIEWS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'comments' ? 'active' : ''; ?>" id="tab-comments">
            <div class="page-header">
                <h1><i class="fas fa-comment"></i> Comments & Reviews</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-filter"></i> Filter</button>
                </div>
            </div>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-list"></i> All Comments</h3>
                    <?php if ($stats['pending_comments'] > 0): ?>
                        <span class="item-badge warning" style="padding:0.2rem 0.8rem;"><?php echo $stats['pending_comments']; ?> pending moderation</span>
                    <?php endif; ?>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>Author</th>
                                <th>Content</th>
                                <th>Type</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($comments as $comment): ?>
                                <tr>
                                    <td><strong style="color:#f0d6b0;"><?php echo e($comment['author']); ?></strong></td>
                                    <td><?php echo e(substr($comment['content'], 0, 50)); ?>...</td>
                                    <td><?php echo ucfirst($comment['type']); ?></td>
                                    <td><?php echo e($comment['date']); ?></td>
                                    <td><span class="status-badge <?php echo $comment['status']; ?>"><?php echo ucfirst($comment['status']); ?></span></td>
                                    <td>
                                        <?php if ($comment['status'] === 'pending'): ?>
                                            <button class="btn btn-success" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                                <i class="fas fa-check"></i>
                                            </button>
                                        <?php endif; ?>
                                        <?php if ($comment['status'] === 'reported'): ?>
                                            <button class="btn btn-warning" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                                <i class="fas fa-eye"></i>
                                            </button>
                                        <?php endif; ?>
                                        <button class="btn btn-danger" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <!-- ====== NOTIFICATIONS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'notifications' ? 'active' : ''; ?>" id="tab-notifications">
            <div class="page-header">
                <h1><i class="fas fa-bell"></i> Notifications & Announcements</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Send Announcement</button>
                </div>
            </div>

            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-bullhorn"></i> Send Announcement</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Title</label>
                            <input type="text" class="form-control" placeholder="Announcement title">
                        </div>
                        <div class="form-group">
                            <label>Content</label>
                            <textarea class="form-control" placeholder="Write your announcement here..." rows="4"></textarea>
                        </div>
                        <div class="form-group">
                            <label>Audience</label>
                            <select class="form-control">
                                <option>All Users</option>
                                <option>Members Only</option>
                                <option>Coaches Only</option>
                                <option>Admins Only</option>
                            </select>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Announcement</button>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-history"></i> Recent Announcements</h3>
                    </div>
                    <div class="card-body">
                        <div class="activity-item">
                            <div class="activity-icon"><i class="fas fa-bullhorn"></i></div>
                            <div class="activity-content">
                                <div class="activity-text"><strong>System Update</strong> - New features available</div>
                                <div class="activity-time"><i class="fas fa-clock"></i> 1 day ago</div>
                            </div>
                        </div>
                        <div class="activity-item">
                            <div class="activity-icon"><i class="fas fa-bullhorn"></i></div>
                            <div class="activity-content">
                                <div class="activity-text"><strong>Tournament Reminder</strong> - Registration closing soon</div>
                                <div class="activity-time"><i class="fas fa-clock"></i> 3 days ago</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== PLAY CHESS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'play' ? 'active' : ''; ?>" id="tab-play">
            <div class="page-header">
                <h1><i class="fas fa-chess-king"></i> Play Chess</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary" onclick="resetBoard()"><i class="fas fa-undo"></i> Reset Board</button>
                    <button class="btn btn-chess" onclick="flipBoard()"><i class="fas fa-arrows-alt-h"></i> Flip Board</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'play'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-chess-board"></i> Chess Board</h3>
                        <span id="turn-indicator" style="color:var(--gold);font-weight:600;">
                            <i class="fas fa-circle" style="color:#f0d9b5;"></i> White's Turn
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="chess-board-container">
                            <div class="chess-board" id="chessBoard"></div>
                        </div>
                        <div style="display:flex;justify-content:space-between;margin-top:0.8rem;padding:0.5rem;background:rgba(255,255,255,0.03);border-radius:0.5rem;">
                            <span id="move-count" style="color:#7a6a5a;">Moves: 0</span>
                            <span id="game-status" style="color:var(--gold);">Game in progress</span>
                            <button class="btn btn-chess" style="padding:0.3rem 0.8rem;font-size:0.75rem;" onclick="undoMove()">
                                <i class="fas fa-undo-alt"></i> Undo
                            </button>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-exchange-alt"></i> Game Controls</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Play Against</label>
                            <select class="form-control" id="playMode" onchange="changePlayMode()">
                                <option value="ai">Computer (AI)</option>
                                <option value="local">Local (2 Players)</option>
                                <option value="online">Online Player</option>
                            </select>
                        </div>
                        <div id="online-opponent-section" style="display:none;">
                            <div class="form-group">
                                <label>Select Opponent</label>
                                <select class="form-control" id="opponentSelect">
                                    <?php foreach ($onlineUsers as $opponent): ?>
                                        <option value="<?php echo $opponent['id']; ?>">
                                            <?php echo e($opponent['username']); ?> (<?php echo $opponent['role']; ?>) - <?php echo $opponent['rating']; ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Time Control (minutes)</label>
                                <select class="form-control" id="timeControl">
                                    <option value="5">5 min (Blitz)</option>
                                    <option value="10">10 min (Rapid)</option>
                                    <option value="30" selected>30 min (Classical)</option>
                                    <option value="60">60 min (Long)</option>
                                </select>
                            </div>
                            <button class="btn btn-chess" onclick="requestOnlineGame()" style="width:100%;">
                                <i class="fas fa-handshake"></i> Request Game
                            </button>
                        </div>
                        <div id="ai-section">
                            <div class="form-group">
                                <label>AI Difficulty</label>
                                <select class="form-control" id="aiDifficulty">
                                    <option value="easy">Easy</option>
                                    <option value="medium" selected>Medium</option>
                                    <option value="hard">Hard</option>
                                </select>
                            </div>
                            <button class="btn btn-chess" onclick="playAIMove()" style="width:100%;">
                                <i class="fas fa-robot"></i> AI Makes Move
                            </button>
                        </div>
                        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color);">
                            <div class="form-group">
                                <label>Piece Color</label>
                                <select class="form-control" id="playerColor">
                                    <option value="white">White</option>
                                    <option value="black">Black</option>
                                    <option value="random">Random</option>
                                </select>
                            </div>
                            <button class="btn btn-primary" onclick="startNewGame()" style="width:100%;">
                                <i class="fas fa-play"></i> Start New Game
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== OVERSEE GAMES TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'oversee' ? 'active' : ''; ?>" id="tab-oversee">
            <div class="page-header">
                <h1><i class="fas fa-eye"></i> Oversee Games</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-refresh"></i> Refresh</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'oversee'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="content-grid game-oversight">
                <!-- Active Games List -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-gamepad"></i> Active Games</h3>
                        <span class="card-action"><?php echo count($activeGames); ?> games</span>
                    </div>
                    <div class="card-body">
                        <?php foreach ($activeGames as $game): ?>
                            <div class="activity-item" style="border-bottom:1px solid rgba(255,255,255,0.05);padding:0.8rem 0;">
                                <div class="activity-icon">
                                    <i class="fas fa-chess"></i>
                                </div>
                                <div class="activity-content">
                                    <div class="activity-text">
                                        <strong><?php echo e($game['white']); ?></strong> 
                                        <span style="color:#7a6a5a;">vs</span> 
                                        <strong><?php echo e($game['black']); ?></strong>
                                    </div>
                                    <div style="display:flex;gap:1rem;font-size:0.8rem;color:#5a4a3a;margin-top:0.2rem;">
                                        <span><i class="fas fa-chess-knight"></i> Move <?php echo $game['move']; ?></span>
                                        <span><i class="fas fa-clock"></i> <?php echo $game['time']; ?></span>
                                        <span><span class="status-badge in_progress"><?php echo str_replace('_', ' ', $game['status']); ?></span></span>
                                    </div>
                                </div>
                                <form method="POST" style="margin-left:auto;">
                                    <input type="hidden" name="game_id" value="<?php echo $game['id']; ?>">
                                    <button type="submit" name="oversee_game" class="btn btn-chess" style="padding:0.2rem 0.6rem;font-size:0.75rem;">
                                        <i class="fas fa-eye"></i> Oversee
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Game Oversight View -->
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-desktop"></i> Game Oversight</h3>
                        <span class="card-action" id="oversee-game-id">No game selected</span>
                    </div>
                    <div class="card-body" id="overseeBoardContainer">
                        <div style="text-align:center;padding:2rem;color:#5a4a3a;">
                            <i class="fas fa-eye" style="font-size:3rem;display:block;margin-bottom:1rem;"></i>
                            <p>Select a game above to oversee it in real-time.</p>
                            <p style="font-size:0.85rem;">You can view all moves and monitor the game progress.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== CHALLENGE PLAYERS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'challenge' ? 'active' : ''; ?>" id="tab-challenge">
            <div class="page-header">
                <h1><i class="fas fa-handshake"></i> Challenge Players</h1>
                <div class="header-actions">
                    <button class="btn btn-secondary"><i class="fas fa-filter"></i> Filter</button>
                </div>
            </div>

            <?php if ($message && $activeTab === 'challenge'): ?>
                <div class="message message-<?php echo $messageType; ?>">
                    <i class="fas fa-<?php echo $messageType === 'success' ? 'check-circle' : 'exclamation-circle'; ?>"></i>
                    <?php echo e($message); ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-users"></i> Online Players</h3>
                    <span class="card-action"><?php echo count($onlineUsers); ?> online</span>
                </div>
                <div class="card-body">
                    <?php foreach ($onlineUsers as $player): ?>
                        <div class="user-item">
                            <div class="user-info">
                                <div class="user-avatar-sm"><?php echo strtoupper(substr($player['username'], 0, 1)); ?></div>
                                <div>
                                    <strong style="color:#f0d6b0;"><?php echo e($player['username']); ?></strong>
                                    <span style="color:#5a4a3a;font-size:0.8rem;"> · <?php echo ucfirst($player['role']); ?></span>
                                    <div style="font-size:0.75rem;color:#7a6a5a;">
                                        <i class="fas fa-star" style="color:var(--gold);"></i> <?php echo $player['rating']; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="user-actions">
                                <span class="user-status online"><i class="fas fa-circle"></i> Online</span>
                                <form method="POST" style="display:inline;">
                                    <input type="hidden" name="opponent_id" value="<?php echo $player['id']; ?>">
                                    <input type="hidden" name="time_control" value="30">
                                    <input type="hidden" name="color" value="random">
                                    <button type="submit" name="request_game" class="btn btn-chess">
                                        <i class="fas fa-handshake"></i> Challenge
                                    </button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-history"></i> Recent Challenges</h3>
                </div>
                <div class="card-body">
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-handshake"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>You</strong> challenged <strong>GrandMasterX</strong> to a game</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 5 minutes ago · <span style="color:var(--warning);">Awaiting response</span></div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-check-circle" style="color:var(--success);"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>CoachMike</strong> accepted your challenge</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 1 hour ago · <span style="color:var(--success);">Game in progress</span></div>
                        </div>
                    </div>
                    <div class="activity-item">
                        <div class="activity-icon"><i class="fas fa-times-circle" style="color:var(--danger);"></i></div>
                        <div class="activity-content">
                            <div class="activity-text"><strong>JohnDoe</strong> declined your challenge</div>
                            <div class="activity-time"><i class="fas fa-clock"></i> 3 hours ago · <span style="color:var(--danger);">Declined</span></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== SYSTEM SETTINGS TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'settings' ? 'active' : ''; ?>" id="tab-settings">
            <div class="page-header">
                <h1><i class="fas fa-cog"></i> System Settings</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-save"></i> Save Settings</button>
                </div>
            </div>

            <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-globe"></i> General Settings</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Website Name</label>
                            <input type="text" class="form-control" value="♚ Chess Heaven">
                        </div>
                        <div class="form-group">
                            <label>Website URL</label>
                            <input type="text" class="form-control" value="https://chessheaven.org">
                        </div>
                        <div class="form-group">
                            <label>Default Language</label>
                            <select class="form-control">
                                <option>English</option>
                                <option>Spanish</option>
                                <option>French</option>
                                <option>German</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Time Zone</label>
                            <select class="form-control">
                                <option>UTC</option>
                                <option>America/New_York</option>
                                <option>Europe/London</option>
                                <option>Asia/Dubai</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-palette"></i> Appearance Settings</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Theme</label>
                            <select class="form-control">
                                <option>Dark Mode (Default)</option>
                                <option>Light Mode</option>
                                <option>System Default</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Primary Color</label>
                            <input type="color" class="form-control" value="#8B1A1A" style="padding:0.2rem;height:50px;">
                        </div>
                        <div class="form-group">
                            <label>Homepage Banner</label>
                            <input type="file" class="form-control" style="padding:0.5rem;">
                            <div class="form-hint">Recommended size: 1920x500px</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="card" style="margin-top:1.5rem;">
                <div class="card-header">
                    <h3><i class="fas fa-envelope"></i> Email Settings</h3>
                </div>
                <div class="card-body">
                    <div class="content-grid" style="grid-template-columns:1fr 1fr;">
                        <div>
                            <div class="form-group">
                                <label>SMTP Host</label>
                                <input type="text" class="form-control" value="smtp.gmail.com">
                            </div>
                            <div class="form-group">
                                <label>SMTP Port</label>
                                <input type="text" class="form-control" value="587">
                            </div>
                            <div class="form-group">
                                <label>SMTP Username</label>
                                <input type="text" class="form-control" value="noreply@chessheaven.org">
                            </div>
                        </div>
                        <div>
                            <div class="form-group">
                                <label>SMTP Password</label>
                                <input type="password" class="form-control" value="********">
                            </div>
                            <div class="form-group">
                                <label>From Email</label>
                                <input type="text" class="form-control" value="noreply@chessheaven.org">
                            </div>
                            <div class="form-group">
                                <label>From Name</label>
                                <input type="text" class="form-control" value="Chess Heaven">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====== HELP & SUPPORT TAB ====== -->
        <div class="tab-content <?php echo $activeTab === 'help' ? 'active' : ''; ?>" id="tab-help">
            <div class="page-header">
                <h1><i class="fas fa-question-circle"></i> Help & Support</h1>
                <div class="header-actions">
                    <button class="btn btn-primary"><i class="fas fa-plus"></i> Add FAQ</button>
                </div>
            </div>

            <div class="content-grid">
                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-question"></i> FAQs</h3>
                    </div>
                    <div class="card-body">
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I add a new user?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to User Management and click "Add User". Fill in the user's details and assign a role.</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I approve a coach?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to Coach Management, find the pending coach, and click "Approve".</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I create a tournament?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to Tournament Management and click "Create Tournament". Fill in the details and publish.</p>
                        </div>
                        <div style="margin-bottom:1rem;">
                            <h4 style="color:#f0d6b0;font-size:0.9rem;">How do I challenge another player?</h4>
                            <p style="color:#7a6a5a;font-size:0.85rem;">Go to Challenge Players, find an online player, and click "Challenge".</p>
                        </div>
                    </div>
                </div>

                <div class="card">
                    <div class="card-header">
                        <h3><i class="fas fa-headset"></i> Support</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-group">
                            <label>Subject</label>
                            <input type="text" class="form-control" placeholder="Brief description">
                        </div>
                        <div class="form-group">
                            <label>Message</label>
                            <textarea class="form-control" placeholder="Describe your issue..." rows="4"></textarea>
                        </div>
                        <button class="btn btn-primary"><i class="fas fa-paper-plane"></i> Send Message</button>
                        <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--border-color);">
                            <p style="color:#5a4a3a;font-size:0.85rem;">
                                <i class="fas fa-envelope"></i> admin-support@chessheaven.org
                            </p>
                            <p style="color:#5a4a3a;font-size:0.85rem;">
                                <i class="fas fa-clock"></i> Response time: 12-24 hours
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- ===== JAVASCRIPT ===== -->
    <script>
        // ===== CHESS ENGINE =====
        // Chess piece symbols
        const PIECES = {
            'K': '♔', 'Q': '♕', 'R': '♖', 'B': '♗', 'N': '♘', 'P': '♙',
            'k': '♚', 'q': '♛', 'r': '♜', 'b': '♝', 'n': '♞', 'p': '♟'
        };

        // Initial board setup
        const INITIAL_BOARD = [
            ['r', 'n', 'b', 'q', 'k', 'b', 'n', 'r'],
            ['p', 'p', 'p', 'p', 'p', 'p', 'p', 'p'],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['', '', '', '', '', '', '', ''],
            ['P', 'P', 'P', 'P', 'P', 'P', 'P', 'P'],
            ['R', 'N', 'B', 'Q', 'K', 'B', 'N', 'R']
        ];

        // State
        let board = JSON.parse(JSON.stringify(INITIAL_BOARD));
        let currentTurn = 'white';
        let selectedSquare = null;
        let moveHistory = [];
        let moveCount = 0;
        let isFlipped = false;
        let gameOver = false;
        let playMode = 'ai';
        let playerColor = 'white';
        let moveList = [];
        let isAIMoving = false;
        let gameOverseeId = null;

        // File ranks for notation
        const FILES = 'abcdefgh';

        // ===== BOARD RENDERING =====
        function renderBoard() {
            const boardEl = document.getElementById('chessBoard');
            if (!boardEl) return;
            
            boardEl.innerHTML = '';
            
            for (let row = 0; row < 8; row++) {
                for (let col = 0; col < 8; col++) {
                    const square = document.createElement('div');
                    const actualRow = isFlipped ? 7 - row : row;
                    const actualCol = isFlipped ? 7 - col : col;
                    const isLight = (row + col) % 2 === 0;
                    square.className = `square ${isLight ? 'light' : 'dark'}`;
                    square.dataset.row = actualRow;
                    square.dataset.col = actualCol;
                    
                    const piece = board[actualRow][actualCol];
                    if (piece) {
                        const pieceSpan = document.createElement('span');
                        pieceSpan.className = `piece ${piece === piece.toUpperCase() ? 'white-piece' : 'black-piece'}`;
                        pieceSpan.textContent = PIECES[piece] || piece;
                        square.appendChild(pieceSpan);
                    }
                    
                    // Highlight selected square
                    if (selectedSquare && selectedSquare.row === actualRow && selectedSquare.col === actualCol) {
                        square.classList.add('selected');
                    }
                    
                    // Show legal moves
                    if (selectedSquare) {
                        const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                        for (const move of legalMoves) {
                            if (move.row === actualRow && move.col === actualCol) {
                                if (board[actualRow][actualCol]) {
                                    square.classList.add('legal-capture');
                                } else {
                                    square.classList.add('legal-move');
                                }
                            }
                        }
                    }
                    
                    square.addEventListener('click', () => onSquareClick(actualRow, actualCol));
                    boardEl.appendChild(square);
                }
            }
            
            updateTurnIndicator();
        }

        // ===== TURN INDICATOR =====
        function updateTurnIndicator() {
            const indicator = document.getElementById('turn-indicator');
            if (!indicator) return;
            if (gameOver) {
                indicator.innerHTML = '<i class="fas fa-flag-checkered"></i> Game Over';
                return;
            }
            const colorName = currentTurn === 'white' ? 'White' : 'Black';
            const colorIcon = currentTurn === 'white' ? '#f0d9b5' : '#1a1a1a';
            indicator.innerHTML = `<i class="fas fa-circle" style="color:${colorIcon};"></i> ${colorName}'s Turn`;
        }

        // ===== MOVE GENERATION =====
        function getLegalMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const direction = isWhite ? -1 : 1;
                    // Forward
                    if (row + direction >= 0 && row + direction < 8 && !board[row + direction][col]) {
                        moves.push({row: row + direction, col: col});
                        // Double move from starting position
                        const startRow = isWhite ? 6 : 1;
                        if (row === startRow && !board[row + 2 * direction][col]) {
                            moves.push({row: row + 2 * direction, col: col});
                        }
                    }
                    // Captures
                    for (const dcol of [-1, 1]) {
                        const newCol = col + dcol;
                        if (newCol >= 0 && newCol < 8 && row + direction >= 0 && row + direction < 8) {
                            const target = board[row + direction][newCol];
                            if (target && (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: row + direction, col: newCol});
                            }
                        }
                    }
                    break;
                    
                case 'n':
                    const knightMoves = [
                        [-2, -1], [-2, 1], [-1, -2], [-1, 2],
                        [1, -2], [1, 2], [2, -1], [2, 1]
                    ];
                    for (const [dr, dc] of knightMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
                    
                case 'b':
                case 'r':
                case 'q':
                    const directions = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                                      piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                                      [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of directions) {
                        for (let i = 1; i < 8; i++) {
                            const newRow = row + dr * i, newCol = col + dc * i;
                            if (newRow < 0 || newRow >= 8 || newCol < 0 || newCol >= 8) break;
                            const target = board[newRow][newCol];
                            if (target) {
                                if (isWhite ? target === target.toLowerCase() : target === target.toUpperCase()) {
                                    moves.push({row: newRow, col: newCol});
                                }
                                break;
                            }
                            moves.push({row: newRow, col: newCol});
                        }
                    }
                    break;
                    
                case 'k':
                    const kingMoves = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of kingMoves) {
                        const newRow = row + dr, newCol = col + dc;
                        if (newRow >= 0 && newRow < 8 && newCol >= 0 && newCol < 8) {
                            const target = board[newRow][newCol];
                            if (!target || (isWhite ? target === target.toLowerCase() : target === target.toUpperCase())) {
                                moves.push({row: newRow, col: newCol});
                            }
                        }
                    }
                    break;
            }
            
            // Filter out moves that leave king in check
            return moves.filter(move => !wouldBeInCheck(row, col, move.row, move.col));
        }

        function wouldBeInCheck(fromRow, fromCol, toRow, toCol) {
            const piece = board[fromRow][fromCol];
            const isWhite = piece === piece.toUpperCase();
            
            // Simulate move
            const captured = board[toRow][toCol];
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            // Find king
            let kingRow, kingCol;
            const kingPiece = isWhite ? 'K' : 'k';
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    if (board[r][c] === kingPiece) {
                        kingRow = r; kingCol = c;
                        break;
                    }
                }
                if (kingRow !== undefined) break;
            }
            
            let inCheck = false;
            if (kingRow !== undefined) {
                // Check if any opponent piece attacks king
                const opponent = isWhite ? 'black' : 'white';
                for (let r = 0; r < 8; r++) {
                    for (let c = 0; c < 8; c++) {
                        const p = board[r][c];
                        if (p && (opponent === 'white' ? p === p.toUpperCase() : p === p.toLowerCase())) {
                            // Simplified attack check
                            const attacks = getRawMoves(r, c);
                            for (const attack of attacks) {
                                if (attack.row === kingRow && attack.col === kingCol) {
                                    inCheck = true;
                                    break;
                                }
                            }
                        }
                        if (inCheck) break;
                    }
                    if (inCheck) break;
                }
            }
            
            // Undo simulation
            board[fromRow][fromCol] = piece;
            board[toRow][toCol] = captured;
            
            return inCheck;
        }

        function getRawMoves(row, col) {
            const piece = board[row][col];
            if (!piece) return [];
            const isWhite = piece === piece.toUpperCase();
            const moves = [];
            
            switch (piece.toLowerCase()) {
                case 'p':
                    const dir = isWhite ? -1 : 1;
                    if (row + dir >= 0 && row + dir < 8 && !board[row + dir][col]) {
                        moves.push({row: row + dir, col: col});
                    }
                    for (const dc of [-1, 1]) {
                        const nc = col + dc;
                        if (nc >= 0 && nc < 8 && row + dir >= 0 && row + dir < 8) {
                            if (board[row + dir][nc]) moves.push({row: row + dir, col: nc});
                        }
                    }
                    break;
                case 'n':
                    const nm = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
                    for (const [dr, dc] of nm) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
                case 'b':
                case 'r':
                case 'q':
                    const dirs = piece.toLowerCase() === 'b' ? [[1,1],[1,-1],[-1,1],[-1,-1]] :
                               piece.toLowerCase() === 'r' ? [[1,0],[-1,0],[0,1],[0,-1]] :
                               [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of dirs) {
                        for (let i = 1; i < 8; i++) {
                            const nr = row + dr * i, nc = col + dc * i;
                            if (nr < 0 || nr >= 8 || nc < 0 || nc >= 8) break;
                            moves.push({row: nr, col: nc});
                            if (board[nr][nc]) break;
                        }
                    }
                    break;
                case 'k':
                    const km = [[1,0],[-1,0],[0,1],[0,-1],[1,1],[1,-1],[-1,1],[-1,-1]];
                    for (const [dr, dc] of km) {
                        const nr = row + dr, nc = col + dc;
                        if (nr >= 0 && nr < 8 && nc >= 0 && nc < 8) moves.push({row: nr, col: nc});
                    }
                    break;
            }
            return moves;
        }

        // ===== GAME LOGIC =====
        function onSquareClick(row, col) {
            if (gameOver || isAIMoving) return;
            
            const piece = board[row][col];
            const isWhiteTurn = currentTurn === 'white';
            const isWhitePiece = piece && piece === piece.toUpperCase();
            
            // If a piece is already selected
            if (selectedSquare) {
                // Check if clicking on a legal move destination
                const legalMoves = getLegalMoves(selectedSquare.row, selectedSquare.col);
                const isLegal = legalMoves.some(m => m.row === row && m.col === col);
                
                if (isLegal) {
                    // Make the move
                    makeMove(selectedSquare.row, selectedSquare.col, row, col);
                    selectedSquare = null;
                    renderBoard();
                    return;
                }
                
                // If clicking on own piece, select it instead
                if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                    selectedSquare = {row, col};
                    renderBoard();
                    return;
                }
                
                // Deselect
                selectedSquare = null;
                renderBoard();
                return;
            }
            
            // Select a piece
            if (piece && ((isWhiteTurn && isWhitePiece) || (!isWhiteTurn && !isWhitePiece))) {
                selectedSquare = {row, col};
                renderBoard();
            }
        }

        function makeMove(fromRow, fromCol, toRow, toCol) {
            const piece = board[fromRow][fromCol];
            const captured = board[toRow][toCol];
            
            // Store move for undo
            moveHistory.push({
                fromRow, fromCol, toRow, toCol,
                piece, captured,
                previousBoard: JSON.parse(JSON.stringify(board))
            });
            
            // Execute move
            board[toRow][toCol] = piece;
            board[fromRow][fromCol] = '';
            
            // Pawn promotion
            if (piece.toLowerCase() === 'p' && (toRow === 0 || toRow === 7)) {
                board[toRow][toCol] = piece === 'P' ? 'Q' : 'q';
            }
            
            moveCount++;
            moveList.push(`${FILES[fromCol]}${8 - fromRow}${FILES[toCol]}${8 - toRow}`);
            
            // Update move count display
            const moveCountEl = document.getElementById('move-count');
            if (moveCountEl) moveCountEl.textContent = `Moves: ${moveCount}`;
            
            // Switch turn
            currentTurn = currentTurn === 'white' ? 'black' : 'white';
            
            // Check game over
            checkGameOver();
            
            // Auto AI move if in AI mode and it's AI's turn
            if (playMode === 'ai' && !gameOver && currentTurn !== playerColor) {
                setTimeout(() => playAIMove(), 300);
            }
        }

        function checkGameOver() {
            // Check if current player has any legal moves
            const hasLegalMoves = hasAnyLegalMoves(currentTurn);
            const statusEl = document.getElementById('game-status');
            
            if (!hasLegalMoves) {
                gameOver = true;
                const isWhite = currentTurn === 'white';
                const winner = isWhite ? 'Black' : 'White';
                if (statusEl) {
                    statusEl.textContent = `🏆 ${winner} wins! (Checkmate)`;
                    statusEl.style.color = 'var(--success)';
                }
                updateTurnIndicator();
                return;
            }
            
            // Check for stalemate (no legal moves but not in check)
            // Simplified: if no legal moves, it's stalemate
            if (!hasLegalMoves) {
                gameOver = true;
                if (statusEl) {
                    statusEl.textContent = '🤝 Stalemate!';
                    statusEl.style.color = 'var(--warning)';
                }
                updateTurnIndicator();
            }
        }

        function hasAnyLegalMoves(color) {
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((color === 'white' && isWhite) || (color === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            if (moves.length > 0) return true;
                        }
                    }
                }
            }
            return false;
        }

        // ===== AI =====
        function playAIMove() {
            if (isAIMoving || gameOver || playMode !== 'ai') return;
            isAIMoving = true;
            
            const aiColor = playerColor === 'white' ? 'black' : 'white';
            if (currentTurn !== aiColor) {
                isAIMoving = false;
                return;
            }
            
            // Get all legal moves for AI
            const allMoves = [];
            for (let r = 0; r < 8; r++) {
                for (let c = 0; c < 8; c++) {
                    const piece = board[r][c];
                    if (piece) {
                        const isWhite = piece === piece.toUpperCase();
                        if ((aiColor === 'white' && isWhite) || (aiColor === 'black' && !isWhite)) {
                            const moves = getLegalMoves(r, c);
                            for (const move of moves) {
                                allMoves.push({fromRow: r, fromCol: c, toRow: move.row, toCol: move.col});
                            }
                        }
                    }
                }
            }
            
            if (allMoves.length === 0) {
                isAIMoving = false;
                checkGameOver();
                return;
            }
            
            // Simple AI: random move with some basic evaluation
            const difficulty = document.getElementById('aiDifficulty')?.value || 'medium';
            
            // Score moves
            const scoredMoves = allMoves.map(move => {
                let score = 0;
                const target = board[move.toRow][move.toCol];
                // Capture piece value
                if (target) {
                    const pieceValues = {'p': 1, 'n': 3, 'b': 3, 'r': 5, 'q': 9, 'k': 100};
                    const val = pieceValues[target.toLowerCase()] || 0;
                    score += val * 10;
                }
                // Center control
                const centerDist = Math.abs(move.toRow - 3.5) + Math.abs(move.toCol - 3.5);
                score += (7 - centerDist) * 2;
                // Random factor for variety
                if (difficulty === 'easy') score += Math.random() * 10;
                if (difficulty === 'medium') score += Math.random() * 5;
                if (difficulty === 'hard') score += Math.random() * 2;
                return {move, score};
            });
            
            // Sort by score descending
            scoredMoves.sort((a, b) => b.score - a.score);
            
            // Pick best move (with some randomness based on difficulty)
            let selectedMove;
            if (difficulty === 'easy') {
                const topN = Math.min(5, Math.floor(scoredMoves.length * 0.3) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else if (difficulty === 'medium') {
                const topN = Math.min(3, Math.floor(scoredMoves.length * 0.15) + 1);
                selectedMove = scoredMoves[Math.floor(Math.random() * topN)].move;
            } else {
                selectedMove = scoredMoves[0].move;
            }
            
            // Make the move
            makeMove(selectedMove.fromRow, selectedMove.fromCol, selectedMove.toRow, selectedMove.toCol);
            renderBoard();
            isAIMoving = false;
        }

        // ===== GAME CONTROLS =====
        function startNewGame() {
            board = JSON.parse(JSON.stringify(INITIAL_BOARD));
            currentTurn = 'white';
            moveHistory = [];
            moveCount = 0;
            gameOver = false;
            selectedSquare = null;
            moveList = [];
            isAIMoving = false;
            
            const colorSelect = document.getElementById('playerColor');
            if (colorSelect) {
                const val = colorSelect.value;
                if (val === 'random') {
                    playerColor = Math.random() < 0.5 ? 'white' : 'black';
                } else {
                    playerColor = val;
                }
            }
            
            // If player is black, AI goes first
            if (playMode === 'ai' && playerColor === 'black') {
                setTimeout(() => playAIMove(), 500);
            }
            
            const statusEl = document.getElementById('game-status');
            if (statusEl) {
                statusEl.textContent = 'Game in progress';
                statusEl.style.color = 'var(--gold)';
            }
            const moveCountEl = document.getElementById('move-count');
            if (moveCountEl) moveCountEl.textContent = 'Moves: 0';
            
            renderBoard();
        }

        function resetBoard() {
            startNewGame();
        }

        function flipBoard() {
            isFlipped = !isFlipped;
            renderBoard();
        }

        function undoMove() {
            if (moveHistory.length === 0 || isAIMoving) return;
            const lastMove = moveHistory.pop();
            board = lastMove.previousBoard;
            currentTurn = currentTurn === 'white' ? 'black' : 'white';
            moveCount--;
            selectedSquare = null;
            gameOver = false;
            const statusEl = document.getElementById('game-status');
            if (statusEl) {
                statusEl.textContent = 'Game in progress';
                statusEl.style.color = 'var(--gold)';
            }
            renderBoard();
        }

        function changePlayMode() {
            const mode = document.getElementById('playMode')?.value || 'ai';
            playMode = mode;
            document.getElementById('ai-section').style.display = mode === 'ai' ? 'block' : 'none';
            document.getElementById('online-opponent-section').style.display = mode === 'online' ? 'block' : 'none';
            startNewGame();
        }

        function requestOnlineGame() {
            const opponentId = document.getElementById('opponentSelect')?.value;
            const timeControl = document.getElementById('timeControl')?.value;
            if (!opponentId) {
                alert('Please select an opponent.');
                return;
            }
            // Simulate request
            const form = document.createElement('form');
            form.method = 'POST';
            const fields = {
                'request_game': '1',
                'opponent_id': opponentId,
                'time_control': timeControl,
                'color': 'random'
            };
            for (const [key, value] of Object.entries(fields)) {
                const input = document.createElement('input');
                input.type = 'hidden';
                input.name = key;
                input.value = value;
                form.appendChild(input);
            }
            document.body.appendChild(form);
            form.submit();
        }

        // ===== OVERSIGHT =====
        function loadOversightGame(gameId) {
            gameOverseeId = gameId;
            const container = document.getElementById('overseeBoardContainer');
            const idDisplay = document.getElementById('oversee-game-id');
            if (idDisplay) idDisplay.textContent = `Game #${gameId}`;
            
            // Simulate loading game state
            container.innerHTML = `
                <div style="display:flex;gap:1rem;flex-wrap:wrap;">
                    <div style="flex:1;min-width:200px;">
                        <div class="game-status-bar">
                            <span class="player"><i class="fas fa-circle" style="color:#f0d9b5;"></i> White</span>
                            <span class="move-info">Move 12</span>
                        </div>
                        <div style="display:grid;grid-template-columns:repeat(8,1fr);max-width:300px;aspect-ratio:1;border:2px solid var(--secondary);border-radius:4px;margin:0 auto;">
                            ${Array.from({length:64}, (_, i) => {
                                const row = Math.floor(i/8), col = i%8;
                                const isLight = (row+col)%2===0;
                                const piece = (row+col)%3===0 ? (Math.random()>0.5 ? '♙' : '♟') : '';
                                return `<div class="square ${isLight?'light':'dark'}" style="display:flex;align-items:center;justify-content:center;font-size:1.5rem;color:${isLight?'#1a1a1a':'#f0d9b5'};">${piece}</div>`;
                            }).join('')}
                        </div>
                    </div>
                    <div style="flex:1;min-width:150px;">
                        <div style="background:rgba(255,255,255,0.03);padding:0.8rem;border-radius:0.5rem;margin-bottom:0.5rem;">
                            <div style="display:flex;justify-content:space-between;font-size:0.85rem;">
                                <span>⏱️ White</span>
                                <span style="color:var(--gold);">12:34</span>
                            </div>
                            <div style="display:flex;justify-content:space-between;font-size:0.85rem;margin-top:0.2rem;">
                                <span>⏱️ Black</span>
                                <span style="color:var(--gold);">15:21</span>
                            </div>
                        </div>
                        <div style="max-height:200px;overflow-y:auto;font-size:0.8rem;color:#7a6a5a;">
                            ${Array.from({length:12}, (_, i) => 
                                `<div style="padding:0.2rem 0;border-bottom:1px solid rgba(255,255,255,0.03);">
                                    ${i+1}. ${String.fromCharCode(97 + (i%8))}${8 - (i%8)} ${String.fromCharCode(97 + ((i+3)%8))}${8 - ((i+5)%8)}
                                </div>`
                            ).join('')}
                        </div>
                    </div>
                </div>
                <div style="margin-top:0.8rem;padding-top:0.8rem;border-top:1px solid var(--border-color);display:flex;gap:0.5rem;flex-wrap:wrap;">
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-play"></i> Play
                    </button>
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-pause"></i> Pause
                    </button>
                    <button class="btn btn-secondary" style="font-size:0.75rem;padding:0.3rem 0.8rem;">
                        <i class="fas fa-step-forward"></i> Forward
                    </button>
                    <span style="color:#5a4a3a;font-size:0.75rem;display:flex;align-items:center;margin-left:auto;">
                        <i class="fas fa-eye" style="color:var(--gold);margin-right:0.3rem;"></i> Overseeing in real-time
                    </span>
                </div>
            `;
        }

        // ===== INITIALIZATION =====
        document.addEventListener('DOMContentLoaded', function() {
            // Initialize chess board
            renderBoard();
            
            // Check if overseeing a game
            const overseeMessage = document.querySelector('#tab-oversee .message');
            if (overseeMessage && overseeMessage.textContent.includes('overseeing game')) {
                const gameId = parseInt(overseeMessage.textContent.match(/#(\d+)/)?.[1] || 101);
                loadOversightGame(gameId);
            }
            
            // Auto-start AI game if in play tab
            if (document.getElementById('tab-play')?.classList.contains('active')) {
                // Check if we're not already in a game
                const hasPieces = board.some(row => row.some(cell => cell !== ''));
                if (hasPieces) {
                    // If player is black, trigger AI move
                    if (playMode === 'ai' && playerColor === 'black' && currentTurn === 'black') {
                        setTimeout(() => playAIMove(), 500);
                    }
                }
            }
        });

        // Override for oversight form submission
        document.querySelectorAll('form input[name="oversee_game"]').forEach(input => {
            const form = input.closest('form');
            if (form) {
                form.addEventListener('submit', function(e) {
                    e.preventDefault();
                    const gameId = parseInt(this.querySelector('input[name="game_id"]')?.value || 101);
                    loadOversightGame(gameId);
                    // Update URL to show we're overseeing
                    if (window.history && window.history.pushState) {
                        window.history.pushState({}, '', '?tab=oversee&game=' + gameId);
                    }
                });
            }
        });
    </script>
</body>
</html>